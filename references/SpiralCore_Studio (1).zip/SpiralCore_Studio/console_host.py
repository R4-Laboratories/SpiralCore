"""Cooperative Python programs on the SpiralCore machine and block card."""
import base64
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import shlex
import sys
import types
import uuid

import spiralcore_kernel as kernel
from console_builtin_sources import SOURCES
from continuity import WorkRecord

CONSOLE_BUDGET = 32768


def serializable(value):
    return json.loads(json.dumps(value, allow_nan=False, separators=(",", ":")))


class ProgramAPI:
    def __init__(self, manager, pid):
        self._manager, self.pid = manager, pid

    def clock(self):
        r = self._manager.runtime
        return {"N": r.N, "loop_tick": r.loop_tick, "loops": r.completed_loops,
                "time_s": r.kuramoto_strata_time, "R": r.kuramoto_R,
                "phases": list(r.phases), "phase_rad": r.clock}

    def carry(self):
        r = self._manager.runtime
        return {"roots": len(r.roots), "contributions": sum(x["memory_count"] for x in r.roots),
                "v3": kernel.valuation_3(r.N) if r.N else 0,
                "values": [x["value"] for x in r.roots]}

    def traffic(self):
        r = self._manager.runtime
        row = list(r.ca184_history[-1])
        last = r.router.vsocket_log[-1] if r.router.vsocket_log else {}
        return {"row": row, "counterfactual": list(r.ca184_cf_history[-1]),
                "particles": sum(row), "flux": sum(a == 1 and row[(i + 1) % len(row)] == 0 for i, a in enumerate(row)),
                "bell_pair": list(last.get("bell_2of6_fwd_hz", [700, 900])),
                "address": last.get("dst_ipv4", r.router.local_ipv4)}

    def publish(self, topic, payload):
        message = serializable({"from": self.pid, "topic": str(topic), "payload": payload,
                                "N": self._manager.runtime.N})
        if len(json.dumps(message).encode()) > 2048 or len(self._manager.outbox) >= 32:
            raise ValueError("Program message queue is full or message exceeds 2 KiB")
        self._manager.outbox.append(message)

    def receive(self, topic=None):
        app = self._manager.apps[self.pid]
        take = [m for m in app["mailbox"] if topic is None or m["topic"] == topic]
        app["mailbox"] = [m for m in app["mailbox"] if topic is not None and m["topic"] != topic]
        return copy.deepcopy(take)

    def write_file(self, filename, data):
        if isinstance(data, str):
            data = data.encode("utf-8")
        if not isinstance(data, bytes):
            raise TypeError("write_file accepts bytes or text")
        name = self.pid + "__" + Path(filename).name
        result = self._manager.runtime.memory_card.store_compressed_file(name, data, {})
        self._manager.note(f"{self.pid}: wrote {Path(filename).name} ({len(data):,} bytes)")
        return result["vpath"]

    def read_file(self, filename):
        name = self.pid + "__" + Path(filename).name
        return self._manager.runtime.memory_card.retrieve_compressed_file(name)[0]

    def record_tone(self, pair=None):
        r = self._manager.runtime
        r.audio.record_step_tone(pair or self.traffic()["bell_pair"], r.kuramoto_R)

    def log(self, text):
        self._manager.note(f"{self.pid}: {str(text)[:180]}")


class ProgramManager:
    def __init__(self, runtime):
        self.runtime = runtime
        self.apps = {}
        self.outbox = []
        self.events = []
        self.revision = 0
        self.last_tick = runtime.N

    def note(self, text):
        self.events.append({"N": self.runtime.N, "text": str(text)[:220]})
        self.events = self.events[-48:]
        self.revision += 1

    def _module(self, source, filename):
        module = types.ModuleType("spiral_program_" + hashlib.sha256(source.encode()).hexdigest()[:12])
        module.__file__ = filename
        sys.modules[module.__name__] = module
        exec(compile(source, filename, "exec"), module.__dict__)
        if not isinstance(getattr(module, "METADATA", None), dict) or not callable(getattr(module, "tick", None)):
            raise ValueError("Program requires METADATA and tick(api, state)")
        return module

    def install(self, source, filename="program.py"):
        module = self._module(source, filename)
        meta = serializable(module.METADATA)
        pid = str(meta.get("id", Path(filename).stem))
        if not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_-]{0,31}", pid):
            raise ValueError("Program id: 1–32 letters, numbers, underscores or hyphens; first character must be a letter")
        if pid in self.apps:
            raise ValueError(f"Program '{pid}' is already installed")
        period = int(meta.get("period", 1))
        if not 1 <= period <= 10000:
            raise ValueError("Program period must be 1..10000 ticks")
        digest = hashlib.sha256(source.encode()).hexdigest()
        app = {"id": pid, "name": str(meta.get("name", pid)), "description": str(meta.get("description", "")),
               "period": period, "subscriptions": list(meta.get("subscriptions", [])),
               "actions": list(meta.get("actions", [])), "state": {}, "mailbox": [],
               "running": True, "ticks": 0, "error": None,
               "source_sha256": digest, "source_file": f"program_{digest[:16]}.py", "module": module}
        self.apps[pid] = app
        try:
            app["state"] = serializable(module.init(ProgramAPI(self, pid)) if callable(getattr(module, "init", None)) else {})
            self.check_budget()
            self.runtime.memory_card.store_compressed_file(app["source_file"], source.encode(), {})
        except Exception:
            del self.apps[pid]
            raise
        self.note(f"Loaded {app['name']}")
        return pid

    def check_budget(self):
        if len(kernel._json_bytes(self.snapshot())) > CONSOLE_BUDGET:
            raise ValueError("Program state exceeds the console's 32 KiB checkpoint allowance; store bulk data with write_file")

    def snapshot(self):
        return {"apps": [{k: copy.deepcopy(v) for k, v in app.items() if k != "module"}
                          for app in self.apps.values()], "outbox": copy.deepcopy(self.outbox),
                "events": copy.deepcopy(self.events), "revision": self.revision, "last_tick": self.last_tick}

    def restore(self, value):
        self.apps = {}
        for app in value["apps"]:
            app = copy.deepcopy(app)
            source = self.runtime.memory_card.retrieve_compressed_file(app["source_file"])[0]
            if hashlib.sha256(source).hexdigest() != app["source_sha256"]:
                raise ValueError("Program source checksum mismatch")
            app["module"] = self._module(source.decode(), app["source_file"])
            self.apps[app["id"]] = app
        self.outbox = copy.deepcopy(value["outbox"])
        self.events = copy.deepcopy(value["events"])
        self.revision = value["revision"]
        self.last_tick = value["last_tick"]
        self.check_budget()

    def _invoke(self, app, method, *args):
        callback = getattr(app["module"], method, None)
        if not callable(callback):
            return
        before_state, before_mailbox, before_outbox = copy.deepcopy(app["state"]), copy.deepcopy(app["mailbox"]), copy.deepcopy(self.outbox)
        try:
            callback(ProgramAPI(self, app["id"]), app["state"], *args)
            app["state"] = serializable(app["state"])
            self.check_budget()
            self.revision += 1
        except Exception as exc:
            app["state"], app["mailbox"], self.outbox = before_state, before_mailbox, before_outbox
            app["running"] = False
            app["error"] = f"{type(exc).__name__}: {exc}"
            self.note(f"{app['name']} paused: {app['error']}")

    def tick_once(self):
        if self.last_tick == self.runtime.N:
            return
        self.last_tick = self.runtime.N
        pending, self.outbox = self.outbox, []
        for message in pending:
            for app in self.apps.values():
                if message["topic"] in app["subscriptions"]:
                    if len(app["mailbox"]) >= 32:
                        app["running"], app["error"] = False, "Message inbox is full; consume messages with receive()"
                    else:
                        app["mailbox"].append(copy.deepcopy(message))
        for app in self.apps.values():
            if app["running"] and self.runtime.N % app["period"] == 0:
                self._invoke(app, "tick")
                app["ticks"] += 1

    def action(self, pid, event):
        app = self.apps[pid]
        self._invoke(app, "handle", serializable(event))
        if not app["error"]:
            self.note(f"{app['name']}: {event.get('action', 'event')}")


class ConsoleRuntime(kernel.SpiralcoreRuntime):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.programs = ProgramManager(self)
        self.foreground = "runner"
        self.branch_parent = None
        self.last_saved_revision = None
        self.work = WorkRecord(self)

    def install_builtins(self):
        for filename, source in SOURCES.items():
            self.programs.install(source, filename)

    @property
    def dirty(self):
        return self.N != self.last_saved_N or self.programs.revision != self.last_saved_revision or self.work.dirty

    def _snapshot(self):
        result = super()._snapshot()
        result["console"] = {"version": 1, "programs": self.programs.snapshot(),
                             "foreground": self.foreground, "branch_parent": self.branch_parent}
        result["console"]["work"] = self.work.prepare_anchor()
        return result

    def _close_loop(self, filepath=None):
        # Programs see the completed tick BEFORE its automatic checkpoint.
        self.programs.tick_once()
        return super()._close_loop(filepath)

    def step(self, payload_value=1.0, label=""):
        result = super().step(payload_value, label)
        if not result.get("blocked"):
            self.programs.tick_once()
        return result

    def save_checkpoint(self, filepath=None):
        self.programs.check_budget()
        self.memory_card.tree["paths"]["/sys/programs"] = {
            p: {"name": a["name"], "running": a["running"], "ticks": a["ticks"], "source_sha256": a["source_sha256"]}
            for p, a in self.programs.apps.items()}
        result = super().save_checkpoint(filepath)
        self.last_saved_revision = self.programs.revision
        self.work.saved_revision = self.work.record["revision"]
        return result

    def load_checkpoint(self, filepath):
        candidate = type(self)()
        result = kernel.SpiralcoreRuntime.load_checkpoint(candidate, filepath)
        _, saved, _ = kernel.unpack_checkpoint(candidate.memory_card._resume_block)
        console = saved.get("console")
        if not console or console.get("version") != 1:
            raise ValueError("This card has no console program state; open it with the earlier loop runtime")
        candidate.programs = ProgramManager(candidate)
        candidate.programs.restore(console["programs"])
        candidate.foreground = console["foreground"]
        candidate.branch_parent = console["branch_parent"]
        candidate.last_saved_revision = candidate.programs.revision
        candidate.work = WorkRecord.restore(candidate, console["work"]) if console.get("work") else WorkRecord(candidate)
        self.__dict__.clear()
        self.__dict__.update(candidate.__dict__)
        self.programs.runtime = self
        self.work.runtime = self
        return result

    def fork_card(self, filepath=None):
        if self.dirty:
            self.save_checkpoint()
        parent = {"card": Path(self.autosave_path).name, "run_id": self.run_id, "N": self.N}
        self.work.revise({"parent": {**parent, "task_revision": self.work.record["revision"]}}, "Create a separate task continuation")
        self.run_id = uuid.uuid4().hex
        self.branch_parent = parent
        target = filepath or self._new_card_path(Path(self.autosave_path).parent)
        self.programs.note(f"Branched from tick {self.N}")
        return self.save_checkpoint(target)

    def new_session(self):
        if self.dirty:
            self.save_checkpoint()
        sources = [(a["source_file"], self.memory_card.retrieve_compressed_file(a["source_file"])[0].decode())
                   for a in self.programs.apps.values()]
        directory = Path(self.autosave_path).parent
        fresh = type(self)(fixed_dt=self.fixed_dt)
        fresh.autosave_path = fresh._new_card_path(directory)
        fresh.step_interval_sec = self.step_interval_sec
        for filename, source in sources:
            fresh.programs.install(source, filename)
        fresh.foreground = self.foreground if self.foreground in fresh.programs.apps else next(iter(fresh.programs.apps), "")
        self.__dict__.clear()
        self.__dict__.update(fresh.__dict__)
        self.programs.runtime = self
        self.work.runtime = self

    def shell(self, command):
        args = shlex.split(command)
        if not args:
            return ""
        verb = args[0].lower().lstrip("/")
        if verb == "work":
            return json.dumps(self.work.overview(), indent=2)
        if verb in ("help", "information"):
            return ("/programs · /load <file.py> · /run <id> · /pause <id> · /event <id> <action>\n"
                    "/checkpoint [card.spmc] · /restore <card.spmc> · /fork [card.spmc] · /new\n"
                    "/pause and /resume control the whole machine. Kernel commands remain available.\n"
                    "Programs share clock(), carry(), traffic(), publish()/receive(), write_file()/read_file(), and record_tone().")
        if verb == "programs":
            return json.dumps([{k: a[k] for k in ("id", "name", "running", "ticks", "error")} for a in self.programs.apps.values()], indent=2)
        if verb == "load":
            path = Path(" ".join(args[1:]))
            return "Loaded " + self.programs.install(path.read_text(), path.name)
        if verb in ("run", "pause") and len(args) == 2:
            a = self.programs.apps[args[1]]
            a["running"] = verb == "run"
            a["error"] = None
            self.programs.note(f"{a['name']}: {'running' if a['running'] else 'paused'}")
            return self.programs.events[-1]["text"]
        if verb == "event" and len(args) >= 3:
            self.programs.action(args[1], {"action": args[2], "text": " ".join(args[3:])})
            return self.programs.events[-1]["text"]
        if verb in ("checkpoint", "savecard"):
            return json.dumps(self.save_checkpoint(" ".join(args[1:]) or None), indent=2)
        if verb in ("restore", "loadcard"):
            return json.dumps(self.load_checkpoint(" ".join(args[1:])), indent=2)
        if verb == "fork":
            return json.dumps(self.fork_card(" ".join(args[1:]) or None), indent=2)
        if verb in ("new", "reset"):
            self.new_session()
            return "New machine; installed programs retained; previous card saved"
        return json.dumps(self.execute_command(command), indent=2)
