"""Build the self-contained native Studio from readable standard-library modules."""
from pathlib import Path


def build():
    root=Path(__file__).resolve().parent
    sources={p.name:p.read_text(encoding='utf-8') for p in sorted((root/'programs').glob('*.py'))}
    starter=sources['starter_counter.py']
    (root/'console_builtin_sources.py').write_text('SOURCES = '+repr(sources)+'\nSTARTER = '+repr(starter)+'\n',encoding='utf-8')
    bootstrap='''#!/usr/bin/env python3
"""SpiralCore Studio. Run this file in the existing Tkinter/Pydroid3 environment.
Standard library only; --demo OUTPUT runs the headless integration demonstration.
Embedded modules have readable counterparts in the complete source package.
"""
import sys as _sys
import types as _types
from pathlib import Path as _Path

def _load_module(name,source):
    module=_types.ModuleType(name)
    module.__file__=str(_Path(__file__).resolve().parent/(name+'.py'))
    _sys.modules[name]=module
    exec(compile(source,module.__file__,'exec'),module.__dict__)

'''
    for module in ('spiralcore_kernel','console_builtin_sources','catalog','manual','continuity','console_host','studio_runtime','launcher','work_ui','studio_demo'):
        bootstrap+='_load_module('+repr(module)+','+repr((root/(module+'.py')).read_text(encoding='utf-8'))+')\n\n'
    bootstrap+=(root/'console_ui.py').read_text(encoding='utf-8')
    target=root/'SpiralCore_Studio.py';target.write_text(bootstrap,encoding='utf-8')
    print(f'Built {target} ({target.stat().st_size:,} bytes)')

if __name__=='__main__':build()
