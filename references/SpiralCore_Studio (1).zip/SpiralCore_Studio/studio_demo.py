"""Exercise the actual launcher, callbacks and card format without a display."""
import copy
import hashlib
import json
from pathlib import Path
from studio_runtime import StudioRuntime
from launcher import Launcher
from manual import help_text
from console_host import kernel


def run_demo(directory):
    directory=Path(directory).resolve()
    directory.mkdir(parents=True,exist_ok=True)
    if (directory/'saves'/'sessions.json').exists():
        raise ValueError('Choose a new demonstration directory so existing cards remain unchanged')
    r=StudioRuntime();desk=Launcher(r,directory/'saves');desk.startup()
    r.fixed_dt=0.1
    def step(count):
        for _ in range(count):
            r.step(label='STUDIO_DEMO')
            assert r.telemetry_snapshot()['ca184']['conserved']
            assert all(a['error'] is None for a in r.programs.apps.values()),[(a['id'],a['error']) for a in r.programs.apps.values()]
    def state():
        return copy.deepcopy({'N':r.N,'phases':r.phases,'roots':r.roots,'ca':list(r.ca184_history),'cf':list(r.ca184_cf_history),
                              'outbox':r.programs.outbox,'apps':{p:{k:a[k] for k in ('state','mailbox','ticks')} for p,a in r.programs.apps.items()}})
    desk.run('runner');r.programs.action('runner',{'action':'right'});r.programs.action('runner',{'action':'pulse'})
    r.programs.action('runner',{'action':'auto'});step(90)
    flight=state();desk.save(directory/'Flight_Midway.spmc')
    observation=state()
    for command in ('/help memory','/help programming','/telemetry','/files','/source runner'):
        assert desk.execute(command)['output']
    assert state()==observation,'Observation changed execution'
    desk.run('atlas');r.fixed_dt=0.1
    for _ in range(500):
        step(1)
        if len(r.programs.apps['dispatch']['state']['done'])==192:break
    step(3)
    assert len(r.programs.apps['dispatch']['state']['done'])==192
    raw,check=r.memory_card.retrieve_compressed_file(r.programs.apps['atlas']['state']['last_export'])
    (directory/'Mandelbrot.png').write_bytes(raw)
    compute_tick=r.N;desk.save(directory/'Render_Complete.spmc')
    desk.run('runner');assert state()==flight,'Workspace return changed saved flight'
    r.programs.action('runner',{'action':'auto'}) if not r.programs.apps['runner']['state']['auto'] else None
    step(10);after=state();desk.save();card=r.autosave_path
    clone=StudioRuntime();clone.load_checkpoint(card)
    assert clone.N==r.N and clone.programs.snapshot()==r.programs.snapshot()
    assert clone.phases==r.phases and list(clone.ca184_history)==list(r.ca184_history)
    assert not clone.auto_step_enabled
    # Upload data and load source have deliberately different effects.
    source='METADATA={"id":"upload_probe","name":"Upload probe"}\ndef init(api):return {"count":0}\ndef tick(api,state):state["count"]+=1\n'
    path=directory/'my data program.py';path.write_text(source,encoding='utf-8')
    before=r.N;desk.execute('/upload '+json.dumps(str(path)))
    assert r.N==before+1 and 'upload_probe' not in r.programs.apps
    decoded,verification=r.memory_card.retrieve_compressed_file(path.name);assert decoded==path.read_bytes()
    for invalid in (path,directory/'Flight_Midway.spmc'):
        try:r.data_upload(invalid)
        except (ValueError,FileExistsError):pass
        else:raise AssertionError('Ambiguous/duplicate upload was accepted')
    before=r.N;desk.execute('/load '+json.dumps(str(path)))
    assert r.N==before and r.programs.apps['upload_probe']['state']['count']==0
    r.run_program('upload_probe');step(1);assert r.programs.apps['upload_probe']['state']['count']==1
    desk.save(directory/'Flight_With_Custom_Program.spmc')
    desk.run('courier');r.fixed_dt=0.1;step(180)
    ledger=r.programs.apps['ledger']['state'];assert ledger['verified']>=8 and ledger['failed']==0
    r.programs.action('ledger',{'action':'commit'});r.programs.action('loom',{'action':'export'})
    for name in ('ledger__delivery_ledger.csv','loom__phase_loom.svg'):
        data,_=r.memory_card.retrieve_compressed_file(name);(directory/Path(name).name).write_bytes(data)
    verified=ledger['verified'];desk.save(directory/'Signals.spmc')
    desk.run('counter');r.fixed_dt=0.1;step(4);r.programs.action('counter',{'action':'add'})
    assert r.programs.apps['counter']['state']['count']==104
    desk.save();restarted=StudioRuntime();new_desk=Launcher(restarted,directory/'saves');new_desk.startup()
    assert restarted.programs.apps['counter']['state']['count']==104 and not restarted.auto_step_enabled
    old_card=r.autosave_path;desk.new_session()
    assert r.N==0 and r.programs.apps['counter']['state']['count']==0
    assert old_card!=r.autosave_path and Path(old_card).is_file()
    # Compare live machinery against the identical, separately executed kernel.
    reference=kernel.SpiralcoreRuntime(fixed_dt=0.1)
    r.fixed_dt=0.1
    for key in kernel.SpiralcoreRuntime.STATE_FIELDS:setattr(reference,key,copy.deepcopy(getattr(r,key)))
    reference.router=copy.deepcopy(r.router);reference.audio=copy.deepcopy(r.audio)
    for _ in range(81):
        r.step(1.25,label='MATH_EQUIVALENCE');reference.step(1.25,label='MATH_EQUIVALENCE')
        for key in ('N','clock','phases','active_roots','kuramoto_R','ca184_history','ca184_cf_history','ca110_history','ca30_history'):
            assert getattr(r,key)==getattr(reference,key),key
    report={'passed':True,'native_ui_test':'separate GUI observation','workspaces':list(desk.paths),
            'flight_resume_tick':flight['N'],'render_tiles':192,'render_tick':compute_tick,'verified_deliveries':verified,
            'data_upload_steps':1,'load_python_steps':0,'counter_before_restart':104,
            'observations_added_ticks':0,'card_bytes':8388608,'math_equivalence_steps':81,
            'checks':['flight/card/queue restoration','render switching and PNG','signals CSV/SVG','counter restart',
                      'new session keeps old card','data upload byte verification','duplicate/card upload rejection',
                      'source install then callback','help/telemetry/source are observational','unchanged kernel dynamics']}
    for path in directory.rglob('*.spmc'):assert path.stat().st_size==8388608
    (directory/'Validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2));return report
