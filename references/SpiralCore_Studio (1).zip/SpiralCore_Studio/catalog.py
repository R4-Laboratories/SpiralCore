"""Discoverable program catalog; workspace groups keep checkpoint budgets separate."""
GROUPS = {
    "arcade": ["runner", "studio", "journal"],
    "signals": ["courier", "ledger", "loom"],
    "compute": ["dispatch", "worker_a", "worker_b", "atlas"],
    "counter": ["counter"],
}
CATALOG = [
    {"id":"runner","name":"Phase Runner","group":"arcade","file":"runner.py","about":"Play: arrows or tap lanes; Space pulses. Run starts or resumes a flight."},
    {"id":"studio","name":"Bell Studio","group":"arcade","file":"studio.py","about":"Flight events become a score. Export a WAV or a lower-octave remix."},
    {"id":"journal","name":"Flight Journal","group":"arcade","file":"journal.py","about":"Inspect the game's input/event journal and export JSON."},
    {"id":"courier","name":"Signal Courier","group":"signals","file":"courier.py","about":"Messages ride Rule 184 traffic and reach the Delivery Ledger."},
    {"id":"ledger","name":"Delivery Ledger","group":"signals","file":"ledger.py","about":"Verify received payload hashes and export a CSV journal."},
    {"id":"loom","name":"Phase Loom","group":"signals","file":"loom.py","about":"Live phase/CA drawing. Change the palette and export an SVG."},
    {"id":"atlas","name":"Render Canvas","group":"compute","file":"atlas.py","about":"Watch a 384 × 256 Mandelbrot render and export/recolor its PNG."},
    {"id":"dispatch","name":"Workshop Dispatch","group":"compute","file":"dispatch.py","about":"Inspect tile jobs, worker selection, completion and lease retries."},
    {"id":"worker_a","name":"Compute Worker A","group":"compute","file":"worker_a.py","about":"A cooperative tile worker. Pause it to exercise lease recovery."},
    {"id":"worker_b","name":"Compute Worker B","group":"compute","file":"worker_b.py","about":"The second cooperative worker shares the compute workspace."},
    {"id":"counter","name":"My Counter","group":"counter","file":"starter_counter.py","about":"A minimal editable program with persistent JSON state."},
]
BY_ID = {item["id"]: item for item in CATALOG}


def resolve(value):
    if value in BY_ID:
        return value
    for item in CATALOG:
        if item["name"].casefold() == str(value).casefold():
            return item["id"]
    return value


def group_for_apps(apps):
    ids = set(apps)
    for group, members in GROUPS.items():
        if ids == set(members):
            return group
    return "custom"
