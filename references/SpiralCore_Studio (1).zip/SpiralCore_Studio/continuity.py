"""Explicit task continuity tied to a saved execution, with verifiable evidence."""
import copy
import hashlib
import json
from pathlib import Path
import uuid

VERSION = 1
RECORD_FILE = "continuity_record.json"
MAX_BYTES = 65536


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def execution_digest(runtime):
    import spiralcore_kernel as kernel
    state = kernel.SpiralcoreRuntime._snapshot(runtime)
    # Save/load changes this display string; it has no effect on execution.
    state["runtime"].pop("last_command_banner", None)
    state["programs"] = runtime.programs.snapshot()
    return digest(kernel._encode_state(state))


def empty_record():
    return {"schema": VERSION, "task_id": uuid.uuid4().hex, "revision": 0,
            "title": "Untitled work", "objective": "", "constraints": [], "decisions": [],
            "claims": [], "evidence": [], "questions": [], "status": "draft",
            "next_action": {"kind": "inspect"}, "deliverables": [], "acceptance": [], "history": [], "parent": None}


def validate(record):
    if not isinstance(record, dict) or record.get("schema") != VERSION:
        raise ValueError("Unsupported task record")
    if not isinstance(record.get("task_id"), str) or not isinstance(record.get("revision"), int):
        raise ValueError("Task identity and revision are required")
    for key in ("title", "objective", "status"):
        if not isinstance(record.get(key), str):
            raise ValueError(f"Task {key} must be text")
    for key in ("constraints", "decisions", "claims", "evidence", "questions", "history", "deliverables", "acceptance"):
        if not isinstance(record.get(key), list):
            raise ValueError(f"Task {key} must be a list")
    if not isinstance(record.get("next_action"), dict):
        raise ValueError("Next action must be an object")
    if record["status"] not in ("draft", "ready", "running", "complete", "blocked"):
        raise ValueError("Invalid task status")
    for item in record["evidence"]:
        if not all(k in item for k in ("id", "path", "sha256", "bytes", "description")):
            raise ValueError("Incomplete evidence entry")
    ids = {item["id"] for item in record["evidence"]}
    if len(ids) != len(record["evidence"]):
        raise ValueError("Evidence IDs must be unique")
    for item in record["claims"]:
        if (not isinstance(item, dict) or item.get("kind") not in ("observed", "reported", "hypothesis")
                or not isinstance(item.get("text"), str) or not isinstance(item.get("evidence"), list)
                or any(ref not in ids for ref in item["evidence"])):
            raise ValueError("Claims need an observed/reported/hypothesis kind, text and valid evidence references")
    reserved = {"Handoff.spmc", "Resume_Here.md", "Task_Record.json", "Handoff_Manifest.json", "Continuation_Result.json"}
    for item in record["deliverables"]:
        name = item.get("filename", "")
        if not name or Path(name).name != name or name in reserved or not isinstance(item.get("path"), str):
            raise ValueError("Deliverables need a card path and a plain, non-reserved output filename")
    if len(encoded(record)) > MAX_BYTES:
        raise ValueError("Task record exceeds 64 KiB; move detailed material into evidence files")


class WorkRecord:
    def __init__(self, runtime, record=None, saved_revision=None):
        self.runtime = runtime
        self.record = copy.deepcopy(record or empty_record())
        validate(self.record)
        self.saved_revision = saved_revision
        self.last_anchor = None
        self.last_validation = None

    @property
    def dirty(self):
        return self.saved_revision != self.record["revision"]

    def revise(self, changes, reason):
        allowed = {"title", "objective", "constraints", "decisions", "claims", "evidence",
                   "questions", "status", "next_action", "parent", "deliverables", "acceptance"}
        if not set(changes) <= allowed or not str(reason).strip():
            raise ValueError("A revision requires supported fields and a reason")
        candidate = copy.deepcopy(self.record)
        changed = {k: {"before": copy.deepcopy(candidate[k]), "after": copy.deepcopy(v)}
                   for k, v in changes.items() if candidate[k] != v}
        if not changed:
            return self.record["revision"]
        candidate.update(copy.deepcopy(changes))
        candidate["revision"] += 1
        candidate["history"].append({"revision": candidate["revision"], "N": self.runtime.N,
                                     "reason": str(reason), "changes": changed})
        validate(candidate)
        self.record = candidate
        return candidate["revision"]

    def add_evidence(self, path, description):
        raw, _ = self.runtime.memory_card.retrieve_compressed_file(path)
        vpath = path if path.startswith("/user/files/") else "/user/files/" + path
        item = {"id": "e" + str(len(self.record["evidence"]) + 1), "path": vpath,
                "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw), "description": str(description)}
        self.revise({"evidence": self.record["evidence"] + [item]}, "Attach evidence bytes from the card")
        return item["id"]

    def evidence_report(self):
        results = []
        for item in self.record["evidence"]:
            try:
                raw, _ = self.runtime.memory_card.retrieve_compressed_file(item["path"])
                actual = hashlib.sha256(raw).hexdigest()
                status = "verified" if actual == item["sha256"] and len(raw) == item["bytes"] else "changed"
            except KeyError:
                actual, status = None, "missing"
            results.append({"id": item["id"], "path": item["path"], "status": status,
                            "expected_sha256": item["sha256"], "actual_sha256": actual})
        return results

    def prepare_anchor(self):
        validate(self.record)
        raw = encoded(self.record)
        self.runtime.memory_card.store_compressed_file(RECORD_FILE, raw, {})
        anchor = {"schema": VERSION, "record_path": "/user/files/" + RECORD_FILE,
                  "task_id": self.record["task_id"], "revision": self.record["revision"],
                  "record_sha256": hashlib.sha256(raw).hexdigest(),
                  "execution_sha256": execution_digest(self.runtime), "N": self.runtime.N,
                  "run_id": self.runtime.run_id}
        self.last_anchor = anchor
        return copy.deepcopy(anchor)

    @classmethod
    def restore(cls, runtime, anchor):
        if anchor.get("schema") != VERSION:
            raise ValueError("Unsupported continuity anchor")
        raw, _ = runtime.memory_card.retrieve_compressed_file(anchor["record_path"])
        if hashlib.sha256(raw).hexdigest() != anchor["record_sha256"]:
            raise ValueError("Task record checksum does not match its checkpoint")
        record = json.loads(raw)
        validate(record)
        if (record["task_id"] != anchor["task_id"] or record["revision"] != anchor["revision"]
                or runtime.N != anchor["N"] or runtime.run_id != anchor["run_id"]):
            raise ValueError("Task identity, revision or machine checkpoint mismatch")
        if execution_digest(runtime) != anchor["execution_sha256"]:
            raise ValueError("Task record is bound to different execution state")
        obj = cls(runtime, record, record["revision"])
        obj.last_anchor = copy.deepcopy(anchor)
        evidence = obj.evidence_report()
        obj.last_validation = {"record_hash": "verified", "execution_binding": "verified", "evidence": evidence,
                               "ready": all(e["status"] == "verified" for e in evidence)}
        return obj

    def overview(self):
        return {"task_id": self.record["task_id"], "title": self.record["title"],
                "objective": self.record["objective"], "status": self.record["status"],
                "revision": self.record["revision"], "machine_N": self.runtime.N,
                "saved_binding_matches_current_execution": bool(self.last_anchor and
                      execution_digest(self.runtime) == self.last_anchor["execution_sha256"]),
                "evidence": self.evidence_report(), "next_action": copy.deepcopy(self.record["next_action"]),
                "last_load_validation": self.last_validation}

    def brief(self):
        r = self.record
        lines = ["# Resume this SpiralCore task", "", r["title"], "", "## Objective", "", r["objective"],
                 "", f"Task `{r['task_id']}` · revision {r['revision']} · status {r['status']}",
                 f"Machine tick {self.runtime.N}; run `{self.runtime.run_id}`.", "",
                 "## Constraints", ""]
        lines += ["- " + str(c) for c in r["constraints"]] or ["No constraints recorded."]
        lines += ["", "## Decisions", ""]
        lines += ["- " + str(d) for d in r["decisions"]] or ["No decisions recorded."]
        lines += ["", "## Claims and their status", ""]
        for c in r["claims"]:
            lines.append(f"- [{c.get('kind', 'reported')}] {c.get('text', '')} · evidence {c.get('evidence', [])}")
        lines += ["", "## Open questions", ""]
        lines += ["- " + str(q) for q in r["questions"]] or ["No open questions recorded."]
        lines += ["", "## Next action", "", "```json", json.dumps(r["next_action"], indent=2), "```",
                  "", "## Evidence files", ""]
        for e, result in zip(r["evidence"], self.evidence_report()):
            lines += [f"- {e['id']}: `{e['path']}` — {e['description']}",
                      f"  SHA-256 `{e['sha256']}`; {e['bytes']} bytes; {result['status']}."]
        lines += ["", "## Continue", "", "Inspect the objective, constraints, claims and evidence before continuing.",
                  "The task record is an explicit external work record. Its claims retain their recorded provenance.",
                  "Run `python3 SpiralCore_Continuity.py --inspect Handoff.spmc` to check the supplied card.",
                  "Run `python3 SpiralCore_Continuity.py --continue-card Handoff.spmc --outdir new_continuation`",
                  "to execute the supported recorded action in a separate card, preserving the input file.",
                  "Use --export-card for a differently named card. GUI Open card restores paused.", ""]
        return "\n".join(lines)

    def export_handoff(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.runtime.save_checkpoint()
        card = Path(self.runtime.autosave_path)
        raw = card.read_bytes()
        target = directory / "Handoff.spmc"
        if target.resolve() != card.resolve():
            if target.exists() and target.read_bytes() != raw:
                raise FileExistsError("Destination Handoff.spmc already contains a different card")
            target.write_bytes(raw)
        # The sidecar hashes the completed card; a card cannot contain its own final hash.
        (directory / "Resume_Here.md").write_text(self.brief())
        (directory / "Task_Record.json").write_text(json.dumps(self.record, indent=2) + "\n")
        manifest = {"format": "SpiralCore task handoff v1", "card": target.name,
                    "card_sha256": hashlib.sha256(raw).hexdigest(), "card_bytes": len(raw),
                    "anchor": self.last_anchor, "evidence": self.evidence_report()}
        (directory / "Handoff_Manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        return manifest

    def check_acceptance(self):
        results = []
        evidence = {e["id"]: e for e in self.record["evidence"]}
        for check in self.record["acceptance"]:
            item = evidence[check["evidence"]]
            raw, _ = self.runtime.memory_card.retrieve_compressed_file(item["path"])
            if hashlib.sha256(raw).hexdigest() != item["sha256"]:
                raise ValueError("Acceptance reference evidence changed")
            expected = json.loads(raw)[check["key"]]
            if check["kind"] == "program_state_equals_evidence":
                actual = self.runtime.programs.apps[check["program"]]["state"]
                passed = actual == expected
            elif check["kind"] == "file_sha256_equals_evidence":
                data, _ = self.runtime.memory_card.retrieve_compressed_file(check["path"])
                passed = hashlib.sha256(data).hexdigest() == expected
            else:
                raise ValueError("Unsupported acceptance check")
            results.append({"check": copy.deepcopy(check), "passed": passed})
        return results

    def collect_deliverables(self, directory):
        directory = Path(directory)
        results = []
        evidence = list(self.record["evidence"])
        for item in self.record["deliverables"]:
            raw, _ = self.runtime.memory_card.retrieve_compressed_file(item["path"])
            sha = hashlib.sha256(raw).hexdigest()
            target = directory / item["filename"]
            if target.exists() and target.read_bytes() != raw:
                raise FileExistsError("An output filename already contains different bytes")
            target.write_bytes(raw)
            if not any(e["path"] == item["path"] and e["sha256"] == sha for e in evidence):
                evidence.append({"id": "e" + str(len(evidence) + 1), "path": item["path"],
                                 "sha256": sha, "bytes": len(raw), "description": "Completed deliverable: " + item["filename"]})
            results.append({"filename": item["filename"], "sha256": sha, "bytes": len(raw)})
        self.revise({"evidence": evidence}, "Collect completed deliverables and retain their evidence hashes")
        return results

    def continue_action(self):
        checks = self.evidence_report()
        if any(e["status"] != "verified" for e in checks):
            raise ValueError("Recorded evidence has changed or is missing; review it before continuation")
        action = copy.deepcopy(self.record["next_action"])
        if action.get("kind") == "inspect":
            return {"executed": False, "message": "Inspection requested; no machine steps performed"}
        if action.get("kind") != "advance_until":
            raise ValueError("Supported actions are inspect and advance_until; task text is not executed as code")
        program, field = action["program"], action["field"]
        limit = action.get("max_ticks", 1000)
        settle = action.get("settle_ticks", 0)
        if (not isinstance(limit, int) or not 1 <= limit <= 10000 or
                not isinstance(settle, int) or not 0 <= settle <= 32):
            raise ValueError("Action limits: 1..10000 ticks, 0..32 settling ticks")
        if program not in self.runtime.programs.apps or field not in self.runtime.programs.apps[program]["state"]:
            raise ValueError("Action references an absent program or state field")
        self.revise({"status": "running"}, "Begin the recorded bounded continuation")
        first_N, ticks = self.runtime.N, 0
        try:
            while self.runtime.programs.apps[program]["state"][field] != action["equals"]:
                if ticks >= limit:
                    raise RuntimeError("Recorded action reached its tick limit")
                result = self.runtime.step(label="TASK_CONTINUATION")
                ticks += 1
                if result.get("blocked"):
                    raise RuntimeError("Machine is complete or waiting for a save retry")
                errors = {p: a["error"] for p, a in self.runtime.programs.apps.items() if a["error"]}
                if errors:
                    raise RuntimeError(str(errors))
            for _ in range(settle):
                result = self.runtime.step(label="TASK_SETTLE")
                if result.get("blocked"):
                    raise RuntimeError("Machine blocked while settling messages")
                errors = {p: a["error"] for p, a in self.runtime.programs.apps.items() if a["error"]}
                if errors:
                    raise RuntimeError(str(errors))
            result = {"executed": True, "first_N": first_N, "last_N": self.runtime.N, "work_ticks": ticks,
                      "settle_ticks": settle, "program": program, "field": field, "value": action["equals"]}
            result["acceptance"] = self.check_acceptance()
            if any(not check["passed"] for check in result["acceptance"]):
                raise RuntimeError("A recorded acceptance check failed")
            self.revise({"status": "complete", "next_action": {"kind": "inspect"}}, "Recorded action completed: " + json.dumps(result, sort_keys=True))
            return result
        except Exception as exc:
            self.revise({"status": "blocked"}, "Continuation stopped: " + str(exc))
            raise


def run_cli(args):
    """Commands available in both the readable modules and the single-file launcher."""
    import shutil
    import os
    from console_host import ConsoleRuntime
    source = Path(args.continue_card or args.inspect or args.export_card).resolve()
    source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
    runtime = ConsoleRuntime()
    runtime.load_checkpoint(str(source))
    if args.inspect:
        result = runtime.work.overview()
        print(json.dumps(result, indent=2))
        return result
    if not args.outdir:
        raise ValueError("--outdir is required for continuation or export")
    out = Path(args.outdir).resolve()
    out.mkdir(parents=True, exist_ok=False)
    failure = None
    if args.export_card:
        target = out / "Handoff.spmc"
        shutil.copyfile(source, target)
        runtime.load_checkpoint(str(target))
        result = {"executed": False, "message": "Exported a separate handoff copy"}
    else:
        runtime.fork_card(str(out / "Handoff.spmc"))
        try:
            result = runtime.work.continue_action()
            if result["executed"]:
                result["deliverables"] = runtime.work.collect_deliverables(out)
                result["process_id"] = os.getpid()
                runtime.memory_card.store_compressed_file("continuity_receipt.json", encoded(result), {})
                receipt = runtime.work.add_evidence("continuity_receipt.json", "Receipt of the recorded action and acceptance comparisons")
                runtime.work.revise({"claims": runtime.work.record["claims"] + [{"kind": "observed",
                                     "text": "Produced the recorded deliverables and passed the recorded acceptance comparisons.",
                                     "evidence": [receipt]}]}, "Record the bounded continuation outcome; preserve the open questions")
        except Exception as exc:
            failure = exc
            runtime.work.revise({"status": "blocked"}, "Continuation/export failure: " + str(exc))
            result = {"executed": False, "error": f"{type(exc).__name__}: {exc}"}
    runtime.save_checkpoint()
    result["handoff"] = runtime.work.export_handoff(out)
    result["source_card_unchanged"] = hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
    if not result["source_card_unchanged"]:
        raise AssertionError("Input card changed during read-only handoff/continuation")
    (out / "Continuation_Result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)
    if failure:
        raise failure
    return result
