"""Native Tkinter studio; the machine kernel remains unchanged."""
import argparse
import json
from pathlib import Path
import shlex
import time
from catalog import CATALOG, BY_ID
from console_host import ProgramAPI
from console_builtin_sources import STARTER
from studio_runtime import StudioRuntime
from launcher import Launcher
from manual import SECTIONS, help_text

BG, PANEL, INK, MUTED, ACCENT = '#090d16', '#111a29', '#edf3ff', '#91a4bf', '#e34c98'


def launch(runtime, desk):
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    root=tk.Tk();root.title('SpiralCore Studio');root.configure(bg=BG)
    root.tk.call('tk','scaling',1.3)
    root.geometry(f'{min(1220,root.winfo_screenwidth()-20)}x{min(880,root.winfo_screenheight()-40)}+0+0')
    root.minsize(480,560)
    font=('DejaVu Sans',10);mono=('DejaVu Sans Mono',10)
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('TNotebook',background=BG,borderwidth=0)
    style.configure('TNotebook.Tab',background='#223047',foreground=INK,padding=(12,8))
    style.map('TNotebook.Tab',background=[('selected',PANEL)],foreground=[('selected','#48c9e3')])
    style.configure('TCombobox',fieldbackground='#223047',background='#223047',foreground=INK,arrowcolor=INK,padding=5)
    style.map('TCombobox',fieldbackground=[('readonly','#223047')],foreground=[('readonly',INK)])
    style.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=INK,rowheight=28,font=font)
    style.configure('Treeview.Heading',background='#223047',foreground=INK,font=font)
    root.option_add('*TCombobox*Listbox.background',PANEL);root.option_add('*TCombobox*Listbox.foreground',INK)
    status=tk.StringVar(value=desk.notice or 'Choose a program and press Run. Phase Runner supports taps and on-screen controls.')
    metrics=tk.StringVar();selected=tk.StringVar();title=tk.StringVar();description=tk.StringVar()
    selected_id=runtime.foreground;action_key=None;focus_mode=False;last_tick=time.monotonic();last_panel=0;last_error=None
    name_to_id={};actions_buttons=[];toolbar_buttons=[];file_buttons=[];file_paths=[]
    history=[];history_index=0

    def button(parent,text,command,accent=False):
        return tk.Button(parent,text=text,command=command,bg=ACCENT if accent else '#223047',fg=INK,
                         activebackground='#354a69',activeforeground=INK,relief='flat',bd=0,padx=10,pady=8,font=font)

    def log(text):
        console.configure(state='normal');console.insert('end',str(text)+'\n\n')
        if int(console.index('end-1c').split('.')[0])>20000:console.delete('1.0','5000.0')
        console.see('end');console.configure(state='disabled')

    def guarded(callback):
        try:
            result=callback()
            if result:
                text=result if isinstance(result,str) else json.dumps(result,indent=2)
                status.set(' '.join(text.split())[:240]);log(text)
            refresh_programs();refresh_panels(force=True)
        except Exception as exc:
            status.set(f'{type(exc).__name__}: {exc}');log(status.get());book.select(pages['console'])
            messagebox.showerror('SpiralCore Studio',str(exc),parent=root)

    def wrap_buttons(frame,buttons):
        width=max(100,frame.winfo_width());columns=max(1,min(len(buttons),width//155))
        for col in range(12):frame.columnconfigure(col,weight=1 if col<columns else 0)
        for i,b in enumerate(buttons):b.grid(row=i//columns,column=i%columns,sticky='ew',padx=3,pady=3)

    heading=tk.Frame(root,bg=BG,padx=16,pady=10);heading.pack(fill='x')
    tk.Label(heading,text='SPIRALCORE',bg=BG,fg=INK,font=('DejaVu Sans',22,'bold')).pack(side='left')
    tk.Label(heading,text=' / STUDIO',bg=BG,fg=ACCENT,font=('DejaVu Sans',16)).pack(side='left')
    launchbar=tk.Frame(root,bg=BG,padx=12,pady=5);launchbar.pack(fill='x')
    picker=ttk.Combobox(launchbar,textvariable=selected,state='readonly',font=font)
    picker.pack(side='left',fill='x',expand=True,padx=(0,6))
    button(launchbar,'Run',lambda:guarded(run_selected),True).pack(side='left')
    focus_button=button(launchbar,'Focus view',lambda:toggle_focus());focus_button.pack(side='left',padx=(6,0))
    toolbar=tk.Frame(root,bg=BG,padx=9);toolbar.pack(fill='x')
    metric_label=tk.Label(root,textvariable=metrics,bg=BG,fg='#48c9e3',anchor='w',justify='left',padx=16,pady=7,font=mono)
    metric_label.pack(fill='x')
    book=ttk.Notebook(root);book.pack(fill='both',expand=True,padx=12,pady=5)
    pages={}
    for key,label in [('program','Program'),('telemetry','Telemetry'),('files','Files'),('work','Work'),('help','Help'),('console','Console')]:
        page=tk.Frame(book,bg=PANEL,padx=10,pady=8);pages[key]=page;book.add(page,text=label)
    program=pages['program']
    tk.Label(program,textvariable=title,bg=PANEL,fg=INK,anchor='w',font=('DejaVu Sans',17,'bold')).pack(fill='x')
    description_label=tk.Label(program,textvariable=description,bg=PANEL,fg=MUTED,anchor='w',justify='left',font=font,pady=4)
    description_label.pack(fill='x')
    actions=tk.Frame(program,bg=PANEL);actions.pack(fill='x')
    canvas=tk.Canvas(program,bg='#0b1220',highlightthickness=0);canvas.pack(fill='both',expand=True,pady=(5,0))

    def text_panel(parent,wrap='word'):
        frame=tk.Frame(parent,bg=PANEL);frame.pack(fill='both',expand=True)
        widget=tk.Text(frame,bg=PANEL,fg=INK,insertbackground=ACCENT,font=mono,relief='flat',wrap=wrap,padx=8,pady=8)
        scroll=ttk.Scrollbar(frame,command=widget.yview);widget.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');widget.pack(fill='both',expand=True)
        return widget

    def replace_text(widget,value):
        y=widget.yview()[0];widget.configure(state='normal');widget.delete('1.0','end');widget.insert('1.0',value)
        widget.configure(state='disabled');widget.yview_moveto(y)

    telemetry_top=tk.Frame(pages['telemetry'],bg=PANEL);telemetry_top.pack(fill='x')
    telemetry_title=tk.StringVar()
    tk.Label(telemetry_top,textvariable=telemetry_title,bg=PANEL,fg='#48c9e3',font=font,justify='left',anchor='w').pack(side='left',fill='x',expand=True)
    button(telemetry_top,'Export JSON',lambda:guarded(export_telemetry)).pack(side='right')
    telemetry_mode=tk.StringVar(value='Summary')
    telemetry_picker=ttk.Combobox(telemetry_top,textvariable=telemetry_mode,values=['Summary','Raw JSON'],state='readonly',width=10,font=font)
    telemetry_picker.pack(side='right',padx=6)
    telemetry_picker.bind('<<ComboboxSelected>>',lambda e:refresh_panels(force=True))
    ca_canvas=tk.Canvas(pages['telemetry'],height=128,bg=BG,highlightthickness=0);ca_canvas.pack(fill='x',pady=6)
    telemetry_text=text_panel(pages['telemetry'])
    file_info=tk.StringVar()
    file_label=tk.Label(pages['files'],textvariable=file_info,bg=PANEL,fg=MUTED,justify='left',anchor='w',font=font)
    file_label.pack(fill='x',pady=(0,8))
    file_tools=tk.Frame(pages['files'],bg=PANEL);file_tools.pack(fill='x')
    file_frame=tk.Frame(pages['files'],bg=PANEL);file_frame.pack(fill='both',expand=True,pady=8)
    files_tree=ttk.Treeview(file_frame,columns=('type','raw','stored'),show='tree headings',selectmode='browse')
    files_tree.heading('#0',text='File');files_tree.column('#0',width=340,minwidth=100)
    for col,text,width in [('type','Kind',160),('raw','Bytes',80),('stored','Stored',80)]:
        files_tree.heading(col,text=text);files_tree.column(col,width=width,minwidth=50,anchor='e' if col!='type' else 'w')
    file_scroll=ttk.Scrollbar(file_frame,command=files_tree.yview);files_tree.configure(yscrollcommand=file_scroll.set)
    file_hscroll=ttk.Scrollbar(file_frame,orient='horizontal',command=files_tree.xview);files_tree.configure(xscrollcommand=file_hscroll.set)
    file_scroll.pack(side='right',fill='y');file_hscroll.pack(side='bottom',fill='x');files_tree.pack(fill='both',expand=True)
    work_tools=tk.Frame(pages['work'],bg=PANEL);work_tools.pack(fill='x')
    button(work_tools,'Edit record / Attach evidence',lambda:guarded(work_record),True).pack(side='left')
    button(work_tools,'Memory guide',lambda:show_help('memory')).pack(side='left',padx=6)
    work_text=text_panel(pages['work'])
    help_tools=tk.Frame(pages['help'],bg=PANEL);help_tools.pack(fill='x')
    help_choice=tk.StringVar(value='Start here');topic_map={label:key for key,(label,_) in SECTIONS.items()};topic_map['Complete guide']='all'
    help_picker=ttk.Combobox(help_tools,textvariable=help_choice,values=list(topic_map),state='readonly',width=21,font=font)
    help_picker.pack(side='left',padx=(0,6));help_picker.bind('<<ComboboxSelected>>',lambda e:show_help(topic_map[help_choice.get()]))
    help_search=tk.Entry(help_tools,bg='#223047',fg=INK,insertbackground=ACCENT,font=font,width=12)
    help_search.pack(side='left',fill='x',expand=True)
    button(help_tools,'Find',lambda:search_help()).pack(side='left',padx=4)
    help_search.bind('<Return>',lambda e:search_help())
    help_textbox=text_panel(pages['help']);help_textbox.tag_configure('found',background='#665034',foreground=INK)
    console_tools=tk.Frame(pages['console'],bg=PANEL);console_tools.pack(fill='x')
    button(console_tools,'Export log',lambda:guarded(export_log)).pack(side='left')
    console=text_panel(pages['console']);console.configure(state='disabled')
    command_bar=tk.Frame(root,bg=BG,padx=12,pady=5);command_bar.pack(fill='x')
    tk.Label(command_bar,text='CMD>',bg=BG,fg=ACCENT,font=mono).pack(side='left',padx=(0,8))
    entry=tk.Entry(command_bar,bg=PANEL,fg=INK,insertbackground=ACCENT,font=mono,relief='flat')
    entry.pack(side='left',fill='x',expand=True,ipady=8)
    button(command_bar,'Execute',lambda:guarded(command)).pack(side='left',padx=(6,0))
    status_label=tk.Label(root,textvariable=status,bg=BG,fg=MUTED,anchor='w',justify='left',font=('DejaVu Sans',9),padx=16,pady=7)
    status_label.pack(fill='x')
    # Reserve bottom controls before the notebook gets the remaining height.
    status_label.pack_configure(before=book,side='bottom')
    command_bar.pack_configure(before=book,side='bottom')

    def refresh_programs():
        nonlocal selected_id,action_key
        name_to_id.clear();name_to_id.update({item['name']:item['id'] for item in CATALOG})
        for pid,app in runtime.programs.apps.items():
            if pid not in BY_ID:name_to_id[f"{app['name']} [{pid}]"]=pid
        picker.configure(values=list(name_to_id))
        if selected_id not in name_to_id.values():selected_id=runtime.foreground
        selected.set(next((name for name,pid in name_to_id.items() if pid==selected_id),selected_id))
        app=runtime.programs.apps.get(selected_id)
        key=(selected_id,app['source_sha256'] if app else None,runtime.run_id)
        if action_key!=key:
            action_key=key
            for child in actions.winfo_children():child.destroy()
            actions_buttons.clear()
            title.set(app['name'] if app else BY_ID.get(selected_id,{}).get('name','Program'))
            description.set(app['description'] if app else BY_ID.get(selected_id,{}).get('about','Press Run'))
            if app:
                for event,label in app['actions']:
                    actions_buttons.append(button(actions,label,lambda e=event:guarded(lambda:app_action(e))))
                actions_buttons.append(button(actions,'Pause / resume app',lambda:guarded(toggle_app)))
                actions_buttons.append(button(actions,'Source',lambda:guarded(lambda:show_source(selected_id))))
            wrap_buttons(actions,actions_buttons)

    def choose(pid):
        nonlocal selected_id
        selected_id=pid
        if pid in runtime.programs.apps and runtime.foreground!=pid:
            runtime.foreground=pid;runtime.programs.revision+=1
        refresh_programs();book.select(pages['program']);canvas.focus_set()

    picker.bind('<<ComboboxSelected>>',lambda e:choose(name_to_id[selected.get()]))

    def run_selected():
        result=desk.run(selected_id);choose(runtime.foreground);return result

    def app_action(action,event=None):
        if selected_id not in runtime.programs.apps:return 'Press Run first to open this workspace'
        runtime.programs.action(selected_id,event or {'action':action})
        app=runtime.programs.apps[selected_id]
        if app['error']:raise RuntimeError(app['error'])
        if action=='start' and not runtime.run_complete:
            app['running']=True;runtime.auto_step_enabled=True
        canvas.focus_set()
        return f"{app['name']}: {action}"

    def toggle_app():
        app=runtime.programs.apps[selected_id];app['running']=not app['running'];app['error']=None
        runtime.programs.note(f"{app['name']}: {'running' if app['running'] else 'paused'}")
        return runtime.programs.events[-1]['text']

    def machine_pause():
        runtime.shell('/pause' if runtime.auto_step_enabled else '/resume')
        return f"Machine {'running' if runtime.auto_step_enabled else 'paused'} at tick {runtime.N:,}"

    def single_step():
        runtime.shell('/step');return f'Stepped to tick {runtime.N:,}; machine paused'

    def save_card():
        desk.save();return 'Saved complete machine: '+runtime.autosave_path

    def save_as():
        path=filedialog.asksaveasfilename(parent=root,title='Save complete card as',defaultextension='.spmc',initialfile=Path(runtime.autosave_path).name)
        if path:desk.save(path);return 'Saved complete machine: '+path

    def open_card():
        path=filedialog.askopenfilename(parent=root,title='Open complete console card',filetypes=[('SpiralCore card','*.spmc'),('All files','*')])
        if path:desk.open(path);choose(runtime.foreground);return f'Restored tick {runtime.N}; machine paused'

    def new_session():
        desk.new_session();choose(runtime.foreground);return 'New card ready; previous card saved'

    def branch():
        desk.branch();return 'Branch saved: '+runtime.autosave_path

    def load_python():
        path=filedialog.askopenfilename(parent=root,title='Load Python program into this workspace',filetypes=[('Python','*.py')])
        if path:
            pid=runtime.programs.install(Path(path).read_text(encoding='utf-8'),Path(path).name)
            choose(pid);return 'Loaded '+pid+'; source and state will be included in Save card'

    def upload_data():
        path=filedialog.askopenfilename(parent=root,title='Upload data — stores bytes and advances one tick')
        if path:return runtime.data_upload(path)

    def export_selected():
        selection=files_tree.selection()
        if not selection:raise ValueError('Select a file first')
        vpath=files_tree.item(selection[0],'text')
        data,check=runtime.memory_card.retrieve_compressed_file(vpath)
        path=filedialog.asksaveasfilename(parent=root,title='Export verified card file',initialfile=Path(vpath).name)
        if path:Path(path).write_bytes(data);return {'output':path,**check}

    def export_audio():
        path=filedialog.asksaveasfilename(parent=root,title='Export recorded Bell history',initialfile='Bell_History.wav',defaultextension='.wav')
        if path:return runtime.audio.export_wav(path)

    def export_telemetry():
        path=filedialog.asksaveasfilename(parent=root,title='Export live telemetry',initialfile='Telemetry.json',defaultextension='.json')
        if path:Path(path).write_text(json.dumps(runtime.telemetry_snapshot(),indent=2),encoding='utf-8');return 'Exported '+path

    def export_log():
        path=filedialog.asksaveasfilename(parent=root,title='Export command log',initialfile='Commands.txt')
        if path:Path(path).write_text(console.get('1.0','end-1c'),encoding='utf-8');return 'Exported '+path

    def source_window(source,name,editable=False):
        win=tk.Toplevel(root);win.title(name);win.configure(bg=BG)
        win.geometry(f'{min(860,root.winfo_screenwidth()-40)}x{min(700,root.winfo_screenheight()-60)}')
        win.transient(root);win.grab_set()
        notice='Give your program a unique METADATA id before installing.' if editable else 'Saved/catalog source; use Files → New Python to create your own.'
        tk.Label(win,text=notice,bg=BG,fg=MUTED,font=font,wraplength=440,pady=8).pack(fill='x')
        code=text_panel(win);code.insert('1.0',source)
        if not editable:code.configure(state='disabled')
        controls=tk.Frame(win,bg=BG,pady=8);controls.pack(fill='x')
        def install():
            pid=runtime.programs.install(code.get('1.0','end-1c'),'editor_program.py');choose(pid);win.destroy()
            return 'Loaded '+pid
        def export():
            path=filedialog.asksaveasfilename(parent=win,title='Export Python',initialfile='my_program.py',defaultextension='.py')
            if path:Path(path).write_text(code.get('1.0','end-1c'),encoding='utf-8');return 'Exported '+path
        if editable:button(controls,'Load program',lambda:guarded(install),True).pack(side='left',padx=8)
        button(controls,'Export Python',lambda:guarded(export)).pack(side='left',padx=8)
        button(controls,'Close',win.destroy).pack(side='right',padx=8)

    def show_source(pid):
        reply=desk.execute('/source '+pid);source_window(reply['output'],'Python source — '+pid)

    def editor():
        source_window(STARTER.replace('"counter"','"mycounter"').replace('My Counter','My New Counter'),'Write a program',True)

    def work_record():
        from work_ui import open_work_record
        def recorded(text):
            desk.remember();status.set(text);log(text)
        win=open_work_record(root,runtime,recorded)
        if win is not None:win.grab_set()

    def show_help(topic='start'):
        value=help_text(topic);replace_text(help_textbox,value);help_textbox.yview_moveto(0)
        help_choice.set(next((label for label,key in topic_map.items() if value==help_text(key)), 'Start here'))
        book.select(pages['help'])

    def search_help():
        term=help_search.get().strip();help_textbox.tag_remove('found','1.0','end')
        if not term:return
        start=help_textbox.search(term,'1.0',stopindex='end',nocase=True)
        if start:
            help_textbox.tag_add('found',start,f'{start}+{len(term)}c');help_textbox.see(start)
        else:status.set('No match in this topic. Choose Complete guide to search all sections.')

    def command(event=None):
        nonlocal history_index
        raw=entry.get().strip();entry.delete(0,'end')
        if not raw:return
        history.append(raw);history_index=len(history);log('CMD> '+raw)
        parts=shlex.split(raw);verb=parts[0].lower().lstrip('/')
        if verb=='editor':editor();return 'Program editor opened'
        if len(parts)==1 and verb in ('upload','load','retrieve','restore','loadcard','audio'):
            return {'upload':upload_data,'load':load_python,'retrieve':export_selected,'restore':open_card,'loadcard':open_card,'audio':export_audio}[verb]()
        reply=desk.execute(raw)
        if reply['view']=='source':source_window(reply['output'],'Python source');return 'Source opened'
        if reply['view']=='help':show_help(reply['topic'])
        elif reply['view']=='program' or verb in ('show','select','load','program'):
            choose(runtime.foreground)
        else:book.select(pages.get(reply['view'],pages['console']))
        return reply['output']

    def recall(direction):
        nonlocal history_index
        if not history:return 'break'
        history_index=max(0,min(len(history),history_index+direction));entry.delete(0,'end')
        if history_index<len(history):entry.insert(0,history[history_index])
        return 'break'
    entry.bind('<Return>',lambda e:guarded(command));entry.bind('<Up>',lambda e:recall(-1));entry.bind('<Down>',lambda e:recall(1))

    def toggle_focus():
        nonlocal focus_mode
        focus_mode=not focus_mode
        if focus_mode:
            for widget in (heading,toolbar,metric_label,command_bar,status_label):widget.pack_forget()
        else:
            heading.pack(before=launchbar,fill='x');toolbar.pack(after=launchbar,fill='x');metric_label.pack(after=toolbar,fill='x')
            status_label.pack(before=book,side='bottom',fill='x');command_bar.pack(before=book,side='bottom',fill='x')
        focus_button.configure(text='Exit focus' if focus_mode else 'Focus view')
        canvas.focus_set()

    toolbar_specs=[('Resume machine',machine_pause),('Step',single_step),('Save card',save_card),('Open card',open_card),('Branch',branch),('New session',new_session)]
    for label,callback in toolbar_specs:toolbar_buttons.append(button(toolbar,label,lambda c=callback:guarded(c)))
    for label,callback in [('Upload data',upload_data),('Load Python',load_python),('New Python',editor),('Export selected',export_selected),('Save as',save_as),('Export Bell WAV',export_audio)]:
        file_buttons.append(button(file_tools,label,lambda c=callback:guarded(c)))
    toolbar.bind('<Configure>',lambda e:wrap_buttons(toolbar,toolbar_buttons));actions.bind('<Configure>',lambda e:wrap_buttons(actions,actions_buttons))
    file_tools.bind('<Configure>',lambda e:wrap_buttons(file_tools,file_buttons))

    def draw_program():
        canvas.delete('all');w=max(100,canvas.winfo_width());h=max(100,canvas.winfo_height());ph=max(100,h-64)
        app=runtime.programs.apps.get(selected_id)
        if app:
            draw=getattr(app['module'],'draw',None)
            try:
                if callable(draw):draw(canvas,ProgramAPI(runtime.programs,selected_id),app['state'],w,ph)
                else:canvas.create_text(18,18,anchor='nw',fill=INK,text=json.dumps(app['state'],indent=2),font=mono,width=w-36)
                if app['error']:canvas.create_text(18,ph-10,anchor='sw',fill='#ff9caf',text=app['error'],width=w-36)
            except Exception as exc:canvas.create_text(18,18,anchor='nw',fill='#ff9caf',text='Drawing error: '+str(exc),width=w-36)
        else:
            canvas.create_text(w/2,ph/2,text=BY_ID.get(selected_id,{}).get('about','Choose a program')+'\n\nPress Run to open its saved workspace.',fill=INK,font=('DejaVu Sans',14),width=w-70,justify='center')
        cell=(w-84)/runtime.ca_width
        for label,row,color,y in [('184',runtime.ca184_history[-1],'#39c4df',h-53),('CF',runtime.ca184_cf_history[-1],ACCENT,h-35)]:
            canvas.create_text(10,y+5,anchor='w',text=label,fill=MUTED,font=mono)
            for i,bit in enumerate(row):canvas.create_rectangle(56+i*cell,y,56+(i+1)*cell-1,y+10,fill=color if bit else '#1d293b',outline='')
        canvas.create_text(10,h-10,anchor='w',text=f'CA 184 live · tick {runtime.N:,} · {desk.current} · {"running" if runtime.auto_step_enabled else "paused"}',fill=MUTED,font=('DejaVu Sans Mono',9))

    def draw_histories():
        ca_canvas.delete('all');w=max(100,ca_canvas.winfo_width());cw=(w-26)/2
        for idx,(label,history,color) in enumerate([('184 forward',runtime.ca184_history,'#39c4df'),('184 counterfactual',runtime.ca184_cf_history,ACCENT)]):
            x=8+idx*(cw+10);ca_canvas.create_text(x,4,text=label,anchor='nw',fill=MUTED,font=mono)
            rows=history[-16:];cell=cw/runtime.ca_width
            for j,row in enumerate(rows):
                for i,bit in enumerate(row):
                    if bit:ca_canvas.create_rectangle(x+i*cell,24+j*6,x+(i+1)*cell,30+j*6,fill=color,outline='')

    def refresh_panels(force=False):
        nonlocal last_panel
        now=time.monotonic()
        if not force and now-last_panel<0.5:return
        last_panel=now;view=book.select()
        if view==str(pages['telemetry']):
            snap=runtime.telemetry_snapshot();c=snap['ca184'];m=snap['machine'];p=snap['programs'];card=snap['card']
            telemetry_title.set(f"Tick {m['tick']:,}   ·   loop {m['loop']}/10 + {m['tick_in_loop']:,}/10,000\nCA 184 {'PASS' if c['conserved'] else 'CHECK FAILED'}   ·   {c['forward_particles']} + {c['cf_particles']} = {c['width']}\nProgram state {p['state_bytes']:,}/32,768 B   ·   files {card['user_used']:,}/{card['user_capacity']:,} B")
            replace_text(telemetry_text,json.dumps(snap,indent=2) if telemetry_mode.get()=='Raw JSON' else telemetry_summary(snap));draw_histories()
        elif view==str(pages['files']):
            files=runtime.file_inventory();used=sum(row['stored_bytes'] for row in files)
            file_info.set(f"Workspace: {desk.current}  ·  user files {used:,} / {runtime.memory_card.FILE_CAPACITY:,} B\nCard: {runtime.autosave_path}\nSave folder: {desk.directory}")
            selection=files_tree.selection();old=files_tree.item(selection[0],'text') if selection else None
            rows=[(row['path'],row['kind'],row['original_bytes'],row['stored_bytes']) for row in files]
            if rows!=file_paths:
                file_paths[:]=rows;files_tree.delete(*files_tree.get_children())
                for i,(path,kind,raw,stored) in enumerate(rows):
                    item=files_tree.insert('', 'end',text=path,values=(kind,f'{raw:,}',f'{stored:,}'))
                    if path==old:files_tree.selection_set(item)
        elif view==str(pages['work']):replace_text(work_text,json.dumps(runtime.work.overview(),indent=2))

    def telemetry_summary(s):
        m=s['machine'];clock=s['clock'];carry=s['carry'];card=s['card'];routing=s['routing'];programs=s['programs']
        lines=['CLOCK',f"{'RUNNING' if m['running'] else 'PAUSED'} · interval {m['interval_s']:.2f}s · tick {m['tick']:,}",
               f"Kuramoto R {clock['R']:.6f} · time {clock['time_s']:.3f}s · drift {clock['drift_ms']}ms",
               'Phases (radians): '+', '.join(f'{x:.4f}' for x in clock['phases']),
               '', 'PROGRAMS — callbacks / inbox / status']
        for a in programs['items']:
            lines.append(f"{a['name']} [{a['id']}]\n  {a['ticks']:,} callbacks · {a['inbox']} messages · {'RUNNING' if a['running'] else 'PAUSED'}"+(f"\n  ERROR: {a['error']}" if a['error'] else ''))
        lines.extend(['', 'CARRY / RECALL',f"{carry['roots']} roots · {carry['contributions']:,} contributions · v3(N) {carry['valuation']}",
                      f"Recall {'on' if carry['recall_enabled'] else 'off'} · gain {carry['gain']}",
                      'Field magnitudes: '+', '.join(f'{x:.4f}' for x in carry['field_magnitudes']),
                      '', 'ROUTING / AUDIO',f"Address {routing['address']} · Bell {routing['bell_pair']} Hz",
                      f"Ingress {routing['ingress_packets']} · egress {routing['egress_packets']} · tones {routing['recorded_tones']}",
                      '', 'CARD / CHECKPOINT',f"8 MiB · 1024 × 8192-byte blocks · {card['saved_loop_slots']}/10 saved loop slots",
                      f"{card['files']} user files · {card['user_used']:,}/{card['user_capacity']:,} bytes stored",
                      'Card: '+str(m['card_path']),f"{'Unsaved changes' if m['dirty'] else 'Saved'} · automatic write: every 10,000 ticks",
                      'Save error: '+str(m['save_error'] or 'none'),'', 'TASK RECORD',
                      f"{s['work']['title']} · {s['work']['status']} · revision {s['work']['revision']}",
                      '', 'Choose Raw JSON for every coordinate and machine-readable field.'])
        return '\n'.join(lines)

    def frame():
        nonlocal last_tick,last_error
        now=time.monotonic()
        if runtime.auto_step_enabled and now-last_tick>=runtime.step_interval_sec:
            last_tick=now
            try:runtime.step(label='STUDIO_CPU')
            except Exception as exc:runtime.auto_step_enabled=False;status.set('Machine paused: '+str(exc));log(status.get())
        conserved=(sum(runtime.ca184_history[-1])==runtime.initial_ca184_particles and sum(runtime.ca184_cf_history[-1])==runtime.initial_ca184_cf_particles and sum(runtime.ca184_history[-1])+sum(runtime.ca184_cf_history[-1])==runtime.ca_width)
        metrics.set(f"TICK {runtime.N:,}    R {runtime.kuramoto_R:.4f}    LOOP {runtime.completed_loops}/10 + {runtime.loop_tick:,}\nCA 184 {'PASS' if conserved else 'CHECK FAILED'}    {desk.current.upper()}    {'UNSAVED' if runtime.dirty else 'SAVED'}")
        toolbar_buttons[0].configure(text='Complete — New' if runtime.run_complete else 'Pause machine' if runtime.auto_step_enabled else 'Resume machine')
        errors=tuple((a['id'],a['error']) for a in runtime.programs.apps.values() if a['error'])
        if errors and errors!=last_error:status.set('; '.join(pid+': '+error for pid,error in errors));log(status.get())
        last_error=errors
        if book.select()==str(pages['program']):draw_program()
        refresh_panels();root.after(40,frame)

    def keyboard(event):
        if event.keysym=='Escape' and focus_mode:toggle_focus();return 'break'
        if book.select()!=str(pages['program']) or root.grab_current() is not None:return
        if isinstance(root.focus_get(),(tk.Entry,tk.Text,ttk.Combobox)) or event.state & 0x4:return
        app=runtime.programs.apps.get(selected_id)
        if app:
            action=getattr(app['module'],'KEYS',{}).get(event.keysym)
            if action:guarded(lambda:app_action(action));return 'break'
    root.bind('<KeyPress>',keyboard)
    def pointer(event):
        canvas.focus_set();app=runtime.programs.apps.get(selected_id)
        if app and getattr(app['module'],'POINTER',False) and event.y<canvas.winfo_height()-64:
            guarded(lambda:app_action('pointer',{'action':'pointer','x':event.x/max(1,canvas.winfo_width()),'y':event.y/max(1,canvas.winfo_height()-64)}))
    canvas.bind('<Button-1>',pointer)
    def resized(event):
        if event.widget is root:
            width=max(300,event.width-48)
            description_label.configure(wraplength=width);status_label.configure(wraplength=width);file_label.configure(wraplength=width)
    root.bind('<Configure>',resized)
    book.bind('<<NotebookTabChanged>>',lambda e:refresh_panels(force=True))
    def close():
        try:desk.save()
        except Exception as exc:messagebox.showerror('Save failed — session kept open',str(exc),parent=root);return
        runtime.running=False;root.destroy()
    root.protocol('WM_DELETE_WINDOW',close)
    replace_text(help_textbox,help_text('start'));refresh_programs();book.select(pages['program']);canvas.focus_set()
    log('SpiralCore Studio ready. /help commands · /help memory · /help programming')
    root.after(100,frame);root.mainloop()


def main():
    parser=argparse.ArgumentParser(description='SpiralCore Studio — native programs, live telemetry and block cards')
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument('--load',help='Restore a console card, paused')
    modes.add_argument('--demo',nargs='?',const='studio_demo',help='Run the headless integration demonstration')
    modes.add_argument('--inspect');modes.add_argument('--continue-card');modes.add_argument('--export-card')
    parser.add_argument('--outdir');parser.add_argument('--card',help='New card path');parser.add_argument('--data-dir',help='Workspace save directory')
    args=parser.parse_args()
    if args.inspect or args.continue_card or args.export_card:
        from continuity import run_cli
        run_cli(args);return
    if args.demo:
        from studio_demo import run_demo
        run_demo(Path(args.demo));return
    if args.card and Path(args.card).exists() and not args.load:parser.error('Card exists; use --load or a new --card path')
    directory=Path(args.data_dir).expanduser() if args.data_dir else Path(__file__).resolve().parent/'SpiralCore_Saves'
    try:
        directory.mkdir(parents=True,exist_ok=True)
        import tempfile
        with tempfile.TemporaryFile(dir=directory):pass
    except OSError:
        if args.data_dir:raise
        directory=Path.home()/'SpiralCore_Saves';directory.mkdir(parents=True,exist_ok=True)
    runtime=StudioRuntime();desk=Launcher(runtime,directory);desk.startup(args.load,args.card)
    launch(runtime,desk)

if __name__=='__main__':main()
