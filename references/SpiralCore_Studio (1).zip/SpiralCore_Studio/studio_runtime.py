"""Launcher/command services layered over the unchanged continuity runtime."""
import hashlib
import json
import math
from pathlib import Path
import shlex

from console_host import ConsoleRuntime, kernel, ProgramAPI
from console_builtin_sources import SOURCES
from catalog import BY_ID, GROUPS, resolve


class StudioRuntime(ConsoleRuntime):
    def install_builtins(self):
        self.install_group("arcade")

    def install_group(self, group):
        for pid in GROUPS[group]:
            if pid not in self.programs.apps:
                item = BY_ID[pid]
                self.programs.install(SOURCES[item["file"]], item["file"])

    def run_program(self, pid):
        if self.run_complete:
            raise ValueError("Ten loops are complete. Choose New session to run a fresh machine.")
        pid = resolve(pid)
        if pid not in self.programs.apps:
            raise ValueError("Program is in another workspace; select it in the picker and press Run")
        app = self.programs.apps[pid]
        app["running"], app["error"] = True, None
        self.foreground = pid
        self.programs.note(f"Run {app['name']}")
        if pid == "runner" and app["state"]["status"] != "playing":
            self.programs.action(pid, {"action":"start"})
        if pid in GROUPS["compute"] and "dispatch" in self.programs.apps:
            for member in GROUPS["compute"]:
                self.programs.apps[member]["running"] = True
            self.programs.action("dispatch", {"action":"start"})
        if pid == "courier" and not app["state"]["delivered"] and not app["state"]["waiting"]:
            self.programs.action(pid, {"action":"burst"})
        if app["error"]:
            raise RuntimeError(app["error"])
        self.auto_step_enabled = True
        return f"Running {app['name']} at tick {self.N}"

    def data_upload(self, path):
        path = Path(path).expanduser()
        if path.suffix.lower() == ".spmc":
            raise ValueError("Use Open card / /restore for .spmc cards; Upload data stores ordinary files")
        name = path.name
        if name in ("continuity_record.json",) or name.startswith("program_"):
            raise ValueError("This filename is reserved for the saved runtime; rename the data file")
        if "/user/files/"+name in self.memory_card._raw_files:
            raise FileExistsError("A card file already has that name; rename it to preserve the existing evidence")
        before = self.N
        result = self.upload_and_compress_file(str(path))
        if self.N != before + 1:
            raise RuntimeError("Upload did not produce its expected one-step transition")
        return result

    def file_inventory(self):
        files=[]
        for path,entry in self.memory_card.tree["paths"]["/user/files"].items():
            stats=entry["compression_law_stats"]
            name=Path(path).name
            kind="program source" if name.startswith("program_") else "task record" if name=="continuity_record.json" else "data / output / evidence"
            files.append({"path":path,"kind":kind,"original_bytes":stats["original_bytes"],
                          "stored_bytes":len(self.memory_card._raw_files[path])})
        return files

    def telemetry_snapshot(self):
        traffic=ProgramAPI(self.programs,"").traffic()
        fields,count=self.memory_field()
        state_size=len(kernel._json_bytes(self.programs.snapshot()))
        return {
            "machine":{"tick":self.N,"running":self.auto_step_enabled,"interval_s":self.step_interval_sec,
                       "loop":self.completed_loops,"tick_in_loop":self.loop_tick,"loop_length":10000,"loop_limit":10,
                       "save_error":self.autosave_error,"card_path":self.autosave_path,"dirty":self.dirty},
            "ca184":{"forward_particles":sum(self.ca184_history[-1]),"forward_expected":self.initial_ca184_particles,
                     "cf_particles":sum(self.ca184_cf_history[-1]),"cf_expected":self.initial_ca184_cf_particles,
                     "sum":sum(self.ca184_history[-1])+sum(self.ca184_cf_history[-1]),"width":self.ca_width,
                     "conserved":sum(self.ca184_history[-1])==self.initial_ca184_particles and sum(self.ca184_cf_history[-1])==self.initial_ca184_cf_particles and sum(self.ca184_history[-1])+sum(self.ca184_cf_history[-1])==self.ca_width,
                     "flux":traffic["flux"],"forward":traffic["row"],"counterfactual":traffic["counterfactual"]},
            "other_automata":{"ca110":list(self.ca110_history[-1]),"ca30":list(self.ca30_history[-1])},
            "clock":{"R":self.kuramoto_R,"time_s":self.kuramoto_strata_time,"drift_ms":self.sync_drift_ms,
                     "phases":list(self.phases),"fixed_dt":self.fixed_dt},
            "carry":{"roots":len(self.roots),"contributions":count,"valuation":kernel.valuation_3(self.N) if self.N else 0,
                     "recall_enabled":self.memory_enabled,"gain":self.memory_gain,
                     "field_magnitudes":[abs(x) for x in fields]},
            "programs":{"selected":self.foreground,"state_bytes":state_size,"state_limit_bytes":32768,
                        "outbox_messages":len(self.programs.outbox),"items":[dict({k:a[k] for k in ("id","name","running","ticks","error","period")},
                        inbox=len(a["mailbox"])) for a in self.programs.apps.values()]},
            "card":{"bytes":8388608,"blocks":1024,"block_bytes":8192,"saved_loop_slots":len(self.memory_card._loop_blocks),
                    "user_capacity":self.memory_card.FILE_CAPACITY,
                    "user_used":sum(len(x) for x in self.memory_card._raw_files.values()),"files":len(self.memory_card._raw_files)},
            "routing":{"address":traffic["address"],"bell_pair":traffic["bell_pair"],
                       "ingress_packets":self.router.ingress_packets,"egress_packets":self.router.egress_packets,
                       "recorded_tones":len(self.audio.history_tones)},
            "work":{"title":self.work.record["title"],"status":self.work.record["status"],"revision":self.work.record["revision"],
                    "evidence_files":len(self.work.record["evidence"])}
        }

    def shell(self, command):
        parts=shlex.split(command)
        if not parts:return ""
        verb=parts[0].lower().lstrip("/")
        if verb in ("help","h","?","information"):
            from manual import help_text
            return help_text(" ".join(parts[1:]) or "start")
        if verb in ("telemetry","status"):
            return json.dumps(self.telemetry_snapshot(),indent=2)
        if verb=="programs":
            return json.dumps({"installed":[{k:a[k] for k in ("id","name","running","ticks","error")} for a in self.programs.apps.values()],"catalog":list(BY_ID.values())},indent=2)
        if verb in ("run","play") and len(parts)>1:return self.run_program(" ".join(parts[1:]))
        if verb in ("show","select") and len(parts)>1:
            pid=resolve(" ".join(parts[1:]))
            if pid not in self.programs.apps:raise ValueError("Use the picker and Run to open that workspace")
            self.foreground=pid;self.programs.revision+=1
            return "Selected "+self.programs.apps[pid]["name"]
        if verb=="upload" and len(parts)>1:return json.dumps(self.data_upload(" ".join(parts[1:])),indent=2)
        if verb in ("files","dir"):return json.dumps(self.file_inventory(),indent=2)
        if verb=="audio":
            if len(parts)>2:raise ValueError('/audio ["path.wav"]')
            path=Path(parts[1]).expanduser() if len(parts)==2 else Path(self.autosave_path).with_suffix('.wav')
            result=self.audio.export_wav(str(path))
            return json.dumps(result,indent=2) if result else 'Exported '+str(path)
        if verb in ("retrieve","export"):
            if len(parts)!=3:raise ValueError('/retrieve "card filename" "output path"')
            raw,check=self.memory_card.retrieve_compressed_file(parts[1]);Path(parts[2]).expanduser().write_bytes(raw)
            return json.dumps({"output":parts[2],**check},indent=2)
        if verb=="speed":
            if len(parts)!=2 or not math.isfinite(float(parts[1])):raise ValueError("/speed needs a finite interval in seconds")
        if verb in ("step","fold"):
            if verb=="step":
                if len(parts)>3:raise ValueError("/step [1..243] [finite payload]")
                if len(parts)>1 and not 1<=int(parts[1])<=243:raise ValueError("Step count must be 1..243")
                if len(parts)>2 and not math.isfinite(float(parts[2])):raise ValueError("Payload must be finite")
            self.auto_step_enabled=False
        if verb in ("program","load") and len(parts)>1:
            path=Path(" ".join(parts[1:])).expanduser()
            if path.suffix.lower()!=".py":raise ValueError("Load Python expects a .py program; use Upload data for other files")
            pid=self.programs.install(path.read_text(encoding="utf-8"),path.name)
            self.foreground=pid
            return "Loaded "+pid
        return super().shell(command)
