import hashlib
import math

METADATA = {
    "id": "courier", "name": "Signal Courier", "period": 1,
    "description": "Packets ride the machine's Rule 184 traffic; delivered messages reach the Ledger program.",
    "actions": [["send", "Send packet"], ["burst", "Burst ×8"], ["auto", "Auto traffic"], ["clear", "Clear track"]],
}


def init(api):
    return {"next_id": 1, "waiting": [], "packets": [], "delivered": 0, "travel_ticks": 0,
            "auto": True, "previous_row": api.traffic()["row"], "last_delivery": "Waiting for traffic", "trail": []}


def enqueue(api, state, text=None):
    if len(state["waiting"]) + len(state["packets"]) >= 24:
        return
    number = state["next_id"]
    state["next_id"] += 1
    payload = text or f"SpiralCore packet {number} / created at tick {api.clock()['N']}"
    state["waiting"].append({"id": number, "payload": payload[:300],
                             "sha256": hashlib.sha256(payload[:300].encode()).hexdigest()})


def handle(api, state, event):
    action = event["action"]
    if action in ("send", "burst"):
        for _ in range(8 if action == "burst" else 1):
            enqueue(api, state, event.get("text") or None)
    elif action == "auto":
        state["auto"] = not state["auto"]
    elif action == "clear":
        state["waiting"].clear()
        state["packets"].clear()


def tick(api, state):
    clock, traffic = api.clock(), api.traffic()
    previous, row = state["previous_row"], traffic["row"]
    if state["auto"] and clock["N"] % 24 == 0:
        enqueue(api, state)
    remaining = []
    for packet in state["packets"]:
        position = packet["position"]
        if previous[position] == 1 and previous[(position + 1) % len(row)] == 0:
            packet["position"] = (position + 1) % len(row)
            packet["hops"] += 1
        if packet["hops"] >= packet["distance"]:
            duration = clock["N"] - packet["sent_N"]
            delivery = {k: packet[k] for k in ("id", "payload", "sha256")}
            delivery.update({"sent_N": packet["sent_N"], "received_N": clock["N"], "travel_ticks": duration,
                             "pair": traffic["bell_pair"], "address": traffic["address"]})
            api.publish("delivery", delivery)
            api.record_tone()
            state["delivered"] += 1
            state["travel_ticks"] += duration
            state["last_delivery"] = f"Packet {packet['id']} delivered in {duration} ticks"
            state["trail"].append(delivery["id"])
            state["trail"] = state["trail"][-16:]
        else:
            remaining.append(packet)
    state["packets"] = remaining
    if state["waiting"] and clock["N"] % 3 == 0:
        occupied = [i for i, value in enumerate(row) if value]
        if occupied:
            packet = state["waiting"].pop(0)
            packet.update({"position": occupied[packet["id"] % len(occupied)], "hops": 0,
                           "distance": 12 + packet["id"] % 12, "sent_N": clock["N"]})
            state["packets"].append(packet)
    state["previous_row"] = row


def draw(canvas, api, state, width, height):
    traffic = api.traffic()
    cx, cy = width * 0.48, height * 0.49
    radius = max(45, min(width * 0.29, height * 0.32))
    canvas.create_oval(cx-radius, cy-radius, cx+radius, cy+radius, outline="#26354b", width=3)
    for i, bit in enumerate(traffic["row"]):
        angle = -math.pi / 2 + i * 2 * math.pi / 48
        x, y = cx + radius * math.cos(angle), cy + radius * math.sin(angle)
        canvas.create_oval(x-3, y-3, x+3, y+3, fill="#39c4df" if bit else "#202a3a", outline="")
    colors = ["#f05ba6", "#ffbf69", "#9c8cff", "#5de2b4", "#70bdff"]
    for packet in state["packets"]:
        angle = -math.pi / 2 + packet["position"] * 2 * math.pi / 48
        x, y = cx + radius * math.cos(angle), cy + radius * math.sin(angle)
        color = colors[packet["id"] % len(colors)]
        canvas.create_oval(x-10, y-10, x+10, y+10, fill=color, outline="#f0f4ff", width=1)
        canvas.create_text(x, y, text=str(packet["id"]), fill="#101421", font=("DejaVu Sans", 8, "bold"))
    canvas.create_text(cx, cy-24, text=str(state["delivered"]), fill="#f1f5ff", font=("DejaVu Sans", 38, "bold"))
    canvas.create_text(cx, cy+17, text="DELIVERED", fill="#8f9fb7", font=("DejaVu Sans", 10, "bold"))
    canvas.create_text(cx, cy+42, text=f"{len(state['packets'])} in transit · {len(state['waiting'])} queued", fill="#39c4df", font=("DejaVu Sans", 10))
    canvas.create_text(24, 20, anchor="nw", text="LOCAL MESSAGE TRANSPORT", fill="#8497b4", font=("DejaVu Sans", 10, "bold"))
    canvas.create_text(24, height-58, anchor="nw", text=state["last_delivery"], fill="#e7edf9", font=("DejaVu Sans", 11))
    canvas.create_text(24, height-30, anchor="nw", text=f"48 sites   •   {traffic['particles']} particles   •   flux {traffic['flux']}   •   auto {'ON' if state['auto'] else 'OFF'}", fill="#879bb8", font=("DejaVu Sans", 9))
