"""A bounded input/event journal and portable JSON export for the arcade run."""
import json

METADATA={"id":"journal","name":"Flight Journal","period":1,
          "description":"Records steering inputs and flight events, and saves a JSON journal alongside the complete-state card.",
          "subscriptions":["flight_event","flight_input"],"actions":[["export","Export journal"]]}


def init(api):
    return {"inputs":[],"events":[],"input_total":0,"event_total":0,"summary":{},"last_file":""}


def export(api,state):
    record={"format":"SpiralCore Phase Runner journal v1","machine_N":api.clock()["N"],
            "inputs":state["inputs"],"events":state["events"],"summary":state["summary"],
            "input_total":state["input_total"],"event_total":state["event_total"],
            "inputs_truncated":state["input_total"]>len(state["inputs"]),
            "events_truncated":state["event_total"]>len(state["events"])}
    state["last_file"]=api.write_file("Flight_Journal.json",json.dumps(record,indent=2))


def handle(api,state,event):
    if event["action"]=="export":export(api,state)


def tick(api,state):
    for message in api.receive():
        payload=message["payload"]
        if message["topic"]=="flight_input":
            state["inputs"].append(payload);state["inputs"]=state["inputs"][-96:];state["input_total"]+=1
        else:
            if payload["kind"]=="start":
                state["inputs"].clear();state["events"].clear();state["input_total"]=0;state["event_total"]=0;state["last_file"]=""
            state["events"].append(payload);state["events"]=state["events"][-48:];state["event_total"]+=1
            state["summary"]=payload
            if payload["kind"]=="finish":export(api,state)


def draw(canvas,api,state,width,height):
    canvas.create_text(24,20,anchor="nw",text="FLIGHT JOURNAL / PERSISTENT HISTORY",fill="#91a4bf",font=("DejaVu Sans",11,"bold"))
    canvas.create_text(24,62,anchor="nw",text=f"{state['input_total']} inputs  ·  {state['event_total']} events",fill="#edf3ff",font=("DejaVu Sans",24,"bold"))
    for i,event in enumerate(state["events"][-8:][::-1]):
        yy=124+i*26
        if yy>height-45:break
        canvas.create_text(24,yy,anchor="nw",text=f"{event['t']:03d}   {event['kind']:<8}   score {event['score']:>5}   hull {event['health']:>3}",fill="#8ed6e8",font=("DejaVu Sans Mono",11))
    canvas.create_text(24,height-22,anchor="w",text="Last 96 inputs / 48 events; full live game state is saved with the card.",fill="#91a4bf",font=("DejaVu Sans",9))
