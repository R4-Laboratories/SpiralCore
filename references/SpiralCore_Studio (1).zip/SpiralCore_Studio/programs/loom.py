import colorsys
import math

METADATA = {
    "id": "loom", "name": "Phase Loom", "period": 1,
    "description": "A live drawing program driven by the machine's phases, roots and CA pattern. Exports SVG.",
    "actions": [["palette", "Change palette"], ["export", "Save SVG"], ["clear", "Clear trail"]],
}


def init(api):
    return {"palette": 0, "trail": [], "frames": 0, "last_export": ""}


def points(api, state):
    phases, row = api.clock()["phases"], api.traffic()["row"]
    points = []
    for i, bit in enumerate(row):
        if bit:
            p = phases[i % len(phases)]
            a = i * 2 * math.pi / len(row)
            radius = 0.31 + 0.08 * math.sin(p + a)
            points.append((0.5 + radius * math.cos(a + p * 0.16), 0.5 + radius * math.sin(a + p * 0.16)))
    return points


def color(state, offset=0):
    rgb = colorsys.hsv_to_rgb((state["palette"] * 0.17 + state["frames"] * 0.002 + offset) % 1, 0.63, 0.98)
    return "#" + "".join(f"{int(v*255):02x}" for v in rgb)


def tick(api, state):
    state["frames"] += 1
    phase = api.clock()["phases"][0]
    state["trail"].append([0.5 + 0.36 * math.cos(phase), 0.5 + 0.36 * math.sin(phase * 1.03)])
    state["trail"] = state["trail"][-64:]


def handle(api, state, event):
    if event["action"] == "palette":
        state["palette"] = (state["palette"] + 1) % 6
    elif event["action"] == "clear":
        state["trail"].clear()
    elif event["action"] == "export":
        vertices = points(api, state)
        poly = " ".join(f"{x*800:.3f},{y*800:.3f}" for x, y in vertices + vertices[:1])
        svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800"><rect width="800" height="800" fill="#0b1220"/><polyline points="{poly}" fill="none" stroke="{color(state)}" stroke-width="3"/><text x="28" y="770" fill="#a8bbd8" font-family="monospace" font-size="15">SpiralCore Phase Loom · tick {api.clock()["N"]}</text></svg>'
        state["last_export"] = api.write_file("phase_loom.svg", svg)


def draw(canvas, api, state, width, height):
    size = min(width-48, height-70)
    ox, oy = (width-size)/2, (height-size)/2
    vertices = points(api, state)
    coords = [component for x, y in vertices + vertices[:1] for component in (ox+x*size, oy+y*size)]
    if len(coords) >= 4:
        canvas.create_line(*coords, fill=color(state), width=2, smooth=True)
    for i in range(0, len(vertices), 3):
        x, y = vertices[i]
        canvas.create_line(width/2, height/2, ox+x*size, oy+y*size, fill="#24324b", width=1)
    if len(state["trail"]) > 1:
        trail = [c for x, y in state["trail"] for c in (ox+x*size, oy+y*size)]
        canvas.create_line(*trail, fill="#6bdcc0", width=2, smooth=True)
    canvas.create_text(24, 20, anchor="nw", text="PHASE LOOM / LIVE GENERATIVE DRAWING", fill="#a8bbd8", font=("DejaVu Sans", 10, "bold"))
    canvas.create_text(24, height-28, anchor="nw", text=f"{state['frames']:,} program ticks · palette {state['palette']+1} · {api.carry()['roots']} roots", fill="#8f9fb7", font=("DejaVu Sans", 10))
