"""An event-driven Bell score and a self-contained PCM WAV synthesizer."""
import io
import math
import struct
import wave

METADATA={"id":"studio","name":"Bell Studio","period":1,
          "description":"Flight events become a live Bell score. Export a WAV soundtrack or create a lower-octave remix.",
          "subscriptions":["flight_event"],"actions":[["export","Export WAV"],["remix","Lower octave / original"]]}
CODES={"signal":0,"pulse":1,"hit":2,"wave":3,"finish":4}
COLORS=["#5de2b4","#8ed6e8","#ff82a8","#bca4ff","#ffbf69"]


def init(api):
    return {"notes":[],"total":0,"octave":0,"last_file":"","flight":0}


def export(api,state):
    if not state["notes"]:
        api.log("Play a flight to collect a score first")
        return
    sample_rate=8000
    samples=bytearray()
    factor=0.5 if state["octave"] else 1.0
    for tick,kind,f1,f2 in state["notes"]:
        duration=0.18 if kind==4 else 0.09
        count=int(duration*sample_rate)
        for i in range(count):
            t=i/sample_rate
            envelope=max(0.0,math.sin(math.pi*i/max(1,count-1)))**1.3
            tone=(math.sin(math.tau*f1*factor*t)+math.sin(math.tau*f2*factor*t))*0.5
            bass=math.sin(math.tau*(110+kind*27.5)*factor*t)*0.20
            sample=int(22000*envelope*(tone+bass)/1.2)
            samples.extend(struct.pack('<h',sample))
        samples.extend(b'\0\0'*120)
    stream=io.BytesIO()
    with wave.open(stream,'wb') as output:
        output.setnchannels(1);output.setsampwidth(2);output.setframerate(sample_rate);output.writeframes(samples)
    filename="Flight_Theme_Low.wav" if state["octave"] else "Flight_Theme.wav"
    state["last_file"]=api.write_file(filename,stream.getvalue())


def handle(api,state,event):
    if event["action"]=="remix":
        state["octave"]=1-state["octave"]
        export(api,state)
    elif event["action"]=="export":
        export(api,state)


def tick(api,state):
    for message in api.receive("flight_event"):
        event=message["payload"]
        kind=event["kind"]
        if kind=="start":
            state["notes"].clear();state["total"]=0;state["flight"]=event["flight"];state["last_file"]=""
        elif kind in CODES:
            pair=api.traffic()["bell_pair"]
            state["notes"].append([event["t"],CODES[kind],int(pair[0]),int(pair[1])])
            state["notes"]=state["notes"][-64:]
            state["total"]+=1
            api.record_tone(pair)
            if kind=="finish":
                export(api,state)


def draw(canvas,api,state,width,height):
    canvas.create_text(24,20,anchor="nw",text="BELL STUDIO / EVENT SCORE",fill="#91a4bf",font=("DejaVu Sans",11,"bold"))
    canvas.create_text(24,58,anchor="nw",text=f"{state['total']} notes",fill="#edf3ff",font=("DejaVu Sans",30,"bold"))
    x0,y0=24,125
    cell=(width-48)/32
    h=max(80,height-192)
    for i in range(7):
        yy=y0+i*h/6
        canvas.create_line(x0,yy,width-24,yy,fill="#253b55")
        canvas.create_text(width-29,yy-9,anchor="e",text=str(1500-i*150)+" Hz",fill="#546b87",font=("DejaVu Sans",8))
    for i,(tick,kind,f1,f2) in enumerate(state["notes"][-32:]):
        x=x0+(i+0.5)*cell
        for freq in (f1,f2):
            y=y0+max(0,min(1,(1500-freq)/900))*h
            canvas.create_rectangle(x-cell*0.34,y-5,x+cell*0.34,y+5,fill=COLORS[kind],outline="")
    canvas.create_text(24,height-38,anchor="nw",text="Signals • pulses • impacts • waves • finish    |    "+("LOW OCTAVE" if state["octave"] else "ORIGINAL OCTAVE"),fill="#8ed6e8",font=("DejaVu Sans",9))
    canvas.create_text(24,height-18,anchor="w",text="WAV on card: "+(state["last_file"].split('/')[-1] or "finishes automatically with your flight"),fill="#91a4bf",font=("DejaVu Sans",9))
