import csv
import hashlib
import io

METADATA = {
    "id": "ledger", "name": "Delivery Ledger", "period": 1, "subscriptions": ["delivery"],
    "description": "Receives messages from Courier, verifies payload hashes, and writes a CSV to the card.",
    "actions": [["commit", "Write CSV"], ["clear", "Clear journal"]],
}


def init(api):
    return {"received": 0, "verified": 0, "failed": 0, "rows": [], "last_file": "No export yet"}


def commit(api, state):
    output = io.StringIO()
    fields = ["id", "sent_N", "received_N", "travel_ticks", "payload", "sha256", "verified"]
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    writer.writerows(state["rows"])
    state["last_file"] = api.write_file("delivery_ledger.csv", output.getvalue())


def tick(api, state):
    received = api.receive("delivery")
    for message in received:
        packet = message["payload"]
        valid = hashlib.sha256(packet["payload"].encode()).hexdigest() == packet["sha256"]
        state["received"] += 1
        state["verified" if valid else "failed"] += 1
        state["rows"].append({k: packet[k] for k in ("id", "sent_N", "received_N", "travel_ticks", "payload", "sha256")})
        state["rows"][-1]["verified"] = valid
        state["rows"] = state["rows"][-32:]
    if received and state["received"] % 8 == 0:
        commit(api, state)


def handle(api, state, event):
    if event["action"] == "commit":
        commit(api, state)
    elif event["action"] == "clear":
        state["rows"].clear()


def draw(canvas, api, state, width, height):
    tiles = [("RECEIVED", state["received"], "#70bdff"), ("VERIFIED", state["verified"], "#5de2b4"), ("FAILED", state["failed"], "#f05ba6")]
    for i, (label, value, color) in enumerate(tiles):
        x = 24 + i * (width - 48) / 3
        canvas.create_text(x, 22, anchor="nw", text=label, fill="#8599b8", font=("DejaVu Sans", 10, "bold"))
        canvas.create_text(x, 46, anchor="nw", text=str(value), fill=color, font=("DejaVu Sans", 30, "bold"))
    canvas.create_text(24, 115, anchor="nw", text="Recent deliveries", fill="#edf2ff", font=("DejaVu Sans", 12, "bold"))
    for i, row in enumerate(state["rows"][-9:][::-1]):
        y = 148 + i * 27
        if y > height-48:
            break
        canvas.create_text(24, y, anchor="nw", text=f"#{row['id']:03d}    tick {row['received_N']:>5}    {row['travel_ticks']:>3} ticks    {'HASH OK' if row['verified'] else 'MISMATCH'}", fill="#b7c8df", font=("DejaVu Sans Mono", 10))
    canvas.create_text(24, height-28, anchor="nw", text="CSV on card: " + state["last_file"].split("/")[-1], fill="#8f9fb7", font=("DejaVu Sans", 9))
