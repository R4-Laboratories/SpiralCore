"""A five-lane arcade game with persistent state and machine-driven spawns."""
import json
import math

METADATA = {"id": "runner", "name": "Phase Runner", "period": 1,
            "description": "Dodge red rocks; collect green signals. Arrows or tap lanes; Space pulses. Auto pilot can demonstrate a run.",
            "actions": [["start", "Launch / restart"], ["left", "◀ Left"], ["right", "Right ▶"],
                        ["pulse", "Pulse"], ["auto", "Auto pilot"]]}
KEYS = {"Left": "left", "a": "left", "Right": "right", "d": "right", "space": "pulse", "Return": "start"}
POINTER = True


def init(api):
    return {"status": "ready", "elapsed": 0, "lane": 2, "score": 0, "best": 0, "health": 100,
            "energy": 100.0, "objects": [], "spawned": 0, "collected": 0, "hits": 0,
            "pulses": 0, "dodged": 0, "auto": False, "flash": 0, "invulnerable": 0,
            "flight": 0, "gate_open": False, "last": "Launch when ready", "lean": 0}


def event(api, state, kind):
    api.publish("flight_event", {"kind": kind, "t": state["elapsed"], "score": state["score"],
                                "health": state["health"], "lane": state["lane"], "flight": state["flight"]})


def steer(api, state, lane, kind="manual"):
    lane = max(0, min(4, lane))
    if lane != state["lane"]:
        state["lean"] = lane-state["lane"]
        state["lane"] = lane
        api.publish("flight_input", {"t": state["elapsed"], "lane": lane, "kind": kind})


def pulse(api, state):
    if state["energy"] < 35 or state["status"] != "playing":
        return
    state["energy"] -= 35
    before = len(state["objects"])
    state["objects"] = [o for o in state["objects"] if not (o["kind"] == "rock" and o["z"] >= 5 and abs(o["lane"]-state["lane"]) <= 1)]
    state["score"] += (before-len(state["objects"]))*8
    state["pulses"] += 1
    state["flash"] = 5
    state["last"] = "Phase pulse"
    event(api, state, "pulse")


def handle(api, state, command):
    action = command["action"]
    if action == "start":
        best, auto, flight = state["best"], state["auto"], state["flight"]+1
        state.clear()
        state.update(init(api))
        state.update({"best": best, "auto": auto, "flight": flight, "status": "playing", "last": "Follow the green signals"})
        event(api, state, "start")
    elif action == "auto":
        state["auto"] = not state["auto"]
        state["last"] = "Auto pilot " + ("engaged" if state["auto"] else "released")
    elif state["status"] == "playing":
        if action in ("left", "right"):
            state["auto"] = False
            steer(api, state, state["lane"] + (-1 if action == "left" else 1))
        elif action == "pointer":
            state["auto"] = False
            steer(api, state, int(float(command["x"])*5))
        elif action == "pulse":
            pulse(api, state)


def autopilot(api, state):
    imminent = any(o["kind"] == "rock" and o["z"] >= 8 and o["lane"] == state["lane"] for o in state["objects"])
    if imminent and state["energy"] >= 35:
        pulse(api, state)
    if state["elapsed"] % 2:
        return
    candidates = range(max(0, state["lane"]-1), min(4, state["lane"]+1)+1)
    def cost(lane):
        result = abs(lane-state["lane"])*0.35
        for obj in state["objects"]:
            if obj["lane"] == lane and obj["z"] >= 5:
                result += (30 if obj["z"] >= 8 else 14/(10-obj["z"])) if obj["kind"] == "rock" else -6/(10-obj["z"])
        return result
    steer(api, state, min(candidates, key=cost), "auto")


def tick(api, state):
    if state["status"] != "playing":
        return
    state["elapsed"] += 1
    state["energy"] = min(100.0, state["energy"]+0.8)
    state["flash"] = max(0, state["flash"]-1)
    state["invulnerable"] = max(0, state["invulnerable"]-1)
    clock, traffic, carry = api.clock(), api.traffic(), api.carry()
    phase = clock["phases"][state["spawned"] % len(clock["phases"]) ]
    state["gate_open"] = (phase % math.tau) < math.tau*0.30
    if state["elapsed"] % 10 == 1:
        sector = int((phase % math.tau)/math.tau*16)
        row = traffic["row"]
        position = (sum(i*bit for i, bit in enumerate(row)) + sector + carry["v3"] + state["spawned"]*3) % 5
        state["objects"].append({"lane": position, "z": 0, "kind": "rock"})
        state["objects"].append({"lane": (position+2+state["spawned"]%2)%5, "z": 0, "kind": "signal"})
        state["spawned"] += 1
    if state["auto"]:
        autopilot(api, state)
    if state["elapsed"] % 4 == 0:
        keep = []
        for obj in state["objects"]:
            obj["z"] += 1
            if obj["z"] >= 9:
                if obj["lane"] == state["lane"]:
                    if obj["kind"] == "signal":
                        state["collected"] += 1
                        bonus = 25 + carry["v3"]*5 + (15 if state["gate_open"] else 0)
                        state["score"] += bonus
                        state["last"] = f"Signal +{bonus}"
                        event(api, state, "signal")
                    elif not state["invulnerable"]:
                        state["health"] = max(0, state["health"]-34)
                        state["hits"] += 1
                        state["invulnerable"] = 8
                        state["last"] = "Hull impact"
                        event(api, state, "hit")
                elif obj["kind"] == "rock":
                    state["dodged"] += 1
                    state["score"] += 5
            else:
                keep.append(obj)
        state["objects"] = keep
    if state["elapsed"] % 40 == 0:
        state["score"] += 10
        event(api, state, "wave")
    if state["health"] <= 0 or state["elapsed"] >= 360:
        state["status"] = "complete" if state["health"] > 0 else "over"
        state["best"] = max(state["best"], state["score"])
        state["last"] = "Mission complete" if state["status"] == "complete" else "Flight ended"
        event(api, state, "finish")
        api.write_file("pilot_profile.json", json.dumps({k: state[k] for k in ("best", "score", "collected", "hits", "elapsed", "status")}, indent=2))


def project(lane, depth, width, height):
    t = depth/10
    road = width*(0.22+0.72*t)
    return width/2+(lane/5-0.5)*road, 48+(height-96)*(t**1.35)


def draw(canvas, api, state, width, height):
    clock = api.clock()
    for i in range(55):
        x, y = (i*137+23)%max(1,int(width)), (i*73+clock["N"]*0.7)%max(1,int(height-40))+30
        canvas.create_oval(x,y,x+1.4,y+1.4,fill="#34435f",outline="")
    canvas.create_text(18, 12, anchor="nw", text=f"SCORE  {state['score']:05d}      HULL  {state['health']:03d}      PULSE  {int(state['energy']):03d}", fill="#d6f4ff", font=("DejaVu Sans Mono", 11, "bold"))
    road = [v for lane,depth in [(0,0),(5,0),(5,10),(0,10)] for v in project(lane,depth,width,height)]
    canvas.create_polygon(*road,fill="#101d30",outline="#274666")
    for lane in range(6):
        canvas.create_line(*project(lane,0,width,height),*project(lane,10,width,height),fill="#294968" if lane in (0,5) else "#1c354c",width=2 if lane in(0,5) else 1)
    for row in range(11):
        canvas.create_line(*project(0,row,width,height),*project(5,row,width,height),fill="#19354d")
    for obj in sorted(state["objects"], key=lambda x:x["z"]):
        x,y = project(obj["lane"]+0.5,obj["z"]+0.5,width,height)
        size=5+obj["z"]*1.8
        if obj["kind"] == "rock":
            points=[v for i in range(7) for v in (x+size*math.cos(i*math.tau/7),y+size*0.7*math.sin(i*math.tau/7))]
            canvas.create_polygon(*points,fill="#a83f66",outline="#ff82a8",width=2)
            canvas.create_line(x-size/2,y-2,x+size/3,y+4,fill="#602942",width=2)
        else:
            canvas.create_polygon(x,y-size,x+size*0.65,y,x,y+size,x-size*0.65,y,fill="#5de2b4",outline="#ceffef",width=2)
    x,y=project(state["lane"]+0.5,9.2,width,height)
    if state["flash"]:
        radius=25+(5-state["flash"])*14
        canvas.create_oval(x-radius,y-radius,x+radius,y+radius,outline="#8ed6e8",width=3)
    if not state["invulnerable"] or state["elapsed"]%2:
        canvas.create_polygon(x,y-21,x+20,y+13,x,y+6,x-20,y+13,fill="#edf3ff",outline="#55dfff",width=2)
        canvas.create_polygon(x-7,y+10,x,y+22+(clock["N"]%3)*3,x+7,y+10,fill="#e34c98",outline="")
    progress=state["elapsed"]/360
    canvas.create_rectangle(18,height-33,width-18,height-29,fill="#223047",outline="")
    canvas.create_rectangle(18,height-33,18+(width-36)*progress,height-29,fill="#e34c98",outline="")
    canvas.create_text(18,height-18,anchor="w",text=f"{state['elapsed']:03d}/360   {state['last']}   •   {'AUTO' if state['auto'] else 'PILOT'}   •   phase gate {'OPEN' if state['gate_open'] else 'CLOSED'}",fill="#91a4bf",font=("DejaVu Sans",9))
    if state["status"] != "playing":
        cy=height*0.44
        canvas.create_rectangle(width/2-210,cy-47,width/2+210,cy+63,fill="#111a29",outline="#4b718e",width=2)
        label="PHASE RUNNER" if state["status"]=="ready" else "MISSION COMPLETE" if state["status"]=="complete" else "FLIGHT ENDED"
        canvas.create_text(width/2,cy-12,text=label,fill="#edf3ff",font=("DejaVu Sans",22,"bold"))
        subtitle="Launch • arrows / tap lanes • Space to pulse" if state["status"]=="ready" else f"Score {state['score']}  •  Signals {state['collected']}  •  Best {state['best']}"
        canvas.create_text(width/2,cy+28,text=subtitle,fill="#8ed6e8",font=("DejaVu Sans",10))
