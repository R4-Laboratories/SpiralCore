"""A cooperative CPU worker. Job source, queues and results survive card saves."""
import base64
import hashlib

METADATA = {"id": "worker_b", "name": "Compute Worker B", "period": 1,
            "description": "Consumes tile jobs and computes Mandelbrot escape counts. Publishes hashed results.",
            "subscriptions": ["tile_job/worker_b"], "actions": []}


def init(api):
    return {"queue": [], "computed": 0, "iterations": 0, "pixels": 0, "last_tile": None,
            "recent": [], "last_sha": "", "peak_queue": 0}


def render(job):
    result = bytearray()
    iterations = 0
    for y in range(job["y"], job["y"] + job["th"]):
        ci = (y + 0.5) / job["height"] * 2.0 - 1.0
        for x in range(job["x"], job["x"] + job["tw"]):
            cr = (x + 0.5) / job["width"] * 3.0 - 2.2
            zr = zi = 0.0
            count = 0
            while zr*zr + zi*zi <= 4.0 and count < job["limit"]:
                zr, zi = zr*zr - zi*zi + cr, 2*zr*zi + ci
                count += 1
            result.append(count)
            iterations += count
    return bytes(result), iterations


def tick(api, state):
    for message in api.receive("tile_job/" + api.pid):
        job = message["payload"]
        if job["worker"] == api.pid:
            state["queue"].append(job)
    state["peak_queue"] = max(state["peak_queue"], len(state["queue"]))
    if not state["queue"]:
        return
    job = state["queue"].pop(0)
    raw, iterations = render(job)
    digest = hashlib.sha256(raw).hexdigest()
    api.publish("tile_result", {"tile": job["tile"], "worker": api.pid, "attempt": job["attempt"],
                               "data": base64.b64encode(raw).decode(), "sha256": digest,
                               "iterations": iterations})
    state["computed"] += 1
    state["iterations"] += iterations
    state["pixels"] += len(raw)
    state["last_tile"], state["last_sha"] = job["tile"], digest
    state["recent"].append(job["tile"])
    state["recent"] = state["recent"][-24:]


def draw(canvas, api, state, width, height):
    canvas.create_text(24, 22, anchor="nw", text=METADATA["name"].upper(), fill="#91a4bf", font=("DejaVu Sans", 10, "bold"))
    canvas.create_text(24, 64, anchor="nw", text=f"{state['computed']} tiles", fill="#edf3ff", font=("DejaVu Sans", 32, "bold"))
    lines = [f"{state['pixels']:,} pixels computed", f"{state['iterations']:,} escape iterations",
             f"{len(state['queue'])} queued jobs", f"Last tile: {state['last_tile']}",
             "SHA-256: " + state["last_sha"][:32], "",
             "Pause this program to let leases expire.", "Dispatch will send its uncommitted work to the other worker."]
    canvas.create_text(24, 140, anchor="nw", text="\n".join(lines), fill="#8ed6e8", font=("DejaVu Sans Mono", 11), width=width-48)
