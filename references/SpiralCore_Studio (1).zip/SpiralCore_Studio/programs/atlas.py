"""Tile verification, durable per-tile storage and PNG assembly without dependencies."""
import base64
import colorsys
import hashlib
import json
import math
import struct
import zlib

METADATA = {"id": "atlas", "name": "Render Canvas", "period": 1,
            "description": "Verifies and saves tiles, assembles a PNG, and can recolor the saved image without recomputing it.",
            "subscriptions": ["tile_result"], "actions": [["export", "Export PNG"], ["palette", "Change palette"]]}
WIDTH, HEIGHT, TW, TH, LIMIT = 384, 256, 32, 16, 160
TOTAL = WIDTH // TW * (HEIGHT // TH)
_canvas_image = None
_image_hash = None


def init(api):
    return {"done": [], "duplicates": 0, "rejected": 0, "workers": {}, "palette": 0,
            "last_export": "", "png_sha256": "", "completed_N": None, "preview": {}}


def rgb(value, palette):
    if value >= LIMIT:
        return (9, 13, 22)
    v = math.log1p(value) / math.log1p(LIMIT)
    hue = (0.61 + 0.9*v + palette*0.17) % 1.0
    return tuple(round(c*255) for c in colorsys.hsv_to_rgb(hue, 0.80, min(1.0, 0.20+1.2*v)))


def chunk(kind, data):
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind+data) & 0xffffffff)


def export(api, state):
    if len(state["done"]) != TOTAL:
        api.log(f"Render has {len(state['done'])}/{TOTAL} tiles; export waits for completion")
        return
    counts = bytearray(WIDTH*HEIGHT)
    for tile in state["done"]:
        raw = api.read_file(f"tile_{tile:03d}.bin")
        tx, ty = tile % (WIDTH//TW) * TW, tile // (WIDTH//TW) * TH
        for row in range(TH):
            offset = (ty+row)*WIDTH+tx
            counts[offset:offset+TW] = raw[row*TW:(row+1)*TW]
    raw_image = bytearray()
    for y in range(HEIGHT):
        raw_image.append(0)
        for value in counts[y*WIDTH:(y+1)*WIDTH]:
            raw_image.extend(rgb(value, state["palette"]))
    image = (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', WIDTH, HEIGHT, 8, 2, 0, 0, 0))
             + chunk(b'IDAT', zlib.compress(raw_image, 9)) + chunk(b'IEND', b''))
    state["last_export"] = api.write_file(f"Mandelbrot_Palette_{state['palette']+1}.png", image)
    state["png_sha256"] = hashlib.sha256(image).hexdigest()
    api.write_file("render_manifest.json", json.dumps({"width": WIDTH, "height": HEIGHT, "tiles": len(state["done"]),
                   "palette": state["palette"], "workers": state["workers"], "rejected": state["rejected"],
                   "duplicates": state["duplicates"], "png_sha256": state["png_sha256"], "N": api.clock()["N"]}, indent=2))


def handle(api, state, event):
    if event["action"] == "palette":
        state["palette"] = (state["palette"]+1)%6
        if len(state["done"]) == TOTAL:
            export(api, state)
    elif event["action"] == "export":
        export(api, state)


def tick(api, state):
    for message in api.receive("tile_result"):
        packet = message["payload"]
        raw = base64.b64decode(packet["data"], validate=True)
        tile = packet["tile"]
        if len(raw) != TW*TH or not 0 <= tile < TOTAL or hashlib.sha256(raw).hexdigest() != packet["sha256"]:
            state["rejected"] += 1
            continue
        if tile in state["done"]:
            state["duplicates"] += 1
        else:
            api.write_file(f"tile_{tile:03d}.bin", raw)
            state["done"].append(tile)
            worker = packet["worker"]
            state["workers"][worker] = state["workers"].get(worker, 0)+1
            # 4 x 2 samples per tile give a cheap live preview without a GUI image dependency.
            state["preview"][str(tile)] = [raw[y*TW+x] for y in (4, 12) for x in (4, 12, 20, 28)]
        api.publish("tile_committed", {"tile": tile, "sha256": packet["sha256"]})
    if len(state["done"]) == TOTAL and state["completed_N"] is None:
        state["completed_N"] = api.clock()["N"]
        api.log("Image complete; assembling PNG from card tiles")
        export(api, state)


def draw(canvas, api, state, width, height):
    global _canvas_image, _image_hash
    canvas.create_text(24, 18, anchor="nw", text=f"MANDELBROT / {len(state['done'])} OF {TOTAL} TILES", fill="#91a4bf", font=("DejaVu Sans", 10, "bold"))
    if state["last_export"]:
        import tkinter as tk
        if _image_hash != state["png_sha256"]:
            raw = api.read_file(state["last_export"].split("__", 1)[1])
            image = tk.PhotoImage(master=canvas, data=base64.b64encode(raw).decode())
            scale = max(1, int(min((width-48)/WIDTH, (height-90)/HEIGHT)))
            _canvas_image = image.zoom(scale, scale)
            _image_hash = state["png_sha256"]
        canvas.create_image(width/2, (height+28)/2, image=_canvas_image)
        canvas.create_text(24, height-25, anchor="nw", text=f"Full 384 x 256 PNG on card    {state['rejected']} rejected    {state['duplicates']} duplicate results    palette {state['palette']+1}", fill="#8ed6e8", font=("DejaVu Sans", 9))
        return
    scale = min((width-48)/48, (height-92)/32)
    ox, oy = (width-48*scale)/2, 52
    for tile, preview in state["preview"].items():
        tile = int(tile)
        tx, ty = tile % 12 * 4, tile // 12 * 2
        for i, value in enumerate(preview):
            color = '#'+''.join(f'{c:02x}' for c in rgb(value, state["palette"]))
            x, y = ox+(tx+i%4)*scale, oy+(ty+i//4)*scale
            canvas.create_rectangle(x, y, x+scale+0.5, y+scale+0.5, fill=color, outline='')
    canvas.create_text(24, height-25, anchor="nw", text=f"{state['rejected']} rejected    {state['duplicates']} duplicate results    palette {state['palette']+1}    PNG {'saved on card' if state['last_export'] else 'pending'}", fill="#8ed6e8", font=("DejaVu Sans", 9))
