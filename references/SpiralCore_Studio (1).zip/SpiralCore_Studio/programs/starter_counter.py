"""Load this example with Load Python. Change it and give it a new id to make another program."""
METADATA = {"id": "counter", "name": "My Counter", "period": 1,
            "description": "A minimal persistent Python program.",
            "actions": [["add", "Add 100"]]}


def init(api):
    return {"count": 0, "started_at": api.clock()["N"]}


def tick(api, state):
    state["count"] += 1


def handle(api, state, event):
    if event["action"] == "add":
        state["count"] += 100
