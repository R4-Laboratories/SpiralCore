"""Tile dispatch, bounded leases and retries, driven by live machine coordinates."""
import math

METADATA = {"id": "dispatch", "name": "Workshop Dispatch", "period": 1,
            "description": "Dispatches image tiles using live CA flux, oscillator sectors and carry valuation. Retries expired work.",
            "subscriptions": ["tile_committed"], "actions": [["start", "Start render"], ["hold", "Hold / continue"]]}
WIDTH, HEIGHT, TW, TH, LIMIT = 384, 256, 32, 16, 160
TOTAL = (WIDTH // TW) * (HEIGHT // TH)


def init(api):
    return {"started": False, "hold": False, "next_tile": 0, "active": {}, "done": [], "sent": 0,
            "retries": 0, "schedule": [], "finished_N": None, "started_N": None}


def handle(api, state, event):
    if event["action"] == "start" and not state["started"]:
        state["started"], state["started_N"] = True, api.clock()["N"]
        api.log("Render started: 192 tiles / 384 x 256 pixels")
    elif event["action"] == "hold":
        state["hold"] = not state["hold"]


def send(api, state, tile, worker, attempt):
    clock, traffic, carry = api.clock(), api.traffic(), api.carry()
    phase_sector = int((clock["phases"][tile % len(clock["phases"])] % math.tau) / math.tau * 16)
    job = {"tile": tile, "x": (tile % (WIDTH // TW)) * TW, "y": (tile // (WIDTH // TW)) * TH,
           "width": WIDTH, "height": HEIGHT, "tw": TW, "th": TH, "limit": LIMIT,
           "worker": worker, "attempt": attempt}
    api.publish("tile_job/" + worker, job)
    state["active"][str(tile)] = {"worker": worker, "attempt": attempt, "lease_until": clock["N"] + 32}
    state["sent"] += 1
    state["schedule"].append([clock["N"], tile, worker, traffic["flux"], phase_sector, carry["v3"], attempt])
    state["schedule"] = state["schedule"][-64:]


def tick(api, state):
    for message in api.receive("tile_committed"):
        tile = message["payload"]["tile"]
        state["active"].pop(str(tile), None)
        if tile not in state["done"]:
            state["done"].append(tile)
    if len(state["done"]) == TOTAL and state["finished_N"] is None:
        state["finished_N"] = api.clock()["N"]
        api.log("All 192 tiles committed")
    if not state["started"] or state["hold"] or state["finished_N"] is not None:
        return
    clock, traffic, carry = api.clock(), api.traffic(), api.carry()
    # Bound new work and retries to two messages per tick. Alternate on expired leases.
    credits = 2
    for tile, lease in list(state["active"].items()):
        if credits and clock["N"] >= lease["lease_until"]:
            send(api, state, int(tile), "worker_b" if lease["worker"] == "worker_a" else "worker_a", lease["attempt"] + 1)
            state["retries"] += 1
            credits -= 1
    while credits and len(state["active"]) < 6 and state["next_tile"] < TOTAL:
        tile = state["next_tile"]
        sector = int((clock["phases"][tile % len(clock["phases"])] % math.tau) / math.tau * 16)
        worker = ("worker_a", "worker_b")[(tile + traffic["flux"] + carry["v3"] + sector) % 2]
        send(api, state, tile, worker, 1)
        state["next_tile"] += 1
        credits -= 1


def draw(canvas, api, state, width, height):
    canvas.create_text(24, 22, anchor="nw", text="COOPERATIVE COMPUTE / TILE DISPATCH", fill="#91a4bf", font=("DejaVu Sans", 10, "bold"))
    canvas.create_text(24, 66, anchor="nw", text=f"{len(state['done'])} / {TOTAL}", fill="#edf3ff", font=("DejaVu Sans", 32, "bold"))
    canvas.create_text(24, 122, anchor="nw", text=f"{len(state['active'])} outstanding    {state['retries']} lease retries    {state['sent']} dispatches", fill="#8ed6e8", font=("DejaVu Sans", 11))
    size = min((width-48)/24, (height-225)/8)
    for i in range(TOTAL):
        x, y = 24 + i % 24 * size, 172 + i // 24 * size
        fill = "#5de2b4" if i in state["done"] else "#e34c98" if str(i) in state["active"] else "#223047"
        canvas.create_rectangle(x, y, x+size-3, y+size-3, fill=fill, outline="")
    canvas.create_text(24, height-28, anchor="nw", text="COMPLETE" if state["finished_N"] is not None else "HOLD" if state["hold"] else "RUNNING" if state["started"] else "Press Start render", fill="#91a4bf", font=("DejaVu Sans", 10))
