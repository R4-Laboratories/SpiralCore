"""The same operational guide is available in the GUI and through /help."""
SECTIONS = {
"start": ("Start here", """SPIRALCORE STUDIO — QUICK START

1. Select Phase Runner in the program drop-down.
2. Press Run. The game and its companion programs open together.
3. Steer with Left/Right or A/D, tap a lane, or use the large arrow buttons.
   Space / Pulse clears nearby red rocks. Collect green signals.
4. For a demonstration, press Auto pilot and then Run.

Run resumes an unfinished flight. After a flight ends, Run saves it and starts
a fresh session/card. Launch / restart restarts the flight on the current card.
Pause machine freezes every program and the shared clock. Pause app pauses only
the selected program's callbacks. Focus view gives the program more screen room;
Escape leaves Focus view. A dropdown selection previews an unopened program;
press Run to open its workspace. Selecting an installed program shows it directly.

PROGRAM SETS
Arcade: Phase Runner, Bell Studio, Flight Journal.
Signals: Signal Courier, Delivery Ledger, Phase Loom.
Compute: Render Canvas, Workshop Dispatch, Worker A and Worker B.
Counter: the editable My Counter example.

Switching sets saves the current machine to its own card and opens the other
set's saved machine. Within a set, programs cooperate on the same ticks and bus.
Changing the selected view does not stop companion programs. State, queues and
clock resume together when returning to a set. Open card can open earlier
console, arcade, workshop and continuity block cards with saved program state.
Kernel-only loop cards remain readable in the earlier loop runtime.

Human views: Program, Telemetry, Files, Work, Help and Console tabs.
The Console tab retains command responses; they are not squeezed into the footer.
Use /help commands, /help memory, /help programming, or /help telemetry.
"""),
"commands": ("Commands", """COMMANDS — slash is optional; quote paths or program names containing spaces.

PROGRAMS
  /programs                    Installed programs and the built-in catalog.
  /run [id or name]            Open the correct workspace and start/resume.
  /run "Phase Runner"         Start/resume the game.
  /show id                    View an already installed program.
  /pause id                   Pause that program's callbacks.
  /stop id                    Alias for /pause id.
  /event id action [text]      Call its handle(api, state, event) function.
  /source [id]                Read the actual saved source or catalog source.
  /load "path/program.py"     Install a Python program into this workspace.
  /editor                     Open the native program editor (GUI).

MACHINE
  /pause                      Freeze the shared machine clock.
  /resume                     Resume the clock without restarting a program.
  /step [count] [payload]     Pause, then step 1..243 ticks; default payload 1.
  /fold                       Pause and advance up to 27 ticks seeking a fold.
  /speed seconds              Set interval, clamped to 0.05..5 seconds.
  /new                        Save the old card; fresh state, installed code kept.
  /reset                      Same as /new in Studio.
  /workspace                  Active set, save directory and remembered card paths.

MEMORY / FILES
  /files or /dir              List actual stored files and sizes.
  /card                       Card allocation and file telemetry.
  /upload "path/file.bin"     Data upload: compress/store, route ingress, step once.
  /upload                     Open the data picker (GUI).
  /retrieve "name" "outpath" Verify/decode a card file to an ordinary file.
  /export "name" "outpath"   Same operation; filenames can include program prefixes.
  /savecard [path.spmc]       Save the complete machine and task record.
  /checkpoint [path.spmc]     Same as /savecard.
  /restore "path.spmc"       Open complete saved state, paused.
  /loadcard "path.spmc"      Same as /restore.
  /fork [path.spmc]           Branch the current state into a separate card.
  /audio [path.wav]           Export the runtime's recent Bell tone history.

OBSERVATION / CONTINUITY
  /telemetry or /status       Studio's readable structured live snapshot.
  /cf, /ca                   Original CA/counterfactual report.
  /net, /router              Original internal routing/Bell selection report.
  /work                      Task objective, evidence checks, next action and binding.
  /audit                     Recent original command/step audit.
  /sample [name]             Original sample-data upload; advances one tick.
  /pysr                     Original symbolic-basis/discovery-hook report.
  /help [topic]              This guide; /information is an alias.

Use Files buttons for uploads/exports on a phone. Studio accepts quoted paths
without passing them through a system shell. Run is the application launcher;
/resume is the clock-only command. Original kernel commands remain available.
"""),
"memory": ("Memory & uploads", """MEMORY — THREE RELATED KINDS OF STATE

1. CARRY / PHASE RECALL
Every machine step adds a root with the payload value, one memory contribution,
and a copy of the current per-core phase vector. Ternary carry folds combine
phase sums and contribution counts and average root values. The memory field
normalizes the retained phase sums, rotates them by the current clock and feeds
the original recall torque into think(). Telemetry shows roots, contributions,
recall gain and field magnitudes. A root is not a byte-for-byte file copy.

2. PROGRAM STATE
Each program owns a JSON-serializable state dictionary, mailbox, running flag,
tick count and source hash. Programs share a next-tick message bus. The current
workspace has a 32 KiB program checkpoint allowance, including its bus/log data.
Store large outputs with write_file(), not giant state dictionaries. Programs
in another workspace are saved in that workspace's complete card, not erased.

3. CARD FILES AND CHECKPOINTS
The 8 MiB card is exactly 8,388,608 bytes: 1024 blocks × 8192 bytes.
  Block 0: header; blocks 1..31: directory and allocation metadata.
  Blocks 32..671: ten end-of-loop checkpoints, 64 blocks (512 KiB) each.
  Blocks 672..735: latest resume checkpoint, 64 blocks (512 KiB).
  Blocks 736..1023: user-file region, 288 blocks (2.25 MiB).
User-file space is the sum of encoded stored files, not just original file sizes.
The directory and checkpoint slots have their own finite allocations.

Each 10,000 ticks closes a loop and writes an automatic disk checkpoint. The
clock continues; its loop-local counter returns to zero. After ten full loops
(100,000 ticks) the recorder pauses. New session creates a fresh card. Open card
restores source, program state, queues, CA rows, oscillator/carry state, router,
audio history and trace. Restore is paused; saved downtime is excluded.
Save card also includes the explicit task record and execution binding.

WHAT GOES WHERE — AND WHAT CHANGES

Upload data (/upload)
  Stores the original bytes through SystemLawCodec in /user/files/<basename>.
  Computes greybox metrics; image decoding is used when optional image libraries
  are available, otherwise the deterministic byte-to-RGB fallback is used.
  Routes an ingress record and takes ONE original CPU step. Its root payload
  is max(0.1, luminance_mean). The original step then updates carry, phases,
  CA histories, routing and running programs. Uploading .py as data stores bytes;
  it does not install or run the program. Use Load Python for that.
  Studio refuses an existing name so an upload cannot silently replace evidence.

Load Python (/load)
  Compiles a program requiring METADATA and tick(). Calls init(), saves its
  source as program_<hash>.py on the card, and installs its state. It takes
  no machine tick. Callbacks are enabled for subsequent running-machine ticks;
  Run also resumes the clock. Loading source itself executes normal
  Python module definitions and init(). Give every custom program a unique ID.

Program write_file(name, bytes/text)
  Writes /user/files/<program_id>__<basename>. It takes no extra machine tick.
  The prefix separates programs' output names. Call save/checkpoint to persist
  the card on disk; writing a card file alone changes the in-memory card.

Work record / Attach evidence
  Copies the attached bytes under evidence_<hash>_<name>, records a SHA-256
  and byte count, and saves the task/card. No CPU step is added. Observed,
  reported and hypothetical claims keep their provenance. Hashes verify bytes;
  a claim's meaning remains a review item. Editing wording retains old/new values
  and a reason in revision history. Record limit: 64 KiB, in user-file storage.

Open card
  Replaces the active machine only after its saved state validates. It restores
  a whole checkpoint rather than adding an ordinary file. The old dirty card is
  saved first. Branch before editing a supplied handoff you want to preserve.

Export / retrieve
  Decodes and verifies stored bytes, including the codec's particle accounting
  and SHA-256, then writes an ordinary external file. It adds no machine tick.
  Exporting a PNG, CSV or WAV does not replace the whole card.

CA 184 CROSS-CHECK
The forward and counterfactual rows each retain their initial particle count;
their sum stays equal to the row width. Studio keeps that check visible beside
the clock. Opening telemetry/help/files is observational and adds no tick.
Uploading contributes a normal step; it does not directly inject file bits into
the live CA row. File-codec verification and live CA conservation are both shown
with their actual meaning. The original CA update and coupler equations remain.
"""),
"programming": ("Write programs", """PROGRAMMING THE MACHINE

Open New Python, or load a .py file from Files. A minimal program:

METADATA = {"id": "mycounter", "name": "My New Counter", "period": 1,
            "actions": [["add", "Add 100"]]}

def init(api):
    return {"count": 0}

def tick(api, state):
    state["count"] += 1

def handle(api, state, event):
    if event["action"] == "add":
        state["count"] += 100

Load it, then choose My New Counter and press Run. period is 1..10000 machine
ticks between callbacks. State is JSON-serializable; modules are ordinary Python.
Keep callbacks short because the scheduler and native GUI share one process.
A callback error pauses that program and appears in the status and Telemetry.

OPTIONAL DISPLAY AND CONTROLS
  draw(canvas, api, state, width, height) draws on the native Tkinter Canvas.
  METADATA['actions'] is a list of [action_id, button_label]. handle receives it.
  METADATA['subscriptions'] lists message topics.
  KEYS = {'Left':'left', 'space':'pulse'} maps foreground keyboard input.
  POINTER = True opts into handle events with action='pointer', normalized x/y.
  Editing/command text keeps keyboard focus; game keys don't capture typed text.
  Inspect a working example with Source or /source runner.

SYSTEM SERVICES
  api.clock()       N, loop_tick, loops, time_s, R, phases, phase_rad.
  api.carry()       roots, contributions, v3, values.
  api.traffic()     live forward/CF rows, particles, flux, Bell pair and address.
  api.publish(topic, payload)  Send a JSON envelope for delivery NEXT tick.
  api.receive(topic=None)     Consume received messages.
  api.write_file(name, data)  Store bytes or UTF-8 text under the program prefix.
  api.read_file(name)         Read that program's file as bytes.
  api.record_tone(pair=None)  Add a Bell tone to the runtime's audio history.
  api.log(text)              Append a console event.

Messages are limited to 2 KiB each; inbox and outbox queues hold up to 32 items.
Pausing only a receiver leaves the clock and publishers running: consume its
mailbox when resuming, or pause the whole machine to freeze cooperating work.
Use separate topics for separately addressed workers, as the compute example does.

Persistent values belong in state. Large binary data belongs in card files.
Source, state and queues are saved with the card; restore recompiles the saved
source. The native examples use only Python's standard library. A custom import
needs to exist in your Python environment after a restore too.

The built-in renderer computes the Mandelbrot equation in worker Python code;
machine phase/traffic/carry coordinates choose work assignments. Phase Runner's
game rules are application code reading the same live services.
"""),
"telemetry": ("Read telemetry", """READING THE LIVE INSTRUMENTS

Machine: N is total ticks, loop-local tick is N modulo 10000. Running is the
shared clock switch. Saved/unsaved compares current machine, programs and task
record with the latest disk checkpoint. The card path identifies this workspace.

CA 184: forward and counterfactual particle counts, expected counts, width and
current 1→0 flux. Green means both counts and their combined width match. The
space-time rows are the actual recorded histories. CA 110 and 30 are available
in the original /cf report and raw telemetry; they are separate update rules.

Clock: R is the Kuramoto order parameter; phases are the actual oscillator
coordinates. Time and drift are the runtime's clock values. Live launches use
the wall-clock source. Fixed_dt appears when opening a deterministic demo card.
R alone is one scalar summary of the phase state; the phase list remains visible.

Carry: root count, retained contribution count, valuation v3(N), memory gain,
recall enable flag and field magnitudes describe the current recall machinery.

Programs: running/paused, callbacks executed, inbox sizes, errors and total JSON
state bytes. The selected program is a view choice; its companions can keep
running. Different workspace sets have their own complete cards and clocks.

Storage: user-file usage/capacity, file count, checkpoint slots and physical card
allocation. Source, task record, evidence and output files share the user region.

Routing/audio: current internal destination address, Bell frequency pair,
ingress/egress counts and recorded tones. These are the runtime's virtual routing
records. WAV exports contain synthesized/recorded audio data.

Work: task title, status, revision, evidence hashes and whether the saved record
still matches current execution. Advancing or editing the machine can make it
dirty; Save card creates the next consistent task/execution checkpoint.

The dashboard refreshes while visible. Choose Summary for human labels and
per-program status, or Raw JSON for every coordinate. The snapshot can be copied/exported as
JSON. Opening the dashboard or requesting /telemetry does not itself step N.
"""),
"pydroid": ("Pydroid3 & files", """PYDROID3 / PHONE START

Open the single SpiralCore_Studio.py file in the Python environment you already
use for the native runtime and press its run control. The game, catalog, manual
and modules are embedded in that file. Tkinter support is required, as before.
Studio adds no required external packages. Optional existing image libraries
can still be used by the original upload analyser.

Choose Phase Runner → Run. Use the on-screen arrows/pulse or tap a lane.
Focus view hides extra controls for more play space. Escape or Exit focus
brings them back. The layouts wrap as the window gets narrower.

The default save folder is SpiralCore_Saves beside the script. If that folder
cannot be written, Studio uses a SpiralCore_Saves folder under the Python home
directory. The active directory and card path appear in Files and /workspace.
Use Save as to choose another writable location. Android's file access must
allow the script to read/write the selected directory. File dialogs are provided
by the same Tkinter environment as the existing runtime.

sessions.json remembers which card belongs to each workspace and the last
workspace used. The complete execution is in each .spmc, not in that index.
Open card can recover a card directly even if the index is unavailable.

Use Files → Upload data for data, Load Python for code, Open card for a machine,
and Work → Edit record → Attach file for evidence. Use Export selected to save
a PNG, SVG, CSV or WAV outside the card. The Bell Studio WAV is a short event
score; its Export WAV action writes a card file, which Files can then export.

The frozen source and previous editions are retained in the full package as
references/examples. Startup restores the last card paused. Press Run to continue.
On a first launch, Phase Runner is ready to run; no command typing is needed.
"""),
}


def help_text(topic="start"):
    topic=str(topic).strip().lower()
    aliases={"all":"all","program":"programming","programs":"programming","code":"programming","upload":"memory",
             "uploads":"memory","files":"memory","card":"memory","memory system":"memory","phone":"pydroid",
             "command":"commands","info":"start","phase runner":"start"}
    topic=aliases.get(topic,topic)
    if topic=="all":return "\n\n".join(text for title,text in SECTIONS.values())
    if topic not in SECTIONS:
        return "Unknown help topic. Available: "+", ".join(SECTIONS)+"\n\n"+SECTIONS["start"][1]
    return SECTIONS[topic][1]
