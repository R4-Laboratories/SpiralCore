"""Saved workspaces for the program picker. Each card retains a complete machine."""
import json
import os
from pathlib import Path
import tempfile

from catalog import BY_ID, GROUPS, group_for_apps, resolve
from studio_runtime import StudioRuntime


class Launcher:
    def __init__(self, runtime, directory):
        self.runtime=runtime;self.directory=Path(directory).resolve()
        self.directory.mkdir(parents=True,exist_ok=True)
        self.index_path=self.directory/"sessions.json"
        self.paths={};self.current="arcade";self.notice=""
        if self.index_path.exists():
            try:
                data=json.loads(self.index_path.read_text())
                if not isinstance(data.get('paths'),dict) or not isinstance(data.get('current'),str):raise ValueError('Invalid session index')
                if not all(isinstance(k,str) and isinstance(v,str) for k,v in data['paths'].items()):raise ValueError('Invalid card paths')
                self.paths=data["paths"];self.current=data["current"]
            except (ValueError,KeyError,TypeError):self.notice="Session index could not be read; card files remain available through Open card."

    def remember(self):
        self.paths[self.current]=self.runtime.autosave_path
        payload=json.dumps({"current":self.current,"paths":self.paths},indent=2)
        with tempfile.NamedTemporaryFile(mode="w",dir=self.directory,prefix="session-",suffix=".tmp",delete=False) as handle:
            handle.write(payload);temporary=handle.name
        try:os.replace(temporary,self.index_path)
        finally:
            if os.path.exists(temporary):os.unlink(temporary)

    def fresh(self, group):
        candidate=StudioRuntime()
        candidate.autosave_path=candidate._new_card_path(self.directory)
        candidate.step_interval_sec=0.12
        for _ in range(3):candidate.step(label="BOOT")
        candidate.execute_command("/sample")
        candidate.install_group(group)
        candidate.foreground=GROUPS[group][0]
        candidate.auto_step_enabled=False
        return candidate

    def commit(self, candidate):
        self.runtime.__dict__.clear();self.runtime.__dict__.update(candidate.__dict__)
        self.runtime.programs.runtime=self.runtime;self.runtime.work.runtime=self.runtime

    def startup(self, load=None, card=None):
        if load:
            self.runtime.load_checkpoint(load);self.current=group_for_apps(self.runtime.programs.apps)
        elif card:
            self.commit(self.fresh("arcade"));self.runtime.autosave_path=str(Path(card).resolve());self.current="arcade"
        elif self.current in self.paths and Path(self.paths[self.current]).is_file():
            try:self.runtime.load_checkpoint(self.paths[self.current])
            except Exception as exc:
                self.notice=f"Previous card could not be opened: {exc}. Its file was preserved."
                self.commit(self.fresh("arcade"));self.current="arcade"
        else:self.commit(self.fresh("arcade"));self.current="arcade"

    def save(self, path=None):
        result=self.runtime.save_checkpoint(path);self.remember();return result

    def run(self, pid):
        pid=resolve(pid)
        if pid not in self.runtime.programs.apps:
            if pid not in BY_ID:raise ValueError("Unknown program")
            group=BY_ID[pid]["group"]
            # Validate the destination before saving or replacing the current machine.
            if group in self.paths and Path(self.paths[group]).is_file():
                candidate=StudioRuntime();candidate.load_checkpoint(self.paths[group]);candidate.install_group(group)
            else:candidate=self.fresh(group)
            self.save();self.commit(candidate);self.current=group
        if pid=="runner" and self.runtime.programs.apps[pid]["state"]["status"] in ("complete","over"):
            self.new_session()
        result=self.runtime.run_program(pid);self.save();return result

    def open(self,path):
        candidate=StudioRuntime();candidate.load_checkpoint(path)
        if self.runtime.dirty:self.save()
        self.commit(candidate);self.current=group_for_apps(self.runtime.programs.apps);self.remember()

    def new_session(self):
        self.save();self.runtime.new_session();self.runtime.auto_step_enabled=False
        self.runtime.step_interval_sec=0.12;self.save()

    def branch(self,path=None):
        result=self.runtime.fork_card(path);self.remember();return result

    def execute(self, command):
        import shlex
        from manual import help_text
        parts=shlex.split(command)
        if not parts:return {"view":"console","output":""}
        verb=parts[0].lower().lstrip("/");rest=parts[1:]
        view="console";topic=None
        if verb in ("help","h","?","information"):
            topic=" ".join(rest) or "start";output=help_text(topic);view="help"
        elif verb in ("run","play"):
            output=self.run(" ".join(rest) if rest else self.runtime.foreground);view="program"
        elif verb in ("checkpoint","savecard"):
            output=json.dumps(self.save(" ".join(rest) or None),indent=2)
        elif verb in ("restore","loadcard"):
            if not rest:raise ValueError("/restore needs a card path")
            self.open(" ".join(rest));output=f"Restored tick {self.runtime.N}; paused";view="program"
        elif verb=="fork":output=json.dumps(self.branch(" ".join(rest) or None),indent=2)
        elif verb in ("new","reset"):
            self.new_session();output="New session created; previous card saved";view="program"
        elif verb=="workspace":
            output=json.dumps({"active":self.current,"directory":str(self.directory),"saved_workspaces":self.paths},indent=2)
        elif verb=="source":
            from console_builtin_sources import SOURCES
            pid=resolve(" ".join(rest)) if rest else self.runtime.foreground
            if pid in self.runtime.programs.apps:
                app=self.runtime.programs.apps[pid]
                output=self.runtime.memory_card.retrieve_compressed_file(app["source_file"])[0].decode()
            elif pid in BY_ID:output=SOURCES[BY_ID[pid]["file"]]
            else:raise ValueError("Unknown program")
            view="source"
        else:
            if verb=="stop" and rest:command="/pause "+" ".join(rest)
            output=self.runtime.shell(command)
            if verb in ("telemetry","status","cf","ca","counterfactual","net","route","router","vsocket"):view="telemetry"
            if verb in ("files","dir","card"):view="files"
            if verb=="work":view="work"
        return {"view":view,"topic":topic,"output":output}
