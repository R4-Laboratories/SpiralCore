# SpiralCore Studio

Open **SpiralCore_Studio.py** in the same Pydroid3/Tkinter environment as the existing runtime. Press Python's Run control, select **Phase Runner**, then press the pink **Run** button. Everything needed by the built-in programs is embedded in this single file. Studio adds no required external packages.

Steer with the on-screen Left/Right buttons, tap a lane, or use arrow keys / A / D. Pulse or Space fires. Auto pilot demonstrates the game. **Focus view** gives it more room; Exit focus or Escape restores the controls. Run resumes an unfinished flight; after a flight ends it preserves that card and starts a fresh session.

## What is new

- One program picker with Run: Phase Runner, Bell Studio, Flight Journal, Signal Courier, Delivery Ledger, Phase Loom, Render Canvas, Workshop Dispatch, two workers and My Counter.
- Four saved workspaces: arcade, signals, compute and counter. Switching sets saves the full current machine and restores the chosen set. Companions in a set share ticks and messages. Opening a view does not pause its companions.
- Program, Telemetry, Files, Work, Help and Console tabs. Telemetry offers human summaries, actual CA 184 histories, per-program status, raw JSON and an export button. The CA 184 particle conservation check stays visible.
- Separate Upload data, Load Python, Open card, Attach evidence and Export actions. The memory guide explains exactly what each changes.
- Searchable in-app help for commands, the complete memory layout, programming APIs, telemetry and phone use. `/help programming` includes a working example. Source opens the selected program's Python; Files → New Python opens an editable starter.
- Wrapping controls, scrollable forms and a Focus view for narrower windows. Full command replies remain available in Console, with export and command history on Up/Down.

## Cards and safe exploration

Save card writes the whole machine, source, JSON program state, queues, files and task record to an exact 8 MiB `.spmc`. Open card validates it, saves the old dirty machine, and restores the selected card paused. Branch creates a separate continuation; New session saves the old card and resets state while retaining its installed code.

The default folder is `SpiralCore_Saves` beside the script. If unwritable, a folder with that name under Python's home directory is used. Files and `/workspace` show the actual paths. `sessions.json` remembers the current card for each workspace; execution state remains inside each card. You can recover directly with Open card without the index. Save as selects a different card path.

The recorder still closes and automatically saves every 10,000 ticks, retaining ten full loops. The original CA updates, carry, coupler and oscillator equations are unchanged. `spiralcore_kernel.py` is byte-identical to the prior continuity edition; the original supplied runtime is retained as `Spiralcore_Runtime_v6_3_FROZEN.py`.

| Action | Destination | Machine ticks |
| --- | --- | --- |
| Upload data | Original bytes compressed under `/user/files/<name>`; original greybox analysis and router ingress | One normal tick |
| Load Python | Source hash/file plus program registration and `init()` state | Zero; callbacks enabled on subsequent running ticks |
| Program `write_file()` | `/user/files/<program_id>__<name>` | No extra tick |
| Attach evidence | Hashed file plus explicit Work record reference/checkpoint | Zero |
| Open card | Complete validated machine replacement, paused | Zero added ticks |
| Export selected | Verified, decoded ordinary output file | Zero |

Uploading `.py` as data does not install it. Load Python executes normal Python module definitions and `init()`. Uploading a `.spmc` is refused; use Open card. Duplicate data filenames are refused so uploads cannot silently overwrite existing evidence. Program outputs retain their program prefix and can intentionally update that program's own output.

## Write programs

Use Files → New Python. Give the starter a unique `METADATA['id']`, implement `tick(api,state)`, and keep persistent JSON data in `state`. The editor's Load program button installs it into the current workspace; choose it and press Run. Source, state and queues are checkpointed together.

Services include `clock()`, `carry()`, `traffic()`, `publish()/receive()`, `write_file()/read_file()`, `record_tone()` and `log()`. A program may provide `draw(canvas,api,state,width,height)`, action buttons, keyboard mappings and pointer handling. The help guide includes signatures, queue limits and examples. Large outputs belong in card files; the combined program-state checkpoint allowance is 32 KiB per workspace. Custom imports must also exist when restoring that program.

## Included files

- `SpiralCore_Studio.py`: self-contained native application, about 296 KB.
- `SpiralCore_Guide.md`: the same operational guide used by in-app help.
- Readable modules, `programs/`, and `build_standalone.py` to rebuild the single-file application.
- `examples/Flight_Midway.spmc`, `Render_Complete.spmc`, `Signals.spmc`: working demonstration cards.
- `examples/Handoff.spmc` and `Resume_Here.md`: the previous continuity task example.
- `evidence/`: integration, compatibility, native GUI observations and representative outputs.

To preserve a supplied example, copy it first or use Branch after opening it. Merely selecting a catalog entry previews it; Run opens the workspace. Programs loaded into a workspace run alongside that workspace's companions.

## Execution checks

The self-contained build was executed headlessly and with native Linux Tkinter 8.6. Checks covered manual game input, program picker/workspace switching, the native render, help, Files, telemetry, narrow layout/Focus view, task editor save/reopen, 192 completed render tiles, 15 verified signal deliveries, source loading, one-step uploads, unchanged observation state and complete card/queue restoration. Console, Arcade, Workshop and Continuity cards loaded without modifying their source cards. The unchanged kernel's clock/carry/CA results also matched a separate instance over 81 steps.

Pydroid3/Android was not available for a device test. Studio uses the existing native Tkinter stack, has no new required packages, and was checked at narrower window widths; Android file permissions and the installed Tkinter environment still govern local paths and dialogs.

## Optional command-line use

```text
python SpiralCore_Studio.py
python SpiralCore_Studio.py --load examples/Flight_Midway.spmc
python SpiralCore_Studio.py --data-dir /a/writable/folder
python SpiralCore_Studio.py --demo /a/new/demo-folder
python SpiralCore_Studio.py --inspect examples/Handoff.spmc
```

`--load` restores paused. `--card` chooses a new card and refuses an existing path. The existing `--inspect`, `--continue-card`, `--export-card` and `--outdir` continuity modes remain. `--demo` needs a new output directory and produces actual computed outputs/cards and `Validation.json`.
