"""Native task record editor; execution and files remain in the shared card."""
import json
from pathlib import Path


def open_work_record(root, runtime, status_callback):
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog, ttk

    bg, panel, ink, accent = "#090d16", "#111a29", "#edf3ff", "#e34c98"
    win = tk.Toplevel(root)
    win.title("SpiralCore — Work record")
    win.configure(bg=bg)
    win.geometry(f"{min(960,root.winfo_screenwidth()-40)}x{min(780,root.winfo_screenheight()-60)}")
    win.minsize(440,500)
    header = tk.StringVar()
    tk.Label(win, text="WORK CONTINUITY", bg=bg, fg=ink, font=("DejaVu Sans", 19, "bold"), pady=12).pack(fill="x")
    tk.Label(win, textvariable=header, bg=bg, fg="#8ed6e8", font=("DejaVu Sans Mono", 10), pady=5, wraplength=420).pack(fill="x")
    notebook = ttk.Notebook(win)
    notebook.pack(fill="both", expand=True, padx=14, pady=10)
    pages=[]
    for title in ("Task","Claims & plan","Evidence","Revision history"):
        outer=tk.Frame(notebook,bg=panel);notebook.add(outer,text=title)
        view=tk.Canvas(outer,bg=panel,highlightthickness=0)
        scroll=ttk.Scrollbar(outer,command=view.yview);view.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right",fill="y");view.pack(fill="both",expand=True)
        page=tk.Frame(view,bg=panel,padx=12,pady=8)
        item=view.create_window((0,0),window=page,anchor="nw")
        page.bind("<Configure>",lambda event,v=view:v.configure(scrollregion=v.bbox("all")))
        view.bind("<Configure>",lambda event,v=view,i=item:v.itemconfigure(i,width=event.width))
        pages.append(page)
    task,claims,evidence,history=pages
    fields = {}

    def label(parent, text):
        tk.Label(parent, text=text, bg=panel, fg="#91a4bf", anchor="w", justify="left", wraplength=400, font=("DejaVu Sans", 10, "bold")).pack(fill="x", pady=(8,3))

    def box(parent, value, height):
        widget = tk.Text(parent, height=height, bg="#172337", fg=ink, insertbackground=accent,
                         font=("DejaVu Sans Mono", 10), wrap="word", relief="flat", padx=8, pady=6)
        widget.insert("1.0", value)
        widget.pack(fill="x")
        return widget

    for key, title, height in (("title","Task title",1),("objective","Objective",3),
                                ("constraints","Constraints — one per line",3),
                                ("decisions","Decisions — one per line",3),("questions","Open questions — one per line",3)):
        label(task,title)
        value=runtime.work.record[key]
        fields[key]=box(task,"\n".join(map(str,value)) if isinstance(value,list) else value,height)
    label(task,"Reason for this revision")
    reason=box(task,"Update the task record from the native editor",1)
    label(claims,"Claims retain their kind: observed, reported, or hypothesis; evidence uses IDs from the Evidence tab.")
    fields["claims"]=box(claims,json.dumps(runtime.work.record["claims"],indent=2),8)
    for key,title,height in (("next_action","Next action — inspect or bounded advance_until",5),
                              ("deliverables","Deliverables — card path and output filename",4),
                              ("acceptance","Acceptance checks against attached reference evidence",4)):
        label(claims,title)
        fields[key]=box(claims,json.dumps(runtime.work.record[key],indent=2),height)
    evidence_list=tk.Listbox(evidence,bg="#172337",fg=ink,font=("DejaVu Sans Mono",10),relief="flat",height=16)
    evidence_list.pack(fill="both",expand=True,pady=8)
    history_text=box(history,"",25)
    history_text.pack_configure(fill="both",expand=True)

    def refresh():
        overview=runtime.work.overview()
        verified=sum(e["status"]=="verified" for e in overview["evidence"])
        header.set(f"{overview['status'].upper()}  ·  tick {runtime.N:,}  ·  revision {overview['revision']}  ·  evidence {verified}/{len(overview['evidence'])} verified")
        evidence_list.delete(0,"end")
        for item,result in zip(runtime.work.record["evidence"],overview["evidence"]):
            evidence_list.insert("end",f"{item['id']}  {result['status'].upper()}  {Path(item['path']).name}")
            evidence_list.insert("end",f"    {item['description']}")
            evidence_list.insert("end",f"    {item['bytes']:,} bytes · SHA-256 {item['sha256']}")
        history_text.configure(state="normal");history_text.delete("1.0","end")
        history_text.insert("1.0",json.dumps(runtime.work.record["history"],indent=2));history_text.configure(state="disabled")

    def guard(callback):
        try:
            callback()
            if win.winfo_exists():refresh()
        except Exception as exc:
            messagebox.showerror("Work record",str(exc),parent=win)

    def read_changes():
        changes={}
        for key,widget in fields.items():
            raw=widget.get("1.0","end-1c").strip()
            if key in ("claims","next_action","deliverables","acceptance"):
                changes[key]=json.loads(raw)
            elif key in ("constraints","decisions","questions"):
                changes[key]=[line.strip() for line in raw.splitlines() if line.strip()]
            else:
                changes[key]=raw
        return changes

    def save():
        runtime.work.revise(read_changes(),reason.get("1.0","end-1c").strip())
        runtime.save_checkpoint()
        status_callback("Task record and execution checkpoint saved together")

    def attach():
        path=filedialog.askopenfilename(parent=win,title="Attach an evidence file")
        if not path:return
        raw=Path(path).read_bytes()
        import hashlib
        name="evidence_"+hashlib.sha256(raw).hexdigest()[:12]+"_"+Path(path).name
        description=simpledialog.askstring("Evidence","Describe what this file records:",parent=win,initialvalue=Path(path).name)
        if description is None:return
        runtime.memory_card.store_compressed_file(name,raw,{})
        runtime.work.add_evidence(name,description)
        runtime.save_checkpoint()

    def export():
        path=filedialog.askdirectory(parent=win,title="Export a task handoff")
        if path:
            save()
            runtime.work.export_handoff(path)
            status_callback("Exported Handoff.spmc, Resume_Here.md, task record and hashes")

    def advance():
        changes=read_changes()
        runtime.auto_step_enabled=False
        runtime.fork_card()
        runtime.work.revise(changes,reason.get("1.0","end-1c").strip())
        result=runtime.work.continue_action()
        runtime.save_checkpoint()
        status_callback("Task continuation: "+json.dumps(result)[:180])

    def button(parent,title,callback):
        widget=tk.Button(parent,text=title,command=lambda:guard(callback),bg="#223047",fg=ink,relief="flat",
                  font=("DejaVu Sans",10),padx=10,pady=8)
        widget.pack(side="left",padx=4)
        return widget

    row=tk.Frame(evidence,bg=panel);row.pack(fill="x",pady=8)
    button(row,"Attach file",attach)
    label(evidence,"Hashes verify the attached bytes. Claim provenance and open questions remain explicit in the task record.")
    buttons=tk.Frame(win,bg=bg,pady=12);buttons.pack(before=notebook,side="bottom",fill="x",padx=12)
    controls=[button(buttons,title,callback) for title,callback in
              (("Save record + card",save),("Export handoff",export),("Continue on a branch",advance),("Refresh checks",lambda:None),("Close",win.destroy))]
    for widget in controls:widget.pack_forget()
    def layout(event=None):
        columns=2 if buttons.winfo_width()<720 else 5
        for col in range(5):buttons.columnconfigure(col,weight=1 if col<columns else 0)
        for i,widget in enumerate(controls):widget.grid(row=i//columns,column=i%columns,sticky="ew",padx=3,pady=3)
    buttons.bind("<Configure>",layout)
    layout()
    refresh()
    return win
