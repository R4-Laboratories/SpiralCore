#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/credit-green1"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1
export MVM_HOME="$q/credit-green1-state"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-fc.XXXXXX)
mkdir -m700 "$MVM_HOME"
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
cd "$q/flowmux-credit-mvm-work"
source scripts/dev-env.sh
sha256sum -c "$q/credit-green1-inputs.sha256" > "$out-inputs-before.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-before.sha256"
cmp "$q/credit-green1-inputs.sha256" "$out-file-set-before.sha256"
systemctl --user show sc-credit-green1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
rustc -Vv > "$out-toolchain.txt"
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline -p mvm-hostd --lib --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
python3 - "$out" <<'PY'
import hashlib,json,pathlib,sys
out=sys.argv[1]
rows=[json.loads(line) for line in pathlib.Path(out+'-build.jsonl').read_text().splitlines()]
tests=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('profile',{}).get('test') and r.get('target',{}).get('name')=='mvm_hostd' and r.get('executable')]
assert len(tests)==1
binary=pathlib.Path(tests[0]['executable'])
pathlib.Path(out+'-test-path.txt').write_text(str(binary)+'\n')
pathlib.Path(out+'-executable-before.sha256').write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'  '+str(binary)+'\n')
PY
binary=$(cat "$out-test-path.txt")
selector=supervisor::endpoint::flowmux::credit_tests::returned_upload_credit_keeps_the_session_validator_current
"$binary" --exact "$selector" --list > "$out-selector.txt"
test "$(head -1 "$out-selector.txt")" = "$selector: test"
set +e
/usr/bin/time -v -o "$out-test-time.txt" "$binary" --exact "$selector" --nocapture --test-threads=1 > "$out-tests.txt" 2>&1
rc=$?
set -e
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt" || rc=90
sha256sum -c "$q/credit-green1-inputs.sha256" > "$out-inputs-after.txt" || rc=90
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-after.sha256"
cmp "$q/credit-green1-inputs.sha256" "$out-file-set-after.sha256" || rc=90
printf '%s\n' "$rc" > "$out-exit.txt"
exit "$rc"
