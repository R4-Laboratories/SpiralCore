#[allow(dead_code)]
#[path = "/var/tmp/sc-direct-flowmux.iptmjZre/admitted-credit-mvm-work/xtask/src/rust_source.rs"]
mod rust_source;
#[allow(dead_code)]
#[path = "/var/tmp/sc-direct-flowmux.iptmjZre/admitted-credit-mvm-work/xtask/src/check_rust_footprint.rs"]
mod check_rust_footprint;
fn main() -> anyhow::Result<()> {
    let root = std::env::args_os().nth(1).expect("explicit source root");
    check_rust_footprint::run(std::path::Path::new(&root))
}
