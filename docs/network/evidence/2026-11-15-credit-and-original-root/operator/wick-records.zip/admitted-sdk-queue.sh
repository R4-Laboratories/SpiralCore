#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/admitted-sdk-queue"
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"' EXIT
for ((attempt=0; attempt<1080; attempt++)); do
 if ! systemctl --user is-active --quiet sc-admitted2-mvm-full; then
  test "$(cat "$q/admitted2-mvm-full-exit.txt")" = 0
  python3 - "$q" <<'PY'
from pathlib import Path
import json,sys
q=Path(sys.argv[1]);r=json.loads((q/'admitted2-mvm-full-runtime-executable-set.json').read_text())
assert r=={'expected':284,'running_lines':284,'unique_executed':284,'exact_match':True},r
for name,n in [('executables-after',284),('inputs-after',4717)]:
 lines=(q/f'admitted2-mvm-full-{name}.txt').read_text().splitlines()
 assert len(lines)==n and all(x.endswith(': OK') for x in lines),(name,len(lines))
PY
  systemd-run --user --unit=sc-admitted-sdk-final --collect -p MemoryMax=6G -p MemorySwapMax=0 -p CPUQuota=200% -p TasksMax=512 /bin/bash "$q/admitted-sdk-final.sh"
  echo ADMITTED_SDK_STARTED_AFTER_VERIFIED_MVM_TERMINAL
  exit 0
 fi
 sleep 5
done
echo 'qualification still active after bounded queue observation' >&2
exit 75
