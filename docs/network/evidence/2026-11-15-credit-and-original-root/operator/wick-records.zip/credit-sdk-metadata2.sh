#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/credit-sdk-metadata2"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_NET_GIT_FETCH_WITH_CLI=true
cd "$q/credit-sdk-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
systemctl --user show sc-credit-sdk-metadata2 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
while read -r label manifest features; do
  args=(--format-version=1 --manifest-path "$manifest")
  if [ "$features" != '-' ]; then args+=(--features "$features"); fi
  cargo metadata --locked --offline "${args[@]}" > "$q/credit-sdk2-$label-metadata.json" 2> "$q/credit-sdk2-$label-metadata.stderr"
done <<EOF
live crates/spiralcore-mvm-live/Cargo.toml canonical-host
adapter crates/spiralcore-mvm-adapter/Cargo.toml live,conformance,hardware-sha256
journal crates/spiralcore-mvm-journal-host/Cargo.toml -
owner crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml -
supervisor crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml -
witness tools/installed-flowmux-witness/Cargo.toml installed-linux
guest tools/installed-flowmux-witness/guest/Cargo.toml -
EOF
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
echo CREDIT_SDK_METADATA_PREPARED
