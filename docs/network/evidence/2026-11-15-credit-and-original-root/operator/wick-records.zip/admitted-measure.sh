#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
cd "$q/admitted-credit-mvm-work"
sha256sum -c "$q/admitted-credit-inputs.sha256" > "$q/admitted-footprint-inputs-before.txt"
sha256sum "$q/source/.mvm-test/target/debug/xtask" > "$q/admitted-footprint-counter.sha256"
"$q/source/.mvm-test/target/debug/xtask" check-rust-footprint > "$q/admitted-footprint-measured.txt" 2>&1 && rc=0 || rc=$?
printf '%s\n' "$rc" > "$q/admitted-footprint-measured-exit.txt"
sha256sum -c "$q/admitted-credit-inputs.sha256" > "$q/admitted-footprint-inputs-after.txt"
sha256sum -c "$q/admitted-footprint-counter.sha256" > "$q/admitted-footprint-counter-after.txt"
cat "$q/admitted-footprint-measured.txt"
