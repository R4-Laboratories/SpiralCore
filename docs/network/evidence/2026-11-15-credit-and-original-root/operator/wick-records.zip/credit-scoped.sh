#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/credit-scoped"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1
export MVM_HOME="$q/credit-scoped-state"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-fc.XXXXXX)
mkdir -m700 "$MVM_HOME"
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
cd "$q/flowmux-credit-mvm-work"
source scripts/dev-env.sh
sha256sum -c "$q/credit-green1-inputs.sha256" > "$out-inputs-before.txt"
systemctl --user show sc-credit-scoped -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
binary=$(cat "$q/credit-green1-test-path.txt")
cp "$q/credit-green1-executable-before.sha256" "$out-executable-before.sha256"
sha256sum -c "$out-executable-before.sha256" > "$out-executable-input-check.txt"
finish() {
  rc=$?
  trap - EXIT
  sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt" || rc=90
  sha256sum -c "$q/credit-green1-inputs.sha256" > "$out-inputs-after.txt" || rc=90
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-after.sha256"
  cmp "$q/credit-green1-inputs.sha256" "$out-file-set-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-download-time.txt" "$binary" --exact supervisor::endpoint::flowmux::tests::a_download_past_the_credit_cap_is_not_torn_down --nocapture --test-threads=1 > "$out-download.txt" 2>&1
/usr/bin/time -v -o "$out-flowmux-time.txt" "$binary" supervisor::endpoint::flowmux:: --test-threads=1 > "$out-flowmux.txt" 2>&1
/usr/bin/time -v -o "$out-clippy-time.txt" cargo clippy --locked --offline -p mvm-hostd --all-targets -- -D warnings > "$out-clippy.txt" 2>&1
touch xtask/src/check_rust_footprint.rs
set +e
/usr/bin/time -v -o "$out-footprint-time.txt" cargo run --locked --offline -p xtask --bin xtask -- check-rust-footprint > "$out-footprint.txt" 2>&1
rc=$?
set -e
printf '%s\n' "$rc" > "$out-footprint-exit.txt"
test "$rc" = 0 || test "$rc" = 1
echo CREDIT_SCOPED_COMMANDS_VERIFIED_FOOTPRINT_REVIEW_PENDING
