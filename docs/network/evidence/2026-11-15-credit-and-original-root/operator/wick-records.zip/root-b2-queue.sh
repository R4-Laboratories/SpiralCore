#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/root-b2-queue"
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"' EXIT
for ((attempt=0; attempt<1080; attempt++)); do
 if ! systemctl --user is-active --quiet sc-admitted-sdk-final; then
  test "$(cat "$q/admitted-sdk-final-exit.txt")" = 0
  ! systemctl --user is-active --quiet sc-admitted2-mvm-full
  test "$(cat "$q/admitted2-mvm-full-exit.txt")" = 0
  systemd-run --user --unit=sc-root-b2-qualified1 --collect -p MemoryMax=6G -p MemorySwapMax=0 -p CPUQuota=200% -p TasksMax=512 /bin/bash "$q/root-b2-qualify.sh"
  echo ROOT_B2_STARTED_AFTER_VERIFIED_PREREQUISITES
  exit 0
 fi
 sleep 5
done
echo 'SDK qualification still active after bounded queue observation' >&2
exit 75
