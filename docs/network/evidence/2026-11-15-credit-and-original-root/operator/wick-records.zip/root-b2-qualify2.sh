#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/root-b2-qualified2"
! systemctl --user is-active --quiet sc-admitted2-mvm-full
test "$(cat "$q/admitted2-mvm-full-exit.txt")" = 0
! systemctl --user is-active --quiet sc-admitted-sdk-final
test "$(cat "$q/admitted-sdk-final-exit.txt")" = 0
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_HOME="$q/root-b2-qualified2-state"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-rb.XXXXXX)
mkdir -m700 "$MVM_HOME"
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-root-b2-qualified2 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
check_sources() {
 local suffix=$1
 cd "$q/flowmux-credit-mvm-work" || return
 sha256sum -c "$q/admitted2-final-inputs.sha256" > "$out-mvm-inputs-$suffix.txt" || return
 find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-mvm-file-set-$suffix.sha256" || return
 cmp "$q/admitted2-final-inputs.sha256" "$out-mvm-file-set-$suffix.sha256" || return
 cd "$q/root-b2-load-work" || return
 sha256sum -c "$q/sc-root-b2-fixed-inputs.sha256" > "$out-inputs-$suffix.txt" || return
 find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-$suffix.sha256" || return
 cmp "$q/sc-root-b2-fixed-inputs.sha256" "$out-file-set-$suffix.sha256" || return
}
finish() {
 rc=$?; trap - EXIT
 if test -f "$out-executables-before.sha256"; then sha256sum -c "$out-executables-before.sha256" > "$out-executables-after.txt" || rc=90; fi
 check_sources after || rc=90
 printf '%s\n' "$rc" > "$out-exit.txt"
 if test "$rc" = 0; then echo ROOT_B2_ORIGINAL_LOAD_SOURCE_VERIFIED; fi
 exit "$rc"
}
trap finish EXIT
check_sources before
/usr/bin/time -v -o "$out-clippy-time.txt" cargo clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings > "$out-clippy.txt" 2>&1
cd "$q/flowmux-credit-mvm-work"
/usr/bin/time -v -o "$out-helper-build-time.txt" cargo build --locked --offline -p mvm-hostd --bin mvm-host-agent --bin mvm-signer-helper --bin mvm-network-endpoint --message-format=json > "$out-helper-build.jsonl" 2> "$out-helper-build-stderr.txt"
cd "$q/root-b2-load-work"
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
python3 - "$q" "$out" <<'PY'
import hashlib,json,pathlib,sys
q=pathlib.Path(sys.argv[1]);out=sys.argv[2]
rows=[json.loads(s) for s in pathlib.Path(out+'-build.jsonl').read_text().splitlines()]
selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('profile',{}).get('test') and r['target']['name']=='spiralcore_mvm_live' and r.get('executable')]
assert len(selected)==1,len(selected)
assert selected[0]['fresh'] is False, "new Root fixture must compile at its current root"
binary=pathlib.Path(selected[0]['executable']);assert selected[0]['target']['src_path'].startswith(str(q/'root-b2-load-work')+'/')
helpers={}
for line in pathlib.Path(out+'-helper-build.jsonl').read_text().splitlines():
 r=json.loads(line)
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name'] in ['mvm-host-agent','mvm-signer-helper','mvm-network-endpoint']:
  assert r['target']['src_path'].startswith(str(q/'flowmux-credit-mvm-work')+'/')
  helpers[r['target']['name']]=r['executable']
assert len(helpers)==3,helpers
assert all(path==str(q/'source/.mvm-test/target/debug'/name) for name,path in helpers.items()),helpers
paths=[binary]+[pathlib.Path(helpers[n]) for n in sorted(helpers)]
pathlib.Path(out+'-test-path.txt').write_text(str(binary)+'\n')
pathlib.Path(out+'-helpers.json').write_text(json.dumps(helpers,indent=2)+'\n')
pathlib.Path(out+'-executables-before.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p)+'\n' for p in paths))
PY
export MVM_HOST_AGENT_PATH="$CARGO_TARGET_DIR/debug/mvm-host-agent"
export MVM_SIGNER_HELPER_PATH="$CARGO_TARGET_DIR/debug/mvm-signer-helper"
export MVM_SUBSTITUTION_ENDPOINT_PATH="$CARGO_TARGET_DIR/debug/mvm-network-endpoint"
binary=$(cat "$out-test-path.txt")
/usr/bin/time -v -o "$out-application-time.txt" "$binary" --exact installed_parent::store_load_tests::original_parent_funds_selected_child_populated_store_and_retirement --ignored --nocapture --test-threads=1 > "$out-application-output.txt" 2>&1
grep -E '^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;' "$out-application-output.txt"
