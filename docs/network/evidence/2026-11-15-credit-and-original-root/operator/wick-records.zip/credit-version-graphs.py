from pathlib import Path
import json,sys
q=Path(sys.argv[1]);out=q/'credit-version-graphs';summaries=[]
for label in ['live','adapter','journal','owner','supervisor','witness','guest','mvm']:
 before=json.loads((q/'worker-final-graphs'/f'{label}-after.json').read_text());after=json.loads((out/f'{label}-after.json').read_text());deltas=[];mapping={}
 for key in before['packages']:
  name,version,source=json.loads(key)
  owned=source=='REVIEWED_MVM_SOURCE' or (label=='mvm' and source.startswith('/'))
  if owned and version=='0.28.0-rc.5':
   replacement=json.dumps([name,'0.28.0-rc.6',source],separators=(',',':'))
   deltas.append({'name':name,'before':'0.28.0-rc.5','after':'0.28.0-rc.6','owner':source})
  else:replacement=key
  mapping[key]=replacement
 assert deltas,(label,'no owned prerelease-label updates')
 expected={'packages':sorted(mapping[k] for k in before['packages']),'nodes':[]}
 for node in before['nodes']:
  deps=[dict(d,pkg=mapping[d['pkg']]) for d in node['deps']]
  deps.sort(key=lambda d:(d['name'],d['pkg'],json.dumps(d['dep_kinds'],sort_keys=True)))
  expected['nodes'].append(dict(node,id=mapping[node['id']],deps=deps))
 expected['nodes'].sort(key=lambda n:n['id'])
 assert expected==after,(label,'unexpected package, edge or feature change')
 summary={'label':label,'packages':len(after['packages']),'nodes':len(after['nodes']),'edges':sum(len(n['deps']) for n in after['nodes']),'features':sum(len(n['features']) for n in after['nodes']),'allowed_mvm_package_version_changes':deltas,'all_other_packages_edges_features_equal':True,'baseline_source':'8345cb682ecbc755c7312ba7a5a28c641aa667d0','candidate_source':'411695439f60b2d9c026b5c29d64f2d0e887e4bf','scope':'version/pin preparation; does not qualify merged a0ee61bb source'}
 (out/f'{label}-summary.json').write_text(json.dumps(summary,indent=2)+'\n');summaries.append(summary)
 print(label,len(after['packages']),'packages;',len(deltas),'owned rc.5→rc.6 labels; all other packages/edges/features equal')
(out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
