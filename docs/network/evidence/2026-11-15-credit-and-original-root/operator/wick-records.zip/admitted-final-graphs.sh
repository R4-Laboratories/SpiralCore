#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
mkdir -p "$q/admitted-final-graphs"
while read -r label raw root; do
 jq -S --arg root "$root" --arg expected_mvm 'git+https://github.com/Casey-allard/mvm?rev=b2def5fd556e6ab9aabeb281b554c6ef6bb060d9#b2def5fd556e6ab9aabeb281b554c6ef6bb060d9' --arg expected_core 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' -f "$q/current-owner-final-graph.jq" "$q/$raw" > "$q/admitted-final-graphs/$label-after.json"
done <<EOF
live admitted-sdk-live-metadata.json $q/credit-sdk-work
adapter admitted-sdk-adapter-metadata.json $q/credit-sdk-work
journal admitted-sdk-journal-metadata.json $q/credit-sdk-work
owner admitted-sdk-owner-metadata.json $q/credit-sdk-work
supervisor admitted-sdk-supervisor-metadata.json $q/credit-sdk-work
witness admitted-sdk-witness-metadata.json $q/credit-sdk-work
guest admitted-sdk-guest-metadata.json $q/credit-sdk-work
mvm admitted2-mvm-full-metadata.json $q/flowmux-credit-mvm-work
EOF
for label in live adapter journal owner supervisor witness guest mvm; do
 cmp "$q/credit-version-graphs/$label-after.json" "$q/admitted-final-graphs/$label-after.json"
 jq --arg source 'b2def5fd556e6ab9aabeb281b554c6ef6bb060d9' '{source:$source,packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps|length]|add),features:([.nodes[].features|length]|add),comparison:"exact validated pin change only from41169543; versions/edges/features identical"}' "$q/admitted-final-graphs/$label-after.json" > "$q/admitted-final-graphs/$label-summary.json"
 echo "$label: validated pin; packages, versions, edges and features identical"
done
