#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/admitted-explicit-footprint"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
cd "$q/admitted-credit-mvm-work"
sha256sum -c "$q/admitted-credit-inputs.sha256" > "$out-inputs-before.txt"
lib=$(find "$q/source/.mvm-test/target/debug/deps" -maxdepth 1 -name 'libanyhow-*.rlib' -printf '%T@ %p\n' | sort -nr | head -n1 | cut -d' ' -f2-)
sha256sum "$lib" "$q/admitted-footprint-counter.rs" xtask/src/rust_source.rs xtask/src/check_rust_footprint.rs > "$out-helper-inputs.sha256"
rustc --edition 2024 "$q/admitted-footprint-counter.rs" --extern "anyhow=$lib" -L dependency="$q/source/.mvm-test/target/debug/deps" -o "$q/source/.mvm-test/target/debug/sc-admitted-footprint-counter"
sha256sum "$q/source/.mvm-test/target/debug/sc-admitted-footprint-counter" > "$out-executable.sha256"
"$q/source/.mvm-test/target/debug/sc-admitted-footprint-counter" "$q/admitted-credit-mvm-work" > "$out.txt" 2>&1 && rc=0 || rc=$?
printf '%s\n' "$rc" > "$out-exit.txt"
sha256sum -c "$q/admitted-credit-inputs.sha256" > "$out-inputs-after.txt"
sha256sum -c "$out-helper-inputs.sha256" > "$out-helper-after.txt"
sha256sum -c "$out-executable.sha256" > "$out-executable-after.txt"
cat "$out.txt"
