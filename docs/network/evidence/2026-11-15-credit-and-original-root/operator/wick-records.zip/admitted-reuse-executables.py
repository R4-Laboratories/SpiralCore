from pathlib import Path
import hashlib,json,sys
build,out,root,prior_path=sys.argv[1:]
prior={r['path']:r for r in json.loads(Path(prior_path).read_text())}
rows=[json.loads(x) for x in Path(build).read_text().splitlines()]
old=[b'/var/tmp/sc-direct-flowmux.iptmjZre/'+x for x in (b'verified-runtime-owner-work',b'worker-funding-mvm-work',b'mvm-directory-work',b'workspace-contract-mvm-work')]
selected={}
for row in rows:
    if row.get('reason')!='compiler-artifact' or not row.get('profile',{}).get('test') or not row.get('executable'):continue
    p=Path(row['executable']); data=p.read_bytes(); digest=hashlib.sha256(data).hexdigest()
    assert row['target']['src_path'].startswith(root+'/'),row
    assert data.startswith(b'\x7fELF'),str(p)
    assert sum(data.count(v) for v in old)==0,str(p)
    previous=prior.get(str(p))
    if row['fresh']:assert previous and previous['sha256']==digest,(str(p),'unproven reused executable')
    if row['target']['src_path'].endswith(('/crates/mvm-hostd/src/lib.rs','/xtask/src/main.rs')):
        assert not row['fresh'],(str(p),'changed module not recompiled')
        assert not previous or previous['sha256']!=digest,(str(p),'changed test executable unchanged')
    if row['target']['name']=='mvm_build':assert (root+'/crates/mvm-build').encode() in data
    selected[str(p)]={'path':str(p),'target':row['target']['name'],'source_path':row['target']['src_path'],'package_id':row['package_id'],'fresh':row['fresh'],'bytes':len(data),'sha256':digest,'prior_root_occurrences':0,'current_root_occurrences':data.count(root.encode()),'same_root_reuse_verified':bool(row['fresh'])}
assert len(selected)==284,len(selected)
records=sorted(selected.values(),key=lambda r:r['path'])
Path(out+'-executables-before.json').write_text(json.dumps(records,indent=2)+'\n')
Path(out+'-executables-before.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
print(json.dumps({'test_executables':len(records),'bytes':sum(r['bytes'] for r in records),'recompiled':sum(not r['fresh'] for r in records),'verified_same_root_reuse':sum(r['fresh'] for r in records),'prior_root_occurrences':0}))
