#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
mkdir -p "$q/credit-version-graphs"
while read -r label raw root; do
 jq -S --arg root "$root" --arg expected_mvm 'git+https://github.com/Casey-allard/mvm?rev=411695439f60b2d9c026b5c29d64f2d0e887e4bf#411695439f60b2d9c026b5c29d64f2d0e887e4bf' --arg expected_core 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' -f "$q/current-owner-final-graph.jq" "$q/$raw" > "$q/credit-version-graphs/$label-after.json"
done <<EOF
live credit-sdk2-live-metadata.json $q/credit-sdk-work
adapter credit-sdk2-adapter-metadata.json $q/credit-sdk-work
journal credit-sdk2-journal-metadata.json $q/credit-sdk-work
owner credit-sdk2-owner-metadata.json $q/credit-sdk-work
supervisor credit-sdk2-supervisor-metadata.json $q/credit-sdk-work
witness credit-sdk2-witness-metadata.json $q/credit-sdk-work
guest credit-sdk2-guest-metadata.json $q/credit-sdk-work
mvm credit-mvm-full-metadata.json $q/flowmux-credit-mvm-work
EOF
python3 "$q/credit-version-graphs.py" "$q"
