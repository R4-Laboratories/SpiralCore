#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/root-b2-clippy1"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
ulimit -Sn 4096
ulimit -S -s 8192
cd "$q/root-b2-load-work"
sha256sum -c "$q/sc-root-b2-inputs.sha256" > "$out-inputs-before.txt"
finish() {
 rc=$?; trap - EXIT
 sha256sum -c "$q/sc-root-b2-inputs.sha256" > "$out-inputs-after.txt" || rc=90
 printf '%s\n' "$rc" > "$out-exit.txt"
 exit "$rc"
}
trap finish EXIT
systemctl --user show sc-root-b2-clippy1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
/usr/bin/time -v -o "$out-time.txt" cargo clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings > "$out.txt" 2>&1
