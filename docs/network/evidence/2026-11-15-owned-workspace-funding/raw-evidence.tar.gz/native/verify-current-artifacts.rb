require 'json'
require 'open3'
require 'digest'
require 'fileutils'
root=ARGV.fetch(0)
items=JSON.parse(File.read(root+'/inventory.json'))
FileUtils.mkdir_p(root+'/zips')
rows=items.map do |a|
  name=a.fetch('name')
  abort name unless name.match?(/\A[a-zA-Z0-9_.-]+\z/)
  path=root+'/zips/'+name+'.zip'
  unless File.exist?(path)
    bytes,err,status=Open3.capture3('gh','api',"repos/R4-Laboratories/SpiralCore/actions/artifacts/#{a.fetch('id')}/zip")
    abort err unless status.success?
    File.binwrite(path,bytes)
  end
  abort name unless 'sha256:'+Digest::SHA256.file(path).hexdigest==a.fetch('digest') && File.size(path)==a.fetch('size')
  listing,err,status=Open3.capture3('unzip','-Z1',path)
  abort err unless status.success?
  names=listing.lines.map(&:strip)
  abort names.inspect unless names.uniq==names && names.all?{|n|n.match?(/\A[a-zA-Z0-9_.-]+\z/)}
  out=root+'/'+name
  FileUtils.mkdir_p(out)
  hashes=names.to_h do |n|
    bytes,err,status=Open3.capture3('unzip','-p',path,n)
    abort err unless status.success? && bytes.bytesize<=20*1024*1024
    File.binwrite(out+'/'+n,bytes)
    [n,Digest::SHA256.hexdigest(bytes)]
  end
  embedded=0
  if hashes.key?('SHA256SUMS')
    checked=File.readlines(out+'/SHA256SUMS').map(&:strip).reject(&:empty?).map do |line|
      hash,file=line.split(/\s+/,2)
      abort line unless hashes[file]==hash
      file
    end
    abort name unless checked.uniq==checked && checked.sort==(names-['SHA256SUMS']).sort
    embedded=checked.length
  end
  {name:name,id:a.fetch('id'),zip_sha256:a.fetch('digest'),members:names.length,embedded_checksums:embedded,member_sha256:hashes}
end
File.write(root+'/verification.json',JSON.pretty_generate(rows)+"\n")
puts rows.map{|x|x.reject{|k,_|k==:member_sha256}}.to_json
