require 'json';require 'open3';require 'digest';require 'fileutils'
root=ARGV.fetch(0)
items=JSON.parse(File.read(root+'/inventory.json'))
FileUtils.mkdir_p(root+'/zips')
rows=items.map do |a|
 name=a.fetch('name');path=root+'/zips/'+name+'.zip'
 unless File.exist?(path)
  bytes,err,status=Open3.capture3('gh','api',"repos/R4-Laboratories/SpiralCore/actions/artifacts/#{a.fetch('id')}/zip");abort err unless status.success?;File.binwrite(path,bytes)
 end
 abort name unless 'sha256:'+Digest::SHA256.file(path).hexdigest==a.fetch('digest') && File.size(path)==a.fetch('size')
 names,err,status=Open3.capture3('unzip','-Z1',path);abort err unless status.success?
 names=names.lines.map(&:strip);abort names.inspect unless names.uniq==names && names.all?{|n|n.match?(/\A[a-zA-Z0-9_.-]+\z/)}
 out=root+'/'+name;FileUtils.mkdir_p(out);abort unless system('unzip','-qo',path,'-d',out)
 sums=File.readlines(out+'/SHA256SUMS').map(&:strip).reject(&:empty?)
 checked=sums.map do |line|
  hash,file=line.split(/\s+/,2);abort file.inspect unless names.include?(file) && File.file?(out+'/'+file) && Digest::SHA256.file(out+'/'+file).hexdigest==hash;file
 end
 abort name unless checked.uniq==checked && checked.sort==(names-['SHA256SUMS']).sort
 {name:name,digest:a.fetch('digest'),members:names.size,checksums:sums.size}
end
File.write(root+'/verification.json',JSON.pretty_generate(rows))
puts rows.to_json
