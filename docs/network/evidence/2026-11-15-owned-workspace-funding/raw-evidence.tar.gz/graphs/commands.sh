#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0
mkdir -m700 "$q/workspace-contract-graphs-qualified"
for target in x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu x86_64-apple-darwin aarch64-apple-darwin x86_64-pc-windows-msvc aarch64-pc-windows-msvc; do
  for side in baseline candidate; do
    case "$side" in baseline) source="$q/workspace-contract-baseline-graphs";; candidate) source="$q/workspace-contract-work";; esac
    for edges in normal,build normal,build,dev features; do
      cargo tree --locked --offline --manifest-path "$source/crates/spiralcore-transfer/Cargo.toml" --target "$target" --edges "$edges" --prefix depth --format '{p}' > "$q/workspace-contract-graphs-qualified/$target-$side-$edges.txt"
    done
  done
  for side in baseline candidate; do
    case "$side" in baseline) source="$q/workspace-contract-baseline-graphs";; candidate) source="$q/workspace-contract-work";; esac
    for edges in normal,build normal,build,dev features; do
      sed "s|$source/|SOURCE/|g" "$q/workspace-contract-graphs-qualified/$target-$side-$edges.txt" > "$q/workspace-contract-graphs-qualified/$target-$side-$edges.normalized.txt"
    done
  done
  cmp "$q/workspace-contract-graphs-qualified/$target-baseline-normal,build.normalized.txt" "$q/workspace-contract-graphs-qualified/$target-candidate-normal,build.normalized.txt"
done
printf 'NORMAL_BUILD_GRAPHS_IDENTICAL_ALL_SIX_TARGETS\n'
