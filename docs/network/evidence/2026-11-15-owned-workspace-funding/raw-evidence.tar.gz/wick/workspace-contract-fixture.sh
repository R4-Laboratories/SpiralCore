#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-fixture-work"
systemctl --user show sc-workspace-contract-fixture -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-fixture-limits.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-fixture-inputs.sha256"
set +e
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --example installed_flowmux_fixture --no-run --message-format=json > "$q/workspace-contract-fixture-build.jsonl" 2> "$q/workspace-contract-fixture-build.stderr"
code=$?
set -e
printf '%s\n' "$code" > "$q/workspace-contract-fixture-exit.txt"
jq -r 'select(.reason=="compiler-message") | .message.rendered' "$q/workspace-contract-fixture-build.jsonl" > "$q/workspace-contract-fixture-diagnostics.txt"
sha256sum -c "$q/workspace-contract-fixture-inputs.sha256" > "$q/workspace-contract-fixture-inputs-after.log"
printf 'FIXTURE_BUILD_REPRODUCTION_COMPLETE exit=%s\n' "$code"
