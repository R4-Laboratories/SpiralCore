#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-work"
systemctl --user show sc-workspace-contract-final -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-final-limits.txt"
rustc -vV > "$q/workspace-contract-final-rustc.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-final-inputs.sha256"
cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets --no-run --message-format=json > "$q/workspace-contract-final-build.jsonl" 2> "$q/workspace-contract-final-build.stderr"
jq -r 'select(.reason=="compiler-artifact" and .executable!=null and .profile.test) | .executable' "$q/workspace-contract-final-build.jsonl" | sort -u | xargs sha256sum > "$q/workspace-contract-final-executables.sha256"
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets -- --show-output > "$q/workspace-contract-final-transfer.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --doc > "$q/workspace-contract-final-doc.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets -- -D warnings > "$q/workspace-contract-final-clippy.log" 2>&1
cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets --no-run --message-format=json > "$q/workspace-contract-final-flowmux-build.jsonl" 2> "$q/workspace-contract-final-flowmux-build.stderr"
jq -r 'select(.reason=="compiler-artifact" and .executable!=null and .profile.test) | .executable' "$q/workspace-contract-final-flowmux-build.jsonl" | sort -u | xargs sha256sum > "$q/workspace-contract-final-flowmux-executables.sha256"
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets -- --show-output > "$q/workspace-contract-final-flowmux.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets -- -D warnings > "$q/workspace-contract-final-flowmux-clippy.log" 2>&1
sha256sum -c "$q/workspace-contract-final-inputs.sha256" > "$q/workspace-contract-final-inputs-after.log"
sha256sum -c "$q/workspace-contract-final-executables.sha256" > "$q/workspace-contract-final-executables-after.log"
sha256sum -c "$q/workspace-contract-final-flowmux-executables.sha256" > "$q/workspace-contract-final-flowmux-executables-after.log"
printf 'WORKSPACE_CONTRACT_FINAL_COMPLETE\n'
