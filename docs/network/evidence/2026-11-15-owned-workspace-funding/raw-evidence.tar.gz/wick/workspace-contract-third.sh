#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-work"
systemctl --user show sc-workspace-contract-third -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-third-limits.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-third-inputs.sha256"
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_workspace_contract --test owned_workspace_layout -- --show-output > "$q/workspace-contract-third.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --lib -- --show-output > "$q/workspace-contract-third-lib.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store --test owned_store_resources --test owned_store_allocation --test owned_verification_workspace -- --show-output > "$q/workspace-contract-third-owned.log" 2>&1
sha256sum -c "$q/workspace-contract-third-inputs.sha256" > "$q/workspace-contract-third-inputs-after.log"
printf 'FIRST_CONTRACT_CONTROLS_COMPLETE\n'
