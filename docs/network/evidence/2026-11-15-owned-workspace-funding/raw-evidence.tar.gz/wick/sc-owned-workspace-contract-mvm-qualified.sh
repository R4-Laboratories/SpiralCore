#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
ulimit -Sn 4096
printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)" > "$q/workspace-contract-mvm-qualified-nofile.txt"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp" MVM_HOME="$q/workspace-contract-mvm-state"
mkdir -m700 -p "$MVM_HOME"
cd "$q/workspace-contract-mvm-work"
systemctl --user show sc-workspace-contract-mvm-qualified -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-mvm-qualified-limits.txt"
rustc -vV > "$q/workspace-contract-mvm-qualified-rustc.txt"
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-mvm-qualified-inputs-before.log"
cargo metadata --locked --offline --format-version=1 > "$q/workspace-contract-mvm-qualified-metadata.json"
jq -e --arg source 'git+https://github.com/R4-Laboratories/SpiralCore?rev=86497e8868146f2a21ba581dd09fcfabfca6486d#86497e8868146f2a21ba581dd09fcfabfca6486d' '[.packages[] | select(.name|test("^(spiralcore-|uor-r4-object-store)"))] as $core | ($core|length)==5 and all($core[];.source==$source)' "$q/workspace-contract-mvm-qualified-metadata.json" > "$q/workspace-contract-mvm-qualified-pin-check.txt"
cargo fmt --all -- --check > "$q/workspace-contract-mvm-qualified-format.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --workspace -- --test-threads=1 > "$q/workspace-contract-mvm-qualified-tests.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline --workspace -- -D warnings > "$q/workspace-contract-mvm-qualified-clippy.log" 2>&1
/usr/bin/time -v cargo check --release --locked --offline --workspace --all-targets > "$q/workspace-contract-mvm-qualified-check.log" 2>&1
/usr/bin/time -v cargo check --release --locked --offline -p mvm-conformance --all-targets --features bdd > "$q/workspace-contract-mvm-qualified-bdd-check.log" 2>&1
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-mvm-qualified-inputs-after.log"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-mvm-qualified-actual-final-inputs.sha256"
cmp "$q/workspace-contract-mvm-final-expected.sha256" "$q/workspace-contract-mvm-qualified-actual-final-inputs.sha256"
printf 'MVM_WORKSPACE_FUNDING_QUALIFIED_COMPLETE\n'
