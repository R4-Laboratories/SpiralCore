#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-work"
systemctl --user show sc-workspace-contract-red -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-red-limits.txt"
rustc -vV > "$q/workspace-contract-red-rustc.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-red-inputs.sha256"
set +e
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_workspace_contract --no-run > "$q/workspace-contract-red.log" 2>&1
code=$?
set -e
printf '%s\n' "$code" > "$q/workspace-contract-red-exit.txt"
test "$code" -eq 101
rg -q 'OwnedWorkspaceFunding|workspace_requirements' "$q/workspace-contract-red.log"
sha256sum -c "$q/workspace-contract-red-inputs.sha256" > "$q/workspace-contract-red-inputs-after.log"
printf 'EXPECTED_MISSING_CONTRACT_COMPILE_RED\n'
