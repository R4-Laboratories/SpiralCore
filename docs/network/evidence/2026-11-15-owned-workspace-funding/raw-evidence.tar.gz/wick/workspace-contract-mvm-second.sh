#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-mvm-work"
systemctl --user show sc-workspace-contract-mvm-second -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-mvm-second-limits.txt"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-mvm-second-inputs.sha256"
/usr/bin/time -v cargo test --release --locked -p mvm-hostd --lib supervisor::flowmux::spiralcore_payload:: -- --test-threads=1 --show-output > "$q/workspace-contract-mvm-second-tests.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline -p mvm-hostd --lib --tests -- -D warnings > "$q/workspace-contract-mvm-second-clippy.log" 2>&1
sha256sum -c "$q/workspace-contract-mvm-second-inputs.sha256" > "$q/workspace-contract-mvm-second-inputs-after.log"
printf 'MVM_WORKSPACE_COMPATIBILITY_FOCUSED_COMPLETE\n'
