#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp" MVM_HOME="$q/workspace-contract-mvm-state"
mkdir -m700 -p "$MVM_HOME"
cd "$q/workspace-contract-mvm-work"
systemctl --user show sc-workspace-contract-mvm-full -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-mvm-full-limits.txt"
rustc -vV > "$q/workspace-contract-mvm-full-rustc.txt"
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-mvm-full-inputs-before.log"
cargo metadata --locked --offline --format-version=1 > "$q/workspace-contract-mvm-full-metadata.json"
jq -e --arg source 'git+https://github.com/R4-Laboratories/SpiralCore?rev=86497e8868146f2a21ba581dd09fcfabfca6486d#86497e8868146f2a21ba581dd09fcfabfca6486d' '[.packages[] | select(.name|test("^(spiralcore-|uor-r4-object-store)"))] as $core | ($core|length)==5 and all($core[];.source==$source)' "$q/workspace-contract-mvm-full-metadata.json" > "$q/workspace-contract-mvm-full-pin-check.txt"
cargo fmt --all -- --check > "$q/workspace-contract-mvm-full-format.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --workspace -- --test-threads=1 > "$q/workspace-contract-mvm-full-tests.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline --workspace -- -D warnings > "$q/workspace-contract-mvm-full-clippy.log" 2>&1
/usr/bin/time -v cargo check --release --locked --offline --workspace --all-targets > "$q/workspace-contract-mvm-full-check.log" 2>&1
/usr/bin/time -v cargo check --release --locked --offline -p mvm-conformance --all-targets --features bdd > "$q/workspace-contract-mvm-full-bdd-check.log" 2>&1
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-mvm-full-inputs-after.log"
printf 'MVM_WORKSPACE_FUNDING_FULL_COMPLETE\n'
