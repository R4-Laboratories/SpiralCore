#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-fixture-work"
systemctl --user show sc-workspace-contract-sdk-tools -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-sdk-tools-limits.txt"
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-tools-inputs-before.log"
printf 'Waiting for the separate full workspace build before using the shared target\n'
while systemctl --user is-active --quiet sc-workspace-contract-mvm-qualified.service; do sleep 5; done
ulimit -Sn 4096
printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)" > "$q/workspace-contract-sdk-tools-nofile.txt"
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets > "$q/workspace-contract-sdk-tools-witness-check.log" 2>&1
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$q/workspace-contract-sdk-tools-guest-check.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-tools-inputs-after.log"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/workspace-contract-sdk-tools-actual-final-inputs.sha256"
cmp "$q/workspace-contract-sdk-expected.sha256" "$q/workspace-contract-sdk-tools-actual-final-inputs.sha256"
printf 'SDK_INSTALLED_TOOLS_COMPLETE\n'
