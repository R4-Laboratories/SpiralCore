#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_HOME="$q/workspace-contract-mvm-state" MVM_GPU_TEST_EXPECT_NATIVE=1
export TMPDIR
TMPDIR=$(cat "$q/workspace-contract-delivery-final-private-tmp.txt")
printf '%s\n' "$TMPDIR" > "$q/workspace-contract-qualified-source-private-tmp.txt"
ulimit -Sn 4096
{ printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)"; stat -c '%U %a %n' "$TMPDIR"; cat /proc/driver/nvidia/version; } > "$q/workspace-contract-qualified-source-host-prerequisites.txt"
systemctl --user show sc-workspace-contract-qualified-source -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-qualified-source-limits.txt"
cd "$q/workspace-contract-mvm-work"
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-qualified-source-mvm-inputs-before.log"
rustc -vV > "$q/workspace-contract-qualified-source-rustc.txt"
cargo metadata --locked --offline --format-version=1 > "$q/workspace-contract-qualified-source-mvm-metadata.json"
jq -e --arg source 'git+https://github.com/R4-Laboratories/SpiralCore?rev=86497e8868146f2a21ba581dd09fcfabfca6486d#86497e8868146f2a21ba581dd09fcfabfca6486d' '[.packages[] | select(.name|test("^(spiralcore-|uor-r4-object-store)"))] as $core | ($core|length)==5 and all($core[];.source==$source)' "$q/workspace-contract-qualified-source-mvm-metadata.json" > "$q/workspace-contract-qualified-source-pin-check.txt"
cargo fmt --all -- --check > "$q/workspace-contract-qualified-source-format.log" 2>&1
/usr/bin/time -v cargo test --locked --offline --workspace -- --test-threads=1 > "$q/workspace-contract-qualified-source-mvm-tests.log" 2>&1
/usr/bin/time -v cargo clippy --locked --offline --workspace -- -D warnings > "$q/workspace-contract-qualified-source-mvm-clippy.log" 2>&1
/usr/bin/time -v cargo check --locked --offline --workspace --all-targets > "$q/workspace-contract-qualified-source-mvm-check.log" 2>&1
/usr/bin/time -v cargo check --locked --offline -p mvm-conformance --all-targets --features bdd > "$q/workspace-contract-qualified-source-bdd-check.log" 2>&1
sha256sum -c "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-qualified-source-mvm-inputs-after.log"
find . -path ./.git -prune -o -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-qualified-source-mvm-actual-inputs.sha256"
LC_ALL=C sort "$q/workspace-contract-mvm-final-expected.sha256" > "$q/workspace-contract-qualified-source-mvm-expected-sorted.sha256"
LC_ALL=C sort "$q/workspace-contract-qualified-source-mvm-actual-inputs.sha256" > "$q/workspace-contract-qualified-source-mvm-actual-sorted.sha256"
cmp "$q/workspace-contract-qualified-source-mvm-expected-sorted.sha256" "$q/workspace-contract-qualified-source-mvm-actual-sorted.sha256"
printf 'MVM_FULL_WORKSPACE_COMPLETE\n'
cd "$q/workspace-contract-fixture-work"
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-qualified-source-sdk-inputs-before.log"
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets > "$q/workspace-contract-qualified-source-witness-check.log" 2>&1
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$q/workspace-contract-qualified-source-guest-check.log" 2>&1
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed -- --test-threads=1 --nocapture > "$q/workspace-contract-qualified-source-journal-tests.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-qualified-source-sdk-inputs-after.log"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/workspace-contract-qualified-source-sdk-actual-inputs.sha256"
cmp "$q/workspace-contract-sdk-expected.sha256" "$q/workspace-contract-qualified-source-sdk-actual-inputs.sha256"
printf 'DELIVERY_SLICE_FINAL_QUALIFICATION_COMPLETE\n'
