#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-wsj.XXXXXX)
printf '%s\n' "$TMPDIR" > "$q/workspace-contract-journal-private-tmp.txt"
ulimit -Sn 4096
cd "$q/workspace-contract-fixture-work"
systemctl --user show sc-workspace-contract-journal -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-journal-limits.txt"
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-journal-inputs-before.log"
while systemctl --user is-active --quiet sc-workspace-contract-mvm-qualified.service || systemctl --user is-active --quiet sc-workspace-contract-sdk-tools.service; do sleep 5; done
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed -- --test-threads=1 --nocapture > "$q/workspace-contract-journal-tests.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-journal-inputs-after.log"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/workspace-contract-journal-actual-final-inputs.sha256"
cmp "$q/workspace-contract-sdk-expected.sha256" "$q/workspace-contract-journal-actual-final-inputs.sha256"
printf 'JOURNAL_ORIGINAL_ENVELOPE_RESTART_RECEIPT_COMPLETE\n'
