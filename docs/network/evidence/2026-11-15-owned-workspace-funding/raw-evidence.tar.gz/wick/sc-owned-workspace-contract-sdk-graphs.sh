#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-fixture-work"
systemctl --user show sc-workspace-contract-sdk-graphs -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-sdk-graphs-limits.txt"
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-graphs-inputs-before.log"
ulimit -Sn 4096
printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)" > "$q/workspace-contract-sdk-graphs-nofile.txt"
for row in live adapter journal owner supervisor witness guest; do
  case "$row" in
    live) manifest=crates/spiralcore-mvm-live/Cargo.toml; features=canonical-host ;;
    adapter) manifest=crates/spiralcore-mvm-adapter/Cargo.toml; features=live,conformance,hardware-sha256 ;;
    journal) manifest=crates/spiralcore-mvm-journal-host/Cargo.toml; features= ;;
    owner) manifest=crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml; features= ;;
    supervisor) manifest=crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml; features= ;;
    witness) manifest=tools/installed-flowmux-witness/Cargo.toml; features=installed-linux ;;
    guest) manifest=tools/installed-flowmux-witness/guest/Cargo.toml; features= ;;
  esac
  args=(--locked --format-version=1 --manifest-path "$manifest")
  if [[ -n "$features" ]]; then args+=(--features "$features"); fi
  cargo metadata "${args[@]}" > "$q/workspace-contract-sdk-graphs-$row-metadata.json" 2> "$q/workspace-contract-sdk-graphs-$row-metadata.stderr"
done
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-graphs-inputs-after.log"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-sdk-graphs-actual-final-inputs.sha256"
cmp "$q/workspace-contract-sdk-expected.sha256" "$q/workspace-contract-sdk-graphs-actual-final-inputs.sha256"
printf 'SDK_LOCKED_GRAPHS_COMPLETE\n'
