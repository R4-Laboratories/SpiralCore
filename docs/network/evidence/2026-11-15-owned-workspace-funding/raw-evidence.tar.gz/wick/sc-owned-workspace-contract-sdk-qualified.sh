#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/workspace-contract-tmp"
cd "$q/workspace-contract-fixture-work"
systemctl --user show sc-workspace-contract-sdk-qualified -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-sdk-qualified-limits.txt"
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-qualified-inputs-before.log"
printf 'Waiting for the separate full workspace build before using the shared target\n'
while systemctl --user is-active --quiet sc-workspace-contract-mvm-qualified.service; do sleep 5; done
ulimit -Sn 4096
printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)" > "$q/workspace-contract-sdk-qualified-nofile.txt"
for row in live adapter journal owner supervisor witness guest; do
  case "$row" in
    live) manifest=crates/spiralcore-mvm-live/Cargo.toml; features=canonical-host ;;
    adapter) manifest=crates/spiralcore-mvm-adapter/Cargo.toml; features=live,conformance,hardware-sha256 ;;
    journal) manifest=crates/spiralcore-mvm-journal-host/Cargo.toml; features= ;;
    owner) manifest=crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml; features= ;;
    supervisor) manifest=crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml; features= ;;
    witness) manifest=tools/installed-flowmux-witness/Cargo.toml; features=installed-linux ;;
    guest) manifest=tools/installed-flowmux-witness/guest/Cargo.toml; features= ;;
  esac
  args=(--locked --format-version=1 --manifest-path "$manifest")
  if [[ -n "$features" ]]; then args+=(--features "$features"); fi
  cargo metadata "${args[@]}" > "$q/workspace-contract-sdk-qualified-$row-metadata.json" 2> "$q/workspace-contract-sdk-qualified-$row-metadata.stderr"
done
set +e
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --example installed_flowmux_fixture --no-run --message-format=json > "$q/workspace-contract-sdk-qualified-fixture-build.jsonl" 2> "$q/workspace-contract-sdk-qualified-fixture-build.stderr"
code=$?
set -e
printf '%s\n' "$code" > "$q/workspace-contract-sdk-qualified-fixture-build-exit.txt"
if [[ "$code" != 0 ]]; then exit "$code"; fi
exe=$(jq -ers '[.[] | select(.reason=="compiler-artifact" and .target.name=="installed_flowmux_fixture" and .target.kind==["example"] and .profile.test and (.features|index("canonical-host")) and .executable) | .executable] | select(length==1) | first' "$q/workspace-contract-sdk-qualified-fixture-build.jsonl")
[[ "$(realpath "$exe")" == "$(realpath "$CARGO_TARGET_DIR")"/debug/examples/* ]]
sha256sum "$exe" > "$q/workspace-contract-sdk-qualified-fixture-executable-before.sha256"
/usr/bin/time -v "$exe" --test-threads=1 > "$q/workspace-contract-sdk-qualified-fixture-tests.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-qualified-fixture-executable-before.sha256" > "$q/workspace-contract-sdk-qualified-fixture-executable-after.log"
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --test fixture_native_handoff -- --test-threads=1 > "$q/workspace-contract-sdk-qualified-handoff-tests.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent:: -- --test-threads=1 > "$q/workspace-contract-sdk-qualified-parent-tests.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-adapter/Cargo.toml --features live,conformance,hardware-sha256 --all-targets -- --test-threads=1 > "$q/workspace-contract-sdk-qualified-adapter-tests.log" 2>&1
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets > "$q/workspace-contract-sdk-qualified-witness-check.log" 2>&1
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$q/workspace-contract-sdk-qualified-guest-check.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-expected.sha256" > "$q/workspace-contract-sdk-qualified-inputs-after.log"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$q/workspace-contract-sdk-qualified-actual-final-inputs.sha256"
cmp "$q/workspace-contract-sdk-expected.sha256" "$q/workspace-contract-sdk-qualified-actual-final-inputs.sha256"
printf 'SDK_ORIGINAL_WORKSPACE_COMPATIBILITY_COMPLETE\n'
