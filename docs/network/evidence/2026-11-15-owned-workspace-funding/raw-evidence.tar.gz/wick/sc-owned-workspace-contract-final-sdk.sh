#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_HOME="$q/workspace-contract-mvm-state" MVM_GPU_TEST_EXPECT_NATIVE=1 PYTHONDONTWRITEBYTECODE=1
export TMPDIR
TMPDIR=$(cat "$q/workspace-contract-delivery-final-private-tmp.txt")
ulimit -Sn 4096
systemctl --user show sc-workspace-contract-final-sdk -p ActiveState -p MainPID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$q/workspace-contract-final-sdk-limits.txt"
cd "$q/workspace-contract-fixture-work"
sha256sum -c "$q/workspace-contract-sdk-complete-expected.sha256" > "$q/workspace-contract-final-sdk-inputs-before.log"
/usr/bin/time -v cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$q/workspace-contract-final-sdk-guest-check.log" 2>&1
/usr/bin/time -v cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed -- --test-threads=1 --nocapture > "$q/workspace-contract-final-sdk-journal-tests.log" 2>&1
sha256sum -c "$q/workspace-contract-sdk-complete-expected.sha256" > "$q/workspace-contract-final-sdk-inputs-after.log"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/workspace-contract-final-sdk-actual-inputs.sha256"
cmp "$q/workspace-contract-sdk-complete-expected.sha256" "$q/workspace-contract-final-sdk-actual-inputs.sha256"
printf 'FINAL_SDK_GUEST_JOURNAL_VERIFIED\n'
