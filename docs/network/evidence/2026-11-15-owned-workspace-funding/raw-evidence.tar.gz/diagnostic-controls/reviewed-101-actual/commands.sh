#!/bin/bash
set -euo pipefail
cargo() { cat input.jsonl; cat input.stderr >&2; return 101; }
set +e
cargo +1.97.1 test --locked --manifest-path crates/spiralcore-mvm-live/Cargo.toml \
  --features canonical-host --example installed_flowmux_fixture --no-run \
  --message-format=json > fixture-evidence/fixture-build.jsonl 2> fixture-evidence/fixture-build.stderr
code=$?
set -e
printf '%s\n' "$code" > fixture-evidence/fixture-build-exit.txt
cat fixture-evidence/fixture-build.stderr || {
  printf '%s\n' 'warning: unable to display retained compiler stderr' >&2 || :
}
jq -r 'select(.reason=="compiler-message") | .message.rendered // empty' fixture-evidence/fixture-build.jsonl || {
  printf '%s\n' 'warning: unable to render retained compiler JSON' >&2 || :
}
exit "$code"
