#!/bin/bash
set -euo pipefail
cargo() { cat '/tmp/sc-owned-workspace-evidence/wick/workspace-contract-fixture-build.jsonl'; cat '/tmp/sc-owned-workspace-evidence/wick/workspace-contract-fixture-build.stderr' >&2; return 101; }
set +e
cargo +1.97.1 test --locked --manifest-path crates/spiralcore-mvm-live/Cargo.toml \
  --features canonical-host --example installed_flowmux_fixture --no-run \
  --message-format=json > fixture-evidence/fixture-build.jsonl 2> fixture-evidence/fixture-build.stderr
code=$?
set -e
printf '%s\n' "$code" > fixture-evidence/fixture-build-exit.txt
cat fixture-evidence/fixture-build.stderr
jq -r 'select(.reason=="compiler-message") | .message.rendered' fixture-evidence/fixture-build.jsonl
exit "$code"
