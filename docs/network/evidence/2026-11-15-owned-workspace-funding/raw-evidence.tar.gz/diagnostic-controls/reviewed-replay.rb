require 'open3'
require 'json'
require 'fileutils'
require 'digest'

root='/Users/casey.allard/.codex/worktrees/spiralcore-mvm-resume/spiralcore'
packet='/tmp/sc-owned-workspace-evidence/wick'
text=File.read(root+'/.github/workflows/spiralcore-linux-mvm.yml')
section=text.split('      - name: Build the fixture producer test executable',2).last.split('      - name:',2).first
block=section.split("        run: |\n",2).last.lines.map{|x|x.sub(/^          /,'')}.join
rows=[]
[[101,false],[0,false],[101,true],[0,true]].each do |code,malformed|
  dir="/tmp/sc-owned-workspace-pipeline-check/reviewed-#{code}-#{malformed ? 'malformed' : 'actual'}"
  FileUtils.mkdir_p(dir+'/fixture-evidence')
  json=malformed ? "{invalid json\n" : File.binread(packet+(code==101 ? '/workspace-contract-fixture-build.jsonl' : '/workspace-contract-final3-build.jsonl'))
  stderr=malformed ? "retained truncated-stream control\n" : File.binread(packet+(code==101 ? '/workspace-contract-fixture-build.stderr' : '/workspace-contract-final3-build.stderr'))
  File.binwrite(dir+'/input.jsonl',json)
  File.binwrite(dir+'/input.stderr',stderr)
  script="#!/bin/bash\nset -euo pipefail\ncargo() { cat input.jsonl; cat input.stderr >&2; return #{code}; }\n"+block
  File.write(dir+'/commands.sh',script)
  out,err,status=Open3.capture3('/bin/bash','commands.sh',chdir:dir)
  File.write(dir+'/stdout.txt',out)
  File.write(dir+'/stderr.txt',err)
  row={cargo_exit:code,step_exit:status.exitstatus,malformed_json:malformed,json_retained_exactly:File.binread(dir+'/fixture-evidence/fixture-build.jsonl')==json,stderr_retained_exactly:File.binread(dir+'/fixture-evidence/fixture-build.stderr')==stderr,saved_exit:File.read(dir+'/fixture-evidence/fixture-build-exit.txt').strip.to_i,rendered_e0061:out.include?('E0061')}
  raise row.inspect unless row[:cargo_exit]==row[:step_exit] && row[:saved_exit]==code && row[:json_retained_exactly] && row[:stderr_retained_exactly]
  rows << row
end
File.write('/tmp/sc-owned-workspace-pipeline-check/reviewed-summary.json',JSON.pretty_generate({scope:'exact workflow shell block with replayed compiler streams and malformed JSON controls; no cargo build executed; actual exit0 stream is transfer compilation, not fixture composition',rows:rows})+"\n")
puts JSON.pretty_generate(rows)
