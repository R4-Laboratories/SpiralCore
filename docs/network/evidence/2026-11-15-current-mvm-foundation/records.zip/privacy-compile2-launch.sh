#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
test ! -e "$q/privacy-compile2-exit.txt"
test ! -e "$q/privacy-compile2-frozen-inputs.sha256"
cp "$q/privacy-final-inputs.sha256" "$q/privacy-compile2-frozen-inputs.sha256"
systemd-run --user --unit=sc-privacy-compile2 --wait --collect \
  -p MemoryMax=6G -p MemorySwapMax=0 -p CPUQuota=200% -p TasksMax=512 \
  -p LimitNOFILE=4096 -p LimitSTACK=8M -p RuntimeMaxSec=30min \
  /bin/bash "$q/privacy-compile2.sh"
