#!/usr/bin/env bash
set -euo pipefail
case "$1" in 0002|0022) ;; *) exit 64;; esac
q=/var/tmp/sc-direct-flowmux.iptmjZre
cd "$q/flowmux-credit-mvm-work"
out="$q/privacy-legacy-mode2-$1"
umask "$1"
umask > "$out-umask.txt"
export MVM_HOME="$out-home"
mkdir -m700 "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-lm.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
executable=$(jq -er .executable "$q/privacy-compile4-hostd-selected-artifact.json")
sha256sum -c "$q/privacy-compile4-hostd-executable-before.sha256" > "$out-executable-original-check.txt"
sha256sum "$executable" > "$out-executable-before.sha256"
sha256sum -c "$q/privacy-compile4-frozen-inputs.sha256" > "$out-inputs-before.txt"
set +e
/usr/bin/time -v -o "$out-time.txt" "$executable" --exact plan_admission::admitted_plan_tests::a_verified_legacy_fork_keeps_its_existing_admission_path --test-threads=1 > "$out-tests.txt" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$out-exit.txt"
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt"
sha256sum -c "$q/privacy-compile4-frozen-inputs.sha256" > "$out-inputs-after.txt"
exit "$result"
