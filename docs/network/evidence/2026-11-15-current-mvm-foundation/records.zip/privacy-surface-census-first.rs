use std::collections::BTreeMap;
use std::error::Error;
use syn::{Item, UseTree, Visibility};
fn visibility(value: &Visibility) -> Option<String> {
    match value {
        Visibility::Public(_) => Some("public".into()),
        Visibility::Restricted(value) => Some(format!("restricted:{}", value.path.segments.iter().map(|x| x.ident.to_string()).collect::<Vec<_>>().join("::"))),
        Visibility::Inherited => None,
    }
}
fn names(tree: &UseTree, parent: Option<&str>, result: &mut Vec<String>) -> Result<(), Box<dyn Error>> {
    match tree {
        UseTree::Path(value) => names(&value.tree, Some(&value.ident.to_string()), result)?,
        UseTree::Name(value) => result.push(if value.ident == "self" {parent.ok_or("unresolved self export")?.into()} else {value.ident.to_string()}),
        UseTree::Rename(value) => result.push(value.rename.to_string()),
        UseTree::Group(value) => for item in &value.items {names(item,parent,result)?;},
        UseTree::Glob(_) => return Err("wildcard export needs separate resolution".into()),
    }
    Ok(())
}
fn surface(path: &str) -> Result<BTreeMap<String,String>, Box<dyn Error>> {
    let mut result=BTreeMap::new();
    for item in syn::parse_file(&std::fs::read_to_string(path)?)?.items {
        let entry=match item {
            Item::Use(value) => {if let Some(scope)=visibility(&value.vis) {let mut exported=Vec::new();names(&value.tree,None,&mut exported)?;for name in exported {result.insert(name,scope.clone());}} None},
            Item::Fn(value)=>visibility(&value.vis).map(|v|(value.sig.ident.to_string(),v)),
            Item::Struct(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Enum(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Trait(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Type(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Const(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Static(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            Item::Mod(value)=>visibility(&value.vis).map(|v|(value.ident.to_string(),v)),
            _=>None,
        };
        if let Some((name,scope))=entry {result.insert(name,scope);}
    }
    Ok(result)
}
fn main()->Result<(),Box<dyn Error>> {
    let args=std::env::args().skip(1).collect::<Vec<_>>();
    if args.len()!=4 {return Err("expected old-plan new-plan old-runner new-runner".into());}
    let mut missing=0;
    for (index,pair) in args.chunks_exact(2).enumerate() {
        let before=surface(&pair[0])?;let after=surface(&pair[1])?;
        for (name,scope) in &before {
            if after.get(name)!=Some(scope) {missing+=1;println!("MISSING_OR_CHANGED family={index} name={name} original={scope} current={:?}",after.get(name));}
        }
        println!("SURFACE family={index} old={} new={} scope=top-level-export-names-and-visibility-union-all-cfg",before.len(),after.len());
    }
    println!("MISSING_TOTAL {missing}");
    if missing!=0 {std::process::exit(1);}
    Ok(())
}
