//! Host-side plan-admission pipeline (claim 8).
//!
//! Lives in `mvm-hostd` beside the host signing key it uses, so every driver
//! reaches one admission contract: `mvmctl run` and `mvmctl machine run`
//! today, and the `mvm-client` local backend once the boot seam wires local
//! `run`.
//!
//! Threads `synthesize_plan` + the host keypair into the
//! supervisor-equivalent admission flow:
//!
//! ```text
//! cmd_run(args)
//!   ↓ synthesize_plan(args)
//!   ↓ load_or_init_host_signer()
//!   ↓ sign_plan(plan, signer)
//!   ↓ verify_plan(signed, trusted) — catches signing-time bugs
//!   ↓ check_window(plan, now)      — G4 validity window
//!   ↓ nonce_store.check_and_insert  — G4 replay protection
//!   ↓ return AdmittedPlan { plan, plan_id, signer_id, signed }
//!   ↓ caller invokes backend.start() as before
//! ```
//!
//! What this module does NOT do (intentional scope reduction):
//!
//! - **Drive `Supervisor::launch`.** The supervisor's backend
//!   dispatch slot expects a `BackendLauncher` trait impl that
//!   wraps today's `AnyBackend::start()`; landing that wrapper
//!   means refactoring three call sites in 1084 lines of `up.rs`
//!   (the main path, the MVM_DIRECT_BOOT branch, and the `--watch`
//!   path). That refactor lands in a follow-up. **This module is
//!   the substrate that makes the eventual supervisor refactor a
//!   one-line change** — `admit_for_run` produces the
//!   `SignedExecutionPlan` the supervisor needs.
//!
//! - **Emit audit lines.** A later step wires `FileAuditSigner` onto
//!   the `AdmittedPlan`'s `plan_id`; this module is silent on audit.
//!
//! - **Resolve component slots.** A later step maps `PolicyRef →
//!   concrete SupervisorEgressProxy/ToolGate/...`. This module returns the
//!   plan with refs unresolved.
//!
//! ## Test seam
//!
//! `admit_for_run` takes a `Clock` and a `NonceLedger` so tests can
//! drive the validity window + replay protection deterministically.
//! Production callers use `SystemClock` + the host's nonce store.
//!
//! ## Externally-signed plans
//!
//! [`admit_signed_plan_for_run`] admits a plan signed by a fleet issuer the
//! operator pinned in the host config's `trusted_plan_signers`, verifying the
//! envelope against that set — never the host's own key — before any policy
//! gate reads the plan body. From the content-address check onward it runs
//! the same `finish_admission` tail as the self-signed path: the host's
//! ceiling, budget, validity window, and replay protection apply unchanged,
//! so the host stays the final authority over what it boots.

mod runtime_posture;
pub use runtime_posture::RunPosture;
mod sdk_sidecar;
pub use sdk_sidecar::{
    SdkSidecarBackendCompatibilityError, enforce_sdk_sidecar_attachment,
    enforce_sdk_sidecar_backend_compatibility, enforce_sdk_sidecar_for_launch,
};
mod rollback;
use rollback::{FailureAuditPolicy, UndoLaunch, undo_launch, undo_launch_with};

use anyhow::{Context, Result};
use chrono::Utc;
use ed25519_dalek::VerifyingKey;
use mvm_build::guest_libc::GuestLibc;
use mvm_contract::grants::Grants;
use mvm_contract::grants::ceiling::GrantCeiling;
use mvm_contract::protocol::resource_controls::EnforcedGrants;
use mvm_contract::provenance::{
    ActorRef, AttestationBinding, DecisionActorRole, DecisionCategory, DecisionOutcome,
    DecisionRecord, DecisionRecordBuilder,
};
use mvm_core::pack_cache::{PackVerifyCtx, resolve_pack_digest};
use mvm_core::packs::{PackKind, Sha256Hex};
use mvm_core::plan::bundle::{BundleResolver, TrustStore};
use mvm_core::plan::{
    ExecutionPlan, PlanId, PlanValidityError, SignedExecutionPlan, Variant,
    check_embedded_image_set_for_backend, check_window, sign_plan, verify_plan, verify_plan_bundle,
    verify_plan_id,
};
use mvm_core::policy::PolicyBundle;
use mvm_core::vm_backend::BackendKind;

use crate::audit::host_keypair::host_signer_id;
use mvm_contract::builder::BuilderError;
use mvm_core::plan::{SynthesisInput, synthesize_plan};
use mvm_core::vm_backend::{VmId, VmStartConfig};
use mvm_runtime::AnyBackend;
use sha2::{Digest, Sha256};

mod assurance_runtime;
mod bundle_environment;
mod canonical_kernel;
mod composition;
mod display_grants;
mod final_gates;
#[cfg(unix)]
mod installed_journal;
#[cfg(unix)]
pub use installed_journal::prepare_runtime as prepare_installed_journal_runtime;
mod grant_validation;
mod host_gates;
mod mailbox_posture;
mod nonce_ledger;
#[cfg(target_os = "macos")]
pub(crate) mod object_hvf;
mod registry_pack;
mod shares;
mod verb_grant_sidecar;

use assurance_runtime::AssuranceRuntimeBinding;
use grant_validation::{admit_grants, enforce_mailbox_retention};
#[cfg(test)]
use grant_validation::{enforceability_gate, host_cpu_mechanism_gap};
use host_gates::{admit_host_interface, admit_within_host_budget};
pub use mailbox_posture::{MailboxLaunchPosture, MailboxPostureHandoff};
pub use nonce_ledger::InMemoryNonceLedger;
use registry_pack::verify_registry_pack_assets;
use verb_grant_sidecar::mint_verb_grant_sidecar;

/// The external plan signers this host trusts, from operator config.
///
/// Read from config rather than taken as a parameter for the same reason as
/// the grant ceiling: admission's trust root must not be widen-able by the
/// caller asking for admission. A malformed pin fails the whole read, so the
/// set in force is exactly the set the operator wrote.
fn host_trusted_plan_signers() -> Result<Vec<(String, VerifyingKey)>> {
    mvm_core::user_config::load(None).trusted_plan_signer_keys()
}

/// The bound this host puts on what any workload may be granted.
///
/// Read from the operator's config, never from the plan under admission. The
/// two have different trust roots: whoever authors a plan also authors its
/// grants, so a ceiling the plan could carry would be a bound the bounded party
/// writes. There is no parameter for it here for the same reason — a caller
/// cannot hand admission a wider ceiling than the host configured.
fn host_grant_ceiling() -> GrantCeiling {
    mvm_core::user_config::load(None).grant_ceiling()
}

pub use bundle_environment::BundleEnvironmentRefused;
pub use mvm_core::time::{Clock, SystemClock};
pub use registry_pack::{BuiltPackBootCheck, PreparedBuiltPackRuntime, prepare_built_pack_start};

/// Result of a successful admission. Carries everything the caller
/// needs to hand to the backend (the plan + its id), to the audit
/// chain (the plan again, for `crate::supervisor::audit::for_plan`), and — for the
/// bridge audit substrate and any cross-process consumer — the canonical
/// `SignedExecutionPlan` envelope, which [`populate_audit_substrate`]
/// serializes verbatim onto `VmStartConfig.plan_json`.
///
/// **The fields are private, and that is the type's whole point.** Consumers
/// downstream of admission — the egress gate, the share enforcer, the workload
/// input gate — decide what a workload may do by reading this plan, so a value
/// of this type has to be a claim that the plan *was* signed, verified,
/// window-checked and replay-checked, not merely a struct shaped like one. Both
/// halves of that are enforced by privacy: `finish_admission` — the shared
/// tail of [`admit_for_run`] and [`admit_signed_plan_for_run`] — is the only
/// non-test code that can build one (a struct literal needs every field named,
/// and there is no `Default` to spread from), and no accessor hands out a `&mut`
/// or an owned field, so a caller that legitimately holds one cannot afterwards
/// push a grant into `plan.services` that admission never saw.
#[derive(Debug)]
pub struct AdmittedPlan {
    plan: ExecutionPlan,
    plan_id: PlanId,
    variant: Variant,
    signer_id: String,
    signed: SignedExecutionPlan,
    extensions: Vec<AdmittedExtension>,
    assurance_runtime: Option<AssuranceRuntimeBinding>,
    canonical_kernel: Option<std::sync::Arc<canonical_kernel::AdmittedKernel>>,
    #[cfg(unix)]
    direct_owner: Option<std::sync::Weak<mvm_core::host_lifetime::HostLifetimeAnchor>>,
    backend: Option<BackendKind>,
    /// Set once the backend has been started under this admission. An
    /// admission authorizes one launch; the plan is handed back on
    /// `StartedMachine`, and holding it again must not start a second backend.
    dispatched: bool,
    #[cfg(target_os = "linux")]
    object_firecracker: Option<mvm_runtime::backend::OriginalObjectFirecracker>,
    #[cfg(target_os = "macos")]
    object_hvf: Option<object_hvf::OriginalHvf>,
}

/// Re-verified host artifact behind one extension binding in the signed plan.
#[derive(Debug, Clone)]
pub struct AdmittedExtension {
    pub binding: mvm_contract::protocol::extension_pack::ExtensionPlanBinding,
    pub root: std::path::PathBuf,
}

#[cfg(target_os = "macos")]
fn object_host_backend() -> BackendKind {
    BackendKind::Hvf
}
#[cfg(target_os = "linux")]
fn object_host_backend() -> BackendKind {
    BackendKind::Firecracker
}

impl AdmittedPlan {
    /// The verified plan body — what every downstream authorization decision
    /// reads.
    #[must_use]
    pub fn plan(&self) -> &ExecutionPlan {
        &self.plan
    }

    #[cfg(target_os = "linux")]
    pub(crate) fn object_firecracker(
        &self,
    ) -> Result<&mvm_runtime::backend::OriginalObjectFirecracker> {
        self.object_firecracker
            .as_ref()
            .context("no original selected Firecracker launch for this admission")
    }
    /// Dispatch a selected persistent SDK boot only under this original
    /// reservation, rootfs digest and signed local plan. This consumes the
    /// admission even if the backend subsequently reports a launch error.
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    pub fn start_persistent_object_original(
        &mut self,
        launch: &crate::mailbox_process::original_journal::object_workers::OriginalObjectLaunch<'_>,
        backend: &AnyBackend,
        config: VmStartConfig,
        images: mvm_vmm::driver::prepared_disks::WritableVolumeImages,
        bundle: Option<&PolicyBundle>,
    ) -> Result<VmId> {
        self.start_persistent_object_original_with_verified_runtime(
            launch, backend, config, images, bundle, None,
        )
    }

    /// Keep authenticated runtime evidence beside the original selected admission.
    #[cfg(any(target_os = "linux", target_os = "macos"))]
    pub fn start_persistent_object_original_with_verified_runtime(
        &mut self,
        launch: &crate::mailbox_process::original_journal::object_workers::OriginalObjectLaunch<'_>,
        backend: &AnyBackend,
        config: VmStartConfig,
        images: mvm_vmm::driver::prepared_disks::WritableVolumeImages,
        bundle: Option<&PolicyBundle>,
        verified_runtime: Option<&mvm_runtime::runtime_evidence::VerifiedRuntimeSet>,
    ) -> Result<VmId> {
        anyhow::ensure!(
            !self.dispatched
                && self.variant == Variant::Prod
                && self.backend == Some(object_host_backend())
                && backend.kind() == object_host_backend(),
            "requires a fresh original object admission for this native backend"
        );
        launch.require_open()?;
        launch
            .plan()
            .verify_selected_plan(self.plan(), SystemClock.now().timestamp_millis())?;
        let signed: SignedExecutionPlan = serde_json::from_str(
            config
                .plan_json
                .as_deref()
                .context("missing original signed plan")?,
        )?;
        anyhow::ensure!(
            signed.0.signature == self.signed.0.signature
                && signed.0.payload == self.signed.0.payload
                && signed.0.signer_id == self.signed.0.signer_id
                && config.name == self.plan.image.name
                && mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(
                    &config.rootfs_path
                ))? == self.plan.image.sha256,
            "different persistent boot image or original signed plan"
        );
        RunPosture::on_backend(self.variant, backend.kind())
            .with_runtime(Some(&config))
            .with_verified_runtime(verified_runtime)
            .verify_launch_runtime(self.plan())?;
        if self.assurance_runtime.is_some() {
            self.verify_assurance_launch(&config, verified_runtime)?;
        }
        let (config, runtime) =
            final_gates::run_post_admission_gates(config, self, backend.kind(), bundle)
                .map_err(|(stage, e)| e.context(stage))?;
        registry_pack::verify_runtime_at_dispatch(runtime.as_ref(), &config, self, None)?;
        crate::mailbox_process::require_servable(
            &config,
            backend,
            self.mailbox_posture().as_ref(),
        )?;
        self.dispatched = true;
        #[cfg(target_os = "linux")]
        {
            let (id, original) = backend.start_original_object_firecracker_with_verified_runtime(
                &config,
                images,
                verified_runtime,
            )?;
            self.object_firecracker = Some(original);
            Ok(id)
        }
        #[cfg(target_os = "macos")]
        self.activate_object_hvf(
            launch.hvf_original(),
            backend,
            config,
            images,
            verified_runtime,
        )
    }

    #[cfg(target_os = "linux")]
    pub fn abort_unserved_object(&self, backend: &AnyBackend, id: &VmId) -> Result<()> {
        let native = self.object_firecracker()?;
        native.require_live()?;
        native.boot()?.check_plan(self.plan())?;
        let (pid, _) = native.original_peer()?;
        anyhow::ensure!(
            backend.kind() == BackendKind::Firecracker
                && self.plan.image.name == id.0
                && backend.host_process_id(id)? == Some(pid),
            "original VMM changed before abort"
        );
        backend.abort_start(id).map(|_| ())
    }
    /// The plan's content-address, re-derived and checked during admission.
    #[must_use]
    pub fn plan_id(&self) -> &PlanId {
        &self.plan_id
    }

    /// Retain this host admission's mailbox posture for the exact VM it admitted.
    #[must_use]
    pub fn mailbox_posture(&self) -> Option<MailboxLaunchPosture> {
        self.plan.mailbox.map(|grant| MailboxLaunchPosture {
            variant: self.variant,
            plan_id: self.plan_id.clone(),
            plan_nonce: self.plan.nonce.clone(),
            vm_name: self.plan.image.name.clone(),
            grant,
        })
    }

    /// The signer whose key the plan verified under — this host's own signer
    /// for a synthesized run, or the pinned external signer for a
    /// fleet-issued one.
    #[must_use]
    pub fn signer_id(&self) -> &str {
        &self.signer_id
    }

    /// Check the exact original parent bound into this dispatched direct Linux admission.
    #[cfg(target_os = "linux")]
    pub fn check_original_entrypoint(
        &self,
        owner: &std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>,
    ) -> Result<()> {
        let same_original = self
            .direct_owner
            .as_ref()
            .and_then(std::sync::Weak::upgrade)
            .is_some_and(|bound| std::sync::Arc::ptr_eq(&bound, owner));
        anyhow::ensure!(
            same_original
                && !self.plan.stream_retention.persists()
                && self.plan.stream_edges.is_empty()
                && self.dispatched
                && self.backend == Some(BackendKind::Firecracker)
                && self
                    .plan
                    .agent_verbs
                    .as_ref()
                    .is_some_and(|verbs| verbs.iter().any(|v| v.as_str() == "run-entrypoint")),
            "entrypoint differs from original signed direct launch"
        );
        Ok(())
    }

    /// The canonical signed envelope, for a consumer that re-verifies rather
    /// than trusting this process.
    #[must_use]
    pub fn signed(&self) -> &SignedExecutionPlan {
        &self.signed
    }

    /// Exact re-verified extension artifacts available to this launch.
    #[must_use]
    pub fn extensions(&self) -> &[AdmittedExtension] {
        &self.extensions
    }

    /// Mint one without admitting it — **tests only**, and unreachable from a
    /// production build because the whole `impl` is `#[cfg(test)]`.
    ///
    /// A test that exercises a downstream consumer needs a plan of its own
    /// choosing; going through [`admit_for_run`] for each would drag the
    /// keystore and the nonce ledger into tests about something else. That
    /// convenience is exactly the forgery this type exists to prevent, so it is
    /// compiled out of every artifact anyone ships.
    #[cfg(test)]
    pub(crate) fn for_test(
        plan: ExecutionPlan,
        signer_id: String,
        signed: SignedExecutionPlan,
    ) -> Self {
        Self {
            plan_id: plan.plan_id.clone(),
            variant: Variant::Dev,
            signer_id,
            plan,
            signed,
            extensions: Vec::new(),
            assurance_runtime: None,
            canonical_kernel: None,
            #[cfg(unix)]
            direct_owner: None,
            backend: None,
            dispatched: false,
            #[cfg(target_os = "linux")]
            object_firecracker: None,
            #[cfg(target_os = "macos")]
            object_hvf: None,
        }
    }

    #[cfg(test)]
    pub(crate) fn with_assurance_runtime_for_test(mut self, config: &VmStartConfig) -> Self {
        self.assurance_runtime = Some(
            AssuranceRuntimeBinding::verify(config, &self.plan, None)
                .expect("verified test runtime"),
        );
        self
    }
}

/// Optional bundle-admission context for plans pinned to a
/// `.mvmpkg`. Carries the resolver (where to find the archive
/// bytes by sha256) and the trust store (which publisher pubkeys
/// to accept). `admit_for_run` ignores it when the plan has no
/// pin; rejects when the plan has a pin but the context is
/// `None` (operator misconfiguration); runs full re-verify when
/// both are present.
pub struct BundleAdmissionContext<'a> {
    pub resolver: &'a dyn BundleResolver,
    pub trust: &'a dyn TrustStore,
    /// Required when the bundle embeds an image set. This is the backend that
    /// is actually about to boot, not a manifest label.
    pub image: Option<BundleImageAdmissionContext<'a>>,
}

#[derive(Clone, Copy)]
pub struct BundleImageAdmissionContext<'a> {
    pub arch: mvm_core::arch::GuestArch,
    pub backend: &'a mvm_core::image_set::BackendImageSupport,
    pub host_protocols: &'a mvm_core::image_set::HostProtocolSupport,
}

/// Trust and revocation inputs for exact extension-pack re-verification.
pub struct ExtensionAdmissionContext<'a> {
    verify: &'a PackVerifyCtx<'a>,
    cache_root: Option<&'a std::path::Path>,
}

impl<'a> ExtensionAdmissionContext<'a> {
    /// Use the ordinary MVM pack cache.
    #[must_use]
    pub fn ambient(verify: &'a PackVerifyCtx<'a>) -> Self {
        Self {
            verify,
            cache_root: None,
        }
    }

    /// Use an explicit provider-owned pack cache.
    #[must_use]
    pub fn at(cache_root: &'a std::path::Path, verify: &'a PackVerifyCtx<'a>) -> Self {
        Self {
            verify,
            cache_root: Some(cache_root),
        }
    }

    fn resolve(
        &self,
        digest: &Sha256Hex,
    ) -> Result<Option<mvm_core::pack_cache::VerifiedPackRecord>> {
        match self.cache_root {
            Some(cache_root) => mvm_core::pack_cache::resolve_pack_digest_at(
                cache_root,
                PackKind::Extension,
                digest,
                self.verify,
            ),
            None => resolve_pack_digest(PackKind::Extension, digest, self.verify),
        }
        .map_err(Into::into)
    }
}

/// Run the full admission pipeline for one boot.
///
/// On success, the caller proceeds to `backend.start()` knowing the
/// plan was signed under the host signer, verified with the host's
/// own public key, satisfies its own validity window, hasn't been
/// admitted before (replay protection), and — when the plan pins a
/// `.mvmpkg` bundle — the on-disk archive matches the pin
/// byte-for-byte and verifies under the trust store.
///
/// On failure, the user gets a clear error per failure class:
///   - `tenant must not be empty` / `vm_name must not be empty` —
///     synthesis-time guard
///   - `host signer at {path} has mode {found}; expected 0600` —
///     keystore guard
///   - `plan validity window violated: {detail}` — G4 window check
///   - `plan replay detected for signer {id}; nonce {hex}` — G4 nonce
///   - `bundle re-verify failed: {detail}` — pinned bundle missing,
///     unknown publisher, tampered, or sha256/sig/key_id mismatch
///   - `grant exceeds this host's ceiling: {detail}` — the request asked
///     for more than the host's configured bound in some dimension
///   - `refusing an unenforceable grant: {detail}` — the posture is
///     [`Variant::Prod`] and the backend this run boots on has no mechanism
///     behind a declared grant. The same input under [`Variant::Dev`] warns and
///     proceeds
///   - `plan declares runtime profile {a} but this run boots on {b}` — the
///     plan and the resolved backend disagree about what is about to run
///
/// `posture` is what the plan cannot be trusted to say: whether this is a
/// sealed production launch or a developer's boot, and which backend will
/// actually boot it. See [`RunPosture`].
#[tracing::instrument(skip_all)]
/// Admission decision over an already-synthesized plan.
///
/// This is the inner admission routine that [`admit_for_run`] uses after
/// synthesizing a plan. Keeping it separate lets callers emit a structured
/// refusal audit entry when admission fails, binding the refusal to the
/// plan that was refused.
///
/// `extension_ctx` carries the trust and revocation state a plan with
/// extension bindings is re-verified under: every digest-pinned pack is
/// checked again before signing. `None` refuses any plan that binds an
/// extension.
pub fn admit_plan_for_run(
    plan: &ExecutionPlan,
    clock: &dyn Clock,
    ledger: &InMemoryNonceLedger,
    host_signer_keys_dir: Option<&std::path::Path>,
    bundle_ctx: Option<&BundleAdmissionContext<'_>>,
    extension_ctx: Option<&ExtensionAdmissionContext<'_>>,
    posture: RunPosture,
) -> Result<AdmittedPlan> {
    posture.verify_launch_runtime(plan)?;
    let assurance_runtime = posture.assurance_runtime(plan)?;
    validate_extension_bindings(plan)?;
    let extensions = verify_extension_packs(plan, extension_ctx)?;
    verify_registry_pack_assets(plan)?;
    // Grants are checked in the pre-keystore window, and for the same
    // reason as synthesis: a plan we would refuse must never leave here with a
    // signature on it. A signed refused plan is indistinguishable from a
    // signed admitted one to anything downstream that only checks the
    // signature.
    admit_grants(plan, &host_grant_ceiling(), posture)?;
    posture.enforce_journal(
        plan,
        mvm_core::user_config::load(None).max_mailbox_retention_ms,
    )?;

    // The ceiling above bounds this one workload; the budget bounds the sum of
    // every live one. Both sit in the pre-keystore window for the same reason,
    // and both read host config rather than the plan. The total is measured
    // over live machines only — counting records instead would turn a single
    // crashed VM into a permanent refusal of every later boot.
    admit_within_host_budget(plan)?;
    admit_host_interface(plan)?;

    // Load or generate the host signer. load_or_init refuses
    // loose perms; that error propagates verbatim.
    let signer = match host_signer_keys_dir {
        Some(dir) => crate::audit::host_keypair::load_or_init_at(dir)?,
        None => crate::audit::host_keypair::load_or_init()?,
    };
    let signer_id = host_signer_id();

    // Sign + verify roundtrip. Verifying our own signature catches
    // wire-format bugs that would otherwise surface at a real
    // verifier (mvmd's supervisor, an upstream consumer's mvm).
    let signed = sign_plan(plan, &signer.signing, &signer_id);
    let trusted: [(&str, &VerifyingKey); 1] = [(&signer_id, &signer.verifying)];
    let verified = verify_plan(&signed, &trusted).context("verifying just-signed plan")?;

    finish_admission(VerifiedAdmission {
        verified,
        signed,
        signer_id,
        extensions,
        assurance_runtime,
        posture,
        clock,
        ledger,
        bundle_ctx,
    })
}

/// Admit an externally-signed plan — one signed by a fleet issuer the
/// operator pinned in `trusted_plan_signers`, not by this host's own key.
///
/// The order differs from the self-signed path in exactly the way the trust
/// boundary dictates: the envelope is verified against the pinned signer set
/// *first*, because every byte of it is attacker-controlled until then, and
/// only afterwards do the host's own policy gates (extension bindings, grant
/// ceiling, host budget) read the plan. From [`verify_plan_id`] onward both
/// paths run the same checks through [`finish_admission`] — the host remains
/// the final authority over what it boots, whoever signed the plan.
///
/// The trusted set comes from operator config and nowhere else, so a caller
/// cannot hand admission a wider trust than the host configured. An empty set
/// is the fail-closed default: every externally-signed plan is refused.
///
/// A refusal never emits an audit entry: the plan body is the only anchor a
/// refusal entry could bind to, and until the signature verifies the body is
/// an attacker's claim, not a fact to record.
#[tracing::instrument(skip_all)]
pub fn admit_signed_plan_for_run(
    signed: &SignedExecutionPlan,
    clock: &dyn Clock,
    ledger: &InMemoryNonceLedger,
    bundle_ctx: Option<&BundleAdmissionContext<'_>>,
    posture: RunPosture,
) -> Result<AdmittedPlan> {
    verify_external_plan(signed)?.admit(clock, ledger, bundle_ctx, posture)
}

pub(crate) struct VerifiedExternalPlan<'a> {
    body: ExecutionPlan,
    signed: &'a SignedExecutionPlan,
}

pub(crate) fn verify_external_plan(
    signed: &SignedExecutionPlan,
) -> Result<VerifiedExternalPlan<'_>> {
    let trusted = host_trusted_plan_signers()?;
    if trusted.is_empty() {
        anyhow::bail!(
            "refusing the externally-signed plan: this host pins no trusted plan signers; \
             set `trusted_plan_signers` in the host config.toml to admit fleet-signed plans"
        );
    }
    let trusted_refs: Vec<(&str, &VerifyingKey)> =
        trusted.iter().map(|(id, key)| (id.as_str(), key)).collect();
    let verified =
        verify_plan(signed, &trusted_refs).context("verifying externally-signed plan")?;
    Ok(VerifiedExternalPlan {
        body: verified,
        signed,
    })
}

impl VerifiedExternalPlan<'_> {
    pub(crate) fn plan(&self) -> &ExecutionPlan {
        &self.body
    }

    pub(crate) fn admit(
        self,
        clock: &dyn Clock,
        ledger: &InMemoryNonceLedger,
        bundle_ctx: Option<&BundleAdmissionContext<'_>>,
        posture: RunPosture,
    ) -> Result<AdmittedPlan> {
        let verified = self.body;
        let signed = self.signed;
        let signer_id = signed.0.signer_id.clone();
        posture.verify_launch_runtime(&verified)?;
        let assurance_runtime = posture.assurance_runtime(&verified)?;
        validate_extension_bindings(&verified)?;
        // No extension verification context on this path: a plan that binds
        // optional extensions is refused rather than admitted unchecked.
        let extensions = verify_extension_packs(&verified, None)?;
        verify_registry_pack_assets(&verified)?;
        admit_grants(&verified, &host_grant_ceiling(), posture)?;
        posture.enforce_journal(
            &verified,
            mvm_core::user_config::load(None).max_mailbox_retention_ms,
        )?;
        admit_within_host_budget(&verified)?;
        admit_host_interface(&verified)?;

        finish_admission(VerifiedAdmission {
            verified,
            // The caller lends the envelope; the admitted plan owns a copy so
            // downstream consumers can re-verify without trusting this process.
            signed: signed.clone(),
            signer_id,
            extensions,
            assurance_runtime,
            posture,
            clock,
            ledger,
            bundle_ctx,
        })
    }
}

/// Everything the shared post-verification tail of admission needs.
///
/// A params struct rather than seven positional arguments: `verified`,
/// `signed`, and `signer_id` travel together from whichever path verified
/// them, and a positional call could transpose them with nothing to catch it.
struct VerifiedAdmission<'a> {
    /// The plan body, already signature-verified against the trust root of
    /// the path that produced it (the host signer, or the operator's pinned
    /// external signer set).
    verified: ExecutionPlan,
    /// The envelope `verified` was decoded from, carried verbatim onto the
    /// launch config for consumers that re-verify.
    signed: SignedExecutionPlan,
    /// The signer the envelope verified under — the audit chain records it.
    signer_id: String,
    /// Re-verified extension artifacts, empty when the plan binds none.
    extensions: Vec<AdmittedExtension>,
    assurance_runtime: Option<AssuranceRuntimeBinding>,
    posture: RunPosture<'a>,
    clock: &'a dyn Clock,
    ledger: &'a InMemoryNonceLedger,
    bundle_ctx: Option<&'a BundleAdmissionContext<'a>>,
}

/// The checks every admitted plan passes after its signature has verified,
/// shared by the host-signed and externally-signed paths: content-address,
/// ingress shape, validity window, replay protection, bundle re-verify.
///
/// The replay insert is deliberately last but one: every check that can
/// refuse runs before the nonce is spent, so a refused plan can be corrected
/// and resubmitted, while an admitted one cannot be replayed.
fn finish_admission(parts: VerifiedAdmission<'_>) -> Result<AdmittedPlan> {
    let VerifiedAdmission {
        verified,
        signed,
        signer_id,
        extensions,
        assurance_runtime,
        clock,
        ledger,
        bundle_ctx,
        posture,
    } = parts;
    let backend = posture.backend;

    // The plan_id is the content-address of the plan body — recompute it and
    // refuse a plan whose stored id doesn't match, so a run is only ever
    // admitted under an id that genuinely addresses its content.
    verify_plan_id(&verified).context("plan_id content-address check")?;

    verified
        .validate_ingress()
        .context("validating signed ingress mappings")?;

    // Validity window — refuses plans whose now() is outside
    // [valid_from, valid_until). For freshly-synthesized plans this
    // can only fire if the host's clock changed during signing or if
    // someone overrode the validity window in synthesis defaults; for an
    // externally-signed plan it is the host's own check that the window the
    // fleet issuer chose still holds here.
    let now = clock.now();
    check_window(&verified, now).map_err(|e| match e {
        PlanValidityError::NotYetValid { .. } | PlanValidityError::Expired { .. } => {
            anyhow::anyhow!("plan validity window violated: {e}")
        }
        other => anyhow::anyhow!("plan validity error: {other}"),
    })?;
    #[cfg(unix)]
    installed_journal::capture_owner(posture, &verified)?;

    // Bundle re-verify at admit time. Only fires
    // when the plan pinned a bundle; missing context with a pinned
    // plan is operator misconfiguration (the driver wasn't wired
    // with a resolver/trust store), so we refuse rather than skip
    // silently.
    let canonical_kernel = canonical_kernel::AdmittedKernel::capture(posture, &verified)?;
    if let Some(pin) = verified.bundle.as_ref() {
        let ctx = bundle_ctx.ok_or_else(|| {
            anyhow::anyhow!(
                "plan pins bundle {bundle} but no BundleAdmissionContext was provided — refuse",
                bundle = pin.bundle_sha256
            )
        })?;
        let verified_bundle = if let Some(config) = posture.runtime_config {
            if let Some(owner) = &config.canonical_kernel {
                mvm_core::plan::bundle::verify_canonical_plan_bundle(
                    pin,
                    ctx.resolver,
                    ctx.trust,
                    owner,
                    config,
                    posture
                        .backend
                        .context("canonical kernel admission requires actual backend")?,
                    &mvm_build::stage0_kernel::current_image_set_protocol_support(),
                )
            } else {
                verify_plan_bundle(pin, ctx.resolver, ctx.trust)
            }
        } else {
            verify_plan_bundle(pin, ctx.resolver, ctx.trust)
        }
        .with_context(|| format!("bundle re-verify for pin {}", pin.bundle_sha256))?;
        bundle_environment::verify_environment(&verified, &verified_bundle.manifest, posture)?;
        composition::verify(&verified, &verified_bundle)?;
        if !verified_bundle.embedded_image_sets.is_empty() {
            let image = ctx.image.ok_or_else(|| {
                anyhow::anyhow!(
                    "plan pins bundle {} with an embedded image set but admission has no selected backend image contract — refuse",
                    pin.bundle_sha256
                )
            })?;
            for embedded in &verified_bundle.embedded_image_sets {
                check_embedded_image_set_for_backend(
                    embedded,
                    image.arch,
                    image.backend,
                    image.host_protocols,
                )
                .with_context(|| {
                    format!(
                        "selected backend refuses embedded image set in bundle {}",
                        pin.bundle_sha256
                    )
                })?;
            }
        }
        // The signature-verified manifest is the only trustworthy statement of
        // the bundle's architecture — the boot-time resolver reads an unsigned
        // registry copy. Refuse here so a foreign-arch pin never reaches a
        // backend, where it surfaces as an unrelated-looking boot failure.
        mvm_core::arch::GuestArch::require_host(&verified_bundle.manifest.arch).map_err(|e| {
            anyhow::anyhow!(
                "plan pins bundle {bundle} which {e} — refuse",
                bundle = pin.bundle_sha256
            )
        })?;
    }

    // Spend the nonce only after every fallible descriptor and bundle check.
    // Refusal must not consume an externally signed plan's replay allowance.
    ledger.spend(&signer_id, &verified, now)?;

    Ok(AdmittedPlan {
        plan_id: verified.plan_id.clone(),
        variant: posture.variant(),
        signer_id,
        plan: verified,
        signed,
        extensions,
        assurance_runtime,
        canonical_kernel,
        #[cfg(unix)]
        direct_owner: posture.direct_owner.map(std::sync::Arc::downgrade),
        backend,
        dispatched: false,
        #[cfg(target_os = "linux")]
        object_firecracker: None,
        #[cfg(target_os = "macos")]
        object_hvf: None,
    })
}

fn validate_extension_bindings(plan: &ExecutionPlan) -> Result<()> {
    if !plan.extensions.is_empty() {
        let verbs = plan.agent_verbs.as_deref().unwrap_or_default();
        for required in ["run-extension", "cancel-extension"] {
            if !verbs.iter().any(|verb| verb.as_str() == required) {
                anyhow::bail!(
                    "signed plans with optional extensions must grant the {required} agent verb"
                );
            }
        }
    }
    let mut extension_ids = std::collections::HashSet::new();
    let mut pack_digests = std::collections::HashSet::new();
    let mut capabilities = std::collections::HashSet::new();
    for extension in &plan.extensions {
        extension
            .validate()
            .map_err(|error| anyhow::anyhow!("invalid extension binding: {error}"))?;
        if extension.placement
            != mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload
        {
            anyhow::bail!(
                "extension placement isolated_controller is not executable by this MVM version"
            );
        }
        if !extension_ids.insert(extension.extension_id.clone()) {
            anyhow::bail!("duplicate extension identity in signed plan");
        }
        if !pack_digests.insert(extension.pack_digest) {
            anyhow::bail!("duplicate extension pack digest in signed plan");
        }
        for binding in &extension.capabilities {
            if !plan.services.contains(&binding.capability.service) {
                anyhow::bail!(
                    "extension capability service {} is not bound by the signed plan",
                    binding.capability.service
                );
            }
            if !capabilities.insert(binding.capability.clone()) {
                anyhow::bail!("duplicate extension capability in signed plan");
            }
        }
    }
    Ok(())
}

fn verify_extension_packs(
    plan: &ExecutionPlan,
    context: Option<&ExtensionAdmissionContext<'_>>,
) -> Result<Vec<AdmittedExtension>> {
    if plan.extensions.is_empty() {
        return Ok(Vec::new());
    }
    let context = context.ok_or_else(|| {
        anyhow::anyhow!(
            "plan binds optional extensions but no extension verification context was provided"
        )
    })?;
    plan.extensions
        .iter()
        .map(|binding| {
            let digest = Sha256Hex::new(hex::encode(binding.pack_digest))
                .context("decoding extension pack digest")?;
            let digest_text = digest.as_str();
            let record = context
                .resolve(&digest)
                .with_context(|| format!("re-verifying extension pack {digest_text}"))?
                .ok_or_else(|| anyhow::anyhow!("extension pack {digest_text} is not installed"))?;
            let contract = record.manifest.extension.as_ref().ok_or_else(|| {
                anyhow::anyhow!("verified extension pack {digest_text} has no extension contract")
            })?;
            let contract_digest: [u8; 32] = Sha256::digest(
                serde_json::to_vec(contract).context("encoding extension contract")?,
            )
            .into();
            if !extension_binding_matches_contract(binding, contract, contract_digest) {
                anyhow::bail!("extension binding does not match verified pack {digest_text}");
            }
            let maximum: std::collections::HashSet<_> = contract
                .capabilities
                .iter()
                .map(mvm_contract::protocol::agent_capability::CapabilityDescriptor::binding)
                .collect();
            if binding
                .capabilities
                .iter()
                .any(|capability| !maximum.contains(capability))
            {
                anyhow::bail!("extension binding widens verified pack authority {digest_text}");
            }
            if !budgets_are_narrower(binding.budgets, contract.budgets) {
                anyhow::bail!("extension binding widens verified pack budgets {digest_text}");
            }
            let artifact = record.dir.root.join(&binding.artifact);
            if !artifact.is_file() {
                anyhow::bail!("verified extension artifact is missing from pack {digest_text}");
            }
            let artifact_size = std::fs::metadata(&artifact)
                .with_context(|| format!("inspecting extension artifact for {digest_text}"))?
                .len();
            if extension_artifact_exceeds_budget(artifact_size, binding.budgets.max_artifact_bytes)
            {
                anyhow::bail!(
                    "verified extension artifact exceeds admitted budget for {digest_text}"
                );
            }
            Ok(AdmittedExtension {
                binding: binding.clone(),
                root: record.dir.root,
            })
        })
        .collect()
}

fn extension_binding_matches_contract(
    binding: &mvm_contract::protocol::extension_pack::ExtensionPlanBinding,
    contract: &mvm_contract::protocol::extension_pack::ExtensionPackContract,
    contract_digest: [u8; 32],
) -> bool {
    binding.extension_id == contract.extension_id
        && binding.version == contract.version
        && binding.contract_digest == contract_digest
        && binding.placement == contract.placement
        && binding.artifact == contract.artifact
        && binding.entrypoint == contract.entrypoint
}

fn extension_artifact_exceeds_budget(artifact_size: u64, maximum_size: u64) -> bool {
    artifact_size > maximum_size
}

fn budgets_are_narrower(
    admitted: mvm_contract::protocol::extension_pack::ExtensionBudgets,
    maximum: mvm_contract::protocol::extension_pack::ExtensionBudgets,
) -> bool {
    admitted.cpu_millis <= maximum.cpu_millis
        && admitted.memory_bytes <= maximum.memory_bytes
        && admitted.duration_ms <= maximum.duration_ms
        && admitted.max_steps <= maximum.max_steps
        && admitted.max_concurrency <= maximum.max_concurrency
        && admitted.max_payload_bytes <= maximum.max_payload_bytes
        && admitted.max_output_bytes <= maximum.max_output_bytes
        && admitted.max_artifact_bytes <= maximum.max_artifact_bytes
}

/// Synthesize a plan and admit it for execution.
///
/// This is the high-level admission entry point. It first synthesizes the
/// plan, then delegates to [`admit_plan_for_run`]. Callers that need to emit
/// a structured refusal audit entry should synthesize first and call
/// [`admit_plan_for_run`] directly.
#[tracing::instrument(skip_all)]
pub fn admit_for_run(
    input: &SynthesisInput<'_>,
    clock: &dyn Clock,
    ledger: &InMemoryNonceLedger,
    host_signer_keys_dir: Option<&std::path::Path>,
    bundle_ctx: Option<&BundleAdmissionContext<'_>>,
    posture: RunPosture,
) -> Result<AdmittedPlan> {
    // Build the unsigned plan first. Synthesis failures are caught
    // before we touch the keystore — keeps "signed bad plan" from
    // being an outcome.
    let mut plan = synthesize_plan(input).context("synthesizing plan")?;
    if let Some(original) = posture.object_plan {
        original.apply_unsigned(&mut plan, clock.now().timestamp_millis())?;
    }
    if let Some(identity) = posture.release_identity()? {
        plan.runtime_identity = Some(identity);
    }
    admit_plan_for_run(
        &plan,
        clock,
        ledger,
        host_signer_keys_dir,
        bundle_ctx,
        None,
        posture,
    )
}

/// Soft caps on the JSON envelope sizes flowing through
/// `VmStartConfig` → `SupervisorConfig` over the supervisor's
/// stdin pipe. Adversarial envelopes are a DoS vector (memory pressure
/// on the supervisor + pipe-buffer pressure on the producer). 1 MiB /
/// 4 MiB are generous for legitimate plans / bundles and tight enough
/// to refuse pathological inputs.
const PLAN_JSON_MAX_BYTES: usize = 1024 * 1024;
const BUNDLE_JSON_MAX_BYTES: usize = 4 * 1024 * 1024;

/// Refuse an envelope over its byte cap.
///
/// A one-line comparison inlined at each call site is not reachable by a
/// test at its boundary: the only way to exercise it is to serialize a
/// real plan of exactly the cap, which is impractical to construct. So the
/// comparison lives here, where `cap - 1`, `cap` and `cap + 1` are three
/// cheap assertions.
///
/// The direction matters. Loosening `>` to `>=` refuses at exactly the cap
/// — stricter, and merely wrong. Tightening it to `==` refuses *only* at
/// exactly the cap and admits everything larger, which turns the cap into
/// no cap at all and reopens the memory-pressure vector it exists to
/// close.
fn enforce_size_cap(what: &str, len: usize, cap: usize) -> Result<()> {
    if len > cap {
        anyhow::bail!("{what} exceeds {cap} byte cap (got {len}); refusing");
    }
    Ok(())
}

/// Populate the three `VmStartConfig` audit-substrate fields
/// (`tenant_id`, `plan_json`, `bundle_json`) from the admitted
/// plan. Call after the `VmStartConfig` is built and before
/// `backend.start()`; the libkrun/HVF backends read these to wire
/// `SupervisorConfig.{tenant_id, audit_dir, gateway_audit_socket,
/// gateway_events_socket, signing_key_path}` and activate the
/// bridge-factory path.
///
/// JSON-encoded so the `VmStartConfig` wire type stays a serde seam
/// with no typed coupling to `mvm_core::plan` at the backend boundary. The
/// supervisor re-verifies the `SignedExecutionPlan` envelope before
/// trusting any decoded field — see
/// `mvm_hostd::supervisor::supervisor::SupervisorAdmission::admit`.
///
/// **Do not log the resulting `plan_json` / `bundle_json` values.**
/// The signed envelope may contain secret bindings, environment
/// variables, or policy refs that resolve to credentials. Treat as
/// opaque transport bytes.
/// Thread *only* the admitted tenant label onto the `VmStartConfig`.
///
/// The per-VM host-services broker (`host.audit.v1` / `host.time.v1` /
/// `host.cost.v1`) keys its spawn off `config.tenant_id`, so any admitted
/// workload must carry it — `host.audit.v1` is implicitly available to any
/// admitted workload. This is decoupled from
/// [`populate_audit_substrate`]: the broker needs the tenant string, **not**
/// the signed `plan_json`, whose presence flips libkrun/HVF workload boots onto
/// the claim-10 gateway-bridge supervisor path. Call this unconditionally; call
/// `populate_audit_substrate` when a backend has a signed-plan consumer.
pub fn thread_tenant_id(cfg: &mut mvm_core::vm_backend::VmStartConfig, admitted: &AdmittedPlan) {
    cfg.tenant_id = Some(admitted.plan().tenant.0.clone());
}

/// Carry the admitted CPU bound onto the launch config, so the backend can be
/// born inside it rather than adjusted into it afterwards.
///
/// Taken from the **signed, admitted** plan and nowhere else. A caller-supplied
/// `cfg.cpu_grant` would be a bound chosen outside the admission that just
/// checked it against the host's ceiling, so whatever was there is overwritten
/// — including with `None`, which is what an uncapped plan means.
pub fn thread_cpu_grant(cfg: &mut mvm_core::vm_backend::VmStartConfig, admitted: &AdmittedPlan) {
    cfg.cpu_grant = admitted.plan().grants.as_ref().and_then(|g| g.cpu);
}

pub fn populate_audit_substrate(
    cfg: &mut mvm_core::vm_backend::VmStartConfig,
    admitted: &AdmittedPlan,
    policy_bundle: Option<&PolicyBundle>,
) -> Result<()> {
    thread_tenant_id(cfg, admitted);
    thread_cpu_grant(cfg, admitted);
    admitted.bind_canonical_kernel(cfg)?;

    let plan_json = serde_json::to_string(admitted.signed())
        .context("serializing SignedExecutionPlan for VmStartConfig.plan_json")?;
    enforce_size_cap("plan_json", plan_json.len(), PLAN_JSON_MAX_BYTES)?;
    cfg.plan_json = Some(plan_json);

    // `bundle_json` carries the resolved tenant **PolicyBundle** (network /
    // egress / tool policy) that the supervisor's L4 gate + observers consume.
    // It is NOT the ExecutionPlan's `.mvmpkg` artifact pin
    // (`admitted.plan().bundle`, a `PlanArtifact` — content-addressed
    // kernel/rootfs, verified separately at admit time via `verify_plan_bundle`).
    // Feeding the pin here was a conflation the supervisor's PolicyBundle decode
    // would reject. `None` until a policy-bundle source is wired.
    cfg.bundle_json = match policy_bundle {
        Some(bundle) => {
            let bj = serde_json::to_string(bundle)
                .context("serializing PolicyBundle for VmStartConfig.bundle_json")?;
            enforce_size_cap("bundle_json", bj.len(), BUNDLE_JSON_MAX_BYTES)?;
            Some(bj)
        }
        None => None,
    };
    Ok(())
}

/// Atomically write `body` to `path` at mode 0600 on Unix hosts.
///
/// The Firecracker bridge sidecar reads `plan.json` + `bundle.json` from
/// the per-VM state dir at spawn time. Those files carry the signed
/// `ExecutionPlan` envelope and the (optional) bundle pin, which may
/// resolve through `secrets` / policy refs to credentials. They sit at
/// the same trust tier as the host signer key
/// (mode 0600); `std::fs::write` would default to 0644 minus umask which
/// on most contributor hosts is 0644 or 0664 — world-readable. Use
/// `OpenOptionsExt::mode(0o600)` + tmp-and-rename so a concurrent
/// bridge reader never sees a partial file.
///
/// Parent dir is assumed pre-created by the caller (the producer sites
/// in `up.rs` ensure `mvm_home/vms/<name>/` exists with the same
/// `0700` umbrella as `~/.mvm`).
///
/// Nothing is synced. Every file written here is a per-run copy of material
/// the admission record already holds durably, read by this run from the
/// page cache; a host crash that could lose it also ends the guest that would
/// read it, and a torn signed envelope fails verification rather than being
/// trusted. On a rotational disk the sync was most of a warm claim's time
/// between verifying its parent and forking its child.
///
/// The temporary has a fresh random name created exclusively, so nothing
/// planted beside `path` is written through, and the rename replaces whatever
/// sits at `path` itself, a link included, without following it.
#[cfg(unix)]
pub(crate) fn write_secret_file(path: &std::path::Path, body: &[u8]) -> Result<()> {
    let parent = path.parent().ok_or_else(|| {
        anyhow::anyhow!("write_secret_file: path has no parent: {}", path.display())
    })?;
    std::fs::create_dir_all(parent)
        .with_context(|| format!("create parent dir {}", parent.display()))?;
    mvm_core::atomic_io::write_private_ephemeral(path, body)
        .with_context(|| format!("write {}", path.display()))
}

/// Stash the signed plan envelope + (optional) bundle pin in the
/// per-VM state dir so the Firecracker bridge sidecar can read them
/// at spawn time.
///
/// Called from every `up.rs` producer site immediately after
/// `populate_audit_substrate`, before `backend.start()`. No-op when
/// `cfg.plan_json` is `None` (legacy / no-admission path). Files land
/// at mode 0600 via [`write_secret_file`] — see that helper's doc for
/// why `std::fs::write` is insufficient.
///
/// Lives in the producer (mvm-cli) rather than `microvm::run_from_build`
/// because the producer is the only place that has the signed envelope
/// in scope; `microvm` reads it back from disk inside the
/// `target_os = "linux"` bridge-spawn block.
pub fn stash_plan_for_bridge(cfg: &mvm_core::vm_backend::VmStartConfig) -> Result<()> {
    stash_plan_and_mint_verb_grant(cfg).map(|_| ())
}

/// Persist a VM's admitted plan material and mint its optional signed agent
/// verb grant, returning the exact envelope written to disk. Warm-restore
/// callers use the returned value in the post-restore handshake because there
/// is no new kernel boot at which to consume the sidecar.
pub fn stash_plan_and_mint_verb_grant(
    cfg: &mvm_core::vm_backend::VmStartConfig,
) -> Result<Option<mvm_core::protocol::vm_backend::VerbGrantEnvelope>> {
    let Some(plan_json) = cfg.plan_json.as_deref() else {
        return Ok(None);
    };
    let state_dir = mvm_core::config::vm_state_dir(&cfg.name);
    std::fs::create_dir_all(&state_dir)
        .with_context(|| format!("create per-VM state dir {}", state_dir.display()))?;
    write_secret_file(&state_dir.join("plan.json"), plan_json.as_bytes())?;
    // A new plan under this name is a new run, and a human credential entered
    // during the previous one is not in this guest.
    mvm_runtime::vm::human_credential::clear_for_new_run(&state_dir)?;
    if let Some(bundle_json) = cfg.bundle_json.as_deref() {
        write_secret_file(&state_dir.join("bundle.json"), bundle_json.as_bytes())?;
    }
    mint_verb_grant_sidecar(plan_json, &cfg.name, &state_dir)
}

/// Admission enforcement: every volume about to be attached must be
/// named in the verified `ExecutionPlan.shares`, with matching
/// host path, guest path, kind, ro/rw, and encryption.
///
/// On the local `mvmctl machine run` path the CLI builds both the signed
/// plan and the launch config from one source, so this is self-consistent
/// by construction — but it **fails closed** if they ever diverge (a CLI
/// bug, or a future caller that hands a config the plan didn't authorize).
/// It's the trust-boundary hook: no host-fs grant reaches a guest unless
/// the signed plan admitted it (claim 1 / claim 8). The supervisor +
/// mvmd enforcement mirror this check against the same `plan.shares`.
pub fn enforce_admitted_shares(
    volumes: &[mvm_core::vm_backend::VmVolume],
    plan: &ExecutionPlan,
) -> Result<()> {
    for v in volumes {
        let want_kind = if v.materialized_image.is_some() {
            mvm_core::plan::ShareKind::DirShare
        } else {
            mvm_core::plan::ShareKind::Disk
        };
        let admitted = plan
            .shares
            .iter()
            .find(|g| shares::matches_grant(g, v, want_kind));
        let Some(grant) = admitted else {
            anyhow::bail!(
                "refusing to attach volume '{}' -> '{}' ({}): it is not named in the signed \
                 ExecutionPlan's admitted shares — every host-fs grant must be admitted (claim 1).",
                v.host,
                v.guest,
                if v.read_only { "ro" } else { "rw" },
            );
        };
        // Content identity (claim 19): a grant that recorded what the shared
        // tree hashed to at admission must still hash the same at attach
        // time. The admitted digest is inside the signed plan, so this closes
        // the window between admission and boot where the host directory
        // could change under the granted path — the guest would otherwise
        // receive bytes the plan never vouched for.
        if let Some(expected) = &grant.content_sha256 {
            // Canonicalize so a symlinked host dir (macOS `/tmp`) hashes
            // the same tree admission pinned, whichever alias names it.
            let actual = if let Some(image) = &v.materialized_image {
                mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(image)).map_err(
                    |e| {
                        anyhow::anyhow!(
                            "refusing to attach volume '{}' -> '{}': cannot re-hash frozen image \
                             '{}': {e}",
                            v.host,
                            v.guest,
                            image,
                        )
                    },
                )?
            } else {
                let resolved = std::fs::canonicalize(&v.host)?;
                mvm_fs::hash::hash_source(&resolved).map_err(|e| {
                    anyhow::anyhow!(
                        "refusing to attach volume '{}' -> '{}': cannot re-hash the granted \
                         directory to check its admitted content identity: {e}",
                        v.host,
                        v.guest,
                    )
                })?
            };
            if actual != *expected {
                anyhow::bail!(
                    "refusing to attach volume '{}' -> '{}': the directory changed after \
                     admission — admitted content identity {expected}, now {actual}. Re-admit \
                     the plan against the current tree.",
                    v.host,
                    v.guest,
                );
            }
        }
    }
    Ok(())
}

/// Inputs for [`admit_and_start`]. The `synthesis` describes the plan to admit
/// (the signed authority) and `config` is the launch shape to boot; they come
/// from one source in a well-formed caller, and [`enforce_admitted_shares`]
/// fails closed if they ever disagree on volumes.
pub struct AdmitAndStartParams<'a> {
    pub synthesis: &'a SynthesisInput<'a>,
    pub config: VmStartConfig,
    pub clock: &'a dyn Clock,
    pub ledger: &'a InMemoryNonceLedger,
    pub host_signer_keys_dir: Option<&'a std::path::Path>,
    pub bundle_ctx: Option<&'a BundleAdmissionContext<'a>>,
    pub extension_ctx: Option<&'a ExtensionAdmissionContext<'a>>,
    /// This run's posture. Decides whether a grant the resolved backend has no
    /// mechanism for refuses the boot ([`Variant::Prod`]) or warns and proceeds
    /// ([`Variant::Dev`]).
    pub variant: Variant,
    pub policy_bundle: Option<&'a PolicyBundle>,
    /// Optional chain-signed emitter: `plan.admitted` fires after admission
    /// succeeds, then `plan.launched` on a successful backend start or
    /// `plan.failed` on a start failure — the same event ordering the CLI's
    /// up path wires by hand.
    pub emitter: Option<&'a crate::audit::emitter::AuditEmitter>,
    /// Whether a failure to record `plan.admitted` refuses the boot.
    ///
    /// Only the admission is gated. `plan.launched` and `plan.failed` describe
    /// something that has already happened — refusing after the fact prevents
    /// nothing, and tearing down a running workload because a log write failed
    /// trades a missing record for a killed job. The admission is different:
    /// it is the record that the run was allowed, and it is written before the
    /// backend starts, so refusing on it actually stops the unaudited run.
    pub audit_durability: crate::audit::durability::AuditDurability,
    /// An assurance campaign to open against this boot, when the operator
    /// declared one. `None` — the default — is every ordinary run: extension
    /// discovery must not sit on the launch critical path, so a run that
    /// declares no campaign does no assurance work at all.
    pub assurance: Option<&'a crate::assurance_session::CampaignRequest>,
}

impl<'a> AdmitAndStartParams<'a> {
    /// Start building a [`AdmitAndStartParams`]. Every value is set by name, so a
    /// call site cannot transpose two fields that share a type.
    #[must_use]
    pub fn builder() -> AdmitAndStartParamsBuilder<'a> {
        AdmitAndStartParamsBuilder::new()
    }
}

/// Builder for [`AdmitAndStartParams`]. Required fields are checked by
/// [`AdmitAndStartParamsBuilder::build`] rather than defaulted, so an unset one is a
/// reported error and never a silently empty value.
pub struct AdmitAndStartParamsBuilder<'a> {
    synthesis: Option<&'a SynthesisInput<'a>>,
    config: Option<VmStartConfig>,
    clock: Option<&'a dyn Clock>,
    ledger: Option<&'a InMemoryNonceLedger>,
    host_signer_keys_dir: Option<&'a std::path::Path>,
    bundle_ctx: Option<&'a BundleAdmissionContext<'a>>,
    extension_ctx: Option<&'a ExtensionAdmissionContext<'a>>,
    variant: Option<Variant>,
    policy_bundle: Option<&'a PolicyBundle>,
    emitter: Option<&'a crate::audit::emitter::AuditEmitter>,
    audit_durability: Option<crate::audit::durability::AuditDurability>,
    assurance: Option<&'a crate::assurance_session::CampaignRequest>,
}

impl<'a> AdmitAndStartParamsBuilder<'a> {
    /// An empty builder: nothing set yet.
    #[must_use]
    pub fn new() -> Self {
        Self {
            synthesis: None,
            config: None,
            clock: None,
            ledger: None,
            host_signer_keys_dir: None,
            bundle_ctx: None,
            extension_ctx: None,
            variant: None,
            policy_bundle: None,
            emitter: None,
            audit_durability: None,
            assurance: None,
        }
    }

    /// Set `synthesis`.
    #[must_use]
    pub fn synthesis(mut self, synthesis: &'a SynthesisInput<'a>) -> Self {
        self.synthesis = Some(synthesis);
        self
    }

    /// Set `config`.
    #[must_use]
    pub fn config(mut self, config: VmStartConfig) -> Self {
        self.config = Some(config);
        self
    }

    /// Set `clock`.
    #[must_use]
    pub fn clock(mut self, clock: &'a dyn Clock) -> Self {
        self.clock = Some(clock);
        self
    }

    /// Set `ledger`.
    #[must_use]
    pub fn ledger(mut self, ledger: &'a InMemoryNonceLedger) -> Self {
        self.ledger = Some(ledger);
        self
    }

    /// Set `host_signer_keys_dir`. Takes a value or an `Option`; unset means `None`.
    #[must_use]
    pub fn host_signer_keys_dir(
        mut self,
        host_signer_keys_dir: impl Into<Option<&'a std::path::Path>>,
    ) -> Self {
        self.host_signer_keys_dir = host_signer_keys_dir.into();
        self
    }

    /// Set `bundle_ctx`. Takes a value or an `Option`; unset means `None`.
    #[must_use]
    pub fn bundle_ctx(
        mut self,
        bundle_ctx: impl Into<Option<&'a BundleAdmissionContext<'a>>>,
    ) -> Self {
        self.bundle_ctx = bundle_ctx.into();
        self
    }

    /// Supply current trust and revocation inputs for optional extensions.
    #[must_use]
    pub fn extension_ctx(
        mut self,
        extension_ctx: impl Into<Option<&'a ExtensionAdmissionContext<'a>>>,
    ) -> Self {
        self.extension_ctx = extension_ctx.into();
        self
    }

    /// Set `variant`.
    #[must_use]
    pub fn variant(mut self, variant: Variant) -> Self {
        self.variant = Some(variant);
        self
    }

    /// Set `policy_bundle`. Takes a value or an `Option`; unset means `None`.
    #[must_use]
    pub fn policy_bundle(mut self, policy_bundle: impl Into<Option<&'a PolicyBundle>>) -> Self {
        self.policy_bundle = policy_bundle.into();
        self
    }

    /// Set `emitter`. Takes a value or an `Option`; unset means `None`.
    #[must_use]
    pub fn emitter(
        mut self,
        emitter: impl Into<Option<&'a crate::audit::emitter::AuditEmitter>>,
    ) -> Self {
        self.emitter = emitter.into();
        self
    }

    /// Declare an assurance campaign for this boot.
    pub fn assurance(
        mut self,
        assurance: impl Into<Option<&'a crate::assurance_session::CampaignRequest>>,
    ) -> Self {
        self.assurance = assurance.into();
        self
    }

    /// Set `audit_durability`.
    #[must_use]
    pub fn audit_durability(
        mut self,
        audit_durability: crate::audit::durability::AuditDurability,
    ) -> Self {
        self.audit_durability = Some(audit_durability);
        self
    }

    /// Finish, or name the first required field left unset.
    pub fn build(self) -> Result<AdmitAndStartParams<'a>, BuilderError> {
        Ok(AdmitAndStartParams {
            synthesis: self
                .synthesis
                .ok_or(BuilderError::missing("AdmitAndStartParams", "synthesis"))?,
            config: self
                .config
                .ok_or(BuilderError::missing("AdmitAndStartParams", "config"))?,
            clock: self
                .clock
                .ok_or(BuilderError::missing("AdmitAndStartParams", "clock"))?,
            ledger: self
                .ledger
                .ok_or(BuilderError::missing("AdmitAndStartParams", "ledger"))?,
            host_signer_keys_dir: self.host_signer_keys_dir,
            bundle_ctx: self.bundle_ctx,
            extension_ctx: self.extension_ctx,
            variant: self
                .variant
                .ok_or(BuilderError::missing("AdmitAndStartParams", "variant"))?,
            policy_bundle: self.policy_bundle,
            emitter: self.emitter,
            audit_durability: self.audit_durability.ok_or(BuilderError::missing(
                "AdmitAndStartParams",
                "audit_durability",
            ))?,
            assurance: self.assurance,
        })
    }
}

impl<'a> Default for AdmitAndStartParamsBuilder<'a> {
    fn default() -> Self {
        Self::new()
    }
}

/// Refuse a boot whose kernel is not the one the plan pinned.
///
/// The image digest says what the workload *is*; it says nothing about what
/// confines it. The same signed image on a kernel built for a different job has
/// a different security posture — a kernel with `CONFIG_USER_NS` enabled lets
/// the guest become uid 0 in a user namespace, which the workload kernel is
/// built to prevent. Before the kernel was pinned, that substitution was
/// invisible: identical plan, identical image digest, and confinement decided
/// by whichever kernel the host happened to have cached.
///
/// Fail-closed in both directions. A plan that pins a kernel and a launch
/// config that supplies none is a refusal, not a pass — otherwise dropping the
/// kernel path would be a way to skip the check.
/// Takes the kernel path rather than the whole [`VmStartConfig`] so the two
/// admission seams can share one gate. `mvmctl` synthesizes and admits its plan
/// without ever building a `VmStartConfig`, so a config-shaped signature meant
/// the CLI — the seam that ships — could not call this at all.
pub fn enforce_admitted_environment(
    kernel_path: Option<&std::path::Path>,
    plan: &ExecutionPlan,
) -> Result<()> {
    let Some(environment) = plan.environment.as_ref() else {
        // No environment pinned. Plans predating the field, and backends that
        // boot their own bundled kernel, land here.
        return Ok(());
    };
    let Some(kernel_path) = kernel_path else {
        anyhow::bail!(
            "plan pins kernel {} but the launch config supplies no kernel path",
            environment.kernel_sha256
        );
    };
    let actual =
        mvm_core::crypto::image_verify::sha256_file_cached(kernel_path).with_context(|| {
            format!(
                "hashing kernel at {} for admitted-environment check",
                kernel_path.display()
            )
        })?;
    if actual != environment.kernel_sha256 {
        anyhow::bail!(
            "admitted-environment mismatch: plan pins kernel {} but {} hashes to {actual}",
            environment.kernel_sha256,
            kernel_path.display()
        );
    }
    Ok(())
}

/// Outcome of a successful admitted boot: the backend's VM id plus the
/// `AdmittedPlan` (for the caller's audit chain / typed result).
#[derive(Debug)]
pub struct StartedMachine {
    pub vm_id: VmId,
    pub admitted: AdmittedPlan,
    /// What actually bounded this workload, read back off the live controls by
    /// the backend that booted it.
    ///
    /// Not the grants that were requested — those are already on the signed
    /// plan. A caller building a receipt gets the tier that fired, so it cannot
    /// report a bound that was only asked for.
    pub enforced_grants: EnforcedGrants,
}

/// Apply the admitted plan's grants to the VM that is now running, and report
/// what the backend achieved.
///
/// After `start` rather than before, because a control needs something to
/// attach to; the backends that bound CPU do it by placing the VMM process
/// itself, which does not exist until then.
///
/// Not best-effort. A workload whose bounds could not be applied is running
/// unbounded, so the launch is undone rather than completed alongside a record
/// that says otherwise — the same posture the supervisor's own launch path
/// takes.
fn apply_admitted_grants(
    backend: &AnyBackend,
    vm_id: &VmId,
    admitted: &AdmittedPlan,
) -> Result<EnforcedGrants> {
    let undeclared = Grants::default();
    let grants = admitted.plan().grants.as_ref().unwrap_or(&undeclared);
    backend
        .as_vm_backend()
        .apply_grants(vm_id, grants)
        .context("applying the admitted plan's grants to the started VM")
}

/// Apply the admitted plan's grants to a VM that has just started, and undo
/// the launch if they cannot be applied.
///
/// Every launch path that starts a VM itself and then applies its grants goes
/// through here, so they share one failure posture: a backend that cannot
/// report what bounded the VM stops it, the chain records `plan.failed` at the
/// `grants` stage, and the error comes back. A caller never gets to substitute
/// an all-`Declared` answer for a failed application, because that answer
/// would then be signed into `plan.grants_enforced` as if it were the tier
/// the host achieved.
///
/// `Declared` is still a legitimate *successful* answer: a host with no
/// mechanism for a dimension reports it that way, and the boot proceeds. Only
/// an application that errored refuses.
///
/// `backend` must be the object that started `vm_id`. A backend rebuilt from a
/// name is a different object, and one that keeps per-run state in memory has
/// nothing to read back for a VM it did not start.
pub fn apply_admitted_grants_or_undo_launch(
    backend: &AnyBackend,
    vm_id: &VmId,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
) -> Result<EnforcedGrants> {
    apply_admitted_grants_with_rollback(
        backend,
        vm_id,
        admitted,
        emitter,
        || backend.stop(vm_id).map(|_| ()),
        FailureAuditPolicy::LegacyImmediate,
    )
}

/// Use the caller's original VM handle for rollback. Emit terminal grant
/// failure only after that rollback confirms the VM stopped.
pub fn apply_grants_with_owned_rollback(
    backend: &AnyBackend,
    vm_id: &VmId,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
    rollback: impl FnOnce() -> Result<()>,
) -> Result<EnforcedGrants> {
    apply_admitted_grants_with_rollback(
        backend,
        vm_id,
        admitted,
        emitter,
        rollback,
        FailureAuditPolicy::OwnedAfterConfirmedRollback,
    )
}

fn apply_admitted_grants_with_rollback(
    backend: &AnyBackend,
    vm_id: &VmId,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
    rollback: impl FnOnce() -> Result<()>,
    audit_policy: FailureAuditPolicy,
) -> Result<EnforcedGrants> {
    apply_admitted_grants(backend, vm_id, admitted).map_err(|err| {
        undo_launch_with(
            UndoLaunch {
                backend,
                vm_id,
                admitted,
                emitter,
                stage: "grants",
                reason: "grants could not be applied",
                err,
            },
            rollback,
            audit_policy,
        )
    })
}

/// Record what this boot committed against the host budget, rolling the
/// launch back when the record cannot be written.
///
/// A missing per-VM record makes a running machine invisible to later budget
/// admissions, so recording failure is fatal. `vm_name` keys the charge while
/// `vm_id` identifies the machine to stop; callers must provide both.
pub fn record_charge_or_undo_launch(
    backend: &AnyBackend,
    vm_id: &VmId,
    vm_name: &str,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
) -> Result<()> {
    record_charge_with_rollback(
        backend,
        vm_id,
        vm_name,
        admitted,
        emitter,
        || backend.stop(vm_id).map(|_| ()),
        FailureAuditPolicy::LegacyImmediate,
    )
}

/// Share budget policy while the host receiver keeps original native custody.
pub fn record_charge_with_owned_rollback(
    backend: &AnyBackend,
    vm_id: &VmId,
    vm_name: &str,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
    rollback: impl FnOnce() -> Result<()>,
) -> Result<()> {
    record_charge_with_rollback(
        backend,
        vm_id,
        vm_name,
        admitted,
        emitter,
        rollback,
        FailureAuditPolicy::OwnedAfterConfirmedRollback,
    )
}

fn record_charge_with_rollback(
    backend: &AnyBackend,
    vm_id: &VmId,
    vm_name: &str,
    admitted: &AdmittedPlan,
    emitter: Option<&crate::audit::emitter::AuditEmitter>,
    rollback: impl FnOnce() -> Result<()>,
    audit_policy: FailureAuditPolicy,
) -> Result<()> {
    let undeclared = Grants::default();
    let charge = crate::admission_budget::charge_for(
        admitted.plan().resources.mem_mib,
        admitted.plan().grants.as_ref().unwrap_or(&undeclared),
    );
    crate::admission_budget::record_charge(vm_name, charge).map_err(|err| {
        undo_launch_with(
            UndoLaunch {
                backend,
                vm_id,
                admitted,
                emitter,
                stage: "host-budget",
                reason: "its admitted charge could not be recorded",
                err,
            },
            rollback,
            audit_policy,
        )
    })
}

fn launch_decision_record(plan: &ExecutionPlan, backend_name: &str) -> DecisionRecord {
    DecisionRecordBuilder::new()
        .version(1)
        .category(DecisionCategory::Launch)
        .actor(ActorRef {
            principal: crate::audit::host_keypair::host_signer_id(),
            key_id: crate::audit::host_keypair::host_signer_id(),
            key_role: Some(DecisionActorRole::Orchestrator),
        })
        .scenario(mvm_contract::provenance::DecisionScenario {
            plan_id: Some(plan.plan_id.0.clone()),
            ..Default::default()
        })
        .reasoning(format!("workload launched on backend {backend_name}"))
        .outcome(DecisionOutcome::Approved)
        .timestamp(Utc::now().to_rfc3339())
        .attestation(AttestationBinding {
            plan_id: Some(plan.plan_id.0.clone()),
            ..AttestationBinding::default()
        })
        .build()
        .expect("launch decision record is well-formed")
}

fn attach_assurance_proxy(
    config: &mut VmStartConfig,
    proxy: mvm_contract::protocol::broker_control::ServiceProxyBinding,
) -> Result<()> {
    if config
        .service_proxies
        .iter()
        .any(|binding| binding.service == proxy.service)
    {
        anyhow::bail!("assurance controller proxy service is already configured");
    }
    config.service_proxies.push(proxy);
    Ok(())
}

/// Everything the post-admission tail needs, in one struct.
///
/// A params struct rather than six positional arguments: three of the fields
/// are optional borrows of unrelated types and a positional call could drop or
/// transpose one with nothing to catch it.
pub struct StartAdmittedParams<'a> {
    pub backend: &'a AnyBackend,
    /// The plan this boot runs under. Taken by value because it is handed back
    /// on the [`StartedMachine`], and holding one is the only proof admission
    /// ran — it cannot be built any other way.
    pub admitted: AdmittedPlan,
    pub config: VmStartConfig,
    pub policy_bundle: Option<&'a PolicyBundle>,
    /// Optional chain-signed emitter: `plan.launched` fires on a successful
    /// backend start, `plan.failed` on a start failure or a post-start refusal.
    /// The caller owns `plan.admitted`, which is already recorded by the time
    /// this runs.
    pub emitter: Option<&'a crate::audit::emitter::AuditEmitter>,
    /// An assurance campaign to open against this boot, when the operator
    /// declared one. `None` — the default — is every ordinary run.
    pub assurance: Option<&'a crate::assurance_session::CampaignRequest>,
}

/// The post-admission tail every admitted boot shares: the gates, the backend
/// start, the grants, the budget charge and the launch records.
///
/// Split out of [`admit_and_start`] so a caller holding an already-admitted
/// plan — a resumed durable session, for one — can boot it without admitting a
/// second time. Two admissions would mean two nonces and two signed plans, with
/// the second silently becoming the real authority. Because this is the only
/// path from an `AdmittedPlan` to a running VM, a caller cannot boot on a path
/// that skipped a gate.
///
/// Order matters and is fail-closed: the signed plan is threaded onto the
/// launch config and every volume checked against the admitted shares
/// (claim 1); only then does the backend start the VM. A refusal in any gate
/// returns with **no VM created**, and a refusal *after* the start rolls the
/// launch back rather than leaving a VM up whose only record says it was
/// bounded.
///
/// The caller resolves the image to a `config.rootfs_path` beforehand; this
/// function is backend-agnostic (it drives whatever `AnyBackend` it is handed,
/// including the in-memory mock in tests).
#[tracing::instrument(skip_all)]
pub fn start_admitted(params: StartAdmittedParams<'_>) -> Result<StartedMachine> {
    let verified =
        mvm_runtime::runtime_evidence::verify_selected_release_runtime_set(&params.config)?;
    start_admitted_with_verified_release(params, verified.as_ref())
}

/// Start a locally admitted release using this launch's authenticated archive.
pub(crate) fn start_admitted_with_verified_release(
    params: StartAdmittedParams<'_>,
    verified_runtime: Option<&mvm_runtime::runtime_evidence::VerifiedRuntimeSet>,
) -> Result<StartedMachine> {
    let backend = params.backend;
    let mut admitted = params.admitted;
    anyhow::ensure!(
        !admitted.dispatched,
        "original admitted plan was already dispatched"
    );
    anyhow::ensure!(
        admitted.plan().runtime_identity.is_none() || params.emitter.is_some(),
        "signed release runtime cannot dispatch without an admission audit emitter"
    );

    anyhow::ensure!(
        admitted
            .plan()
            .mailbox
            .is_none_or(|g| g.durable_object_pair_sha256_v1.is_none()),
        "selected pair must dispatch through both original worker owners"
    );
    // A refusal in any post-admission gate must still terminate the chain:
    // `plan.admitted` already fired, so a gate refusal emits `plan.failed`
    // carrying the refusing stage rather than leaving a dangling admission.
    let gated = (|| {
        if params.assurance.is_some() {
            admitted
                .bind_assurance_runtime(&params.config, verified_runtime)
                .map_err(|error| ("assurance-runtime", error))?;
        }
        if params.assurance.is_some() || admitted.assurance_runtime.is_some() {
            admitted
                .verify_assurance_launch(&params.config, verified_runtime)
                .map_err(|error| ("assurance-runtime", error))?;
        }
        RunPosture::on_backend(admitted.variant, backend.kind())
            .with_runtime(Some(&params.config))
            .with_verified_runtime(verified_runtime)
            .verify_launch_runtime(admitted.plan())
            .map_err(|error| ("guest-runtime", error))?;
        final_gates::run_post_admission_gates(
            params.config,
            &admitted,
            backend.kind(),
            params.policy_bundle,
        )
    })();
    let (mut config, _built_runtime) = match gated {
        Ok(prepared) => prepared,
        Err((stage, err)) => {
            if let Some(emitter) = params.emitter
                && let Err(e) = emitter.emit_failed(admitted.plan(), stage, &format!("{err:#}"))
            {
                tracing::warn!(error = %e, "audit emit_failed failed (non-fatal)");
            }
            return Err(err.context(format!("admission gate refused ({stage})")));
        }
    };
    if params.assurance.is_some() {
        let proxy = crate::assurance_session::prepare_controller_proxy(&config.name)
            .context("preparing admitted assurance controller proxy")?;
        attach_assurance_proxy(&mut config, proxy)?;
    }

    let backend_name = backend.name().to_string();
    let vm_name = config.name.clone();
    let mailbox_posture = admitted.mailbox_posture();
    registry_pack::verify_runtime_at_dispatch(
        _built_runtime.as_ref(),
        &config,
        &admitted,
        params.emitter,
    )?;
    // Before the boot, so a grant this backend cannot serve never reaches a
    // guest that would assert it.
    crate::mailbox_process::require_servable(&config, backend, mailbox_posture.as_ref())?;
    // Spent before the backend starts, so an admission that reached dispatch
    // can never authorize another launch, whatever the start's outcome.
    admitted.dispatched = true;
    #[cfg(target_os = "linux")]
    let started = if backend.kind() == BackendKind::Firecracker
        && admitted
            .plan()
            .mailbox
            .is_some_and(|g| g.durable_object_pair_sha256_v1.is_some())
    {
        backend
            .start_original_object_firecracker_with_verified_runtime(
                &config,
                Vec::new(),
                verified_runtime,
            )
            .map(|(id, original)| {
                admitted.object_firecracker = Some(original);
                id
            })
    } else {
        backend.start_with_verified_runtime(&config, verified_runtime)
    };
    #[cfg(not(target_os = "linux"))]
    let started = backend.start_with_verified_runtime(&config, verified_runtime);
    match started.context("backend start after signed-plan admission") {
        Ok(vm_id) => {
            // A VM whose grants could not be applied is running without the
            // bounds it was admitted under; the helper stops it rather than
            // leaving a run whose only record says it was bounded.
            let enforced_grants =
                apply_admitted_grants_or_undo_launch(backend, &vm_id, &admitted, params.emitter)?;

            // Record what this boot committed, so every later admission counts
            // it. A machine running without a record is invisible to the
            // budget, and an undercounted host is precisely the state the
            // budget exists to prevent — so this is fatal, and rolls the
            // launch back the same way an unapplied grant does.
            record_charge_or_undo_launch(backend, &vm_id, &vm_name, &admitted, params.emitter)?;
            if let Some(emitter) = params.emitter {
                if let Err(e) = emitter.emit_launched(admitted.plan(), &backend_name) {
                    tracing::warn!(error = %e, "audit emit_launched failed (non-fatal)");
                }
                let record = launch_decision_record(admitted.plan(), &backend_name);
                if let Err(e) = emitter.emit_decision_record(admitted.plan(), record) {
                    tracing::warn!(error = %e, "audit emit_decision_record for launch failed (non-fatal)");
                }
                if let Err(e) = emitter.emit_grants_enforced(admitted.plan(), &enforced_grants) {
                    tracing::warn!(error = %e, "audit emit_grants_enforced failed (non-fatal)");
                }
            }
            // After the VM is running, so a failed boot leaves no session, and
            // after `plan.launched`, so the campaign's own records follow the
            // launch they belong to. A refusal here fails the boot: a campaign
            // the operator declared and that silently did not open would be
            // reported as a trial that observed nothing.
            if let Some(campaign) = params.assurance
                && let Err(err) =
                    crate::assurance_session::open_for_boot(campaign, &vm_id.0, &admitted)
            {
                // Rolls the launch back rather than returning with the VM up.
                // The session opens after the backend start, so a bare `?`
                // here left a running workload behind while reporting the boot
                // as failed — and an orphan whose only record says it did not
                // start is worse than either outcome alone.
                return Err(undo_launch(UndoLaunch {
                    backend,
                    vm_id: &vm_id,
                    admitted: &admitted,
                    emitter: params.emitter,
                    stage: "assurance-session",
                    reason: "the declared assurance campaign could not be opened",
                    err,
                }));
            }
            // Last, so no earlier rollback leaves a mailbox process behind.
            // A grant that cannot be served is refused rather than booting a
            // guest whose mailbox port nobody answers.
            if let Err(err) = crate::mailbox_process::spawn_for_launch(
                admitted.plan(),
                backend,
                &vm_name,
                mailbox_posture.as_ref(),
            ) {
                return Err(undo_launch(UndoLaunch {
                    backend,
                    vm_id: &vm_id,
                    admitted: &admitted,
                    emitter: params.emitter,
                    stage: "mailbox-process",
                    reason: "the granted guest mailbox could not be served",
                    err: err.into(),
                }));
            }
            Ok(StartedMachine {
                vm_id,
                admitted,
                enforced_grants,
            })
        }
        Err(err) => {
            if let Some(emitter) = params.emitter
                && let Err(e) =
                    emitter.emit_failed(admitted.plan(), "backend-start", &format!("{err:#}"))
            {
                tracing::warn!(error = %e, "audit emit_failed failed (non-fatal)");
            }
            Err(err)
        }
    }
}

/// The single admitted-boot entrypoint every driver shares — the CLI's
/// `mvmctl run` / `mvmctl machine run` and the `mvm-client` local backend both reach it, so a
/// workload can never boot on a path that skipped admission.
///
/// Order matters and is fail-closed: synthesize + sign + verify + validity +
/// replay (+ bundle re-verify) run first, and any failure among them returns
/// with **no VM created** — admission is a gate, not a formality. Only once the
/// admission is recorded does this delegate to [`start_admitted`], which owns
/// the rest of the order.
#[tracing::instrument(skip_all)]
pub fn admit_and_start(
    backend: &AnyBackend,
    params: AdmitAndStartParams<'_>,
) -> Result<StartedMachine> {
    let verified =
        mvm_runtime::runtime_evidence::verify_selected_release_runtime_set(&params.config)?;
    admit_and_start_with_verified_release(backend, params, verified.as_ref())
}

/// Admit and boot a local launch with one release verification for all gates.
pub(crate) fn admit_and_start_with_verified_release(
    backend: &AnyBackend,
    params: AdmitAndStartParams<'_>,
    verified_runtime: Option<&mvm_runtime::runtime_evidence::VerifiedRuntimeSet>,
) -> Result<StartedMachine> {
    let admitted = admit_synthesized_with_verified_release(backend, &params, verified_runtime)?;
    start_admitted_with_verified_release(
        StartAdmittedParams {
            backend,
            admitted,
            config: params.config,
            policy_bundle: params.policy_bundle,
            emitter: params.emitter,
            assurance: params.assurance,
        },
        verified_runtime,
    )
}

/// Admit a synthesized plan without dispatching it; the caller retains its one-use authority.
pub(crate) fn admit_synthesized_with_verified_release(
    backend: &AnyBackend,
    params: &AdmitAndStartParams<'_>,
    verified_runtime: Option<&mvm_runtime::runtime_evidence::VerifiedRuntimeSet>,
) -> Result<AdmittedPlan> {
    // The tier comes from the backend that is about to boot this plan — the
    // object itself, via its typed discriminant. Nothing here reads a backend
    // name: the grant gate decides which resource controls a run is measured
    // against, and deciding that from a string is how a plan ends up measured
    // against a tier it is not running on.
    let posture = RunPosture::on_backend(params.variant, backend.kind())
        .with_runtime(Some(&params.config))
        .with_verified_runtime(verified_runtime);

    // Synthesize the plan up-front so a refusal can be recorded with the
    // plan context if admission fails. Synthesis failures have no plan to
    // anchor to; they propagate without a chain entry.
    let mut plan = synthesize_plan(params.synthesis).context("synthesizing plan")?;
    if let Some(runtime) = verified_runtime {
        plan.runtime_identity = Some(runtime.identity().clone());
    }

    let admitted_result = admit_plan_for_run(
        &plan,
        params.clock,
        params.ledger,
        params.host_signer_keys_dir,
        params.bundle_ctx,
        params.extension_ctx,
        posture,
    );
    let admitted = match admitted_result {
        Ok(admitted) => admitted,
        Err(err) => {
            if let Some(emitter) = params.emitter
                && let Err(e) =
                    emitter.emit_refused(&plan, "admit_plan_for_run", &format!("{err:#}"))
            {
                tracing::warn!(error = %e, "audit emit_refused failed (non-fatal)");
            }
            return Err(err);
        }
    };

    crate::audit::durability::record_admission(
        params.emitter,
        admitted.plan(),
        admitted.signer_id(),
        params.audit_durability,
    )?;

    Ok(admitted)
}

#[cfg(test)]
mod admitted_environment_tests {
    use super::*;

    fn plan_pinning(kernel_sha256: Option<&str>) -> ExecutionPlan {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new().build();
        plan.environment = kernel_sha256.map(|k| mvm_core::plan::EnvironmentRef {
            kernel_sha256: k.to_string(),
        });
        plan
    }

    fn write_kernel(dir: &std::path::Path, bytes: &[u8]) -> std::path::PathBuf {
        let p = dir.join("vmlinux");
        std::fs::write(&p, bytes).expect("write kernel fixture");
        p
    }

    /// The pinned kernel is the one on disk: the boot proceeds.
    #[test]
    fn matching_kernel_digest_is_admitted() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let kernel = write_kernel(tmp.path(), b"workload-kernel");
        let sha = mvm_core::crypto::image_verify::sha256_file(&kernel).expect("hash");
        enforce_admitted_environment(Some(kernel.as_path()), &plan_pinning(Some(&sha)))
            .expect("matching kernel must be admitted");
    }

    /// A different kernel than the plan pinned is refused: same plan, same
    /// image, a kernel swapped underneath — a substitution that would be
    /// invisible if nothing in the plan described the environment.
    #[test]
    fn substituted_kernel_is_refused() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let kernel = write_kernel(tmp.path(), b"workload-kernel");
        let sha = mvm_core::crypto::image_verify::sha256_file(&kernel).expect("hash");
        std::fs::write(&kernel, b"a-general-purpose-kernel").expect("swap kernel");

        let err = enforce_admitted_environment(Some(kernel.as_path()), &plan_pinning(Some(&sha)))
            .expect_err("a substituted kernel must be refused");
        let msg = format!("{err:#}");
        assert!(
            msg.contains("admitted-environment mismatch"),
            "error must name the mismatch, got: {msg}"
        );
    }

    /// Dropping the kernel path must not be a way around the pin.
    #[test]
    fn pinned_plan_with_no_kernel_path_is_refused() {
        let err = enforce_admitted_environment(None, &plan_pinning(Some(&"a".repeat(64))))
            .expect_err("a pinned plan with no kernel path must be refused");
        assert!(format!("{err:#}").contains("supplies no kernel path"));
    }

    /// Plans that pin nothing still boot — every plan written before the field
    /// existed, and backends that carry their own bundled kernel.
    #[test]
    fn unpinned_plan_is_unaffected() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let kernel = write_kernel(tmp.path(), b"whatever");
        enforce_admitted_environment(Some(kernel.as_path()), &plan_pinning(None))
            .expect("an unpinned plan must be unaffected");
        enforce_admitted_environment(None, &plan_pinning(None))
            .expect("an unpinned plan with no kernel must be unaffected");
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use chrono::{DateTime, TimeZone, Utc};
    use mvm_contract::protocol::mailbox::{
        ExecutionEpoch, MailboxGrant, MailboxId, MailboxRetentionPolicy,
    };
    use mvm_core::plan::{PlanSeccompTier, SecretReleasePolicy};
    use rand::Rng;

    const FIXTURE_SHA: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";

    fn runtime_identity_fixture() -> mvm_core::plan::RuntimeIdentity {
        let digests = mvm_core::plan::RuntimeArtifactDigests {
            overlay_sha256: "a".repeat(64),
            overlay_verity_sha256: "b".repeat(64),
            overlay_roothash: "c".repeat(64),
            initramfs_sha256: "d".repeat(64),
        };
        mvm_core::plan::RuntimeIdentity {
            archive_sha256: "f".repeat(64),
            version: "0.28.0".into(),
            arch: mvm_core::arch::GuestArch::host().to_string(),
            declaration: digests.clone(),
            selected: digests,
            signer_identity: "release@example.org".into(),
            signer_issuer: "https://issuer.example.org".into(),
        }
    }

    #[test]
    fn signed_runtime_identity_without_launch_evidence_is_not_admitted() {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new().build();
        plan.runtime_identity = Some(runtime_identity_fixture());
        let error = RunPosture::without_backend(Variant::Dev)
            .verify_launch_runtime(&plan)
            .expect_err("plan data cannot substitute for a verified launch-owned set");
        assert!(error.to_string().contains("no verified launch evidence"));
    }

    #[test]
    fn release_proof_without_a_launch_owned_set_cannot_be_admitted() {
        let plan = mvm_core::plan::test_support::PlanFixture::new().build();
        let config = VmStartConfig {
            runtime_release_proof: Some(mvm_core::protocol::runtime_release::RuntimeReleaseProof {
                archive: "/untrusted/runtime.tar.gz".into(),
                checksum: "/untrusted/runtime.tar.gz.sha256".into(),
                signature_bundle: "/untrusted/runtime.tar.gz.bundle".into(),
                archive_sha256: "a".repeat(64),
                version: "0.28.0".into(),
                arch: mvm_core::arch::GuestArch::host(),
            }),
            ..Default::default()
        };
        let error = RunPosture::without_backend(Variant::Dev)
            .with_runtime(Some(&config))
            .verify_launch_runtime(&plan)
            .expect_err("a path-based proof cannot replace a verified runtime set");
        assert!(
            error
                .to_string()
                .contains("requires verified launch evidence")
        );
    }

    #[test]
    fn a_verified_legacy_fork_keeps_its_existing_admission_path() {
        use mvm_core::checkpoint::{
            CheckpointClass, CheckpointId, CheckpointMeta, ContentBlob, HVF_FRAME_BLOB,
        };
        use mvm_vmm::runtime_artifacts::{RuntimeArtifact, RuntimeArtifacts};

        let (_env, home) = host_with_ceiling(Default::default());
        let fixture = tempfile::tempdir().expect("signed legacy fixture");
        let selected =
            mvm_runtime::signed_legacy_runtime_fixture(fixture.path(), home.path(), false);
        let (config, binding) =
            mvm_runtime::runtime_evidence::retained_legacy_runtime_fixture(&selected)
                .expect("retain legacy fixture before checkpoint capture");
        let observe = |path: &str| RuntimeArtifact {
            path: path.into(),
            sha256: mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(path))
                .expect("fixture digest"),
        };
        let actual = RuntimeArtifacts {
            kernel: None,
            initramfs: config.initrd_path.as_deref().map(observe),
            disks: vec![observe(&config.rootfs_path)],
            kernel_cmdline: "console=hvc0".into(),
            firecracker_drives: None,
        };
        let store = mvm_runtime::checkpoint::CheckpointStore::at(home.path().join("checkpoints"));
        let id = CheckpointId::new("legacy-fork");
        let content = store.content_dir(&id);
        std::fs::create_dir_all(&content).expect("checkpoint content directory");
        let bytes = serde_json::to_vec(&actual).expect("runtime observation");
        std::fs::write(content.join("runtime-artifacts.json"), &bytes)
            .expect("checkpoint runtime evidence");
        let meta = CheckpointMeta::builder(id, CheckpointClass::VmFull, &config.name)
            .runtime_launch_binding(Some(binding))
            .content(vec![
                ContentBlob {
                    name: "runtime-artifacts.json".into(),
                    sha256: mvm_core::crypto::image_verify::sha256_reader(bytes.as_slice())
                        .expect("evidence digest"),
                },
                ContentBlob {
                    name: HVF_FRAME_BLOB.into(),
                    sha256: "ab".repeat(32),
                },
            ])
            .build();
        let retained = mvm_runtime::checkpoint::verify_checkpoint_runtime(&store, &meta)
            .expect("authenticated retained legacy generation");
        assert!(retained.identity().is_none());
        let plan = mvm_core::plan::test_support::PlanFixture::new().build();
        RunPosture::without_backend(Variant::Dev)
            .with_runtime(Some(&config))
            .with_verified_retained(Some(&retained))
            .verify_launch_runtime(&plan)
            .expect("legacy fork uses its prior verifier, not the warm-claim-only comparator");

        let mut invalid = config.clone();
        invalid
            .legacy_bundle_runtime
            .as_mut()
            .expect("legacy proof")
            .pin
            .bundle_sha256 = "0".repeat(64);
        assert!(
            RunPosture::without_backend(Variant::Dev)
                .with_runtime(Some(&invalid))
                .with_verified_retained(Some(&retained))
                .verify_launch_runtime(&plan)
                .is_err(),
            "a changed legacy proof still refuses"
        );
    }

    #[test]
    fn local_retention_requires_a_configured_host_ceiling() {
        let mut grant = MailboxGrant {
            durable_object_pair_sha256_v1: None,
            incoming_journal_policy_sha256_v1: None,
            outbound_journal_v1: None,
            mailbox: MailboxId::from_bytes([1; 32]),
            authority_key: [2; 32],
            epoch: ExecutionEpoch::new(1).expect("epoch"),
            report: None,
            retention: None,
        };
        assert!(enforce_mailbox_retention(Some(&grant), None).is_ok());
        grant.retention = Some(MailboxRetentionPolicy::new(10_000).expect("window"));
        assert!(enforce_mailbox_retention(Some(&grant), None).is_err());
        assert!(enforce_mailbox_retention(Some(&grant), Some(0)).is_err());
        assert!(enforce_mailbox_retention(Some(&grant), Some(u64::MAX)).is_err());
        assert!(enforce_mailbox_retention(Some(&grant), Some(9_999)).is_err());
        assert!(enforce_mailbox_retention(Some(&grant), Some(10_000)).is_ok());
        assert!(enforce_mailbox_retention(Some(&grant), Some(20_000)).is_ok());
    }

    #[test]
    fn selected_object_pair_requires_installed_endpoint_support() {
        let mut grant = MailboxGrant {
            durable_object_pair_sha256_v1: None,
            incoming_journal_policy_sha256_v1: None,
            outbound_journal_v1: None,
            mailbox: MailboxId::from_bytes([1; 32]),
            authority_key: [2; 32],
            epoch: ExecutionEpoch::new(1).unwrap(),
            report: None,
            retention: Some(MailboxRetentionPolicy::new(10_000).unwrap()),
        };
        let posture = RunPosture::without_backend(Variant::Prod);
        let legacy = mvm_core::plan::test_support::PlanFixture::new()
            .mailbox(grant)
            .build();
        assert!(posture.enforce_journal(&legacy, Some(10_000)).is_ok());
        grant.durable_object_pair_sha256_v1 = Some([42; 32]);
        let selected = mvm_core::plan::test_support::PlanFixture::new()
            .mailbox(grant)
            .build();
        assert!(
            posture
                .enforce_journal(&selected, Some(10_000))
                .unwrap_err()
                .to_string()
                .contains("not installed")
        );
    }

    #[cfg(feature = "manifest-verify")]
    const PYTHON_MANIFEST: &[u8] =
        include_bytes!("../../mvm-cli/tests/fixtures/signed-registry-python/manifest.json");
    #[cfg(feature = "manifest-verify")]
    const PYTHON_BUNDLE: &[u8] = include_bytes!(
        "../../mvm-cli/tests/fixtures/signed-registry-python/manifest.sigstore.json"
    );

    #[cfg(feature = "manifest-verify")]
    fn install_signed_python_pack(
        home: &std::path::Path,
    ) -> mvm_core::registry_pack::InstalledRegistryPack {
        use mvm_core::registry_pack::{
            PackAdoption, RegistryPackPublisher, RegistryPackPublisherPolicy,
        };
        use mvm_core::registry_pack_store::{adopt_install_and_pin, save_publisher_policy};

        let publisher = RegistryPackPublisher::new(
            "runtime",
            "https://token.actions.githubusercontent.com",
            vec!["https://github.com/tinylabscom/mvm-templates/.github/workflows/publish.yml@refs/heads/feat/3716-python-image-pack".to_string()],
        )
        .expect("branch publisher identity");
        let policy = RegistryPackPublisherPolicy::new(vec![publisher]).expect("publisher trust");
        save_publisher_policy(
            &mvm_core::config::registry_pack_publisher_policy_path(),
            &policy,
        )
        .expect("save publisher trust");
        let fixture = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../mvm-cli/tests/fixtures/signed-registry-python/files");
        let staged = home.join("staged-pack");
        std::fs::create_dir_all(staged.join("pack/image")).expect("staged image directory");
        for relative in [
            "pack/group.toml",
            "pack/image/mvm.toml",
            "pack/image/flake.nix",
            "pack/image/flake.lock",
        ] {
            std::fs::copy(fixture.join(relative), staged.join(relative))
                .expect("stage signed payload bytes");
        }
        let reference = "runtime/python@1.1.0".parse().expect("pack reference");
        adopt_install_and_pin(
            &PackAdoption {
                requested: &reference,
                manifest_bytes: PYTHON_MANIFEST,
                signature_bundle: PYTHON_BUNDLE,
                publisher_policy: &policy,
            },
            &staged,
            &mvm_core::config::registry_pack_cache_dir(),
            &mvm_core::config::pack_lockfile_path(),
        )
        .expect("adopt signed image pack")
    }

    /// This module's own source, for the unforgeability check below.
    const SOURCE: &str = include_str!("plan_admission.rs");

    /// The production half of it — everything before this test module, so the
    /// checks below cannot be satisfied by a string literal written here.
    fn production_source() -> &'static str {
        SOURCE
            .split_once("#[cfg(test)]\nmod tests {")
            .expect("this module keeps its tests at the end")
            .0
    }

    /// The body of the `AdmittedPlan` declaration, plus the derives above it.
    fn admitted_plan_declaration() -> (&'static str, &'static str) {
        let (before, after) = production_source()
            .split_once("pub struct AdmittedPlan {")
            .expect("the type is declared in this file");
        let derives = before
            .rfind("#[derive(")
            .map(|at| &before[at..])
            .unwrap_or_default();
        let body = after
            .split_once("\n}")
            .expect("the declaration is brace-terminated")
            .0;
        (derives, body)
    }

    /// Every `impl ... for AdmittedPlan` line, i.e. trait impls on the type.
    fn trait_impls_on_admitted_plan() -> Vec<&'static str> {
        production_source()
            .lines()
            .map(str::trim_start)
            .filter(|line| line.starts_with("impl") && line.contains("for AdmittedPlan"))
            .collect()
    }

    #[test]
    fn an_admitted_plan_cannot_be_fabricated_outside_this_module() {
        // Downstream consumers — the share enforcer, the workload input gate —
        // treat a value of this type as proof that admission ran, so a caller
        // able to mint one has the authority admission was supposed to hold.
        // What stops them is a set of *absences* in this declaration, and an
        // absence is exactly what no runtime assertion can observe: the honest
        // form is a compile-fail test, and this workspace has no harness for
        // one. So the source is the assertion, and each branch below names the
        // public path it keeps closed.
        let (derives, body) = admitted_plan_declaration();

        // 1. No `pub` field: a struct literal needs every field named, and a
        //    private one makes the literal unwritable outside this module.
        //    Privacy also means no `&mut` reaches a field, so a caller holding
        //    a legitimately-admitted plan cannot afterwards push a service
        //    grant into it that admission never saw.
        for field in ["plan", "plan_id", "signer_id", "signed", "extensions"] {
            assert!(
                body.contains(&format!("\n    {field}: ")),
                "`AdmittedPlan.{field}` must stay private — a pub field is a forge"
            );
        }

        // 2. No derive that reconstitutes one: `Clone` would let a caller
        //    duplicate a legitimate plan (harmless alone, but it is the first
        //    half of clone-then-mutate), `Default` and `Deserialize` would
        //    each build one from nothing at all.
        for derive in ["Clone", "Default", "Deserialize", "Serialize"] {
            assert!(
                !derives.contains(derive),
                "`AdmittedPlan` must not derive {derive} — it is a second way to obtain one"
            );
        }

        // 3. No trait impl offering a conversion in: `From`/`TryFrom`, a
        //    hand-written `Default`, a `Deserialize` impl.
        assert!(
            trait_impls_on_admitted_plan().is_empty(),
            "no trait may be implemented for AdmittedPlan without re-checking \
             whether it hands out a construction path: {:?}",
            trait_impls_on_admitted_plan()
        );

        // 4. The one convenience constructor is compiled out of production.
        assert!(
            SOURCE.contains("#[cfg(test)]\n    pub(crate) fn for_test("),
            "the test constructor must stay `#[cfg(test)]` and crate-private"
        );

        // 5. And `finish_admission` is the only place that writes the literal.
        let literals = production_source().matches("Ok(AdmittedPlan {").count();
        assert_eq!(
            literals, 1,
            "exactly one production construction site, inside finish_admission"
        );
    }

    fn fixture_input(vm_name: &str) -> SynthesisInput<'_> {
        SynthesisInput {
            mailbox: None,
            outputs: Vec::new(),
            grants: None,
            stream_edges: Vec::new(),
            kernel_sha256: None,
            network_mode: Default::default(),
            ingress: Vec::new(),
            vm_name,
            tenant: None,
            backend_name: "firecracker",
            image_name: "img",
            image_sha256: FIXTURE_SHA,
            image_cosign_bundle: None,
            intent: None,
            seccomp_tier: PlanSeccompTier::Standard,
            network_policy_ref: None,
            fs_policy_ref: None,
            egress_policy_ref: None,
            secret_release: SecretReleasePolicy::None,
            secrets: Vec::new(),
            audit_event_prefix: None,
            cpus: 1,
            mem_mib: 256,
            disk_mib: 0,
            boot_timeout_secs: 30,
            destroy_on_exit: true,
            bundle_pin: None,
            deps_volume: None,
            shares: Vec::new(),
            assets: Vec::new(),
            redaction: mvm_core::policy::RedactionPolicy::default(),
            reversible_replacement: mvm_core::policy::ReversibleReplacementPolicy::default(),
            caller_commitment: None,
            audit_labels: Default::default(),
            agent_verbs: None,
            services: Vec::new(),
            extensions: Vec::new(),
            stream_retention: Default::default(),
            attestation_mode: mvm_contract::plan::AttestationMode::Noop,
        }
    }

    fn extension_binding(
        placement: mvm_contract::protocol::extension_pack::ExtensionPlacement,
    ) -> mvm_contract::protocol::extension_pack::ExtensionPlanBinding {
        mvm_contract::protocol::extension_pack::ExtensionPlanBinding {
            extension_id: mvm_contract::protocol::extension_pack::ExtensionId::parse(
                "org.example.generic-extension",
            )
            .expect("valid fixture extension id"),
            version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse("1.0.0")
                .expect("valid fixture extension version"),
            pack_digest: [7; 32],
            contract_digest: [8; 32],
            placement,
            artifact: "extension.ext4".to_string(),
            entrypoint: "bin/extension".to_string(),
            capabilities: vec![mvm_contract::assurance::probe_capability_descriptor().binding()],
            budgets: mvm_contract::protocol::extension_pack::ExtensionBudgets {
                cpu_millis: 500,
                memory_bytes: 128 * 1024 * 1024,
                duration_ms: 30_000,
                max_steps: 12,
                max_concurrency: 1,
                max_payload_bytes: 16 * 1024,
                max_output_bytes: 16 * 1024,
                max_artifact_bytes: 1024 * 1024,
            },
        }
    }

    fn extension_contract(
        binding: &mvm_contract::protocol::extension_pack::ExtensionPlanBinding,
    ) -> mvm_contract::protocol::extension_pack::ExtensionPackContract {
        mvm_contract::protocol::extension_pack::ExtensionPackContract {
            schema: mvm_contract::protocol::extension_pack::EXTENSION_PACK_SCHEMA.to_string(),
            extension_id: binding.extension_id.clone(),
            version: binding.version.clone(),
            protocol: mvm_contract::protocol::extension_pack::ExtensionProtocolRange {
                min_mvm_version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse(
                    "0.18.0",
                )
                .expect("valid minimum extension version"),
                max_mvm_version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse(
                    env!("CARGO_PKG_VERSION"),
                )
                .expect("valid maximum extension version"),
                min_protocol: 1,
                max_protocol: 1,
            },
            placement: binding.placement,
            artifact: binding.artifact.clone(),
            entrypoint: binding.entrypoint.clone(),
            capabilities: vec![mvm_contract::assurance::probe_capability_descriptor()],
            budgets: binding.budgets,
            revocation_identity: "org.example.generic-extension.release".to_string(),
            permission_delta: "May execute one declared assurance probe.".to_string(),
        }
    }

    fn admitted_with_extension(
        binding: mvm_contract::protocol::extension_pack::ExtensionPlanBinding,
        root: &std::path::Path,
    ) -> AdmittedPlan {
        let plan = mvm_core::plan::test_support::PlanFixture::new()
            .extensions(vec![binding.clone()])
            .build();
        let signer_id = "host:extension-test".to_string();
        let signed = mvm_core::plan::signing::sign_plan(
            &plan,
            &ed25519_dalek::SigningKey::from_bytes(&[31; 32]),
            &signer_id,
        );
        let mut admitted = AdmittedPlan::for_test(plan, signer_id, signed);
        admitted.extensions.push(AdmittedExtension {
            binding,
            root: root.to_path_buf(),
        });
        admitted
    }

    #[test]
    fn extension_budget_comparison_requires_every_dimension() {
        let maximum = extension_binding(
            mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
        )
        .budgets;
        assert!(budgets_are_narrower(maximum, maximum));

        let mut candidates = Vec::new();
        let mut candidate = maximum;
        candidate.cpu_millis += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.memory_bytes += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.duration_ms += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.max_steps += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.max_concurrency += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.max_payload_bytes += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.max_output_bytes += 1;
        candidates.push(candidate);
        let mut candidate = maximum;
        candidate.max_artifact_bytes += 1;
        candidates.push(candidate);

        for candidate in candidates {
            assert!(
                !budgets_are_narrower(candidate, maximum),
                "one widened budget dimension must refuse the whole binding"
            );
        }
    }

    #[test]
    fn extension_binding_identity_requires_every_verified_field() {
        let mut binding = extension_binding(
            mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
        );
        let contract = extension_contract(&binding);
        let contract_digest: [u8; 32] = Sha256::digest(
            serde_json::to_vec(&contract).expect("encode extension contract fixture"),
        )
        .into();
        binding.contract_digest = contract_digest;
        assert!(extension_binding_matches_contract(
            &binding,
            &contract,
            contract_digest
        ));

        let mut mismatches = Vec::new();
        let mut mismatch = binding.clone();
        mismatch.extension_id =
            mvm_contract::protocol::extension_pack::ExtensionId::parse("org.example.other")
                .expect("valid alternate extension id");
        mismatches.push(mismatch);
        let mut mismatch = binding.clone();
        mismatch.version = mvm_contract::protocol::extension_pack::ExtensionVersion::parse("1.0.1")
            .expect("valid alternate extension version");
        mismatches.push(mismatch);
        let mut mismatch = binding.clone();
        mismatch.contract_digest[0] ^= 1;
        mismatches.push(mismatch);
        let mut mismatch = binding.clone();
        mismatch.placement =
            mvm_contract::protocol::extension_pack::ExtensionPlacement::IsolatedController;
        mismatches.push(mismatch);
        let mut mismatch = binding.clone();
        mismatch.artifact.push_str(".other");
        mismatches.push(mismatch);
        let mut mismatch = binding.clone();
        mismatch.entrypoint.push_str("-other");
        mismatches.push(mismatch);

        for mismatch in mismatches {
            assert!(
                !extension_binding_matches_contract(&mismatch, &contract, contract_digest),
                "one mismatched identity field must refuse the whole binding"
            );
        }
    }

    #[test]
    fn extension_artifact_budget_is_inclusive_at_the_exact_limit() {
        assert!(!extension_artifact_exceeds_budget(7, 8));
        assert!(!extension_artifact_exceeds_budget(8, 8));
        assert!(extension_artifact_exceeds_budget(9, 8));
    }

    #[test]
    fn extension_attachment_sets_plan_identity_and_refuses_controller_placement() {
        let root = tempfile::tempdir().expect("extension root");
        let guest_binding = extension_binding(
            mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
        );
        let admitted = admitted_with_extension(guest_binding.clone(), root.path());
        let mut config = mvm_core::vm_backend::VmStartConfig::default();
        final_gates::attach_admitted_extensions(&mut config, &admitted)
            .expect("an admitted guest extension attaches");
        assert_eq!(
            config.extension_plan_id.as_deref(),
            Some(admitted.plan_id().0.as_str())
        );
        assert_eq!(config.extensions, vec![guest_binding]);
        assert_eq!(config.volumes.len(), 1);
        let error = final_gates::attach_admitted_extensions(&mut config, &admitted)
            .expect_err("the same guest mountpoint must not attach twice");
        assert!(error.to_string().contains("mountpoint collision"));

        let controller_binding = extension_binding(
            mvm_contract::protocol::extension_pack::ExtensionPlacement::IsolatedController,
        );
        let admitted = admitted_with_extension(controller_binding, root.path());
        let error = final_gates::attach_admitted_extensions(
            &mut mvm_core::vm_backend::VmStartConfig::default(),
            &admitted,
        )
        .expect_err("a controller extension must never reach guest attachment");
        assert!(error.to_string().contains("isolated_controller"));
    }

    #[test]
    fn assurance_proxy_attachment_refuses_a_duplicate_service() {
        let proxy = mvm_contract::protocol::broker_control::ServiceProxyBinding {
            service: mvm_contract::protocol::broker::ServiceId::parse(
                mvm_contract::assurance::HOST_ASSURANCE_SERVICE,
            )
            .expect("valid assurance service"),
            endpoint: "/tmp/mvm-assurance-test.sock".to_string(),
            capabilities: vec![mvm_contract::assurance::probe_capability_descriptor()],
        };
        let mut config = mvm_core::vm_backend::VmStartConfig::default();
        config.service_proxies.push(proxy.clone());
        let error = attach_assurance_proxy(&mut config, proxy)
            .expect_err("the same controller service must not be attached twice");
        assert!(error.to_string().contains("already configured"));
    }

    #[test]
    fn extension_binding_requires_the_signed_dispatch_verb() {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new()
            .services(vec![
                mvm_contract::protocol::broker::ServiceId::parse(
                    mvm_contract::assurance::HOST_ASSURANCE_SERVICE,
                )
                .expect("valid fixture service"),
            ])
            .extensions(vec![extension_binding(
                mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
            )])
            .build();

        let error = validate_extension_bindings(&plan)
            .expect_err("an extension plan without the dispatch verb must be refused");
        assert!(error.to_string().contains("run-extension"));

        plan.agent_verbs = Some(vec![
            mvm_contract::plan::VerbId::new("run-extension").expect("valid fixture verb"),
        ]);
        let error = validate_extension_bindings(&plan)
            .expect_err("an extension plan without the cancellation verb must be refused");
        assert!(error.to_string().contains("cancel-extension"));

        plan.agent_verbs = Some(vec![
            mvm_contract::plan::VerbId::new("run-extension").expect("valid fixture verb"),
            mvm_contract::plan::VerbId::new("cancel-extension").expect("valid fixture verb"),
        ]);
        validate_extension_bindings(&plan).expect("the exact signed verb admits dispatch");
    }

    #[test]
    fn unsupported_extension_placement_fails_closed() {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new()
            .services(vec![
                mvm_contract::protocol::broker::ServiceId::parse(
                    mvm_contract::assurance::HOST_ASSURANCE_SERVICE,
                )
                .expect("valid fixture service"),
            ])
            .extensions(vec![extension_binding(
                mvm_contract::protocol::extension_pack::ExtensionPlacement::IsolatedController,
            )])
            .build();
        plan.agent_verbs = Some(vec![
            mvm_contract::plan::VerbId::new("run-extension").expect("valid fixture verb"),
            mvm_contract::plan::VerbId::new("cancel-extension").expect("valid fixture verb"),
        ]);

        let error = validate_extension_bindings(&plan)
            .expect_err("an unimplemented placement must never fall through to guest dispatch");
        assert!(error.to_string().contains("not executable"));
    }

    /// A musl guest cannot load the glibc cdylib, and the failure would
    /// otherwise land inside the guest at `dlopen` time as a relocation error
    /// naming a symbol the operator never heard of. Refuse on the host, where
    /// the cause can be named.
    /// Stage a rootfs whose `mvm-meta.json` records `libc`, and hand back the
    /// rootfs path the launch would boot.
    fn rootfs_recording_libc(dir: &std::path::Path, libc: GuestLibc) -> String {
        let sidecar = mvm_build::builder_vm::GuestSidecar::for_oci_run("fixture", false, false)
            .with_libc(libc);
        sidecar.write_to_dir(dir).expect("write mvm-meta.json");
        dir.join("rootfs.ext4").to_string_lossy().into_owned()
    }

    /// The launch-shaped entry point reads the image's libc off the rootfs
    /// rather than taking it on trust, so a caller cannot pass a libc that
    /// disagrees with the image it is about to boot.
    #[test]
    fn the_launch_gate_reads_the_libc_off_the_rootfs_it_is_given() {
        let dir = tempfile::tempdir().expect("tempdir");
        let plan = plan_binding(&["host.kv.v1"]);

        let musl_rootfs = rootfs_recording_libc(dir.path(), GuestLibc::Musl);
        enforce_sdk_sidecar_for_launch(
            &musl_rootfs,
            &[sdk_sidecar_volume_for(GuestLibc::Musl)],
            &plan,
        )
        .expect("a musl image may load the musl sidecar");

        let err = enforce_sdk_sidecar_for_launch(
            &musl_rootfs,
            &[sdk_sidecar_volume_for(GuestLibc::Glibc)],
            &plan,
        )
        .expect_err("a musl image must not receive the glibc sidecar");
        let msg = err.to_string();
        assert!(msg.contains("musl") && msg.contains("glibc"), "{msg}");
    }

    /// A rootfs with no sidecar beside it records nothing, and an image whose
    /// libc cannot be established is refused rather than assumed loadable.
    #[test]
    fn the_launch_gate_refuses_an_image_recording_no_libc() {
        let dir = tempfile::tempdir().expect("tempdir");
        let plan = plan_binding(&["host.kv.v1"]);
        let rootfs = dir
            .path()
            .join("rootfs.ext4")
            .to_string_lossy()
            .into_owned();

        let err = enforce_sdk_sidecar_for_launch(
            &rootfs,
            &[sdk_sidecar_volume_for(GuestLibc::Musl)],
            &plan,
        )
        .expect_err("an image of unknown libc must not receive a sidecar");

        assert!(
            err.to_string().contains("records no libc"),
            "the refusal must say the image is the unknown side: {err}"
        );
    }

    /// A sidecar whose path carries no libc segment cannot be identified, and
    /// an unidentifiable variant is refused rather than assumed to match. Any
    /// path this layout did not write reads that way — the check is on what the
    /// launch config presents, not on where it came from.
    #[test]
    fn a_sidecar_filed_under_no_libc_is_refused() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let plan = plan_binding(&["host.kv.v1"]);
        let unkeyed = VmVolume {
            host: "/cache/sdk-sidecar/1.2.3/aarch64/sdk.ext4".into(),
            guest: mvm_core::plan::SDK_SIDECAR_GUEST_PATH.into(),
            read_only: true,
            kind: VmVolumeKind::Disk,
            ..Default::default()
        };

        let err = enforce_sdk_sidecar_attachment(&[unkeyed], &plan, GuestLibc::Musl)
            .expect_err("a sidecar of unknown variant must not be attached");

        assert!(
            err.to_string().contains("`mvmctl bootstrap`"),
            "the refusal must say how to repopulate the cache: {err}"
        );
    }

    #[test]
    fn a_sidecar_the_guest_cannot_load_is_refused_before_boot() {
        let plan = plan_binding(&["host.kv.v1"]);
        let err = enforce_sdk_sidecar_attachment(
            &[sdk_sidecar_volume_for(GuestLibc::Glibc)],
            &plan,
            GuestLibc::Musl,
        )
        .expect_err("a musl image must not receive the glibc sidecar");
        let msg = err.to_string();
        assert!(msg.contains("musl"), "must name the image's libc: {msg}");
        assert!(msg.contains("glibc"), "must name the sidecar's libc: {msg}");
        assert!(
            msg.contains("host.kv.v1"),
            "must name the binding that asked for it: {msg}"
        );
    }

    /// Unknown is the arm a permissive default would wave through. It covers an
    /// image materialized before mvm recorded the libc, so the message has to
    /// say how to make it known rather than just refusing.
    #[test]
    fn an_unknown_libc_is_refused_and_says_how_to_resolve_it() {
        let plan = plan_binding(&["host.kv.v1"]);
        let err = enforce_sdk_sidecar_attachment(
            &[sdk_sidecar_volume()],
            &plan,
            mvm_build::guest_libc::GuestLibc::Unknown,
        )
        .expect_err("an unrecorded libc must not be attached on a guess");
        let msg = err.to_string();
        assert!(
            msg.contains("re-pull or rebuild"),
            "must name the remedy: {msg}"
        );
    }

    /// The libc gate must sit behind the binding check: a workload that binds
    /// no SDK service carries no sidecar, so its libc is irrelevant and must
    /// not refuse the boot.
    #[test]
    fn an_unbound_workload_is_unaffected_by_its_libc() {
        let plan = plan_binding(&[]);
        assert!(
            enforce_sdk_sidecar_attachment(&[], &plan, mvm_build::guest_libc::GuestLibc::Unknown)
                .is_ok()
        );
    }

    /// The libc the shipped cdylib is built for. These tests assert attachment
    /// *shape* — count, read-only, kind — so they hold the libc loadable and
    /// let the dedicated libc tests vary it.
    /// One libc for both sides of the admission fixtures: what the image
    /// records and what the sidecar was filed under have to agree for the
    /// attachment to be admissible, and these tests are about the other rules.
    const LOADABLE_LIBC: GuestLibc = GuestLibc::Musl;

    /// A sidecar volume shaped the way the resolver actually hands one over:
    /// filed under its libc, because that segment is where the gate reads the
    /// variant from. A path without it is not a lesser fixture, it is a
    /// different case — covered by
    /// `a_sidecar_filed_under_no_libc_is_refused`.
    fn sdk_sidecar_volume() -> mvm_core::vm_backend::VmVolume {
        sdk_sidecar_volume_for(LOADABLE_LIBC)
    }

    /// The same volume filed under an arbitrary libc, so a test can state both
    /// sides of the comparison instead of leaning on which one the shared
    /// fixture happens to use.
    fn sdk_sidecar_volume_for(libc: GuestLibc) -> mvm_core::vm_backend::VmVolume {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        VmVolume {
            host: format!(
                "/cache/sdk-sidecar/1.2.3/aarch64/{}/sdk.ext4",
                libc.as_str()
            ),
            guest: mvm_core::plan::SDK_SIDECAR_GUEST_PATH.into(),
            read_only: true,
            kind: VmVolumeKind::Disk,
            ..Default::default()
        }
    }

    fn plan_binding(services: &[&str]) -> ExecutionPlan {
        let mut input = fixture_input("vm-sdk");
        input.services = services
            .iter()
            .map(|s| {
                mvm_contract::protocol::broker::ServiceId::parse(*s).expect("fixture service id")
            })
            .collect();
        synthesize_plan(&input).expect("fixture plan synthesizes")
    }

    #[test]
    fn registry_pack_asset_requires_an_exact_version_and_a_verified_installation() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let mut plan = plan_binding(&[]);
        plan.asset_identities.push(
            mvm_core::plan::AssetIdentity::new(
                mvm_core::plan::AssetKind::RegistryPack,
                "runtime/python",
                FIXTURE_SHA,
            )
            .expect("valid digest"),
        );
        let error = verify_registry_pack_assets(&plan).expect_err("version required");
        assert!(error.to_string().contains("exact version"), "{error}");
        assert!(
            registry_pack::verify_registry_pack_boot(
                &plan,
                &mut VmStartConfig::default(),
                BackendKind::Firecracker,
            )
            .is_err(),
            "backend handoff must also refuse a non-versioned pack pin"
        );

        plan.asset_identities
            .last_mut()
            .expect("pack identity was appended")
            .name = "runtime/python@1.0.0".to_string();
        let error = verify_registry_pack_assets(&plan).expect_err("uninstalled pack refused");
        assert!(
            error.to_string().contains("verifying registry pack"),
            "{error}"
        );

        plan.asset_identities
            .last_mut()
            .expect("pack identity was appended")
            .name = "../../outside@1.0.0".to_string();
        let error = verify_registry_pack_assets(&plan).expect_err("unsafe reference refused");
        assert!(
            error
                .to_string()
                .contains("invalid registry pack reference"),
            "{error}"
        );
    }

    #[test]
    fn admission_without_registry_pack_assets_needs_no_pack_store() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let plan = plan_binding(&[]);
        verify_registry_pack_assets(&plan).expect("ordinary plan has no pack lookup");
        registry_pack::verify_registry_pack_boot(
            &plan,
            &mut VmStartConfig::default(),
            BackendKind::Mock,
        )
        .expect("ordinary workloads need no built-pack boot contract");
    }

    #[cfg(feature = "manifest-verify")]
    #[test]
    fn real_signed_pack_identity_is_reverified_at_host_admission() {
        let (_env, home) = host_with_ceiling(Default::default());
        let installed = install_signed_python_pack(home.path());
        let digest = mvm_core::packs::Sha256Hex::from_bytes(PYTHON_MANIFEST);
        let mut plan = plan_binding(&[]);
        plan.asset_identities.push(
            mvm_core::plan::AssetIdentity::new(
                mvm_core::plan::AssetKind::RegistryPack,
                "runtime/python@1.1.0",
                digest.as_str(),
            )
            .expect("pack asset identity"),
        );
        verify_registry_pack_assets(&plan).expect("signed pack admits");
        registry_pack::verify_registry_pack_boot(
            &plan,
            &mut VmStartConfig::default(),
            BackendKind::Mock,
        )
        .expect("source packs do not acquire built-image boot authority");

        let ledger = InMemoryNonceLedger::new();
        let admitted = admit_plan_for_run(
            &plan,
            &SystemClock,
            &ledger,
            None,
            None,
            None,
            RunPosture::on_backend(Variant::Dev, BackendKind::Firecracker),
        )
        .expect("real source pack plan is admitted");
        let mut config = VmStartConfig {
            tenant_id: Some(admitted.plan().tenant.0.clone()),
            plan_json: Some(serde_json::to_string(admitted.signed()).unwrap()),
            ..Default::default()
        };
        assert!(
            admitted
                .built_pack_boot_check()
                .unwrap()
                .unwrap()
                .prepare(&mut config, BackendKind::Firecracker)
                .unwrap()
                .is_none(),
            "a source pack keeps its existing non-built launch path"
        );
        assert!(
            admitted
                .built_pack_boot_check()
                .unwrap()
                .unwrap()
                .prepare(&mut config, BackendKind::Hvf)
                .unwrap_err()
                .to_string()
                .contains("backend differs")
        );
        config.plan_json = Some("{}".into());
        assert!(
            admitted
                .built_pack_boot_check()
                .unwrap()
                .unwrap()
                .prepare(&mut config, BackendKind::Firecracker)
                .unwrap_err()
                .to_string()
                .contains("admitted plan")
        );

        plan.asset_identities
            .last_mut()
            .expect("pack identity")
            .digest = FIXTURE_SHA.to_string();
        let error = verify_registry_pack_assets(&plan).expect_err("wrong plan digest refused");
        assert!(error.to_string().contains("signed-plan digest"), "{error}");

        plan.asset_identities
            .last_mut()
            .expect("pack identity")
            .digest = digest.as_str().to_string();
        let path = installed.payload_root().join("pack/image/mvm.toml");
        let mut bytes = std::fs::read(&path).expect("read signed image manifest");
        bytes[0] ^= 1;
        std::fs::write(path, bytes).expect("tamper cached payload without changing length");
        let error = verify_registry_pack_assets(&plan).expect_err("tampered pack refused");
        assert!(
            format!("{error:#}").contains("digest mismatch"),
            "{error:#}"
        );
    }

    struct FixedClock(DateTime<Utc>);

    impl Clock for FixedClock {
        fn now(&self) -> DateTime<Utc> {
            self.0
        }
    }

    /// Claim 1: a volume that the signed plan didn't admit — or that
    /// mismatches the admitted ro/rw — is refused before launch.
    /// Materializing a granted directory must not change what it has to be
    /// granted *as*.
    ///
    /// `enforce_admitted_shares` is the trust-boundary hook for claim 1: a
    /// volume reaches a guest only if the signed plan admitted that exact
    /// host path, guest path and kind. `--mount` now attaches an ext4 image
    /// rather than the directory, and the volume records which image in
    /// `materialized_image` — but `host` stays the directory that was
    /// granted, so the grant still matches.
    ///
    /// This is not cosmetic. Had the materialized mount become a `Disk` whose
    /// `host` was the image under `~/.mvm`, this check would compare that path
    /// against the granted directory and refuse the boot. The field exists so
    /// the transport can change without the grant changing.
    #[test]
    fn a_materialized_grant_still_satisfies_the_directory_share_it_was_granted_as() {
        let grant = mvm_core::plan::HostShareGrant {
            tag: "uvol0".into(),
            host_path: "/h/src".into(),
            guest_path: "/data".into(),
            kind: mvm_core::plan::ShareKind::DirShare,
            read_only: true,
            encrypted: false,
            content_sha256: None,
            include: Vec::new(),
            exclude: Vec::new(),
        };
        let mut input = fixture_input("vm-materialized-share");
        input.shares = vec![grant];
        let plan = synthesize_plan(&input).unwrap();

        let materialized = mvm_core::vm_backend::VmVolume {
            host: "/h/src".into(),
            guest: "/data".into(),
            read_only: true,
            materialized_image: Some("/state/mount-0.ext4".into()),
            volume_label: None,
            ..Default::default()
        };
        enforce_admitted_shares(std::slice::from_ref(&materialized), &plan)
            .expect("a materialized grant is still the grant that was admitted");

        // And the image path is not what is checked: a volume claiming a host
        // path nobody granted is refused whatever it materialized into.
        let ungranted = mvm_core::vm_backend::VmVolume {
            host: "/state/mount-0.ext4".into(),
            ..materialized.clone()
        };
        assert!(
            enforce_admitted_shares(std::slice::from_ref(&ungranted), &plan).is_err(),
            "only the granted host path may reach a guest"
        );

        let mut disk_input = fixture_input("vm-materialized-share-as-disk");
        disk_input.shares = vec![mvm_core::plan::HostShareGrant {
            tag: "uvol0".into(),
            host_path: "/h/src".into(),
            guest_path: "/data".into(),
            kind: mvm_core::plan::ShareKind::Disk,
            read_only: true,
            encrypted: false,
            content_sha256: None,
            include: Vec::new(),
            exclude: Vec::new(),
        }];
        let disk_plan = synthesize_plan(&disk_input).expect("synthesize disk plan");
        assert!(
            enforce_admitted_shares(std::slice::from_ref(&materialized), &disk_plan).is_err(),
            "a materialized directory must not satisfy a disk grant"
        );
    }

    /// A re-bind under a different deny set refuses: claim-time binding
    /// binds the include/exclude vectors, so a volume whose share grants it
    /// a different effective tree than the plan admitted cannot attach —
    /// the deny set cannot be weakened between admission and boot.
    #[test]
    fn a_rebind_with_a_different_deny_set_is_refused() {
        let grant = mvm_core::plan::HostShareGrant {
            tag: "uvol0".into(),
            host_path: "/h/src".into(),
            guest_path: "/data".into(),
            kind: mvm_core::plan::ShareKind::DirShare,
            read_only: true,
            encrypted: false,
            content_sha256: None,
            include: Vec::new(),
            exclude: vec![mvm_contract::policy::protected_paths::ProtectedPath::new(
                "**/target",
            )],
        };
        let mut input = fixture_input("vm-share-deny-rebind");
        input.shares = vec![grant];
        let plan = synthesize_plan(&input).unwrap();

        let matching = mvm_core::vm_backend::VmVolume {
            host: "/h/src".into(),
            guest: "/data".into(),
            read_only: true,
            materialized_image: Some("/state/mount-0.ext4".into()),
            share_include: Vec::new(),
            share_exclude: vec![mvm_contract::policy::protected_paths::ProtectedPath::new(
                "**/target",
            )],
            ..Default::default()
        };
        enforce_admitted_shares(std::slice::from_ref(&matching), &plan)
            .expect("the admitted deny set attaches");

        let weakened = mvm_core::vm_backend::VmVolume {
            share_exclude: Vec::new(),
            ..matching.clone()
        };
        assert!(
            enforce_admitted_shares(std::slice::from_ref(&weakened), &plan).is_err(),
            "a re-bind that drops the additional deny set must refuse"
        );
    }

    #[test]
    fn admitted_share_digest_refuses_directory_changed_after_admission() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let data = tmp.path().join("data");
        std::fs::create_dir_all(&data).expect("mkdir");
        std::fs::write(data.join("rows.csv"), b"a,b\n1,2\n").expect("write");
        let image = tmp.path().join("mount.ext4");
        std::fs::write(&image, b"frozen image bytes").expect("write image");
        let digest =
            mvm_core::crypto::image_verify::sha256_file(&image).expect("hash admitted image");
        let grant = mvm_core::plan::HostShareGrant {
            tag: "uvol0".into(),
            host_path: data.to_string_lossy().into_owned(),
            guest_path: "/data".into(),
            kind: mvm_core::plan::ShareKind::DirShare,
            read_only: true,
            encrypted: false,
            content_sha256: Some(digest.clone()),
            include: Vec::new(),
            exclude: Vec::new(),
        };
        let mut input = fixture_input("vm-share-digest-drift");
        input.shares = vec![grant];
        let plan = synthesize_plan(&input).expect("synthesize");

        let volume = |host: &str| mvm_core::vm_backend::VmVolume {
            host: host.into(),
            guest: "/data".into(),
            read_only: true,
            materialized_image: Some(image.display().to_string()),
            ..Default::default()
        };

        // Unchanged frozen image: the admitted identity still matches.
        enforce_admitted_shares(
            std::slice::from_ref(&volume(&plan.shares[0].host_path)),
            &plan,
        )
        .expect("unchanged tree attaches");

        // A byte flips between admission and attach: refused, and the error
        // names both identities.
        std::fs::write(&image, b"tampered frozen image").expect("tamper");
        let err = enforce_admitted_shares(
            std::slice::from_ref(&volume(&plan.shares[0].host_path)),
            &plan,
        )
        .expect_err("a changed image must not attach under the admitted identity");
        let msg = format!("{err:#}");
        assert!(
            msg.contains(&digest),
            "error names the admitted digest: {msg}"
        );
        assert!(
            msg.contains("changed after admission"),
            "error says why: {msg}"
        );
    }

    #[test]
    fn enforce_admitted_shares_refuses_unadmitted_or_mismatched() {
        use mvm_core::vm_backend::VmVolume;
        let grant = mvm_core::plan::HostShareGrant {
            tag: "uvol0".into(),
            host_path: "/h/src".into(),
            guest_path: "/data".into(),
            kind: mvm_core::plan::ShareKind::DirShare,
            read_only: true,
            encrypted: false,
            content_sha256: None,
            include: Vec::new(),
            exclude: Vec::new(),
        };
        let mut input = fixture_input("vm-shares");
        input.shares = vec![grant];
        let plan = synthesize_plan(&input).unwrap();

        let admitted_vol = VmVolume {
            host: "/h/src".into(),
            guest: "/data".into(),
            read_only: true,
            materialized_image: Some("/state/mount-0.ext4".into()),
            ..Default::default()
        };
        // The exact admitted volume passes.
        assert!(enforce_admitted_shares(std::slice::from_ref(&admitted_vol), &plan).is_ok());

        // A volume the plan never named is refused.
        let unadmitted = VmVolume {
            host: "/etc".into(),
            guest: "/data".into(),
            read_only: true,
            materialized_image: Some("/state/mount-1.ext4".into()),
            ..Default::default()
        };
        assert!(enforce_admitted_shares(&[unadmitted], &plan).is_err());

        // Same path/kind, but read-WRITE when the plan admitted read-only:
        // an unauthorized escalation, refused.
        let escalated = VmVolume {
            read_only: false,
            ..admitted_vol
        };
        assert!(enforce_admitted_shares(&[escalated], &plan).is_err());
    }

    /// A workload that binds no SDK host service gets no sidecar, and nothing
    /// may attach one behind the plan's back.
    #[test]
    fn no_sdk_binding_means_no_sidecar_attachment() {
        let plan = plan_binding(&[]);
        assert!(enforce_sdk_sidecar_attachment(&[], &plan, LOADABLE_LIBC).is_ok());

        let err = enforce_sdk_sidecar_attachment(&[sdk_sidecar_volume()], &plan, LOADABLE_LIBC)
            .expect_err("an unauthorized sidecar must be refused");
        let msg = err.to_string();
        assert!(msg.contains("binds no SDK host service"), "{msg}");
    }

    /// An unrelated host-service binding is not an SDK binding: it must not pull
    /// the glibc sidecar into an ordinary workload.
    #[test]
    fn unrelated_service_binding_does_not_require_the_sidecar() {
        let plan = plan_binding(&["broker.v1", "host.other.v1"]);
        assert!(enforce_sdk_sidecar_attachment(&[], &plan, LOADABLE_LIBC).is_ok());
        assert!(
            enforce_sdk_sidecar_attachment(&[sdk_sidecar_volume()], &plan, LOADABLE_LIBC).is_err()
        );
    }

    /// A bound SDK host service with the sidecar attached read-only is admitted.
    #[test]
    fn sdk_binding_with_a_read_only_sidecar_is_admitted() {
        for service in mvm_core::plan::SDK_HOST_SERVICES {
            let plan = plan_binding(&[service]);
            assert!(
                enforce_sdk_sidecar_attachment(&[sdk_sidecar_volume()], &plan, LOADABLE_LIBC)
                    .is_ok(),
                "{service} bound + sidecar attached read-only must be admitted"
            );
        }
    }

    /// Wasm has neither block devices nor a native dynamic loader, so the
    /// ext4-hosted SDK cdylib cannot reach that tier. Refuse in terms of the
    /// requested service before the backend leaks a synthetic disk-volume
    /// implementation detail.
    #[test]
    fn wasm_sdk_binding_is_refused_at_the_delivery_seam() {
        let plan = plan_binding(&["host.time.v1"]);
        let err = enforce_sdk_sidecar_backend_compatibility(
            mvm_core::vm_backend::BackendKind::Wasm,
            &plan,
        )
        .expect_err("wasm cannot receive or load the SDK sidecar");
        let msg = err.to_string();
        assert!(msg.contains("wasm"), "{msg}");
        assert!(msg.contains("host.time.v1"), "{msg}");
        assert!(msg.contains("SDK host service"), "{msg}");
        assert!(!msg.contains("DiskVolumeNotSupported"), "{msg}");
    }

    #[test]
    fn microvm_backend_keeps_the_sdk_sidecar_delivery_path() {
        let plan = plan_binding(&["host.time.v1"]);
        assert!(
            enforce_sdk_sidecar_backend_compatibility(
                mvm_core::vm_backend::BackendKind::Firecracker,
                &plan,
            )
            .is_ok()
        );
    }

    #[test]
    fn direct_protocol_binding_requires_no_sidecar_and_refuses_a_stray_one() {
        let mut plan = plan_binding(&["host.kv.v1"]);
        plan.sdk_uses_sidecar = false;

        assert!(
            enforce_sdk_sidecar_backend_compatibility(
                mvm_core::vm_backend::BackendKind::Wasm,
                &plan,
            )
            .is_ok()
        );
        assert!(enforce_sdk_sidecar_attachment(&[], &plan, LOADABLE_LIBC).is_ok());

        let err = enforce_sdk_sidecar_attachment(&[sdk_sidecar_volume()], &plan, LOADABLE_LIBC)
            .expect_err("a direct-protocol plan must refuse a stray sidecar");
        assert!(err.to_string().contains("sdk_uses_sidecar=false"), "{err}");
    }

    /// A bound SDK host service with no sidecar attachment fails closed, and the
    /// message names the binding that demanded it without leaking file bytes.
    #[test]
    fn sdk_binding_without_the_sidecar_fails_closed() {
        let plan = plan_binding(&["host.kv.v1"]);
        let err = enforce_sdk_sidecar_attachment(&[], &plan, LOADABLE_LIBC)
            .expect_err("a required-but-absent sidecar must refuse the launch");
        let msg = err.to_string();
        assert!(msg.contains("host.kv.v1"), "{msg}");
        assert!(
            msg.contains(mvm_core::plan::SDK_SIDECAR_GUEST_PATH),
            "{msg}"
        );
    }

    /// The sidecar is read-only by contract: a writable or directory-share
    /// attachment at the sidecar mount point is a different, unadmitted shape.
    #[test]
    fn a_writable_or_dir_share_sidecar_fails_closed() {
        let plan = plan_binding(&["host.audit.v1"]);

        let writable = mvm_core::vm_backend::VmVolume {
            read_only: false,
            ..sdk_sidecar_volume()
        };
        let err = enforce_sdk_sidecar_attachment(&[writable], &plan, LOADABLE_LIBC)
            .expect_err("rw refused");
        assert!(err.to_string().contains("read-only"), "{err}");

        let share = mvm_core::vm_backend::VmVolume {
            materialized_image: Some("/state/mount.ext4".to_string()),
            ..sdk_sidecar_volume()
        };
        let err = enforce_sdk_sidecar_attachment(&[share], &plan, LOADABLE_LIBC)
            .expect_err("share refused");
        assert!(err.to_string().contains("disk image"), "{err}");
    }

    /// Two attachments racing for the same mount point is ambiguous — refuse
    /// rather than let mount order decide which cdylib the workload loads.
    #[test]
    fn duplicate_sidecar_attachments_fail_closed() {
        let plan = plan_binding(&["host.time.v1"]);
        let dup = [sdk_sidecar_volume(), sdk_sidecar_volume()];
        let err = enforce_sdk_sidecar_attachment(&dup, &plan, LOADABLE_LIBC)
            .expect_err("duplicates refused");
        assert!(err.to_string().contains("exactly one"), "{err}");
    }

    /// Unrelated volumes are untouched by the sidecar gate in either direction.
    #[test]
    fn unrelated_volumes_are_ignored_by_the_sidecar_gate() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let other = VmVolume {
            host: "/h/data.img".into(),
            guest: "/data".into(),
            read_only: false,
            kind: VmVolumeKind::Disk,
            ..Default::default()
        };
        assert!(
            enforce_sdk_sidecar_attachment(
                std::slice::from_ref(&other),
                &plan_binding(&[]),
                LOADABLE_LIBC
            )
            .is_ok()
        );
        let bound = plan_binding(&["host.cost.v1"]);
        assert!(
            enforce_sdk_sidecar_attachment(
                &[other.clone(), sdk_sidecar_volume()],
                &bound,
                LOADABLE_LIBC
            )
            .is_ok()
        );
        assert!(
            enforce_sdk_sidecar_attachment(std::slice::from_ref(&other), &bound, LOADABLE_LIBC)
                .is_err(),
            "an unrelated volume must not satisfy the sidecar requirement"
        );
    }

    /// The signed plan round-trips its service bindings, so the gate decides on
    /// the same bytes the signature covers.
    #[test]
    fn service_bindings_survive_plan_serialization() {
        let plan = plan_binding(&["host.audit.v1", "broker.v1"]);
        let json = serde_json::to_string(&plan).expect("plan serializes");
        let back: ExecutionPlan = serde_json::from_str(&json).expect("plan round-trips");
        assert_eq!(back.services, plan.services);
        assert!(mvm_core::plan::sdk_sidecar_required(&back));
        assert!(
            enforce_sdk_sidecar_attachment(&[sdk_sidecar_volume()], &back, LOADABLE_LIBC).is_ok()
        );
    }

    // ---- grants: the ceiling, and what the tier can actually enforce ----

    /// Isolate `MVM_HOME` and write an operator config carrying `ceiling`.
    ///
    /// Admission reads the ceiling from host config rather than from a
    /// parameter, so a test that wants a bounded host has to *be* one. Every
    /// test that reaches `admit_for_run` or `admit_and_start` must hold the
    /// returned guard, including tests using the default ceiling; otherwise it
    /// can observe another parallel test's process-wide `MVM_HOME`. The guard
    /// and home dir must both outlive the admission call.
    fn host_with_ceiling(
        ceiling: mvm_contract::grants::ceiling::GrantCeiling,
    ) -> (mvm_core::util::test_env::TestEnv, tempfile::TempDir) {
        let home = tempfile::tempdir().expect("scratch mvm home");
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.isolate_mvm_home(home.path());
        let cfg = mvm_core::user_config::MvmConfig {
            max_cpu_millicores: ceiling.max_cpu_millicores,
            max_memory_mib: ceiling.max_memory_mib,
            max_wall_clock_secs: ceiling.max_wall_clock_secs,
            ..mvm_core::user_config::MvmConfig::default()
        };
        mvm_core::user_config::save(&cfg, None).expect("writing the host config");
        // Precondition, not a redundant assertion: if this fails the isolation
        // did not hold, and every ceiling assertion below would then be
        // measuring some other directory's config.
        assert_eq!(
            mvm_core::user_config::load(None).grant_ceiling(),
            ceiling,
            "the isolated host must read back the ceiling it was configured with"
        );
        (env, home)
    }

    /// Run `f` with a subscriber installed, returning its value and everything
    /// that was logged.
    ///
    /// A test that only asserts "admitted" cannot tell a warned admission from
    /// a silent one, and the difference is the whole dev half of the rule.
    fn capturing_warnings<T>(f: impl FnOnce() -> T) -> (T, String) {
        use std::io::Write;
        use std::sync::{Arc, Mutex};

        #[derive(Clone)]
        struct Sink(Arc<Mutex<Vec<u8>>>);

        impl Write for Sink {
            fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
                self.0
                    .lock()
                    .expect("log sink poisoned")
                    .extend_from_slice(buf);
                Ok(buf.len())
            }
            fn flush(&mut self) -> std::io::Result<()> {
                Ok(())
            }
        }

        impl<'a> tracing_subscriber::fmt::MakeWriter<'a> for Sink {
            type Writer = Self;
            fn make_writer(&'a self) -> Self::Writer {
                self.clone()
            }
        }

        let sink = Sink(Arc::new(Mutex::new(Vec::new())));
        let subscriber = tracing_subscriber::fmt()
            .with_writer(sink.clone())
            .with_max_level(tracing::Level::WARN)
            .with_ansi(false)
            .finish();
        // Another thread may have cached a callsite as uninteresting before
        // this per-thread subscriber existed; recompute before running `f`.
        let value = tracing::subscriber::with_default(subscriber, || {
            tracing::callsite::rebuild_interest_cache();
            f()
        });
        let logged = String::from_utf8(sink.0.lock().expect("log sink poisoned").clone())
            .expect("log output is utf-8");
        (value, logged)
    }

    fn cpu_share(millicores: u32) -> mvm_contract::grants::Grants {
        mvm_contract::grants::Grants {
            cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores }),
            ..mvm_contract::grants::Grants::default()
        }
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn host_cpu_mechanism_gap_honors_hvf_quota_range() {
        // On macOS the HVF tier serves CPU shares through its own scheduler.
        // A share outside the scheduler's range is a missing mechanism; a
        // share inside the range is enforceable.
        assert!(
            host_cpu_mechanism_gap(&cpu_share(1500), BackendKind::Hvf, None).is_some(),
            "1500 millicores is out of range and must be reported as unenforceable"
        );
        assert!(
            host_cpu_mechanism_gap(&cpu_share(500), BackendKind::Hvf, None).is_none(),
            "500 millicores is inside the scheduler range and is enforceable"
        );
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn prod_admits_a_valid_hvf_cpu_share() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-hvf-valid-share");
        input.backend_name = "hvf";
        input.grants = Some(cpu_share(500));

        admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Hvf),
        )
        .expect("a 500 millicore share is enforceable on HVF");
    }

    /// The spawn-time memory and task ceilings are host protection nobody
    /// requested, so a host that cannot attach them is no reason to refuse a
    /// sealed run: without a CPU share there is no mechanism gap to report,
    /// whichever half of the mechanism is missing.
    #[test]
    fn a_missing_scope_mechanism_refuses_nothing_that_did_not_ask_for_cpu() {
        use mvm_core::spawn_scope::MechanismGap;
        for kind in [
            BackendKind::Firecracker,
            BackendKind::Qemu,
            BackendKind::Libkrun,
        ] {
            for gap in [
                MechanismGap::SystemdRunMissing,
                MechanismGap::NoUserSessionBus,
            ] {
                assert_eq!(
                    host_cpu_mechanism_gap(
                        &mvm_contract::grants::Grants::default(),
                        kind,
                        Some(gap)
                    ),
                    None,
                    "{kind:?} with {gap:?}"
                );
            }
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn host_cpu_mechanism_gap_requires_a_share_capable_tier_and_a_reported_gap() {
        use mvm_core::spawn_scope::MechanismGap;

        let missing_bus = Some(MechanismGap::NoUserSessionBus);
        assert_eq!(
            host_cpu_mechanism_gap(
                &mvm_contract::grants::Grants::default(),
                BackendKind::Firecracker,
                missing_bus,
            ),
            None,
            "a plan with no CPU share has no CPU mechanism gap"
        );
        assert_eq!(
            host_cpu_mechanism_gap(&cpu_share(1000), BackendKind::Wasm, missing_bus),
            None,
            "a tier whose CPU control is not a cgroup share does not use the host mechanism"
        );
        assert_eq!(
            host_cpu_mechanism_gap(&cpu_share(1000), BackendKind::Firecracker, None),
            None,
            "an available host mechanism leaves no gap"
        );

        let detail =
            host_cpu_mechanism_gap(&cpu_share(1000), BackendKind::Firecracker, missing_bus)
                .expect("a missing mechanism must be reported for a share-capable tier");
        assert!(detail.contains("no user session bus"), "{detail}");
    }

    /// Admit the fixture under a home whose `host-interface/` files are
    /// `files`; returns the admission result.
    fn admit_with_host_interface_files(files: &[(&str, &str)]) -> Result<AdmittedPlan> {
        let (_env, home) = host_with_ceiling(Default::default());
        let hi = home.path().join("host-interface");
        std::fs::create_dir_all(&hi).unwrap();
        for (name, body) in files {
            std::fs::write(hi.join(name), body).unwrap();
        }
        let keys = tempfile::tempdir().unwrap();
        admit_for_run(
            &fixture_input("vm-host-interface"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
    }

    /// The launch budgets are 300 ms cold and 50 ms warm for everything the
    /// preflight adds. This times only the host-interface gate (node record,
    /// policy and ledger reads, and the concurrent checks), not synthesis,
    /// signing or the boot. It asserts the median, which is stable on a loaded
    /// runner, and prints the 99th percentile for the record; run with
    /// `--nocapture` to read both.
    #[test]
    fn host_interface_preflight_stays_inside_the_launch_budgets() {
        use std::time::{Duration, Instant};
        let (_env, _home) = host_with_ceiling(Default::default());
        let plan = synthesize_plan(&fixture_input("vm-timing")).expect("fixture plan");

        let cold = Instant::now();
        host_gates::admit_host_interface(&plan).expect("the default node admits");
        let cold = cold.elapsed();

        let mut warm: Vec<Duration> = (0..300)
            .map(|_| {
                let t = Instant::now();
                host_gates::admit_host_interface(&plan).expect("admits");
                t.elapsed()
            })
            .collect();
        warm.sort();
        let (p50, p99) = (warm[warm.len() / 2], warm[warm.len() * 99 / 100]);
        println!("host-interface preflight: cold {cold:?}, warm p50 {p50:?}, p99 {p99:?}");

        assert!(
            cold < Duration::from_millis(300),
            "cold {cold:?} exceeds the 300 ms budget"
        );
        assert!(
            p50 < Duration::from_millis(50),
            "warm p50 {p50:?} exceeds the 50 ms budget"
        );
    }

    #[test]
    fn host_interface_with_no_local_state_admits_unchanged() {
        admit_with_host_interface_files(&[]).expect("the permissive local default admits");
    }

    #[test]
    fn host_interface_refuses_revoked_and_quarantined_nodes() {
        for state in ["revoked", "quarantined"] {
            let node = format!(r#"{{"node_id":"local","state":"{state}","epoch":1}}"#);
            let err = admit_with_host_interface_files(&[("node.json", &node)])
                .expect_err("a node that is not active must not boot a workload");
            assert!(err.to_string().contains(state), "{err}");
        }
    }

    #[test]
    fn host_interface_refuses_only_the_quarantined_workload() {
        let name = "vm-host-interface";
        let ledger = format!(r#"{{"{name}":{{"epoch":1,"quarantined":true}}}}"#);
        let err = admit_with_host_interface_files(&[("workloads.json", &ledger)])
            .expect_err("a quarantined workload must not boot");
        assert!(err.to_string().contains("quarantined"), "{err}");
        let other = r#"{"some-other-workload":{"epoch":1,"quarantined":true}}"#;
        admit_with_host_interface_files(&[("workloads.json", other)])
            .expect("quarantining another workload must not block this one");
    }

    #[test]
    fn host_interface_refuses_a_plan_from_before_a_replacement() {
        // The ledger says epoch 2; a plan synthesized before the replacement
        // (or issued by a control plane that never saw it) still carries 1.
        let (_env, home) = host_with_ceiling(Default::default());
        let hi = home.path().join("host-interface");
        std::fs::create_dir_all(&hi).unwrap();
        std::fs::write(
            hi.join("workloads.json"),
            r#"{"vm-epoch":{"epoch":2,"quarantined":false}}"#,
        )
        .unwrap();
        let mut stale = synthesize_plan(&fixture_input("vm-epoch")).unwrap();
        assert_eq!(
            stale.execution_epoch, 2,
            "synthesis reads the current epoch"
        );
        stale.execution_epoch = 1;
        let err = host_gates::admit_host_interface(&stale)
            .expect_err("a plan at an older epoch must not admit");
        assert!(err.to_string().contains("stale execution epoch"), "{err}");
        stale.execution_epoch = 2;
        host_gates::admit_host_interface(&stale).expect("the current epoch admits");
        stale.execution_epoch = 3;
        assert!(
            host_gates::admit_host_interface(&stale).is_err(),
            "an epoch the host never issued is refused too"
        );
    }

    #[test]
    fn host_interface_refuses_expired_policy_and_unpinned_image() {
        let expired =
            admit_with_host_interface_files(&[("policy.json", r#"{"version":1,"not_after":1}"#)])
                .expect_err("an expired policy must not admit");
        assert!(expired.to_string().contains("expired"), "{expired}");
        let pinned = admit_with_host_interface_files(&[(
            "policy.json",
            r#"{"version":1,"not_after":null,"image_digests":["feedface"]}"#,
        )])
        .expect_err("an image outside the pinned list must not admit");
        assert!(pinned.to_string().contains("image"), "{pinned}");
    }

    #[test]
    fn host_interface_refuses_a_malformed_or_hardware_requiring_policy() {
        let bad = admit_with_host_interface_files(&[("policy.json", "{nope")])
            .expect_err("a malformed policy must fail closed");
        assert!(bad.to_string().contains("unreadable"), "{bad}");
        let hw = admit_with_host_interface_files(&[(
            "policy.json",
            r#"{"version":1,"not_after":null,"attestation":{"required":true,"minimum":"hardware"}}"#,
        )])
        .expect_err("software evidence cannot satisfy a hardware requirement");
        assert!(hw.to_string().contains("attestation"), "{hw}");
    }

    #[test]
    fn admission_refuses_a_grant_over_the_ceiling() {
        let (_env, _home) = host_with_ceiling(mvm_contract::grants::ceiling::GrantCeiling {
            max_cpu_millicores: Some(2000),
            ..Default::default()
        });
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-over-ceiling");
        input.grants = Some(cpu_share(64_000));

        let err = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("a grant above the host's ceiling must not be admitted");
        let msg = err.to_string();
        assert!(msg.contains("ceiling"), "{msg}");
        assert!(msg.contains("64000") && msg.contains("2000"), "{msg}");

        // Under the same ceiling, a request within it still admits — otherwise
        // this test would pass on a gate that refuses everything.
        let mut within = fixture_input("vm-under-ceiling");
        within.grants = Some(cpu_share(1500));
        admit_for_run(
            &within,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("a grant inside the ceiling admits");
    }

    #[test]
    fn mailbox_retention_above_or_without_host_ceiling_refuses_before_signing() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().expect("keystore");
        let mut input = fixture_input("vm-retention");
        input.mailbox = Some(MailboxGrant {
            durable_object_pair_sha256_v1: None,
            incoming_journal_policy_sha256_v1: None,
            outbound_journal_v1: None,
            mailbox: MailboxId::from_bytes([1; 32]),
            authority_key: [2; 32],
            epoch: ExecutionEpoch::new(1).expect("epoch"),
            report: None,
            retention: Some(MailboxRetentionPolicy::new(10_000).expect("window")),
        });
        let attempt = || {
            admit_for_run(
                &input,
                &SystemClock,
                &InMemoryNonceLedger::new(),
                Some(keys.path()),
                None,
                RunPosture::without_backend(Variant::Dev),
            )
        };
        let missing = attempt().expect_err("missing operator ceiling must refuse");
        assert!(
            missing.to_string().contains("max_mailbox_retention_ms"),
            "{missing:#}"
        );
        assert!(
            !keys.path().join("host-signer.ed25519").exists(),
            "a refused grant must not reach the keystore"
        );
        let mut config = mvm_core::user_config::load(None);
        config.max_mailbox_retention_ms = Some(9_999);
        mvm_core::user_config::save(&config, None).expect("set host ceiling");
        let over = attempt().expect_err("request above host ceiling must refuse");
        assert!(over.to_string().contains("ceiling"), "{over:#}");
        assert!(
            !keys.path().join("host-signer.ed25519").exists(),
            "an over-ceiling grant must not be signed"
        );
    }

    #[test]
    fn admission_refuses_before_signing() {
        // Not "an error came back" — no *signature* may exist for a run we
        // refuse. The host signer is generated lazily on first use, so an
        // untouched keys dir is proof the keystore was never reached and
        // therefore that nothing was signed.
        let (_env, _home) = host_with_ceiling(mvm_contract::grants::ceiling::GrantCeiling {
            max_cpu_millicores: Some(2000),
            ..Default::default()
        });
        let keys = tempfile::tempdir().unwrap();
        let key_file = keys
            .path()
            .join(crate::audit::host_keypair::SECRET_FILENAME);

        let mut input = fixture_input("vm-refused-unsigned");
        input.grants = Some(cpu_share(64_000));
        let refused = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        );
        assert!(refused.is_err(), "the ceiling must refuse this run");
        assert!(
            !key_file.exists(),
            "the refusal path reached the keystore; a plan we would not admit \
             must never acquire a signature"
        );

        // The control: an admitted run does reach the keystore, so the
        // assertion above is about the refusal and not about a keys dir that
        // is never written under any outcome.
        admit_for_run(
            &fixture_input("vm-admitted-signed"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("an unbounded run admits");
        assert!(
            key_file.exists(),
            "an admitted run signs under the host key"
        );
    }

    #[test]
    fn prod_refuses_a_cpu_grant_on_a_backend_that_cannot_bound_cpu() {
        // The hvf tier has no cgroup equivalent on any host, so a CPU share is
        // a bound nothing behind it implements. The tier comes from the
        // posture — the backend in hand — not from the plan's label.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-prod-unenforceable");
        input.backend_name = "hvf";
        input.grants = Some(cpu_share(1500));

        let err = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Hvf),
        )
        .expect_err("a sealed run must not boot with a bound nothing enforces");
        let msg = err.to_string();
        assert!(msg.contains("unenforceable"), "{msg}");
        assert!(msg.contains("cpu.share"), "{msg}");
    }

    #[test]
    fn dev_warns_and_proceeds_on_the_same_input() {
        // Same tier, same grant, dev posture: admitted, because a laptop that
        // cannot bound CPU is where most development happens and refusing
        // there would only teach everyone to stop declaring grants.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-dev-unenforceable");
        input.backend_name = "hvf";
        input.grants = Some(cpu_share(1500));

        let (result, logs) = capturing_warnings(|| {
            admit_for_run(
                &input,
                &SystemClock,
                &InMemoryNonceLedger::new(),
                Some(keys.path()),
                None,
                RunPosture::on_backend(Variant::Dev, BackendKind::Hvf),
            )
        });
        let admitted = result.expect("a dev run proceeds with an unenforceable grant");
        assert_eq!(
            admitted.plan().grants.as_ref().map(|g| g.cpu),
            Some(Some(mvm_contract::grants::CpuGrant::Share {
                millicores: 1500
            })),
            "the declared grant rides in the signed plan even when unenforced"
        );

        // "Warns" is half of what this test's name promises, so it is asserted
        // rather than assumed: a silent admission would leave the operator with
        // a grant they believe is bounding something.
        assert!(
            logs.contains("WARN"),
            "the dev path must warn, not admit silently: {logs:?}"
        );
        assert!(
            logs.contains("cpu.share") && logs.contains("not enforced"),
            "the warning must name what went unenforced: {logs:?}"
        );

        // Posture is the only difference between this outcome and the refusal
        // above. Asserted against the gate directly as well, so a change that
        // makes the rule unconditional in either direction fails here and not
        // only in the prod witness.
        let plan = admitted.plan();
        let grants = cpu_share(1500);
        assert!(
            enforceability_gate(
                &grants,
                plan,
                RunPosture::on_backend(Variant::Prod, BackendKind::Hvf)
            )
            .is_err()
        );
        assert!(
            enforceability_gate(
                &grants,
                plan,
                RunPosture::on_backend(Variant::Dev, BackendKind::Hvf)
            )
            .is_ok()
        );
    }

    #[test]
    fn a_mismatched_profile_label_cannot_select_the_wrong_tier() {
        // A fuel grant is enforceable on the wasm tier and on no other. A plan
        // labelled `wasm` that is actually booting on hvf must not be admitted
        // on the strength of that label — the label is the plan author's
        // string, the tier is what will run.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();
        let fuel = mvm_contract::grants::Grants {
            cpu: Some(mvm_contract::grants::CpuGrant::Fuel {
                instructions: 1_000_000,
            }),
            ..mvm_contract::grants::Grants::default()
        };

        let mut mislabelled = fixture_input("vm-mislabelled");
        mislabelled.backend_name = "wasm";
        mislabelled.grants = Some(fuel.clone());
        let err = admit_for_run(
            &mislabelled,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Hvf),
        )
        .expect_err("the label must not buy admission for a tier that is not booting");
        let msg = err.to_string();
        assert!(msg.contains("runtime profile"), "{msg}");
        assert!(msg.contains("wasm") && msg.contains("hvf"), "{msg}");

        // Honest label, honest tier, and the same grant: still refused, because
        // hvf meters no instructions. The refusal follows the tier either way.
        let mut honest = fixture_input("vm-honest-label");
        honest.backend_name = "hvf";
        honest.grants = Some(fuel.clone());
        let err = admit_for_run(
            &honest,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Hvf),
        )
        .expect_err("no microVM tier counts instructions");
        assert!(err.to_string().contains("cpu.fuel"), "{err}");

        // And on the tier that does meter them, the same grant admits — so the
        // two refusals above are about the mechanism, not about fuel grants
        // being refused everywhere.
        let mut on_wasm = fixture_input("vm-on-wasm");
        on_wasm.backend_name = "wasm";
        on_wasm.grants = Some(fuel);
        admit_for_run(
            &on_wasm,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Wasm),
        )
        .expect("the wasm tier meters instructions, so a fuel grant is enforceable there");
    }

    #[test]
    fn a_run_admitted_without_a_backend_cannot_claim_its_grants_are_enforced() {
        // A caller with no backend object has nothing to measure against. That
        // must fail closed rather than fall back to the plan's own label, which
        // is how a mislabelled plan would pick its own controls.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        // `firecracker` is a tier that *can* bound a share on Linux, so a gate
        // reading the label would admit this on a host where that is true.
        let mut input = fixture_input("vm-no-backend");
        input.backend_name = "firecracker";
        input.grants = Some(cpu_share(1500));

        let err = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Prod),
        )
        .expect_err("an unmeasurable grant must not be admitted under a sealed posture");
        assert!(err.to_string().contains("without the backend"), "{err}");
    }

    #[test]
    fn a_profile_that_names_no_tier_is_not_treated_as_a_disagreement() {
        // `mvmctl exec` labels its plans `transient-run`; the lineage path uses
        // the workload's name. Neither is a backend, so neither can contradict
        // the backend in hand — refusing them as a mismatch would break real
        // paths over a string that never claimed to be a tier.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-transient");
        input.backend_name = "transient-run";
        input.grants = Some(mvm_contract::grants::Grants {
            cpu: Some(mvm_contract::grants::CpuGrant::Fuel {
                instructions: 1_000_000,
            }),
            ..mvm_contract::grants::Grants::default()
        });

        admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::on_backend(Variant::Prod, BackendKind::Wasm),
        )
        .expect("the tier that boots meters instructions, whatever the profile is called");
    }

    #[test]
    fn a_run_that_grants_nothing_is_unaffected_by_the_tier_gate() {
        // The gate must stay silent for the overwhelmingly common case, or
        // every unbounded boot on a laptop becomes a warning.
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = tempfile::tempdir().unwrap();

        let mut input = fixture_input("vm-no-grants");
        input.backend_name = "hvf";
        admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Prod),
        )
        .expect("a run declaring no grant admits on any tier");
    }

    #[test]
    fn the_ceiling_bounds_memory_even_though_no_one_granted_it() {
        // Memory is fixed at VM creation rather than requested, so a plan that
        // declares no grants at all can still reserve the whole host.
        let (_env, _home) = host_with_ceiling(mvm_contract::grants::ceiling::GrantCeiling {
            max_memory_mib: Some(128),
            ..Default::default()
        });
        let keys = tempfile::tempdir().unwrap();

        let err = admit_for_run(
            &fixture_input("vm-fat"), // fixture asks for 256 MiB
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("memory above the ceiling must be refused");
        assert!(err.to_string().contains("memory_mib"), "{err}");
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn installed_entrypoint_issues_only_the_original_admitted_boot_grant() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let keys = mvm_core::config::mvm_keys_dir();
        let mut input = fixture_input("vm-original");
        input.stream_retention = mvm_core::plan::StreamRetention::Ephemeral;
        input.agent_verbs = Some(vec![
            mvm_core::plan::VerbId::new("activate-environment").unwrap(),
            mvm_core::plan::VerbId::new("run-entrypoint").unwrap(),
        ]);
        let admitted = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(&keys),
            None,
            RunPosture::on_backend(Variant::Dev, BackendKind::Firecracker),
        )
        .unwrap();
        let signer = crate::audit::host_keypair::load_or_init_at(&keys).unwrap();
        let issue = || {
            verb_grant_sidecar::installed_issuer(&admitted, "vm-original")
                .unwrap()
                .unwrap()
        };
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&signer.secret_path, std::fs::Permissions::from_mode(0o644))
            .unwrap();
        let prior = crate::host_signer::keystore::Keystore::test_signing_calls();
        assert!(
            issue().issue(&signer.verifying.to_bytes()).is_err(),
            "registered issuer used a non-private original key"
        );
        assert_eq!(
            crate::host_signer::keystore::Keystore::test_signing_calls(),
            prior
        );
        std::fs::set_permissions(&signer.secret_path, std::fs::Permissions::from_mode(0o600))
            .unwrap();
        let held = issue();
        let envelope = held.issue(&signer.verifying.to_bytes()).unwrap();
        assert!(held.issue(&signer.verifying.to_bytes()).is_err());
        assert!(issue().issue(&[1; 32]).is_err());
        input.agent_verbs.as_mut().unwrap().pop();
        let activation_only = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(&keys),
            None,
            RunPosture::on_backend(Variant::Dev, BackendKind::Firecracker),
        )
        .unwrap();
        assert!(verb_grant_sidecar::installed_issuer(&activation_only, "vm-original").is_err());
        let plan = admitted.plan();
        envelope
            .grant
            .verify(
                &signer.verifying,
                "vm-original",
                &plan.nonce,
                chrono::Utc::now(),
            )
            .unwrap();
        assert_eq!(Some(&envelope.grant.verbs), plan.agent_verbs.as_ref());
        assert_eq!(envelope.grant.not_after, plan.valid_until);
        assert!(
            envelope
                .grant
                .verify(
                    &signer.verifying,
                    "different",
                    &plan.nonce,
                    chrono::Utc::now()
                )
                .is_err()
        );
        assert!(
            !mvm_core::config::vm_state_dir("vm-original")
                .join("verb-grant.json")
                .exists()
        );
    }

    #[test]
    fn happy_path_returns_admitted_plan_with_plan_id() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let clock = SystemClock;
        let ledger = InMemoryNonceLedger::new();
        let admitted = admit_for_run(
            &fixture_input("vm1"),
            &clock,
            &ledger,
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy path");
        assert!(!admitted.plan_id().0.is_empty());
        assert!(admitted.signer_id().starts_with("host:"));
        // The signed envelope must be re-verifiable with the public
        // half of the host signer.
        let signer = crate::audit::host_keypair::load_or_init_at(dir.path()).unwrap();
        let trusted: [(&str, &ed25519_dalek::VerifyingKey); 1] =
            [(admitted.signer_id(), &signer.verifying)];
        let recovered = mvm_core::plan::verify_plan(admitted.signed(), &trusted).unwrap();
        assert_eq!(&recovered.plan_id, admitted.plan_id());
    }

    #[test]
    fn admitted_plan_id_is_a_content_address() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let admitted = admit_for_run(
            &fixture_input("vm1"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy path");
        assert!(
            admitted.plan_id().0.starts_with("sha256:"),
            "content-addressed, not a UUID: {}",
            admitted.plan_id().0
        );
        // The admission path enforces the content-address; the admitted plan
        // re-derives to exactly its stored id.
        assert_eq!(mvm_core::plan::verify_plan_id(admitted.plan()), Ok(()));
    }

    #[test]
    fn rejects_replay_within_validity_window() {
        let dir = tempfile::tempdir().unwrap();
        // We can't naturally replay because synthesize_plan generates a
        // fresh nonce each call — instead, build the plan once, sign,
        // then ask the ledger to admit twice. The second call must
        // refuse with nonce-replay.
        let plan = synthesize_plan(&fixture_input("vm1")).unwrap();
        let signer = crate::audit::host_keypair::load_or_init_at(dir.path()).unwrap();
        let signer_id = host_signer_id();
        let signed = sign_plan(&plan, &signer.signing, &signer_id);
        let verified =
            mvm_core::plan::verify_plan(&signed, &[(&signer_id, &signer.verifying)]).unwrap();

        let ledger = InMemoryNonceLedger::new();
        {
            let mut store = ledger.inner.lock().unwrap();
            assert!(store.check_and_insert(&signer_id, &verified).is_ok());
            assert!(
                store.check_and_insert(&signer_id, &verified).is_err(),
                "second insert of same (signer, nonce) must fail"
            );
        }
    }

    #[test]
    fn rejects_plan_outside_validity_window() {
        // Construct a fixed clock 30 minutes in the future — past
        // the plan's 10-minute window from synthesis.
        let now_plus_30 = Utc.with_ymd_and_hms(2099, 1, 1, 12, 30, 0).unwrap();
        // Override time by constructing a plan with a known window
        // and a FixedClock outside it.
        let dir = tempfile::tempdir().unwrap();
        // To exercise the window check deterministically, we
        // pre-build a stale signed plan and feed it directly through
        // the check (synthesize_plan can't make a stale plan because
        // it uses Utc::now()).
        let mut plan = synthesize_plan(&fixture_input("vm1")).unwrap();
        plan.valid_from = Utc.with_ymd_and_hms(2000, 1, 1, 0, 0, 0).unwrap();
        plan.valid_until = Utc.with_ymd_and_hms(2000, 1, 1, 0, 10, 0).unwrap();
        let signer = crate::audit::host_keypair::load_or_init_at(dir.path()).unwrap();
        let signed = sign_plan(&plan, &signer.signing, &host_signer_id());
        let verified = verify_plan(&signed, &[(&host_signer_id(), &signer.verifying)]).unwrap();
        let _clock = FixedClock(now_plus_30);
        // Inline the window check (admit_for_run does it after
        // synthesis; we're proving the underlying assert).
        assert!(check_window(&verified, now_plus_30).is_err());
    }

    #[test]
    fn admitted_plan_signed_field_round_trips_through_verify() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let admitted = admit_for_run(
            &fixture_input("vm1"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .unwrap();
        // The signed field is what the audit signer will hash;
        // proving it round-trips here closes the contract.
        let signer = crate::audit::host_keypair::load_or_init_at(dir.path()).unwrap();
        let trusted: [(&str, &ed25519_dalek::VerifyingKey); 1] =
            [(admitted.signer_id(), &signer.verifying)];
        assert!(verify_plan(admitted.signed(), &trusted).is_ok());
    }

    #[test]
    fn propagates_synthesis_failures() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let err = admit_for_run(
            &fixture_input(""), // empty vm_name fails synthesis
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("must refuse");
        assert!(
            err.to_string().contains("vm_name")
                || err.chain().any(|e| e.to_string().contains("vm_name"))
        );
    }

    #[test]
    fn two_distinct_admit_calls_produce_distinct_plan_ids_and_nonces() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let clock = SystemClock;
        let ledger = InMemoryNonceLedger::new();
        let a1 = admit_for_run(
            &fixture_input("vm1"),
            &clock,
            &ledger,
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .unwrap();
        let a2 = admit_for_run(
            &fixture_input("vm1"),
            &clock,
            &ledger,
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .unwrap();
        assert_ne!(a1.plan_id, a2.plan_id);
        assert_ne!(a1.plan.nonce, a2.plan.nonce);
    }

    // ── Claim 9: admit-time bundle re-verify ─────────────────────
    //
    // Tests exercise the boundary between `synthesize_plan`'s
    // `bundle_pin` (the input) and `admit_for_run`'s
    // `BundleAdmissionContext` (the verifier seam). The mvm_plan
    // bundle module already tests every BundleVerifyError /
    // PlanBundleError variant in isolation; these tests prove the
    // wiring fires when admit_for_run sees a pinned plan.

    use mvm_core::plan::bundle::{
        BundleResolveError, BundleResolver, KeyId as BundleKeyId, PlanArtifact, TrustStore,
        bundle_sha256, key_id_from_pubkey, write_bundle,
    };
    use std::collections::HashMap;

    struct FixedResolver(Vec<u8>);
    impl BundleResolver for FixedResolver {
        fn resolve(&self, _bundle_sha256: &str) -> Result<Vec<u8>, BundleResolveError> {
            Ok(self.0.clone())
        }
    }

    struct MapTrust(HashMap<BundleKeyId, ed25519_dalek::VerifyingKey>);
    impl TrustStore for MapTrust {
        fn lookup(&self, key_id: &BundleKeyId) -> Option<ed25519_dalek::VerifyingKey> {
            self.0.get(key_id).copied()
        }
    }

    /// Build a minimal signed bundle around `(kernel, rootfs)` bytes.
    /// Returns the archive plus the matching `PlanArtifact` pin.
    fn make_test_bundle(
        sk: &ed25519_dalek::SigningKey,
        kernel: &[u8],
        rootfs: &[u8],
    ) -> (Vec<u8>, PlanArtifact) {
        make_test_bundle_for_arch(
            sk,
            kernel,
            rootfs,
            &mvm_core::arch::GuestArch::host().to_string(),
        )
    }

    /// [`make_test_bundle`] with an explicit declared architecture, so the
    /// cross-arch refusal can be exercised from either host.
    fn make_test_bundle_for_arch(
        sk: &ed25519_dalek::SigningKey,
        kernel: &[u8],
        rootfs: &[u8],
        arch: &str,
    ) -> (Vec<u8>, PlanArtifact) {
        make_test_bundle_with_members(sk, kernel, rootfs, arch, Vec::new())
    }

    // Synthetic, locally signed admission fixtures, not released image or VM evidence.
    fn make_test_bundle_with_members(
        sk: &ed25519_dalek::SigningKey,
        kernel: &[u8],
        rootfs: &[u8],
        arch: &str,
        members: Vec<mvm_core::plan::bundle::BundleMember>,
    ) -> (Vec<u8>, PlanArtifact) {
        use mvm_core::plan::bundle::{
            ARTIFACTS_DIR, ArtifactRole, BUNDLE_SCHEMA_VERSION, BundleArtifact, BundleManifest,
            sha256_hex,
        };
        let key_id = key_id_from_pubkey(&sk.verifying_key());
        let make_art = |name: &str, role: ArtifactRole, bytes: &[u8]| BundleArtifact {
            name: name.to_string(),
            role,
            path: format!("{ARTIFACTS_DIR}/{name}"),
            sha256: sha256_hex(bytes),
            size_bytes: bytes.len() as u64,
        };
        let manifest = BundleManifest {
            schema_version: BUNDLE_SCHEMA_VERSION,
            publisher: "test".to_string(),
            key_id: key_id.clone(),
            arch: arch.to_string(),
            kernel_version: None,
            profile: None,
            workload_label: None,
            created_at: "2026-05-13T00:00:00Z".to_string(),
            labels: std::collections::BTreeMap::new(),
            artifacts: vec![
                make_art("vmlinux", ArtifactRole::Kernel, kernel),
                make_art("rootfs.ext4", ArtifactRole::Rootfs, rootfs),
            ],
            members,
            verity: None,
            resources: None,
        };
        let archive = write_bundle(
            &manifest,
            sk,
            vec![
                (format!("{ARTIFACTS_DIR}/vmlinux"), kernel.to_vec()),
                (format!("{ARTIFACTS_DIR}/rootfs.ext4"), rootfs.to_vec()),
            ],
        )
        .expect("write_bundle");

        // Recover the signature bytes from the archive for the pin.
        let mut sig_bytes: Vec<u8> = Vec::new();
        let mut a = tar::Archive::new(std::io::Cursor::new(&archive));
        for entry in a.entries().unwrap() {
            let mut entry = entry.unwrap();
            if entry.path().unwrap().to_string_lossy() == "manifest.sig" {
                std::io::Read::read_to_end(&mut entry, &mut sig_bytes).unwrap();
                break;
            }
        }
        let sig_arr: [u8; 64] = sig_bytes.as_slice().try_into().unwrap();
        let pin = PlanArtifact::new(bundle_sha256(&archive), &sig_arr, key_id);
        (archive, pin)
    }

    fn input_with_pin<'a>(vm_name: &'a str, pin: &PlanArtifact) -> SynthesisInput<'a> {
        let mut input = fixture_input(vm_name);
        input.bundle_pin = Some(pin.clone());
        input
    }

    #[test]
    fn direct_and_external_admission_refuse_unenforced_environment_requirements() {
        use mvm_core::plan::bundle::BundleMember;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = ed25519_dalek::SigningKey::from_bytes(&[37; 32]);
        let arch = mvm_core::arch::GuestArch::host().to_string();
        let fleet = ed25519_dalek::SigningKey::from_bytes(&[42; 32]);
        let mut config = mvm_core::user_config::load(None);
        config.trusted_plan_signers = vec![mvm_core::user_config::TrustedPlanSigner {
            signer_id: "requirements-fleet".into(),
            ed25519_pubkey_hex: hex::encode(fleet.verifying_key().as_bytes()),
        }];
        mvm_core::user_config::save(&config, None).unwrap();
        for (field, value, refused_field) in [
            (
                "entrypoint",
                serde_json::json!({"argv": ["/usr/bin/agent"], "working_dir": "/workspace"}),
                "entrypoint.working_dir",
            ),
            (
                "volumes",
                serde_json::json!([{"name": "workspace", "guest_path": "/workspace"}]),
                "volumes",
            ),
            (
                "services",
                serde_json::json!([{"name": "indexer", "argv": ["/usr/bin/indexer"]}]),
                "services",
            ),
        ] {
            let mut document = serde_json::json!({
                "descriptor_version": 1,
                "target": format!("{arch}-linux"),
                "entrypoint": { "argv": ["/usr/bin/agent"] },
            });
            document[field] = value;
            let mut members = vec![BundleMember::Environment(
                serde_json::from_value(document).unwrap(),
            )];
            if field == "volumes" {
                let BundleMember::Environment(environment) = &mut members[0] else {
                    panic!("environment fixture");
                };
                environment.capabilities =
                    vec![mvm_contract::plan::environment::EnvironmentCapability::HostVolumes];
                members.push(BundleMember::SecurityPosture(
                    mvm_core::plan::BundleSecurityPosture {
                        profile: mvm_core::security::AgentProfile::Dev,
                        verity_protected: false,
                        requires_auth: true,
                        allows_volumes: true,
                        allows_egress: false,
                    },
                ));
            }
            let (archive, pin) =
                make_test_bundle_with_members(&sk, b"kernel", b"rootfs", &arch, members);
            let trust = MapTrust(HashMap::from([(
                key_id_from_pubkey(&sk.verifying_key()),
                sk.verifying_key(),
            )]));
            let resolver = FixedResolver(archive);
            let ctx = BundleAdmissionContext {
                resolver: &resolver,
                trust: &trust,
                image: None,
            };
            let input = input_with_pin("vm-requirements", &pin);
            let error = admit_for_run(
                &input,
                &SystemClock,
                &InMemoryNonceLedger::new(),
                Some(dir.path()),
                Some(&ctx),
                RunPosture::without_backend(Variant::Dev),
            )
            .expect_err("self-synthesized plans must meet signed requirements");
            assert!(format!("{error:#}").contains(refused_field), "{error:#}");
            let signed = sign_plan(
                &synthesize_plan(&input).unwrap(),
                &fleet,
                "requirements-fleet",
            );
            let ledger = InMemoryNonceLedger::new();
            for _ in 0..2 {
                let error = admit_signed_plan_for_run(
                    &signed,
                    &SystemClock,
                    &ledger,
                    Some(&ctx),
                    RunPosture::without_backend(Variant::Dev),
                )
                .expect_err("external plans cannot bypass signed requirements");
                assert!(format!("{error:#}").contains(refused_field), "{error:#}");
            }
        }
    }

    #[test]
    fn signed_environment_policy_refuses_missing_or_wider_actual_runtime() {
        use mvm_core::network_policy::NetworkPolicy;
        use mvm_core::plan::bundle::BundleMember;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = ed25519_dalek::SigningKey::from_bytes(&[37; 32]);
        let arch = mvm_core::arch::GuestArch::host().to_string();
        let environment = serde_json::from_value(serde_json::json!({
            "descriptor_version": 1,
            "target": format!("{arch}-linux"),
            "entrypoint": { "argv": ["/usr/bin/agent"] },
            "policy": { "allow_hosts": ["api.anthropic.com:443"] }
        }))
        .unwrap();
        let (archive, pin) = make_test_bundle_with_members(
            &sk,
            b"kernel",
            b"rootfs",
            &arch,
            vec![BundleMember::Environment(environment)],
        );
        let trust = MapTrust(HashMap::from([(
            key_id_from_pubkey(&sk.verifying_key()),
            sk.verifying_key(),
        )]));
        let resolver = FixedResolver(archive);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let input = input_with_pin("vm-policy", &pin);
        let fleet = ed25519_dalek::SigningKey::from_bytes(&[42; 32]);
        let mut config = mvm_core::user_config::load(None);
        config.trusted_plan_signers = vec![mvm_core::user_config::TrustedPlanSigner {
            signer_id: "policy-fleet".into(),
            ed25519_pubkey_hex: hex::encode(fleet.verifying_key().as_bytes()),
        }];
        mvm_core::user_config::save(&config, None).unwrap();
        let signed = sign_plan(&synthesize_plan(&input).unwrap(), &fleet, "policy-fleet");
        let wider = VmStartConfig {
            network_policy: NetworkPolicy::unrestricted(),
            ..Default::default()
        };
        for runtime in [None, Some(&wider)] {
            let posture = RunPosture::without_backend(Variant::Dev).with_runtime(runtime);
            let error = admit_for_run(
                &input,
                &SystemClock,
                &InMemoryNonceLedger::new(),
                Some(dir.path()),
                Some(&ctx),
                posture,
            )
            .expect_err("signed policy requires an actual bounded runtime");
            assert!(
                error.downcast_ref::<BundleEnvironmentRefused>().is_some(),
                "{error:#}"
            );
            assert!(
                format!("{error:#}").contains("actual launch network"),
                "{error:#}"
            );
            let ledger = InMemoryNonceLedger::new();
            for _ in 0..2 {
                let error =
                    admit_signed_plan_for_run(&signed, &SystemClock, &ledger, Some(&ctx), posture)
                        .expect_err("external plans cannot bypass the runtime ceiling");
                assert!(
                    error.downcast_ref::<BundleEnvironmentRefused>().is_some(),
                    "{error:#}"
                );
                assert!(
                    !format!("{error:#}").contains("replay protection"),
                    "{error:#}"
                );
            }
        }
    }

    #[test]
    fn direct_host_admission_enforces_signed_environment_slots() {
        use mvm_core::plan::bundle::BundleMember;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = ed25519_dalek::SigningKey::from_bytes(&[37; 32]);
        let arch = mvm_core::arch::GuestArch::host().to_string();
        let environment = serde_json::from_value(serde_json::json!({
            "descriptor_version": 1,
            "target": format!("{arch}-linux"),
            "entrypoint": { "argv": ["/usr/bin/agent"] },
            "secret_slots": [
                { "name": "AGENT_TOKEN", "required": true },
                { "name": "OPTIONAL_KEY", "required": false }
            ]
        }))
        .unwrap();
        let (archive, pin) = make_test_bundle_with_members(
            &sk,
            b"kernel",
            b"rootfs",
            &arch,
            vec![BundleMember::Environment(environment)],
        );
        let trust = MapTrust(HashMap::from([(
            key_id_from_pubkey(&sk.verifying_key()),
            sk.verifying_key(),
        )]));
        let resolver = FixedResolver(archive);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let mut input = input_with_pin("vm-environment", &pin);
        let error = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("direct host admission must refuse missing mandatory slot");
        assert!(format!("{error:#}").contains("AGENT_TOKEN"), "{error:#}");
        input.secrets = vec![mvm_core::plan::SecretBinding {
            name: "AGENT_TOKEN".into(),
            source: mvm_core::plan::SecretSource::Keystore {
                address: "agent-token".into(),
            },
            destinations: Vec::new(),
            approval_required: false,
        }];
        let admitted = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("bound required slot admits without binding optional slot");
        assert_eq!(admitted.plan().secrets.len(), 1);

        // Exercise the independently authenticated external-plan entry point,
        // not just the host's synthesis/signing wrapper.
        let fleet = ed25519_dalek::SigningKey::from_bytes(&[42; 32]);
        let mut config = mvm_core::user_config::load(None);
        config.trusted_plan_signers = vec![mvm_core::user_config::TrustedPlanSigner {
            signer_id: "environment-fleet".into(),
            ed25519_pubkey_hex: hex::encode(fleet.verifying_key().as_bytes()),
        }];
        mvm_core::user_config::save(&config, None).unwrap();
        let bound = sign_plan(admitted.plan(), &fleet, "environment-fleet");
        admit_signed_plan_for_run(
            &bound,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("externally signed bound required slot admits");
        input.secrets.clear();
        let missing = synthesize_plan(&input).unwrap();
        let signed = sign_plan(&missing, &fleet, "environment-fleet");
        let ledger = InMemoryNonceLedger::new();
        let error = admit_signed_plan_for_run(
            &signed,
            &SystemClock,
            &ledger,
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("externally signed plan must also bind mandatory slot");
        assert!(format!("{error:#}").contains("AGENT_TOKEN"), "{error:#}");
        let retry = admit_signed_plan_for_run(
            &signed,
            &SystemClock,
            &ledger,
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("a rejected descriptor must not spend the nonce");
        assert!(format!("{retry:#}").contains("AGENT_TOKEN"), "{retry:#}");
        assert!(
            !format!("{retry:#}").contains("replay protection"),
            "{retry:#}"
        );
    }

    #[test]
    fn admit_with_clean_pinned_bundle_passes() {
        // Generate the publisher key out of band, build a bundle,
        // enrol the pubkey in the trust store, hand admit_for_run a
        // matching pin + context.
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = {
            let mut __ed_seed = [0u8; 32];
            rand::rng().fill_bytes(&mut __ed_seed);
            ed25519_dalek::SigningKey::from_bytes(&__ed_seed)
        };
        let (archive, pin) = make_test_bundle(&sk, b"kernel-bytes", b"rootfs-bytes");
        let mut map = HashMap::new();
        let key_id = key_id_from_pubkey(&sk.verifying_key());
        map.insert(key_id, sk.verifying_key());
        let trust = MapTrust(map);
        let resolver = FixedResolver(archive);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let admitted = admit_for_run(
            &input_with_pin("vm-pinned", &pin),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("clean pin admits");
        assert!(admitted.plan().bundle.is_some());
    }

    #[test]
    fn admit_with_pin_but_no_context_refuses() {
        // Publisher misconfiguration: plan carries a pin but the
        // boot path didn't wire a BundleAdmissionContext. The
        // admit path refuses rather than silently skipping the
        // re-verify step (fail closed, not fail open).
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = {
            let mut __ed_seed = [0u8; 32];
            rand::rng().fill_bytes(&mut __ed_seed);
            ed25519_dalek::SigningKey::from_bytes(&__ed_seed)
        };
        let (_archive, pin) = make_test_bundle(&sk, b"k", b"r");
        let err = admit_for_run(
            &input_with_pin("vm-no-ctx", &pin),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("must refuse without context");
        let msg = format!("{err:#}");
        assert!(msg.contains("BundleAdmissionContext"), "got: {msg}");
    }

    /// A pinned bundle built for the other architecture is refused at the trust
    /// boundary, before any backend sees it. Without this the plan admits and
    /// fails deep in boot with an unrelated-looking kernel error.
    #[test]
    fn admit_with_cross_arch_pinned_bundle_refuses() {
        let other = match mvm_core::arch::GuestArch::host() {
            mvm_core::arch::GuestArch::X86_64 => "aarch64",
            mvm_core::arch::GuestArch::Aarch64 => "x86_64",
        };
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = {
            let mut __ed_seed = [0u8; 32];
            rand::rng().fill_bytes(&mut __ed_seed);
            ed25519_dalek::SigningKey::from_bytes(&__ed_seed)
        };
        let (archive, pin) =
            make_test_bundle_for_arch(&sk, b"kernel-bytes", b"rootfs-bytes", other);
        let mut map = HashMap::new();
        map.insert(key_id_from_pubkey(&sk.verifying_key()), sk.verifying_key());
        let trust = MapTrust(map);
        let resolver = FixedResolver(archive);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let err = admit_for_run(
            &input_with_pin("vm-cross-arch", &pin),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("a foreign-arch bundle must not be admitted");
        let msg = format!("{err:#}");
        assert!(msg.contains("but this host is"), "{msg}");
        assert!(msg.contains(other), "{msg}");
    }

    #[test]
    fn admit_with_unknown_publisher_in_trust_store_refuses() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = {
            let mut __ed_seed = [0u8; 32];
            rand::rng().fill_bytes(&mut __ed_seed);
            ed25519_dalek::SigningKey::from_bytes(&__ed_seed)
        };
        let (archive, pin) = make_test_bundle(&sk, b"k", b"r");
        // Empty trust store — publisher's key_id is unknown locally.
        let trust = MapTrust(HashMap::new());
        let resolver = FixedResolver(archive);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let err = admit_for_run(
            &input_with_pin("vm-untrusted", &pin),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("must refuse unknown publisher");
        let msg = format!("{err:#}");
        // The error chain bubbles up the BundleVerifyError::UnknownKey
        // variant from the read_and_verify pass.
        assert!(
            err.chain().any(|e| e.to_string().contains("key_id")),
            "expected key_id mention; got: {msg}"
        );
    }

    #[test]
    fn admit_with_pin_mismatching_archive_refuses() {
        // Resolver returns a different archive than the pin describes.
        // The bundle_sha256 cross-check catches it before the
        // signature verify even runs.
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let sk = {
            let mut __ed_seed = [0u8; 32];
            rand::rng().fill_bytes(&mut __ed_seed);
            ed25519_dalek::SigningKey::from_bytes(&__ed_seed)
        };
        let (_archive_a, pin_a) = make_test_bundle(&sk, b"kA", b"rA");
        let (archive_b, _pin_b) = make_test_bundle(&sk, b"kB", b"rB");
        let mut map = HashMap::new();
        map.insert(key_id_from_pubkey(&sk.verifying_key()), sk.verifying_key());
        let trust = MapTrust(map);
        let resolver = FixedResolver(archive_b);
        let ctx = BundleAdmissionContext {
            resolver: &resolver,
            trust: &trust,
            image: None,
        };
        let err = admit_for_run(
            &input_with_pin("vm-pin-drift", &pin_a),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            Some(&ctx),
            RunPosture::without_backend(Variant::Dev),
        )
        .expect_err("must refuse pin drift");
        assert!(
            err.chain().any(|e| e.to_string().contains("sha256")),
            "expected sha256 mismatch chain; got {err:#}"
        );
    }

    #[test]
    fn thread_tenant_id_sets_only_tenant_label_not_the_bridge_plan() {
        use mvm_core::vm_backend::VmStartConfig;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let admitted = admit_for_run(
            &fixture_input("vm-tenant-only"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy admit");

        let mut cfg = VmStartConfig::default();
        thread_tenant_id(&mut cfg, &admitted);

        // The broker spawn keys off this label.
        assert_eq!(
            cfg.tenant_id.as_deref(),
            Some(admitted.plan().tenant.0.as_str())
        );
        // It must NOT thread the signed plan / policy bundle — that flips
        // libkrun/HVF onto the gateway-bridge supervisor (+ its ~/.mvm/keys
        // substrate validation), which is a separate opt-in concern.
        assert!(
            cfg.plan_json.is_none(),
            "thread_tenant_id must not set plan_json"
        );
        assert!(
            cfg.bundle_json.is_none(),
            "thread_tenant_id must not set bundle_json"
        );
    }

    #[test]
    fn populate_audit_substrate_threads_tenant_and_signed_envelope() {
        use mvm_core::vm_backend::VmStartConfig;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let clock = SystemClock;
        let ledger = InMemoryNonceLedger::new();
        let admitted = admit_for_run(
            &fixture_input("vm-substrate"),
            &clock,
            &ledger,
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy admit");

        let mut cfg = VmStartConfig::default();
        populate_audit_substrate(&mut cfg, &admitted, None).expect("populate");
        assert_eq!(
            cfg.tenant_id.as_deref(),
            Some(admitted.plan().tenant.0.as_str())
        );
        let plan_json = cfg.plan_json.expect("plan_json populated");
        let roundtrip: mvm_core::plan::SignedExecutionPlan =
            serde_json::from_str(&plan_json).expect("roundtrip");
        // Re-verify the envelope to get the inner ExecutionPlan and
        // confirm the plan_id matches what the producer admitted.
        let signer = crate::audit::host_keypair::load_or_init_at(dir.path()).unwrap();
        let trusted: [(&str, &ed25519_dalek::VerifyingKey); 1] =
            [(admitted.signer_id(), &signer.verifying)];
        let recovered =
            mvm_core::plan::verify_plan(&roundtrip, &trusted).expect("envelope re-verifies");
        assert_eq!(&recovered.plan_id, admitted.plan_id());
        // fixture has no bundle pin, so bundle_json stays None
        assert!(cfg.bundle_json.is_none());
    }

    #[test]
    fn bundle_json_carries_a_policy_bundle_not_the_artifact_pin() {
        // De-conflation: bundle_json is the tenant PolicyBundle the
        // supervisor's L4 gate + observers consume — sourced from the
        // policy_bundle arg, NOT from `admitted.plan().bundle` (the .mvmpkg
        // PlanArtifact pin, a different bundle verified separately).
        use mvm_core::vm_backend::VmStartConfig;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let clock = SystemClock;
        let ledger = InMemoryNonceLedger::new();
        let admitted = admit_for_run(
            &fixture_input("vm-policy-bundle"),
            &clock,
            &ledger,
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy admit");

        let bundle = mvm_core::policy::PolicyBundle {
            schema_version: mvm_core::policy::SCHEMA_VERSION,
            bundle_id: mvm_core::policy::PolicyId("test".into()),
            bundle_version: 1,
            network: Default::default(),
            egress: Default::default(),
            pii: Default::default(),
            artifact: Default::default(),
            keys: Default::default(),
            audit: Default::default(),
            wasi: Default::default(),
            tenant_overlays: std::collections::BTreeMap::new(),
        };

        let mut cfg = VmStartConfig::default();
        populate_audit_substrate(&mut cfg, &admitted, Some(&bundle)).expect("populate");
        let bj = cfg.bundle_json.expect("bundle_json populated");
        let roundtrip: mvm_core::policy::PolicyBundle =
            serde_json::from_str(&bj).expect("bundle_json deserializes as a PolicyBundle");
        assert_eq!(roundtrip, bundle);

        // No policy bundle → None (the de-conflated default; a pinned artifact
        // no longer leaks into this field).
        let mut cfg2 = VmStartConfig::default();
        populate_audit_substrate(&mut cfg2, &admitted, None).expect("populate none");
        assert!(cfg2.bundle_json.is_none());
    }

    // ───────────────────────────────────────────────────────────────
    // write_secret_file + stash_plan_for_bridge
    // ───────────────────────────────────────────────────────────────

    #[test]
    #[cfg(unix)]
    fn write_secret_file_creates_mode_0600() {
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("plan.json");
        write_secret_file(&path, b"{\"hello\":\"world\"}").expect("write");
        let meta = std::fs::metadata(&path).expect("stat");
        let mode = meta.permissions().mode() & 0o777;
        assert_eq!(mode, 0o600, "secret file must be mode 0600 (got {mode:o})");
        let body = std::fs::read(&path).expect("read");
        assert_eq!(body, b"{\"hello\":\"world\"}");
    }

    #[test]
    #[cfg(unix)]
    fn write_secret_file_atomic_via_rename() {
        // Two consecutive writes; the second must fully replace the
        // first and leave no `*.json.tmp` artifact behind. This proves
        // the tmp-and-rename happy path doesn't leak partial files.
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("plan.json");
        write_secret_file(&path, b"first body").expect("first write");
        write_secret_file(&path, b"second body wins").expect("second write");
        assert_eq!(std::fs::read(&path).unwrap(), b"second body wins");
        // The tmp file path is `plan.json.tmp`; it must not exist after
        // a clean write.
        assert!(
            !dir.path().join("plan.json.tmp").exists(),
            "tmp file should be renamed away"
        );
    }

    #[test]
    #[cfg(unix)]
    fn write_secret_file_never_writes_through_a_planted_link() {
        let dir = tempfile::tempdir().expect("tempdir");
        let outside = dir.path().join("outside");
        std::fs::write(&outside, b"untouched").unwrap();
        let path = dir.path().join("plan.json");
        // A link at the old fixed temporary name and one at the destination:
        // neither may carry the write to the file they point at.
        std::os::unix::fs::symlink(&outside, path.with_extension("json.tmp")).unwrap();
        write_secret_file(&path, b"first").expect("write past a planted temporary");
        assert_eq!(std::fs::read(&outside).unwrap(), b"untouched");
        assert_eq!(std::fs::read(&path).unwrap(), b"first");

        std::fs::remove_file(&path).unwrap();
        std::os::unix::fs::symlink(&outside, &path).unwrap();
        write_secret_file(&path, b"second").expect("write over a planted destination");
        assert_eq!(std::fs::read(&outside).unwrap(), b"untouched");
        assert!(
            !std::fs::symlink_metadata(&path)
                .unwrap()
                .file_type()
                .is_symlink()
        );
        assert_eq!(std::fs::read(&path).unwrap(), b"second");
    }

    #[test]
    #[cfg(unix)]
    fn write_secret_file_creates_parent_dir() {
        // The bridge writes under `~/.mvm/vms/<vm>/`; that dir may not
        // exist on a first boot. The helper must create it (matching
        // the `stash_plan_for_bridge` callsite's invariant).
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("vms").join("foo").join("plan.json");
        write_secret_file(&path, b"body").expect("write with missing parent");
        assert!(path.exists());
    }

    #[test]
    fn stash_plan_for_bridge_skips_when_plan_json_none() {
        use mvm_core::vm_backend::VmStartConfig;
        // Legacy / no-admission path: cfg.plan_json is None.
        // `stash_plan_for_bridge` must succeed without touching disk
        // because there's nothing to stash.
        let dir = tempfile::tempdir().unwrap();
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.set("MVM_HOME", dir.path());

        let cfg = VmStartConfig {
            name: "skip-me".into(),
            ..Default::default()
        };
        stash_plan_for_bridge(&cfg).expect("None plan_json is a no-op");
        assert!(
            !dir.path().join("vms/skip-me/plan.json").exists(),
            "no files when plan_json is None"
        );
    }

    #[test]
    #[cfg(unix)]
    fn stash_plan_for_bridge_writes_both_files_when_present() {
        use mvm_core::vm_backend::VmStartConfig;
        use std::os::unix::fs::PermissionsExt;
        let dir = tempfile::tempdir().unwrap();
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.set("MVM_HOME", dir.path());

        let cfg = VmStartConfig {
            name: "with-plan".into(),
            plan_json: Some("{\"plan\":\"body\"}".into()),
            bundle_json: Some("{\"bundle\":\"pin\"}".into()),
            ..Default::default()
        };
        stash_plan_for_bridge(&cfg).expect("stash succeeds");

        let plan_path = dir.path().join("vms/with-plan/plan.json");
        let bundle_path = dir.path().join("vms/with-plan/bundle.json");
        assert!(plan_path.exists(), "plan.json must be written");
        assert!(bundle_path.exists(), "bundle.json must be written");
        assert_eq!(
            std::fs::metadata(&plan_path).unwrap().permissions().mode() & 0o777,
            0o600,
            "plan.json must be mode 0600"
        );
        assert_eq!(
            std::fs::metadata(&bundle_path)
                .unwrap()
                .permissions()
                .mode()
                & 0o777,
            0o600,
            "bundle.json must be mode 0600"
        );
    }

    #[test]
    fn caller_audit_labels_flow_through_admission() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let mut input = fixture_input("vm-label");
        input.audit_labels.insert(
            "origin.descriptor".to_string(),
            "blake3:testvalue".to_string(),
        );
        let admitted = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("happy path");
        assert_eq!(
            admitted.plan().audit_labels["origin.descriptor"],
            "blake3:testvalue"
        );
        // Profile-derived keys must still be present and authoritative.
        assert!(!admitted.plan().audit_labels["intent"].is_empty());
        assert!(!admitted.plan().audit_labels["admission_profile"].is_empty());
        assert_eq!(admitted.plan().audit_labels["seccomp_tier"], "standard");
    }

    // ───────────────────────────────────────────────────────────────
    // verb-grant sidecar: stash_plan_for_bridge mint path
    // ───────────────────────────────────────────────────────────────

    #[test]
    #[cfg(unix)]
    fn stash_plan_for_bridge_writes_verb_grant_when_agent_verbs_present() {
        use ed25519_dalek::VerifyingKey;
        use mvm_core::plan::VerbId;
        use mvm_core::protocol::vm_backend::VerbGrantEnvelope;
        use mvm_core::vm_backend::VmStartConfig;
        use std::os::unix::fs::PermissionsExt;

        let dir = tempfile::tempdir().unwrap();
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.set("MVM_HOME", dir.path());
        let keys_dir = mvm_core::config::mvm_keys_dir();

        // Build an admitted plan that carries agent_verbs.
        let mut input = fixture_input("vm-verb-grant");
        input.agent_verbs = Some(vec![VerbId::new("run-entrypoint").unwrap()]);
        let admitted = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys_dir.as_path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit with agent_verbs");

        let mut cfg = VmStartConfig {
            name: "vm-verb-grant".into(),
            ..Default::default()
        };
        populate_audit_substrate(&mut cfg, &admitted, None).expect("populate");
        let issued = stash_plan_and_mint_verb_grant(&cfg)
            .expect("stash succeeds")
            .expect("agent verbs mint a grant");

        let grant_path = dir.path().join("vms/vm-verb-grant/verb-grant.json");
        assert!(grant_path.exists(), "verb-grant.json must be written");
        let mode = std::fs::metadata(&grant_path).unwrap().permissions().mode() & 0o777;
        assert_eq!(mode, 0o600, "verb-grant.json must be mode 0600");

        // Parse the envelope and verify the grant under the signer key.
        let raw = std::fs::read(&grant_path).unwrap();
        let envelope: VerbGrantEnvelope = serde_json::from_slice(&raw).unwrap();
        assert_eq!(
            serde_json::to_vec(&issued).unwrap(),
            serde_json::to_vec(&envelope).unwrap(),
            "the returned envelope is exactly the sidecar payload"
        );
        assert!(!envelope.pubkey_hex.is_empty(), "pubkey_hex must be set");
        assert_eq!(
            envelope.plan_nonce_hex,
            admitted.plan().nonce.as_hex(),
            "nonce hex must match plan"
        );
        assert_eq!(
            envelope.grant.not_after,
            admitted.plan().valid_until,
            "a verb grant must not outlive its admitted plan"
        );
        let pub_arr: [u8; 32] = hex::decode(&envelope.pubkey_hex)
            .unwrap()
            .try_into()
            .unwrap();
        let vk = VerifyingKey::from_bytes(&pub_arr).unwrap();
        envelope
            .grant
            .verify(
                &vk,
                "vm-verb-grant",
                &admitted.plan().nonce,
                SystemClock.now(),
            )
            .expect("grant must verify under the signer key");
    }

    #[test]
    fn stash_plan_for_bridge_no_verb_grant_when_agent_verbs_absent() {
        use mvm_core::vm_backend::VmStartConfig;

        let dir = tempfile::tempdir().unwrap();
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.set("MVM_HOME", dir.path());
        let keys_dir = mvm_core::config::mvm_keys_dir();

        // Plain plan with no agent_verbs — the fixture default.
        let admitted = admit_for_run(
            &fixture_input("vm-no-verbs"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys_dir.as_path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit without agent_verbs");

        let mut cfg = VmStartConfig {
            name: "vm-no-verbs".into(),
            ..Default::default()
        };
        populate_audit_substrate(&mut cfg, &admitted, None).expect("populate");
        stash_plan_for_bridge(&cfg).expect("stash succeeds");

        assert!(
            !dir.path().join("vms/vm-no-verbs/verb-grant.json").exists(),
            "verb-grant.json must NOT be written when agent_verbs is None"
        );
    }

    #[test]
    #[cfg(unix)]
    fn stash_plan_for_bridge_removes_stale_verb_grant_on_grant_less_restash() {
        use mvm_core::plan::VerbId;
        use mvm_core::vm_backend::VmStartConfig;

        let dir = tempfile::tempdir().unwrap();
        let mut env = mvm_core::util::test_env::TestEnv::new();
        env.set("MVM_HOME", dir.path());
        let keys_dir = mvm_core::config::mvm_keys_dir();

        let vm_name = "vm-stale-grant";

        // First boot: plan with agent_verbs — sidecar must be written.
        let mut input_with = fixture_input(vm_name);
        input_with.agent_verbs = Some(vec![VerbId::new("run-entrypoint").unwrap()]);
        let admitted_with = admit_for_run(
            &input_with,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys_dir.as_path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit with agent_verbs");
        let mut cfg_with = VmStartConfig {
            name: vm_name.into(),
            ..Default::default()
        };
        populate_audit_substrate(&mut cfg_with, &admitted_with, None).expect("populate");
        stash_plan_for_bridge(&cfg_with).expect("first stash succeeds");

        let grant_path = dir.path().join(format!("vms/{vm_name}/verb-grant.json"));
        assert!(
            grant_path.exists(),
            "verb-grant.json must be present after first stash"
        );

        // Second boot: same VM name, no agent_verbs — stale sidecar must be removed.
        let admitted_without = admit_for_run(
            &fixture_input(vm_name),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(keys_dir.as_path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit without agent_verbs");
        let mut cfg_without = VmStartConfig {
            name: vm_name.into(),
            ..Default::default()
        };
        populate_audit_substrate(&mut cfg_without, &admitted_without, None).expect("populate");
        stash_plan_for_bridge(&cfg_without).expect("second stash succeeds");

        assert!(
            !grant_path.exists(),
            "stale verb-grant.json must be removed on a grant-less re-stash of the same VM name"
        );
    }

    // ───────────────────────────────────────────────────────────────
    // admit_and_start: the shared admitted-boot entrypoint
    // ───────────────────────────────────────────────────────────────

    fn baked_assurance_config(directory: &std::path::Path) -> VmStartConfig {
        mvm_runtime::signed_legacy_runtime_fixture(
            directory,
            std::path::Path::new(&mvm_core::config::mvm_home()),
            false,
        )
    }

    #[test]
    fn an_unsigned_release_proof_cannot_mint_an_assurance_binding() {
        let directory = tempfile::tempdir().unwrap();
        let archive = directory.path().join("runtime.tar.gz");
        let checksum = directory.path().join("runtime.tar.gz.sha256");
        let signature = directory.path().join("runtime.tar.gz.bundle");
        std::fs::write(&archive, b"unsigned archive").unwrap();
        let digest = mvm_core::crypto::image_verify::sha256_file(&archive).unwrap();
        std::fs::write(&checksum, format!("{digest}  runtime.tar.gz\n")).unwrap();
        std::fs::write(&signature, b"{}").unwrap();
        let config = VmStartConfig {
            runtime_release_proof: Some(mvm_core::protocol::runtime_release::RuntimeReleaseProof {
                archive,
                checksum,
                signature_bundle: signature,
                archive_sha256: digest,
                version: "1.2.3".into(),
                arch: mvm_core::arch::GuestArch::host(),
            }),
            runtime_overlay_version: Some("1.2.3".into()),
            runtime_overlay_path: Some(directory.path().join("overlay").display().to_string()),
            runtime_overlay_verity_path: Some(
                directory.path().join("verity").display().to_string(),
            ),
            runtime_overlay_roothash: Some("a".repeat(64)),
            initrd_path: Some(directory.path().join("initramfs").display().to_string()),
            ..Default::default()
        };
        assert!(AssuranceRuntimeBinding::verify(&config, &plan_binding(&[]), None).is_err());
    }

    #[test]
    fn dispatch_without_verified_owner_refuses_signed_runtime_identity_before_effects() {
        let (_env, _home) = host_with_ceiling(Default::default());
        for has_release_identity in [false, true] {
            let directory = tempfile::tempdir().unwrap();
            let audit = tempfile::tempdir().unwrap();
            let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
            let config = VmStartConfig {
                name: format!("dispatch-runtime-{has_release_identity}"),
                rootfs_path: directory.path().join("rootfs").display().to_string(),
                ..Default::default()
            };
            std::fs::write(&config.rootfs_path, b"dispatch fixture").unwrap();
            let digest = mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(
                &config.rootfs_path,
            ))
            .unwrap();
            let mut input = fixture_input(&config.name);
            input.image_sha256 = &digest;
            let mut plan = synthesize_plan(&input).unwrap();
            if has_release_identity {
                plan.runtime_identity = Some(runtime_identity_fixture());
            }
            plan.plan_id = mvm_core::plan::compute_plan_id(&plan);
            let key = ed25519_dalek::SigningKey::from_bytes(&[7; 32]);
            let signed = sign_plan(&plan, &key, "host:test");
            // Isolate dispatch with a signed admitted snapshot. This fixture
            // supplies no verified runtime and claims no release authentication.
            let admitted = AdmittedPlan::for_test(plan, "host:test".into(), signed);
            let emitter = crate::audit::emitter::AuditEmitter::with_dir(
                ed25519_dalek::SigningKey::from_bytes(&[41; 32]),
                audit.path(),
            )
            .unwrap();
            crate::audit::durability::record_admission(
                Some(&emitter),
                admitted.plan(),
                admitted.signer_id(),
                crate::audit::durability::AuditDurability::BestEffort,
            )
            .unwrap();
            let vm_id = mvm_core::vm_backend::VmId(config.name.clone());
            let state_dir = mvm_core::config::vm_state_dir(&config.name);
            let result = start_admitted(StartAdmittedParams {
                backend: &backend,
                admitted,
                config,
                policy_bundle: None,
                emitter: Some(&emitter),
                assurance: None,
            });
            if !has_release_identity {
                result.expect("ordinary no-release dispatch remains admitted");
                assert!(matches!(
                    backend.status(&vm_id),
                    Ok(mvm_core::vm_backend::VmStatus::Running)
                ));
                continue;
            }
            let error = result.expect_err(
                "a signed runtime identity needs its original verified owner at dispatch",
            );
            assert!(
                format!("{error:#}").contains("no verified launch evidence"),
                "{error:#}"
            );
            assert!(!matches!(
                backend.status(&vm_id),
                Ok(mvm_core::vm_backend::VmStatus::Running)
            ));
            assert!(
                !state_dir.exists(),
                "refusal precedes backend state effects"
            );
            let chain = std::fs::read_to_string(audit.path().join("local.jsonl")).unwrap();
            assert!(
                chain.contains("plan.failed") && chain.contains("guest-runtime"),
                "{chain}"
            );
            assert!(!chain.contains("plan.launched"), "{chain}");
        }
    }

    #[test]
    fn changed_runtime_after_admission_records_failure_without_starting_backend() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let directory = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let config = VmStartConfig {
            name: "changed-assurance-runtime".into(),
            ..baked_assurance_config(directory.path())
        };
        let image_sha256 =
            mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(&config.rootfs_path))
                .unwrap();
        let mut synthesis = fixture_input(&config.name);
        synthesis.image_sha256 = &image_sha256;
        synthesis
            .services
            .push(mvm_core::protocol::broker::ServiceId::parse("host.assurance.v1").unwrap());
        let admitted = admit_for_run(
            &synthesis,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(directory.path()),
            None,
            RunPosture::on_backend(Variant::Dev, backend.kind()).with_runtime(Some(&config)),
        )
        .unwrap();
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&[41; 32]),
            audit.path(),
        )
        .unwrap();
        crate::audit::durability::record_admission(
            Some(&emitter),
            admitted.plan(),
            admitted.signer_id(),
            crate::audit::durability::AuditDurability::BestEffort,
        )
        .unwrap();
        std::fs::write(&config.rootfs_path, b"changed after admission").unwrap();
        let vm_id = mvm_core::vm_backend::VmId(config.name.clone());
        start_admitted(StartAdmittedParams {
            backend: &backend,
            admitted,
            config,
            policy_bundle: None,
            emitter: Some(&emitter),
            assurance: None,
        })
        .expect_err("admitted artifact substitution must refuse before spawn");
        assert!(!matches!(
            backend.status(&vm_id),
            Ok(mvm_core::vm_backend::VmStatus::Running)
        ));
        let chain = std::fs::read_to_string(audit.path().join("local.jsonl")).unwrap();
        assert!(chain.contains("plan.admitted"), "{chain}");
        assert!(chain.contains("plan.failed"), "{chain}");
        assert!(chain.contains("assurance-runtime"), "{chain}");
        assert!(!chain.contains("plan.launched"), "{chain}");
    }

    #[test]
    fn assurance_binding_requires_matching_image_and_unchanged_launch_bytes() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let directory = tempfile::tempdir().unwrap();
        let kernel = directory.path().join("kernel");
        std::fs::write(&kernel, b"original kernel").unwrap();
        let config = VmStartConfig {
            name: "assurance-bound".into(),
            kernel_path: Some(kernel.display().to_string()),
            ..baked_assurance_config(directory.path())
        };
        let mut plan = plan_binding(&[]);
        assert!(AssuranceRuntimeBinding::verify(&config, &plan, None).is_err());
        plan.image.sha256 =
            mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(&config.rootfs_path))
                .unwrap();
        let signer_id = "host:test".to_string();
        let signed = sign_plan(
            &plan,
            &ed25519_dalek::SigningKey::from_bytes(&[7; 32]),
            &signer_id,
        );
        let unchecked = AdmittedPlan::for_test(plan, signer_id, signed);
        assert!(unchecked.require_assurance_runtime(&config.name).is_err());
        let admitted = unchecked.with_assurance_runtime_for_test(&config);
        admitted.require_assurance_runtime(&config.name).unwrap();
        assert!(
            admitted
                .require_assurance_runtime("different-machine")
                .is_err()
        );
        admitted.verify_assurance_launch(&config, None).unwrap();

        let renamed = VmStartConfig {
            name: "different-machine".into(),
            ..config.clone()
        };
        assert!(admitted.verify_assurance_launch(&renamed, None).is_err());
        std::fs::write(&kernel, b"replacement kernel").unwrap();
        assert!(admitted.verify_assurance_launch(&config, None).is_err());
        std::fs::write(&config.rootfs_path, b"replacement rootfs").unwrap();
        assert!(AssuranceRuntimeBinding::verify(&config, admitted.plan(), None).is_err());
    }

    #[test]
    fn portable_assurance_capability_binds_original_proof_and_manifest_after_admission() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let directory = tempfile::tempdir().unwrap();
        let config = mvm_runtime::signed_legacy_portable_runtime_fixture(directory.path());
        let mut plan = plan_binding(&[]);
        plan.image.sha256 =
            mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(&config.rootfs_path))
                .unwrap();
        let signer_id = "host:test".to_string();
        let signed = sign_plan(
            &plan,
            &ed25519_dalek::SigningKey::from_bytes(&[7; 32]),
            &signer_id,
        );
        let admitted = AdmittedPlan::for_test(plan, signer_id, signed)
            .with_assurance_runtime_for_test(&config);
        admitted.verify_assurance_launch(&config, None).unwrap();
        for mutation in 0..3 {
            let mut changed = config.clone();
            let proof = changed.legacy_portable_runtime.as_mut().unwrap();
            match mutation {
                0 => proof.pin.bundle_sha256 = "0".repeat(64),
                1 => proof.manifest_sha256 = "0".repeat(64),
                2 => {
                    let copy = directory.path().join("same-signed-archive.mvmpkg");
                    std::fs::copy(&proof.archive, &copy).unwrap();
                    proof.archive = copy;
                    // An independently valid proof at another location still
                    // changes the selection this capability admitted.
                    AssuranceRuntimeBinding::verify(&changed, admitted.plan(), None).unwrap();
                }
                _ => unreachable!(),
            }
            assert!(
                admitted.verify_assurance_launch(&changed, None).is_err(),
                "mutation {mutation}"
            );
        }
    }

    #[test]
    fn admit_and_start_admits_then_boots_on_mock() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-boot".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let started = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-boot"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect("admit + boot");

        // Admission ran (claim 8): a signed plan id under the host signer.
        assert!(!started.admitted.plan_id().0.is_empty());
        assert!(started.admitted.signer_id().starts_with("host:"));
        // The backend actually started the VM and reports it running.
        assert_eq!(started.vm_id.0, "vm-boot");
        assert!(matches!(
            backend.status(&started.vm_id).unwrap(),
            mvm_core::vm_backend::VmStatus::Running
        ));
    }

    #[test]
    fn one_signed_admission_cannot_start_a_second_backend() {
        // `start_admitted` hands the admitted plan back on `StartedMachine`.
        // Nothing may turn that into a second launch under the same admission.
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let first = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let second = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let config = VmStartConfig {
            name: "single-use-admission".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let admitted = admit_for_run(
            &fixture_input(&config.name),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::on_backend(Variant::Dev, first.kind()),
        )
        .unwrap();
        let started = start_admitted(StartAdmittedParams {
            backend: &first,
            admitted,
            config: config.clone(),
            policy_bundle: None,
            emitter: None,
            assurance: None,
        })
        .expect("the original admission starts the first backend");

        // A different backend instance, so a duplicate-name refusal cannot
        // mask a second dispatch under the original admission.
        let error = start_admitted(StartAdmittedParams {
            backend: &second,
            admitted: started.admitted,
            config,
            policy_bundle: None,
            emitter: None,
            assurance: None,
        })
        .expect_err("a spent admission must refuse a second dispatch");
        assert!(
            error.to_string().contains("already dispatched"),
            "{error:#}"
        );
        assert!(!matches!(
            second.status(&started.vm_id),
            Ok(mvm_core::vm_backend::VmStatus::Running)
        ));
    }

    #[test]
    fn a_campaign_that_cannot_open_rolls_the_launch_back() {
        // The session opens *after* the backend start, so a failure there used
        // to return with the workload still running.
        //
        // The campaign declares no destination, which `open` refuses whether or
        // not a plane happens to be installed. Asserting on the absence of the
        // process-global plane instead would make this test depend on run
        // order — a `OnceLock` admits one value and the neighbouring test
        // installs it, so it would pass under nextest and flake under
        // `cargo test`.
        use std::sync::Arc;

        use mvm_contract::assurance::{
            ApprovalSet, AssuranceId, ObservationScope, RequestedAuthority, Sha256Digest, ToolId,
        };

        use crate::assurance_session::{
            CampaignDeclaration, CampaignRequest, default_policy_ceiling,
        };

        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let emitter = Arc::new(
            crate::audit::emitter::AuditEmitter::with_dir(
                ed25519_dalek::SigningKey::from_bytes(&[41u8; 32]),
                audit.path(),
            )
            .expect("emitter"),
        );
        let id = |raw: &str| AssuranceId::parse(raw).expect("identifier");
        let declaration = CampaignDeclaration {
            request_id: id("mvm-request-rollback"),
            idempotency_key: id("trial-retry-rollback"),
            campaign_id: id("mvm-campaign-9"),
            trial_id: id("trial-9"),
            source_run_id: id("scout-9"),
            source_digest: Sha256Digest::parse(format!("sha256:{}", "5".repeat(64)))
                .expect("digest"),
            artifact_digest: Sha256Digest::parse(format!("sha256:{}", "6".repeat(64)))
                .expect("artifact digest"),
            edges: Vec::new(),
            approvals: ApprovalSet::none().with(ToolId::CampaignProbeV1),
            requested: RequestedAuthority {
                allowed_tools: vec![ToolId::CampaignProbeV1],
                observation_scopes: vec![ObservationScope::HostAuditRefs],
                max_steps: 4,
                max_output_bytes: 4096,
                deadline_unix_ms: 0,
            },
            grant_ttl_ms: 600_000,
        };
        let campaign = CampaignRequest {
            declaration,
            emitter: Arc::clone(&emitter),
            policy_ceiling: default_policy_ceiling(),
            policy: mvm_core::policy::network_policy::NetworkPolicy::deny_all(),
            backend: "mock".to_string(),
            now_unix_ms: 1_800_000_000_000,
        };

        let service =
            mvm_core::protocol::broker::ServiceId::parse("host.assurance.v1").expect("service id");
        let mut synthesis = fixture_input("vm-rollback");
        synthesis.services = vec![service];
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-rollback".into(),
            ..baked_assurance_config(dir.path())
        };
        let image_sha256 =
            mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(&config.rootfs_path))
                .expect("fixture digest");
        synthesis.image_sha256 = &image_sha256;

        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &synthesis,
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: Some(&campaign),
            },
        )
        .expect_err("a campaign declaring no destination cannot open");
        // Deliberately not asserted on the message: which refusal fires
        // depends on whether a neighbouring test installed the process-global
        // plane first (`NoPlane`) or not (`NoEdges`). Both roll the launch
        // back, and the rollback is the property under test.
        let _ = &err;

        // The whole point: no workload is left running behind the failure.
        assert!(
            !matches!(
                backend.status(&mvm_core::vm_backend::VmId("vm-rollback".into())),
                Ok(mvm_core::vm_backend::VmStatus::Running)
            ),
            "a campaign that could not open must not leave the VM up"
        );
    }

    #[test]
    fn a_declared_campaign_opens_its_session_on_the_boot_path() {
        // The production seam: `admit_and_start` is what a run goes through,
        // and a declared campaign has to become a live session there rather
        // than in a test that hand-built one. The broker-handler tests may
        // already have installed the process-global plane, so this test uses
        // that legitimate instance when running in parallel.
        use std::sync::Arc;

        use mvm_contract::assurance::{
            ApprovalSet, AssuranceId, ObservationScope, RequestedAuthority, Sha256Digest, ToolId,
        };

        use crate::assurance_session::{
            CampaignDeclaration, CampaignRequest, DeclaredEdge, default_policy_ceiling,
            host_assurance_plane, install_host_assurance_plane,
        };
        use crate::broker::handlers::host_assurance_v1::HostAssuranceV1Handler;

        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();

        let plane = Arc::new(HostAssuranceV1Handler::new());
        let _ = install_host_assurance_plane(Arc::clone(&plane));

        let emitter = Arc::new(
            crate::audit::emitter::AuditEmitter::with_dir(
                ed25519_dalek::SigningKey::from_bytes(&[31u8; 32]),
                audit.path(),
            )
            .expect("emitter")
            .with_receipts(),
        );
        let id = |raw: &str| AssuranceId::parse(raw).expect("identifier");
        let declaration = CampaignDeclaration {
            request_id: id("mvm-request-1"),
            idempotency_key: id("trial-retry-1"),
            campaign_id: id("mvm-campaign-1"),
            trial_id: id("trial-1"),
            source_run_id: id("scout-1"),
            source_digest: Sha256Digest::parse(format!("sha256:{}", "3".repeat(64)))
                .expect("digest"),
            artifact_digest: Sha256Digest::parse(format!("sha256:{}", "b".repeat(64)))
                .expect("artifact digest"),
            edges: vec![DeclaredEdge {
                label: id("undeclared.synthetic.destination"),
                host: "attacker.example.com".to_string(),
                port: 443,
            }],
            approvals: ApprovalSet::none().with(ToolId::CampaignProbeV1),
            requested: RequestedAuthority {
                allowed_tools: vec![ToolId::CampaignProbeV1],
                observation_scopes: vec![ObservationScope::HostAuditRefs],
                max_steps: 4,
                max_output_bytes: 4096,
                deadline_unix_ms: 0,
            },
            grant_ttl_ms: 600_000,
        };
        let now_unix_ms = 1_800_000_000_000;
        let campaign = CampaignRequest {
            declaration,
            emitter: Arc::clone(&emitter),
            policy_ceiling: default_policy_ceiling(),
            policy: mvm_core::policy::network_policy::NetworkPolicy::deny_all(),
            backend: "mock".to_string(),
            now_unix_ms,
        };

        let service =
            mvm_core::protocol::broker::ServiceId::parse("host.assurance.v1").expect("service id");
        let mut synthesis = fixture_input("vm-assurance");
        synthesis.services = vec![service];
        struct Trust(ed25519_dalek::VerifyingKey);
        impl mvm_core::packs::PackTrustStore for Trust {
            fn verifying_key(
                &self,
                _key_id: &mvm_core::plan::bundle::KeyId,
            ) -> Option<ed25519_dalek::VerifyingKey> {
                Some(self.0)
            }
        }
        struct Revocations;
        impl mvm_core::packs::PackRevocationChecker for Revocations {
            fn status(
                &self,
                _key_id: &mvm_core::plan::bundle::KeyId,
                _pack_hash: &mvm_core::packs::Sha256Hex,
            ) -> mvm_core::packs::RevocationStatus {
                mvm_core::packs::RevocationStatus::Good
            }
        }
        let staged = tempfile::tempdir().expect("extension staging");
        std::fs::write(
            staged.path().join("extension.ext4"),
            b"fixture extension filesystem",
        )
        .expect("write extension artifact");
        let pack_key = ed25519_dalek::SigningKey::from_bytes(&[45; 32]);
        let pack_policy_hash = mvm_core::packs::Sha256Hex::from_bytes(b"extension-policy");
        let pack_metadata = mvm_core::packs::PackMetadata {
            kind: mvm_core::packs::PackKind::Extension,
            target_arch: mvm_core::arch::GuestArch::host(),
            backend_compatibility: vec![mvm_core::packs::PackBackend::Firecracker],
            required_host_capabilities: vec![mvm_core::packs::HostCapability("vsock".to_string())],
            policy_compatibility: mvm_core::packs::PolicyCompatibility {
                policy_hash: pack_policy_hash.clone(),
                local_rebuild_required: false,
                allowed_channels: vec!["stable".to_string()],
            },
            inputs: mvm_core::packs::PackInputs {
                flake_locks: Vec::new(),
                derivations: Vec::new(),
                nar_hashes: Vec::new(),
                oci_images: Vec::new(),
                setup_commands: Vec::new(),
                source_revisions: Vec::new(),
                toolchain_versions: Default::default(),
            },
            provenance: mvm_core::packs::PackProvenanceMeta {
                builder_identity: "assurance-release".to_string(),
                build_environment_identity: "test".to_string(),
                build_timestamp: Utc::now(),
                reproducibility: mvm_core::packs::ReproducibilityStatus::NotChecked,
                sbom: mvm_core::packs::SbomReference {
                    uri: "urn:sbom:extension".to_string(),
                    sha256: mvm_core::packs::Sha256Hex::from_bytes(b"sbom"),
                },
            },
            trust: mvm_core::packs::PackTrustMeta {
                expires_at: Utc.with_ymd_and_hms(2100, 1, 1, 0, 0, 0).unwrap(),
                revocation_channel: "https://example.invalid/revocations".to_string(),
                channel_identity: "stable".to_string(),
                mirror_identity: None,
                transparency_log: None,
            },
            signature: mvm_core::packs::SignatureValidity {
                signed_at: Utc::now(),
                expires_at: Utc.with_ymd_and_hms(2100, 1, 1, 0, 0, 0).unwrap(),
            },
        };
        let extension_budgets = mvm_contract::protocol::extension_pack::ExtensionBudgets {
            cpu_millis: 500,
            memory_bytes: 128 * 1024 * 1024,
            duration_ms: 600_000,
            max_steps: 12,
            max_concurrency: 1,
            max_payload_bytes: 16 * 1024,
            max_output_bytes: 16 * 1024,
            max_artifact_bytes: 1024 * 1024,
        };
        let contract = mvm_contract::protocol::extension_pack::ExtensionPackContract {
            schema: mvm_contract::protocol::extension_pack::EXTENSION_PACK_SCHEMA.to_string(),
            extension_id: mvm_contract::protocol::extension_pack::ExtensionId::parse(
                "org.example.assurance-extension",
            )
            .expect("extension id"),
            version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse("1.0.0")
                .expect("extension version"),
            protocol: mvm_contract::protocol::extension_pack::ExtensionProtocolRange {
                min_mvm_version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse(
                    "0.18.0",
                )
                .expect("minimum version"),
                max_mvm_version: mvm_contract::protocol::extension_pack::ExtensionVersion::parse(
                    env!("CARGO_PKG_VERSION"),
                )
                .expect("maximum version"),
                min_protocol: 1,
                max_protocol: 1,
            },
            placement: mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
            artifact: "extension.ext4".to_string(),
            entrypoint: "bin/assurance-extension".to_string(),
            capabilities: vec![mvm_contract::assurance::probe_capability_descriptor()],
            budgets: extension_budgets,
            revocation_identity: "org.example.assurance-extension.release".to_string(),
            permission_delta: "May execute one declared assurance probe.".to_string(),
        };
        let manifest = mvm_core::packs::PackBuilder::new(staged.path(), pack_metadata, &pack_key)
            .file("extension.ext4")
            .extension(contract)
            .build()
            .expect("build signed extension pack");
        let pack_policy = mvm_core::packs::LocalPackPolicy {
            host_arch: mvm_core::arch::GuestArch::host(),
            backend: mvm_core::packs::PackBackend::Firecracker,
            host_capabilities: [mvm_core::packs::HostCapability("vsock".to_string())]
                .into_iter()
                .collect(),
            policy_hash: pack_policy_hash,
            allowed_channels: ["stable".to_string()].into_iter().collect(),
            now: Utc::now(),
        };
        let trust = Trust(pack_key.verifying_key());
        let revocations = Revocations;
        let verify =
            mvm_core::pack_cache::PackVerifyCtx::ed25519(&pack_policy, &trust, &revocations);
        let promoted = mvm_core::pack_cache::promote(staged.path(), &manifest, &verify)
            .expect("promote extension pack");
        let capability = mvm_contract::assurance::probe_capability_descriptor().id;
        let authority = std::collections::HashSet::from([capability]);
        let placements = std::collections::BTreeSet::from([
            mvm_contract::protocol::extension_pack::ExtensionPlacement::GuestWorkload,
        ]);
        let extension = crate::extension_admission::admit_extension(
            &manifest,
            &promoted.verified,
            crate::extension_admission::ExtensionAuthority {
                requested: &authority,
                policy_ceiling: &authority,
                session_grant: &authority,
                explicit_approval: &authority,
            },
            crate::extension_admission::ExtensionAdmissionPolicy {
                placements: &placements,
                budgets: extension_budgets,
            },
        )
        .expect("admit extension authority");
        synthesis.extensions = vec![extension];
        synthesis.agent_verbs = Some(vec![
            mvm_contract::plan::VerbId::new("run-extension").expect("extension verb"),
            mvm_contract::plan::VerbId::new("cancel-extension").expect("extension verb"),
        ]);
        synthesis
            .audit_labels
            .insert("assurance.source_run_id".to_string(), "scout-1".to_string());
        synthesis.audit_labels.insert(
            "assurance.source_digest".to_string(),
            format!("sha256:{}", "3".repeat(64)),
        );
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-assurance".into(),
            ..baked_assurance_config(dir.path())
        };
        let image_sha256 =
            mvm_core::crypto::image_verify::sha256_file(std::path::Path::new(&config.rootfs_path))
                .expect("fixture digest");
        synthesis.image_sha256 = &image_sha256;

        let started = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &synthesis,
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: Some(&ExtensionAdmissionContext::ambient(&verify)),
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: Some(&campaign),
            },
        )
        .expect("admit + boot with a declared campaign");

        let plane = host_assurance_plane().expect("the plane this test installed");
        let binding = plane
            .binding_for(&started.vm_id.0)
            .expect("the boot path opened a session for this VM");
        // The binding renders the content address in the counterparty's
        // identifier grammar; it still names exactly this plan.
        assert_eq!(
            binding.plan_id.as_str(),
            started.admitted.plan_id().0.replace(':', "-")
        );
        assert_eq!(binding.runtime.backend.as_str(), "mock");
        // Its citations came from real emission on the boot path.
        assert!(!binding.audit_refs.is_empty());
        assert!(!binding.receipt_refs.is_empty());

        let mut refused_synthesis = synthesis.clone();
        refused_synthesis.vm_name = "vm-assurance-refused";
        refused_synthesis
            .audit_labels
            .remove("assurance.source_digest");
        let refusal = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &refused_synthesis,
                config: mvm_core::vm_backend::VmStartConfig {
                    name: "vm-assurance-refused".into(),
                    ..baked_assurance_config(dir.path())
                },
                clock: &SystemClock,
                ledger: &InMemoryNonceLedger::new(),
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: Some(&ExtensionAdmissionContext::ambient(&verify)),
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: Some(&campaign),
            },
        )
        .expect_err("an assurance launch without its admitted service must fail");
        assert!(
            refusal
                .to_string()
                .contains("does not bind the campaign source identity")
        );
        assert!(
            matches!(
                backend.status(&mvm_core::vm_backend::VmId(
                    "vm-assurance-refused".to_string()
                )),
                Ok(mvm_core::vm_backend::VmStatus::Stopped)
            ),
            "a post-start assurance refusal must roll the VM back"
        );
    }

    /// The bound the backend spawns under comes off the signed plan, and only
    /// off the signed plan. A caller-supplied one would be a bound chosen
    /// outside the admission that just measured it against the host's ceiling.
    #[test]
    fn the_admitted_grant_reaches_the_launch_config_and_a_caller_supplied_one_does_not() {
        use mvm_core::vm_backend::VmStartConfig;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let mut input = fixture_input("vm-grant-threaded");
        let grants = mvm_contract::grants::Grants {
            cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 1500 }),
            ..Default::default()
        };
        input.grants = Some(grants);
        let admitted = admit_for_run(
            &input,
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit");

        let mut cfg = VmStartConfig {
            // A bound nobody admitted, planted by the caller.
            cpu_grant: Some(mvm_contract::grants::CpuGrant::Share { millicores: 64_000 }),
            ..VmStartConfig::default()
        };
        thread_cpu_grant(&mut cfg, &admitted);
        assert_eq!(
            cfg.cpu_grant,
            Some(mvm_contract::grants::CpuGrant::Share { millicores: 1500 }),
            "the launch must carry the admitted bound, not the caller's"
        );
    }

    /// An uncapped plan must clear a planted bound rather than leave it: a
    /// launch config is not a place to smuggle a control past admission.
    #[test]
    fn an_ungranted_plan_clears_a_caller_supplied_bound() {
        use mvm_core::vm_backend::VmStartConfig;
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let admitted = admit_for_run(
            &fixture_input("vm-no-grant"),
            &SystemClock,
            &InMemoryNonceLedger::new(),
            Some(dir.path()),
            None,
            RunPosture::without_backend(Variant::Dev),
        )
        .expect("admit");

        let mut cfg = VmStartConfig {
            cpu_grant: Some(mvm_contract::grants::CpuGrant::Share { millicores: 64_000 }),
            ..VmStartConfig::default()
        };
        thread_cpu_grant(&mut cfg, &admitted);
        assert_eq!(cfg.cpu_grant, None);
    }

    /// Every admitted boot leaves a record of what actually bounded it. Before
    /// this, `apply_grants` was reachable only from a launch path with no
    /// production implementation, so a real boot recorded nothing at all — and
    /// a bound nobody reports is indistinguishable from a bound nobody applied.
    #[test]
    fn an_admitted_boot_records_the_tier_that_bounded_it() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-tiers".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let started = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-tiers"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect("admit + boot");

        // The mock bounds nothing, and says so rather than claiming a tier it
        // has no mechanism for.
        assert_eq!(started.enforced_grants, EnforcedGrants::all_declared());
        assert!(!started.enforced_grants.cpu.is_enforced());
    }

    /// The budget gate every later admission measures against sums these
    /// per-VM records; a boot that never wrote one was invisible to it. The
    /// charge is the plan's configured memory — the same figure the balloon
    /// may not exceed — and a plan that declared no CPU bound commits none.
    #[test]
    fn an_admitted_boot_records_its_charge_for_the_host_budget() {
        let (_env, home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-charge".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-charge"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect("admit + boot");

        let record = mvm_core::config::vm_state_dir_at(home.path(), "vm-charge")
            .join("admitted-charge.json");
        let bytes = std::fs::read(&record).expect("the charge record is written");
        let charge: mvm_contract::grants::budget::MachineCharge =
            serde_json::from_slice(&bytes).expect("the charge record parses");
        assert_eq!(
            charge.memory_mib, 256,
            "the fixture plan grants 256 MiB: {charge:?}"
        );
        assert_eq!(
            charge.cpu_millicores, 0,
            "the fixture declares no CPU bound: {charge:?}"
        );
    }

    /// A boot whose charge cannot be recorded must not stay up: the host's
    /// committed total would undercount by exactly the machine nobody can
    /// see. The VM is stopped and the refusal lands on the chain at the
    /// host-budget stage.
    #[test]
    fn a_boot_whose_charge_cannot_be_recorded_rolls_back() {
        let (_env, home) = host_with_ceiling(Default::default());
        // A regular file where the vms dir must be: create_dir_all for the
        // charge record's state dir then fails with NotADirectory.
        std::fs::write(home.path().join("vms"), b"not a directory").expect("blocker file");
        let dir = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&[42u8; 32]),
            audit.path(),
        )
        .expect("emitter");
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-charge-blocked".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };

        admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-charge-blocked"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect_err("a boot whose charge cannot be recorded must not proceed");

        // The whole point: no workload is left running behind the failure.
        assert!(
            !matches!(
                backend.status(&mvm_core::vm_backend::VmId("vm-charge-blocked".into())),
                Ok(mvm_core::vm_backend::VmStatus::Running)
            ),
            "the VM whose charge could not be recorded is stopped"
        );
        let chain =
            std::fs::read_to_string(audit.path().join("local.jsonl")).expect("chain written");
        assert!(
            chain.contains("plan.failed") && chain.contains("host-budget"),
            "the refusal is on the chain, naming the host-budget stage: {chain}"
        );
    }

    /// The achieved tier reaches the chain-signed log, not just the return
    /// value — an operator answering "was this run bounded?" from the audit
    /// trail alone must not have to take the caller's word for it.
    #[test]
    fn an_admitted_boot_writes_the_achieved_tier_to_the_audit_chain() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-tier-audit".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let audit_dir = dir.path().join("audit");
        let mut seed = [0u8; 32];
        rand::rng().fill_bytes(&mut seed);
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&seed),
            &audit_dir,
        )
        .expect("emitter");

        admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-tier-audit"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect("admit + boot");

        let chain = std::fs::read_to_string(audit_dir.join("local.jsonl")).expect("chain written");
        assert!(
            chain.contains("plan.grants_enforced"),
            "the achieved tier must be on the chain: {chain}"
        );
        assert!(
            chain.contains("grants_cpu_tier"),
            "the CPU dimension must be named: {chain}"
        );
        // The spawn ceilings are written beside the CPU tier even when nothing
        // held them: the mock backend has no scope, so both say `declared` and
        // neither carries a number that could be read as a bound.
        assert!(
            chain.contains("grants_memory_tier") && chain.contains("grants_tasks_tier"),
            "the memory and task dimensions must be named: {chain}"
        );
        assert!(
            !chain.contains("grants_memory_max_bytes") && !chain.contains("grants_tasks_max"),
            "a declared ceiling must not carry a value: {chain}"
        );
    }

    /// A backend that cannot apply the admitted grants to the VM it just
    /// started must not leave that VM running, and must not leave a
    /// `plan.grants_enforced` entry behind: the boot fails at the `grants`
    /// stage and the chain says so.
    #[test]
    fn a_grant_that_cannot_be_applied_undoes_the_launch() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let mock = mvm_runtime::MockBackend::new().with_failing_apply_grants();
        let backend = mvm_runtime::AnyBackend::Mock(mock.clone());
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-grants-fail".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let audit_dir = dir.path().join("audit");
        let mut seed = [0u8; 32];
        rand::rng().fill_bytes(&mut seed);
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&seed),
            &audit_dir,
        )
        .expect("emitter");

        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-grants-fail"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect_err("a boot whose grants could not be applied must fail");

        assert!(
            format!("{err:#}").contains("applying the admitted plan's grants"),
            "{err:#}"
        );
        assert_eq!(mock.count(), 0, "the started VM must have been stopped");
        let chain = std::fs::read_to_string(audit_dir.join("local.jsonl")).expect("chain written");
        assert!(chain.contains("plan.failed"), "{chain}");
        assert!(
            chain.contains("\"grants\""),
            "the failing stage is named: {chain}"
        );
        assert!(
            !chain.contains("plan.grants_enforced"),
            "no enforcement may be recorded for grants that were never applied: {chain}"
        );
    }

    /// The end-to-end half of the tier question: `admit_and_start` holds the
    /// backend object, so the grant gate must be measuring against *its* kind
    /// and not against whatever the plan's profile says.
    ///
    /// The fixture's plan is labelled `firecracker` while the backend booting
    /// it is the mock. With a grant declared, that disagreement has to surface
    /// — and, because the refusal precedes signing, no VM may exist afterwards.
    #[test]
    fn admit_and_start_measures_grants_against_the_backend_that_boots() {
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let mut synthesis = fixture_input("vm-tier-mismatch");
        synthesis.grants = Some(cpu_share(1500));
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-tier-mismatch".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };

        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &synthesis,
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Prod,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect_err("the plan's profile and the booting backend disagree");
        let msg = err.to_string();
        assert!(msg.contains("firecracker") && msg.contains("mock"), "{msg}");
        assert_eq!(
            backend
                .status(&mvm_core::vm_backend::VmId("vm-tier-mismatch".into()))
                .expect("the mock reports a status for any name"),
            mvm_core::vm_backend::VmStatus::Stopped,
            "no VM may exist behind a refused admission"
        );
    }

    /// The point of `AuditDurability::Required`: a run that cannot record its
    /// admission does not reach the backend at all.
    ///
    /// Asserting the error is not enough — what matters is that no VM booted,
    /// because the failure mode being closed is a workload that ran while
    /// leaving no evidence it was ever admitted.
    #[test]
    fn a_required_admission_record_that_cannot_be_written_stops_the_boot() {
        use crate::audit::durability::AuditDurability;

        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-unauditable".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };

        // A chain whose tenant file cannot be written: a directory sits where
        // the JSONL belongs.
        let audit_dir = dir.path().join("audit");
        std::fs::create_dir_all(&audit_dir).unwrap();
        std::fs::create_dir(audit_dir.join("local.jsonl")).unwrap();
        let mut seed = [0u8; 32];
        rand::rng().fill_bytes(&mut seed);
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&seed),
            &audit_dir,
        )
        .expect("the emitter opens; writing the tenant file is what fails");

        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-unauditable"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: AuditDurability::Required,
                assurance: None,
            },
        )
        .expect_err("an unauditable sealed run must not boot");
        assert!(
            format!("{err:#}").contains("cannot be proven"),
            "the refusal must explain itself: {err:#}"
        );

        assert!(
            backend.list().expect("mock list").is_empty(),
            "no VM may exist for a run whose admission could not be recorded"
        );
    }

    /// The same broken chain under the dev tier boots and warns.
    #[test]
    fn a_best_effort_admission_record_does_not_stop_the_boot() {
        use crate::audit::durability::AuditDurability;

        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-dev-unauditable".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };

        let audit_dir = dir.path().join("audit");
        std::fs::create_dir_all(&audit_dir).unwrap();
        std::fs::create_dir(audit_dir.join("local.jsonl")).unwrap();
        let mut seed = [0u8; 32];
        rand::rng().fill_bytes(&mut seed);
        let emitter = crate::audit::emitter::AuditEmitter::with_dir(
            ed25519_dalek::SigningKey::from_bytes(&seed),
            &audit_dir,
        )
        .expect("emitter");

        let started = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-dev-unauditable"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: Some(&emitter),
                audit_durability: AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect("a dev run is not blocked by a broken audit chain");
        assert_eq!(started.vm_id.0, "vm-dev-unauditable");
    }

    #[test]
    fn admit_and_start_refuses_unadmitted_volume_before_boot() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let (_env, _home) = host_with_ceiling(Default::default());
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        // The synthesized plan admits no shares, but the launch config carries a
        // volume — claim 1 must refuse before the backend ever starts.
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-badvol".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            volumes: vec![VmVolume {
                host: "/etc".into(),
                guest: "/data".into(),
                read_only: true,
                kind: VmVolumeKind::Disk,
                materialized_image: Some("/state/mount.ext4".to_string()),
                ..Default::default()
            }],
            ..Default::default()
        };
        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &fixture_input("vm-badvol"),
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect_err("unadmitted volume must refuse");
        assert!(
            err.chain()
                .any(|e| e.to_string().contains("not named in the signed")),
            "expected admitted-shares refusal; got: {err:#}"
        );
        // Crucially: no VM was started (the gate fired before backend.start).
        assert!(matches!(
            backend.status(&VmId("vm-badvol".into())),
            Ok(mvm_core::vm_backend::VmStatus::Stopped)
        ));
    }

    #[test]
    fn admit_and_start_refuses_a_grant_over_the_host_ceiling_and_boots_nothing() {
        let (_env, _home) = host_with_ceiling(mvm_contract::grants::ceiling::GrantCeiling {
            max_cpu_millicores: Some(2000),
            ..Default::default()
        });
        let dir = tempfile::tempdir().unwrap();
        let backend = mvm_runtime::AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let mut synthesis = fixture_input("vm-denied");
        synthesis.grants = Some(cpu_share(64_000));
        let config = mvm_core::vm_backend::VmStartConfig {
            name: "vm-denied".into(),
            rootfs_path: "/store/rootfs.ext4".into(),
            ..Default::default()
        };
        let err = admit_and_start(
            &backend,
            AdmitAndStartParams {
                synthesis: &synthesis,
                config,
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: Some(dir.path()),
                bundle_ctx: None,
                extension_ctx: None,
                variant: Variant::Dev,
                policy_bundle: None,
                emitter: None,
                audit_durability: crate::audit::durability::AuditDurability::BestEffort,
                assurance: None,
            },
        )
        .expect_err("a grant over the host ceiling must be refused at admission");
        assert!(
            err.chain().any(|e| e.to_string().contains("ceiling")),
            "expected a ceiling refusal; got: {err:#}"
        );
        assert!(matches!(
            backend.status(&VmId("vm-denied".into())),
            Ok(mvm_core::vm_backend::VmStatus::Stopped)
        ));
        assert!(
            !dir.path()
                .join(crate::audit::host_keypair::SECRET_FILENAME)
                .exists(),
            "a refused launch must not be signed"
        );
    }

    /// Three points around the cap. The `>` → `==` mutant admits
    /// everything above the cap, which is the whole vector the cap closes;
    /// `>` → `>=` refuses a payload exactly at it. Only a boundary test
    /// separates the two, and only an extracted comparison makes a
    /// boundary test cheap.
    #[test]
    fn the_size_cap_admits_up_to_the_cap_and_refuses_above_it() {
        assert!(enforce_size_cap("plan_json", 0, 16).is_ok());
        assert!(enforce_size_cap("plan_json", 15, 16).is_ok());
        assert!(
            enforce_size_cap("plan_json", 16, 16).is_ok(),
            "a payload exactly at the cap is within it"
        );
        assert!(
            enforce_size_cap("plan_json", 17, 16).is_err(),
            "a payload over the cap must be refused"
        );
        assert!(
            enforce_size_cap("plan_json", usize::MAX, 16).is_err(),
            "a cap that only refuses one exact size is not a cap"
        );
    }

    /// The stale-sidecar removal exists so a reused VM name cannot inherit
    /// the previous boot's grant. Swallowing a real removal failure leaves
    /// that grant in place while reporting success — the one outcome the
    /// removal is there to prevent.
    #[test]
    fn a_failed_stale_grant_removal_is_not_reported_as_success() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let state_dir = tmp.path().join("vm-state");
        std::fs::create_dir_all(&state_dir).unwrap();

        // A non-empty directory where the sidecar file belongs: remove_file
        // refuses it, and the refusal is not NotFound.
        let sidecar = state_dir.join("verb-grant.json");
        std::fs::create_dir_all(&sidecar).unwrap();
        std::fs::write(sidecar.join("occupant"), b"stale").unwrap();

        assert!(
            mint_verb_grant_sidecar("{}", "vm-reused", &state_dir).is_err(),
            "a stale grant that could not be removed must not read as removed"
        );

        // Absent is still the quiet, successful case.
        let clean = tmp.path().join("clean-state");
        std::fs::create_dir_all(&clean).unwrap();
        assert!(mint_verb_grant_sidecar("{}", "vm-fresh", &clean).is_ok());
    }
}

#[cfg(test)]
mod admit_and_start_params_builder_tests {
    use super::*;

    /// An empty builder must refuse to finish, naming the first
    /// required field it is missing — never substituting a default.
    #[test]
    fn an_empty_builder_names_the_first_missing_field() {
        let Err(err) = AdmitAndStartParams::builder().build() else {
            panic!("an empty AdmitAndStartParams builder must not build");
        };
        assert_eq!(
            err,
            BuilderError::missing("AdmitAndStartParams", "synthesis")
        );
    }
}

#[cfg(test)]
mod launch_decision_record_tests {
    use super::*;

    /// The launch decision record names the plan it launched — in the
    /// scenario it describes and in the attestation it binds to.
    ///
    /// Deleting either `plan_id` leaves a record that says a workload was
    /// launched but not which signed plan authorized it, and the scenario's
    /// `plan_id` is part of the record's content address, so dropping it also
    /// re-addresses the decision. Both deletions survived mutation because
    /// nothing read the fields back.
    #[test]
    fn a_launch_decision_record_binds_the_plan_it_launched() {
        let plan = mvm_core::plan::test_support::PlanFixture::new()
            .plan_id("plan-under-launch")
            .build();

        let record = launch_decision_record(&plan, "firecracker");

        assert_eq!(record.category, DecisionCategory::Launch);
        assert_eq!(
            record.scenario.plan_id.as_deref(),
            Some("plan-under-launch"),
            "the scenario must name the launched plan"
        );
        assert_eq!(
            record.attestation.plan_id.as_deref(),
            Some("plan-under-launch"),
            "the attestation binding must name the launched plan"
        );
    }
}

#[cfg(test)]
mod signed_plan_admission_tests {
    use super::*;
    use chrono::{Duration, Utc};
    use ed25519_dalek::SigningKey;
    use mvm_core::plan::test_support::PlanFixture;
    use mvm_core::user_config::{MvmConfig, TrustedPlanSigner};
    use mvm_core::util::test_env::TestEnv;

    /// The fleet issuer key the tests pin — or deliberately don't.
    fn fleet_key() -> SigningKey {
        SigningKey::from_bytes(&[42u8; 32])
    }

    fn pin_for(signer_id: &str, key: &SigningKey) -> TrustedPlanSigner {
        TrustedPlanSigner {
            signer_id: signer_id.to_string(),
            ed25519_pubkey_hex: hex::encode(key.verifying_key().as_bytes()),
        }
    }

    /// Isolate `MVM_HOME` and write `cfg` as the host config. Admission reads
    /// the trusted signer set (and the grant ceiling) from host config rather
    /// than from a parameter, so a test that wants a trusting host has to
    /// *be* one. The guard and home must both outlive the admission call.
    fn host_with(cfg: MvmConfig) -> (TestEnv, tempfile::TempDir) {
        let home = tempfile::tempdir().expect("scratch mvm home");
        let mut env = TestEnv::new();
        env.isolate_mvm_home(home.path());
        let pins = cfg.trusted_plan_signers.len();
        mvm_core::user_config::save(&cfg, None).expect("writing the host config");
        // Precondition, not a redundant assertion: if this fails the isolation
        // did not hold and every check below would measure some other host.
        assert_eq!(
            mvm_core::user_config::load(None).trusted_plan_signers.len(),
            pins,
            "the isolated host must read back the pins it was configured with"
        );
        (env, home)
    }

    fn host_pinning(signers: Vec<TrustedPlanSigner>) -> (TestEnv, tempfile::TempDir) {
        host_with(MvmConfig {
            trusted_plan_signers: signers,
            ..MvmConfig::default()
        })
    }

    fn signed_by_fleet(plan: &ExecutionPlan) -> SignedExecutionPlan {
        sign_plan(plan, &fleet_key(), "fleet-prod")
    }

    fn admit(signed: &SignedExecutionPlan, ledger: &InMemoryNonceLedger) -> Result<AdmittedPlan> {
        admit_signed_plan_for_run(
            signed,
            &SystemClock,
            ledger,
            None,
            RunPosture::without_backend(Variant::Dev),
        )
    }

    #[test]
    fn a_pinned_fleet_signers_plan_is_admitted() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let plan = PlanFixture::new().tenant("fleet-tenant").build();
        let signed = signed_by_fleet(&plan);

        let admitted = admit(&signed, &InMemoryNonceLedger::new())
            .expect("a plan signed by a pinned fleet signer admits");

        assert_eq!(admitted.signer_id(), "fleet-prod");
        assert_eq!(admitted.plan().tenant.0, "fleet-tenant");
        // The admitted plan is content-addressed and the envelope the caller
        // handed in is carried verbatim — not re-signed under the host key.
        assert_eq!(admitted.plan_id(), &admitted.plan().plan_id);
        assert_eq!(admitted.signed().0.signer_id, "fleet-prod");
        assert_eq!(admitted.signed().0.signature, signed.0.signature);
    }

    #[test]
    fn an_unpinned_host_refuses_every_signed_plan() {
        // The default: no pins, no externally-signed admissions. This is the
        // fail-closed posture a host is in before the operator delegates.
        let (_env, _home) = host_pinning(Vec::new());
        let signed = signed_by_fleet(&PlanFixture::new().build());

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a host that pins nobody must refuse");
        assert!(
            format!("{err:#}").contains("pins no trusted plan signers"),
            "got: {err:#}"
        );
    }

    #[test]
    fn an_unknown_signer_is_refused() {
        // The host pins a *different* fleet issuer; the envelope names one it
        // never heard of.
        let other = SigningKey::from_bytes(&[7u8; 32]);
        let (_env, _home) = host_pinning(vec![pin_for("fleet-staging", &other)]);
        let signed = signed_by_fleet(&PlanFixture::new().build());

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("an unpinned signer must be refused");
        assert!(
            format!("{err:#}").contains("no trusted key matched signer_id fleet-prod"),
            "got: {err:#}"
        );
    }

    #[test]
    fn a_tampered_payload_is_refused() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let mut signed = signed_by_fleet(&PlanFixture::new().build());
        signed.0.payload[0] ^= 0x01;

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a tampered payload must fail signature verification");
        assert!(
            format!("{err:#}").contains("signature verification failed"),
            "got: {err:#}"
        );
    }

    #[test]
    fn an_expired_plan_is_refused() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let now = Utc::now();
        let plan = PlanFixture::new()
            .validity(now - Duration::hours(2), now - Duration::hours(1))
            .build();
        let signed = signed_by_fleet(&plan);

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a validly-signed but expired plan must be refused");
        assert!(
            format!("{err:#}").contains("plan validity window violated"),
            "got: {err:#}"
        );
    }

    #[test]
    fn a_not_yet_valid_plan_is_refused() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let now = Utc::now();
        let plan = PlanFixture::new()
            .validity(now + Duration::hours(1), now + Duration::hours(2))
            .build();
        let signed = signed_by_fleet(&plan);

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a plan whose window has not opened must be refused");
        assert!(
            format!("{err:#}").contains("plan validity window violated"),
            "got: {err:#}"
        );
    }

    #[cfg(unix)]
    #[test]
    fn a_replayed_plan_is_refused_by_a_fresh_process_sharing_the_durable_ledger() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let signed = signed_by_fleet(&PlanFixture::new().build());
        let dir = tempfile::tempdir().expect("ledger dir");
        let ledger_dir = dir.path().join("plan-nonces");

        // Two ledgers on one directory stand in for two launches, which each
        // build their own ledger.
        let first = InMemoryNonceLedger::durable_in(&ledger_dir).expect("open ledger");
        admit(&signed, &first).expect("the first launch is admitted");
        let second = InMemoryNonceLedger::durable_in(&ledger_dir).expect("open ledger");
        let err = admit(&signed, &second).expect_err("the same plan in a later launch is a replay");
        assert!(format!("{err:#}").contains("replay"), "got: {err:#}");
    }

    #[cfg(unix)]
    #[test]
    fn a_plan_is_refused_when_its_nonce_cannot_be_recorded() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let signed = signed_by_fleet(&PlanFixture::new().build());
        let dir = tempfile::tempdir().expect("ledger dir");
        let ledger =
            InMemoryNonceLedger::durable_in(dir.path().join("plan-nonces")).expect("open ledger");
        std::fs::write(
            dir.path().join("plan-nonces").join("nonces.tsv"),
            "corrupt\n",
        )
        .expect("corrupt the ledger");
        let err = admit(&signed, &ledger).expect_err("an unreadable ledger must refuse");
        assert!(
            format!("{err:#}").contains("cannot be recorded"),
            "got: {err:#}"
        );
    }

    #[test]
    fn a_replayed_nonce_is_refused() {
        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        let signed = signed_by_fleet(&PlanFixture::new().build());
        let ledger = InMemoryNonceLedger::new();

        admit(&signed, &ledger).expect("the first admission succeeds");
        let err = admit(&signed, &ledger).expect_err("the same plan admitted twice is a replay");
        assert!(format!("{err:#}").contains("replay"), "got: {err:#}");
    }

    #[test]
    fn a_plan_id_that_does_not_address_its_content_is_refused() {
        use ed25519_dalek::Signer as _;

        let (_env, _home) = host_pinning(vec![pin_for("fleet-prod", &fleet_key())]);
        // sign_plan re-derives the content address, so a mismatched id cannot
        // come through it — build the envelope by hand: a valid signature over
        // a plan whose stored id does not address its body.
        let plan = PlanFixture::new()
            .plan_id("not-the-content-address")
            .build();
        let payload = serde_json::to_vec(&plan).expect("plan serializes");
        let signature = fleet_key().sign(&payload);
        let signed = SignedExecutionPlan(mvm_core::protocol::signing::SignedPayload {
            payload,
            signature: signature.to_bytes().to_vec(),
            signer_id: "fleet-prod".to_string(),
        });

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a signed plan whose id does not address its content must be refused");
        assert!(
            format!("{err:#}").contains("plan_id content-address check"),
            "got: {err:#}"
        );
    }

    #[test]
    fn a_grant_over_the_host_ceiling_is_refused() {
        // The fleet's signature does not widen host policy: the ceiling the
        // operator configured still bounds what an externally-signed plan may
        // ask for.
        let (_env, _home) = host_with(MvmConfig {
            max_cpu_millicores: Some(2000),
            trusted_plan_signers: vec![pin_for("fleet-prod", &fleet_key())],
            ..MvmConfig::default()
        });
        let plan = PlanFixture::new()
            .grants(Some(mvm_contract::grants::Grants {
                cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 64_000 }),
                ..mvm_contract::grants::Grants::default()
            }))
            .build();
        let signed = signed_by_fleet(&plan);

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a grant above the host's ceiling must not be admitted");
        let msg = format!("{err:#}");
        assert!(msg.contains("ceiling"), "{msg}");
        assert!(msg.contains("64000") && msg.contains("2000"), "{msg}");
    }

    #[test]
    fn a_malformed_pin_refuses_admission() {
        // A pin the operator mistyped fails the whole load — admission never
        // runs against a silently-truncated trust set.
        let (_env, _home) = host_pinning(vec![TrustedPlanSigner {
            signer_id: "fleet-prod".to_string(),
            ed25519_pubkey_hex: "not-hex".to_string(),
        }]);
        let signed = signed_by_fleet(&PlanFixture::new().build());

        let err = admit(&signed, &InMemoryNonceLedger::new())
            .expect_err("a malformed pin must refuse admission");
        assert!(format!("{err:#}").contains("fleet-prod"), "got: {err:#}");
    }
}
