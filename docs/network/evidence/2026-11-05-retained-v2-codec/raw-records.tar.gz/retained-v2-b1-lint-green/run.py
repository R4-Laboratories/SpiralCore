import pathlib,hashlib,json,tarfile,subprocess,os,shutil,time
r=pathlib.Path('/var/tmp/spiralcore-retained-catalog-20261104'); source=r/'source'; out=r/'validation/retained-v2-b1-lint-green'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((out/'source.sha256.json').read_text())
baseline=json.loads((r/'validation/retained-v2-b1-green/source-after.json').read_text())
pre={p:sha(source/p) for p in baseline}
(out/'pre-overlay-source.json').write_text(json.dumps(pre,indent=2)+'\n')
bad=[p for p in baseline if p not in expected and pre[p]!=baseline[p]]
assert not bad,('unowned preimage differences',bad)
preimage=out/'preimages';preimage.mkdir(exist_ok=False)
with tarfile.open(out/'source-overlay.tar.gz') as t:
 assert set(t.getnames())==set(expected)
 for m in t.getmembers():
  assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
  path=source/m.name
  if path.exists():
   saved=preimage/m.name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved)
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(t.extractfile(m).read())
  assert sha(path)==expected[m.name]
keys=sorted(set(baseline)|set(expected)); before={p:sha(source/p) for p in keys};(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
lock=source/'crates/spiralcore-mvm-live/Cargo.lock';assert before[str(lock.relative_to(source))]==baseline[str(lock.relative_to(source))]
argv=['/home/callard/.cargo/bin/cargo','+1.97.1','test','--release','--offline','--locked','--manifest-path',str(source/'crates/spiralcore-mvm-live/Cargo.toml'),'--features','linux-host,canonical-host','--lib','--no-run','--message-format=json']
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/var/tmp/spiralcore-resident-parent-20261103/publication-target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1')
(out/'command.json').write_text(json.dumps({'argv':argv,'started_unix':time.time(),'env':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS']}},indent=2)+'\n')
with (out/'build.jsonl').open('w') as stdout,(out/'build.stderr').open('w') as stderr:
 proc=subprocess.Popen(argv,env=env,cwd=source,stdout=stdout,stderr=stderr);(out/'build.pid').write_text(str(proc.pid)+'\n');code=proc.wait()
(out/'build.exit').write_text(str(code)+'\n')
if code==0:
 artifacts=[]
 for line in (out/'build.jsonl').read_text().splitlines():
  try:x=json.loads(line)
  except ValueError:continue
  if x.get('reason')=='compiler-artifact' and x.get('executable') and x.get('target',{}).get('name')=='spiralcore_mvm_live' and x.get('profile',{}).get('test'):artifacts.append(x['executable'])
 assert len(set(artifacts))==1,artifacts
 binary=out/'protected-test';shutil.copy2(artifacts[0],binary);binary.chmod(0o500)
 (out/'binary.json').write_text(json.dumps({'source':artifacts[0],'protected':str(binary),'sha256':sha(binary)},indent=2)+'\n')
 fixture=r/'validation/recovery-old-fixture-baseline/old-process-state'
 paths=['installation/state.bin','installation/owner.lock','installation/.retained-telemetry.bin','vms/retained-before-restart/.installed-retained-telemetry']
 (out/'fixture-before.json').write_text(json.dumps({p:sha(fixture/p) for p in paths},indent=2)+'\n')
 test=[str(binary),'installed_owner::retained_telemetry::transfer_tests::','--nocapture','--test-threads=1']
 env['SPIRALCORE_OLD_RETAINED_STATE']=str(fixture)
 (out/'test-command.json').write_text(json.dumps({'argv':test,'SPIRALCORE_OLD_RETAINED_STATE':str(fixture)},indent=2)+'\n')
 with (out/'test.stdout').open('w') as stdout,(out/'test.stderr').open('w') as stderr:code=subprocess.call(test,env=env,cwd=source,stdout=stdout,stderr=stderr)
 (out/'test.exit').write_text(str(code)+'\n');(out/'binary-after.sha256').write_text(sha(binary)+'\n')
 (out/'fixture-after.json').write_text(json.dumps({p:sha(fixture/p) for p in paths},indent=2)+'\n')

if code==0:
 args=['/home/callard/.cargo/bin/cargo','+1.97.1','clippy','--release','--offline','--locked','--manifest-path',str(source/'crates/spiralcore-mvm-live/Cargo.toml'),'--features','linux-host,canonical-host','--lib','--tests','--message-format=json','--','-D','clippy::all']
 (out/'strict-command.json').write_text(json.dumps(args)+'\n')
 with (out/'strict.jsonl').open('w') as stdout,(out/'strict.stderr').open('w') as stderr:
  proc=subprocess.Popen(args,env=env,cwd=source,stdout=stdout,stderr=stderr);(out/'strict.pid').write_text(str(proc.pid)+'\n');code=proc.wait()
 (out/'strict.exit').write_text(str(code)+'\n')
 (out/'binary-after-strict.sha256').write_text(sha(binary)+'\n')
for phase in ['build','strict']:
 file=out/(phase+'.jsonl')
 if file.exists():
  warnings=[];errors=[]
  for line in file.read_text().splitlines():
   try:x=json.loads(line)
   except ValueError:continue
   m=x.get('message',{})
   if m.get('level')=='warning':warnings.append(m)
   if m.get('level')=='error':errors.append(m)
  (out/(phase+'-warnings.json')).write_text(json.dumps(warnings,indent=2)+'\n')
  (out/(phase+'-errors.json')).write_text(json.dumps(errors,indent=2)+'\n')

after={p:sha(source/p) for p in keys};(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
(out/'batch.exit').write_text(str(code)+'\n');print('BATCH_TERMINAL',code,flush=True)
