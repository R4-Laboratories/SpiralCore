#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
cd "$q"
mapfile -t files < <(find . -maxdepth 1 -type f -name 'mvm-directory-*' ! -name '*.bin' ! -name '*.tar.gz' ! -name '*metadata.json' ! -name 'mvm-directory-sdk-*.json' ! -name 'mvm-directory-phase-state.md' ! -name 'mvm-directory-raw*' -printf '%f\n' | LC_ALL=C sort)
test "${#files[@]}" -gt 200
sha256sum -- "${files[@]}" > mvm-directory-raw-members.sha256
tar -czf mvm-directory-raw.tar.gz mvm-directory-raw-members.sha256 "${files[@]}"
sha256sum mvm-directory-raw.tar.gz > mvm-directory-raw.tar.gz.sha256
cat mvm-directory-raw.tar.gz.sha256
printf 'raw_members=%s\n' "${#files[@]}"
