#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 MVM_HOME="$q/mvm-directory-home"
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
cd "$q/mvm-directory-work"
source scripts/dev-env.sh
{ ulimit -Sn; ulimit -Hn; stat -c '%U %a %n' "$TMPDIR"; } > "$q/mvm-directory-workspace-final-limits.txt"
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-workspace-final-source-before.txt"
/usr/bin/time -v cargo test --locked --offline --workspace -- --test-threads=1 > "$q/mvm-directory-workspace-final.log" 2>&1
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-final-source-after.txt"
systemctl --user show sc-mvm-directory-workspace-final -p Id -p MainPID -p MemoryPeak -p CPUUsageNSec -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p LimitNOFILE -p LimitNOFILESoft > "$q/mvm-directory-workspace-final-unit-receipt.txt"
