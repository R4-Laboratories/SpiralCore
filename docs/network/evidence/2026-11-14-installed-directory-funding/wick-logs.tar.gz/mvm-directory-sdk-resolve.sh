#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
cd "$q/mvm-directory-sdk/spiralcore"
for manifest in crates/spiralcore-mvm-adapter/Cargo.toml crates/spiralcore-mvm-journal-host/Cargo.toml crates/spiralcore-mvm-live/Cargo.toml crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml tools/installed-flowmux-witness/Cargo.toml tools/installed-flowmux-witness/guest/Cargo.toml; do
  name=${manifest//\//_}
  cargo metadata --manifest-path "$manifest" --format-version 1 > "$q/mvm-directory-sdk-$name.json" 2> "$q/mvm-directory-sdk-$name.log"
done
cargo metadata --locked --offline --manifest-path ../paired-guest/Cargo.toml --format-version 1 > "$q/mvm-directory-sdk-paired-metadata.json" 2> "$q/mvm-directory-sdk-paired-metadata.log"
