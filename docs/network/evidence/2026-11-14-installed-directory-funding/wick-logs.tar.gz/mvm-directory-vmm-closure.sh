#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
cd "$q/mvm-directory-work"
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-vmm-closure-source-before.txt"
cp Cargo.lock "$q/mvm-directory-candidate-Cargo.lock"
cp crates/mvm-hostd/Cargo.toml "$q/mvm-directory-candidate-hostd-Cargo.toml"
restore() { cp "$q/mvm-directory-candidate-Cargo.lock" Cargo.lock; cp "$q/mvm-directory-candidate-hostd-Cargo.toml" crates/mvm-hostd/Cargo.toml; }
trap restore EXIT
cargo tree --locked --offline -p mvm-vmm --target x86_64-unknown-linux-gnu -e normal,build,dev,features > "$q/mvm-directory-vmm-closure-candidate.txt"
cp "$q/mvm-directory-baseline-Cargo.lock" Cargo.lock
cp "$q/mvm-directory-baseline-hostd-Cargo.toml" crates/mvm-hostd/Cargo.toml
cargo tree --locked --offline -p mvm-vmm --target x86_64-unknown-linux-gnu -e normal,build,dev,features > "$q/mvm-directory-vmm-closure-baseline.txt"
restore
trap - EXIT
cmp "$q/mvm-directory-vmm-closure-candidate.txt" "$q/mvm-directory-vmm-closure-baseline.txt"
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-vmm-closure-source-after.txt"
