#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
binary="$q/source/.mvm-test/target/debug/deps/mvm_vmm-56c6cdc07fbaaee6"
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
umask 0022
ulimit -Sn > "$q/mvm-directory-fd-1024-full-soft.txt"
ulimit -Hn > "$q/mvm-directory-fd-hard.txt"
sha256sum "$binary" > "$q/mvm-directory-fd-candidate-before.sha256"
set +e
strace -f -e trace=fcntl,close,prlimit64 -o "$q/mvm-directory-fd-1024-full.strace" "$binary" --show-output --test-threads=1 > "$q/mvm-directory-fd-1024-full.log" 2>&1
result=$?
set -e
printf '%s\n' "$result" > "$q/mvm-directory-fd-1024-full-exit.txt"
sha256sum "$binary" > "$q/mvm-directory-fd-candidate-after.sha256"
cmp "$q/mvm-directory-fd-candidate-before.sha256" "$q/mvm-directory-fd-candidate-after.sha256"
exit "$result"
