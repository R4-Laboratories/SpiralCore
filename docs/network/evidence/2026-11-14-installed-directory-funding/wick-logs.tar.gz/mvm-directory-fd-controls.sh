#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
cd "$q/mvm-directory-baseline"
rustc -vV > "$q/mvm-directory-fd-control-rustc.txt"
cargo test --locked --offline -p mvm-vmm --lib --no-run --message-format=json > "$q/mvm-directory-fd-baseline-build.jsonl" 2> "$q/mvm-directory-fd-baseline-build.log"
binary=$(jq -ers '[.[] | select(.reason == "compiler-artifact" and .target.name == "mvm_vmm" and .profile.test and .executable) | .executable] | select(length == 1) | first' "$q/mvm-directory-fd-baseline-build.jsonl")
[[ "$binary" == "$CARGO_TARGET_DIR"/debug/deps/mvm_vmm-* ]]
cp "$binary" "$q/mvm-directory-fd-baseline.bin"
: > "$q/mvm-directory-fd-controls.txt"
for source in baseline candidate; do
  binary="$q/mvm-directory-fd-$source.bin"
  sha256sum "$binary" > "$q/mvm-directory-fd-$source-control-before.sha256"
  for ceiling in 1024 4096; do
    for trial in $(seq 1 10); do
      set +e
      (
        ulimit -Sn "$ceiling"
        { ulimit -Sn; ulimit -Hn; } > "$q/mvm-directory-fd-$source-$ceiling-$trial-limits.txt"
        strace --seccomp-bpf -f -e trace=fcntl -o "$q/mvm-directory-fd-$source-$ceiling-$trial.strace" "$binary" --exact driver::prepared_disks::tests::concurrent_launch_handoffs_always_acquire_contiguous_ranges --show-output --test-threads=1
      ) > "$q/mvm-directory-fd-$source-$ceiling-$trial.log" 2>&1
      result=$?
      set -e
      printf '%s %s %s %s\n' "$source" "$ceiling" "$trial" "$result" >> "$q/mvm-directory-fd-controls.txt"
    done
  done
  sha256sum "$binary" > "$q/mvm-directory-fd-$source-control-after.sha256"
  cmp "$q/mvm-directory-fd-$source-control-before.sha256" "$q/mvm-directory-fd-$source-control-after.sha256"
done
sha256sum -c "$q/mvm-store-final-source.sha256" > "$q/mvm-directory-fd-baseline-source-after.txt"
cat "$q/mvm-directory-fd-controls.txt"
