#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 MVM_HOME="$q/mvm-directory-home" TMPDIR="$q/mvm-directory-tmp"
cd "$q/mvm-directory-work"
source scripts/dev-env.sh
run() { local name=$1; shift; /usr/bin/time -v "$@" > "$q/mvm-directory-$name.log" 2>&1 || { tail -45 "$q/mvm-directory-$name.log"; return 1; }; }
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-final-source-before.txt"
run provenance cargo test --locked --offline -p mvm-build --lib guest_bins::tests::the_producer_records_the_producing_tree_and_every_member -- --exact --show-output
run custody cargo test --locked --offline -p mvm-hostd --lib supervisor::flowmux::owned_relays::custody_tests:: -- --test-threads=1 --show-output
run payload cargo test --locked --offline -p mvm-hostd --lib supervisor::flowmux::spiralcore_payload:: -- --test-threads=1 --show-output
run registered cargo test --locked --offline -p mvm-hostd --test registered_direct_tcp -- --test-threads=1 --show-output
run format cargo fmt --all -- --check
run strict cargo clippy --locked --offline --workspace --all-targets -- -D warnings
run gated just check::gated
run workspace cargo test --locked --offline --workspace -- --test-threads=1
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-final-source-after.txt"
