#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 MVM_HOME="$q/mvm-directory-home"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/mvmd258.XXXXXX)
printf '%s\n' "$TMPDIR" > "$q/mvm-directory-short-tmp.txt"
stat -c '%U %a %n' "$TMPDIR" > "$q/mvm-directory-short-tmp-stat.txt"
cd "$q/mvm-directory-work"
source scripts/dev-env.sh
run() { local name=$1; shift; /usr/bin/time -v "$@" > "$q/mvm-directory-$name.log" 2>&1 || { tail -45 "$q/mvm-directory-$name.log"; return 1; }; }
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-resumed-source-before.txt"
run registered-short cargo test --locked --offline -p mvm-hostd --test registered_direct_tcp -- --test-threads=1 --show-output
run format cargo fmt --all -- --check
run strict cargo clippy --locked --offline --workspace --all-targets -- -D warnings
run gated just check::gated
run workspace cargo test --locked --offline --workspace -- --test-threads=1
sha256sum -c "$q/mvm-directory-source.sha256" > "$q/mvm-directory-final-source-after.txt"
