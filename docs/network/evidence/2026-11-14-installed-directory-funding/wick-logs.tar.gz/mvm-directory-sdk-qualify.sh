#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_HOME="$q/mvm-directory-home"
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
ulimit -S -s 8192
cd "$q/mvm-directory-sdk/spiralcore"
run() { local name=$1; shift; /usr/bin/time -v "$@" > "$q/mvm-directory-sdk-$name.log" 2>&1 || { tail -45 "$q/mvm-directory-sdk-$name.log"; return 1; }; }
sha256sum -c "$q/mvm-directory-sdk-source.sha256" > "$q/mvm-directory-sdk-source-before.txt"
run endpoint cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent::endpoint_tests:: -- --show-output --test-threads=1
run collector cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent::collector_tests:: -- --show-output --test-threads=1
run supervisor cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml --all-targets -- --show-output --test-threads=1
run owner cargo test --release --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml --all-targets -- --show-output --test-threads=1
run paired-basic cargo test --locked --offline --manifest-path ../paired-guest/Cargo.toml --all-targets -- --show-output --test-threads=1
run paired-ordinal cargo test --locked --offline --manifest-path ../paired-guest/Cargo.toml --features object-reader-v1,large-object-fixture,sender-ordinal-v1 --all-targets -- --show-output --test-threads=1
run installed-tool cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets
run installed-tool-strict cargo clippy --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets -- -D warnings
run guest-tool cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets
run live-strict cargo clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings
sha256sum -c "$q/mvm-directory-sdk-source.sha256" > "$q/mvm-directory-sdk-source-after.txt"
