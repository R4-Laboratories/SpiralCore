#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/mvm-directory-tmp" MVM_HOME="$q/mvm-directory-home"
mkdir -p -m700 "$MVM_HOME"
cd "$q/mvm-directory-work"
rustc -vV > "$q/mvm-directory-rustc.txt"
cargo metadata --manifest-path Cargo.toml --format-version 1 > "$q/mvm-directory-metadata.json" 2> "$q/mvm-directory-metadata.log"
/usr/bin/time -v cargo test --locked -p mvm-hostd --lib supervisor::flowmux::spiralcore_payload::resource_pool_tests::installed_store_destruction_precedes_returned_credit -- --exact --show-output > "$q/mvm-directory-red.log" 2>&1
