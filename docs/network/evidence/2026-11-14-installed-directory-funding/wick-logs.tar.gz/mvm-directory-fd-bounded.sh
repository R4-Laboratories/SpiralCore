#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
binary="$q/source/.mvm-test/target/debug/deps/mvm_vmm-56c6cdc07fbaaee6"
export TMPDIR
TMPDIR=$(cat "$q/mvm-directory-short-tmp.txt")
sha256sum "$binary" > "$q/mvm-directory-fd-bounded-before.sha256"
{ ulimit -Sn; ulimit -Hn; } > "$q/mvm-directory-fd-bounded-limits.txt"
: > "$q/mvm-directory-fd-bounded-exits.txt"
for trial in $(seq 1 10); do
  set +e
  strace --seccomp-bpf -f -e trace=fcntl -o "$q/mvm-directory-fd-trial-$trial.strace" "$binary" --exact driver::prepared_disks::tests::concurrent_launch_handoffs_always_acquire_contiguous_ranges --show-output --test-threads=1 > "$q/mvm-directory-fd-trial-$trial.log" 2>&1
  result=$?
  set -e
  printf '%s %s\n' "$trial" "$result" >> "$q/mvm-directory-fd-bounded-exits.txt"
done
sha256sum "$binary" > "$q/mvm-directory-fd-bounded-after.sha256"
cmp "$q/mvm-directory-fd-bounded-before.sha256" "$q/mvm-directory-fd-bounded-after.sha256"
cat "$q/mvm-directory-fd-bounded-exits.txt"
