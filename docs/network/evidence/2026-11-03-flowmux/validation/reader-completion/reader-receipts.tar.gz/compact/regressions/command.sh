#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/regressions"
mkdir -p "$receipt" "$root/bin/regressions" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cd "$root/source" || exit 1
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/source-before.sha256" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
cargo=/home/callard/.cargo/bin/cargo
targets=(--test duplex_tcp --test mapped_stream --test paired_tcp --test authenticated_stream --test reader_completion)
"$cargo" +1.97.1 test --manifest-path "$manifest" --offline --locked --release "${targets[@]}" --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.kind==["test"] and .executable!=null)|{name:.target.name,executable}]|unique_by(.name)' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 5; then exit 1; fi
for target in duplex_tcp mapped_stream paired_tcp authenticated_stream reader_completion; do
 emitted=$(jq -r --arg name "$target" '.[]|select(.name==$name)|.executable' "$receipt/emitted.json")
 cp "$emitted" "$root/bin/regressions/$target" || exit 1
 chmod 500 "$root/bin/regressions/$target" || exit 1
 sha256sum "$root/bin/regressions/$target" > "$receipt/$target-before.sha256" || exit 1
 timeout 60s "$root/bin/regressions/$target" --nocapture --test-threads=1 > "$receipt/$target.txt" 2>&1
 result=$?
 printf '%s\n' "$result" > "$receipt/$target.exit"
 cat "$receipt/$target.txt"
 sha256sum -c "$receipt/$target-before.sha256" > "$receipt/$target-after.txt" || exit 1
 if test "$result" != 0; then exit "$result"; fi
done
"$cargo" +1.97.1 clippy --manifest-path "$manifest" --offline --locked --release "${targets[@]}" -- -D warnings > "$receipt/clippy.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/clippy.exit"
if test "$result" != 0; then tail -n 75 "$receipt/clippy.txt"; exit "$result"; fi
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after.txt" || exit 1
