#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/terminal-eof-control"
mkdir -p "$receipt" "$root/bin/terminal-eof-control" "$root/baseline-ca5/source" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cp -a /var/tmp/spiralcore-installed-factory-20261104/dependency-ca5/crates "$root/baseline-ca5/source/" || exit 1
chmod -R u+w "$root/baseline-ca5/source" || exit 1
cd "$root/baseline-ca5/source" || exit 1
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/baseline-source-before.sha256" || exit 1
(cd /var/tmp/spiralcore-installed-factory-20261104/dependency-ca5 && find . -type f -print0 | sort -z | xargs -0 sha256sum) > "$receipt/original-ca5-source.sha256" || exit 1
cmp "$receipt/baseline-source-before.sha256" "$receipt/original-ca5-source.sha256" > "$receipt/exact-baseline-copy.txt" || exit 1
cmp crates/spiralcore-mvm-flowmux/tests/authenticated_stream.rs "$root/source/crates/spiralcore-mvm-flowmux/tests/authenticated_stream.rs" > "$receipt/same-fixture.txt" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/baseline-ca5/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
/home/callard/.cargo/bin/cargo +1.97.1 test --manifest-path "$manifest" --offline --locked --release --test authenticated_stream --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.name=="authenticated_stream" and .executable!=null)|.executable]|unique' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 1; then exit 1; fi
cp "$(jq -r '.[0]' "$receipt/emitted.json")" "$root/bin/terminal-eof-control/baseline" || exit 1
cp "$root/bin/regressions/authenticated_stream" "$root/bin/terminal-eof-control/candidate" || exit 1
chmod 500 "$root/bin/terminal-eof-control/"* || exit 1
sha256sum "$root/bin/terminal-eof-control/"* > "$receipt/binaries-before.sha256" || exit 1
# Registered phase1 dose: ten interleaved pairs, SAME existing fixture,
# original CA vs additive reader methods. Timing is not performance evidence.
for trial in 1 2 3 4 5 6 7 8 9 10; do
 for arm in baseline candidate; do
  timeout 10s "$root/bin/terminal-eof-control/$arm" --exact fatal_cancel_refuses_verified_buffered_bytes_while_clean_half_close_still_drains --nocapture --test-threads=1 > "$receipt/$trial-$arm.txt" 2>&1
  result=$?
  printf '%s\n' "$result" > "$receipt/$trial-$arm.exit"
  printf '%s %s %s\n' "$trial" "$arm" "$result"
 done
done
sha256sum -c "$receipt/binaries-before.sha256" > "$receipt/binaries-after.txt" || exit 1
sha256sum -c --quiet "$receipt/baseline-source-before.sha256" > "$receipt/baseline-source-after.txt" || exit 1
