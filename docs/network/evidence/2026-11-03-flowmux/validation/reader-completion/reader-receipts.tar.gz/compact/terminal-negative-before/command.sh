#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/terminal-negative-before"
mkdir -p "$receipt" "$root/bin/terminal-negative-before" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cp "$root/terminal-negative-before.rs" "$root/source/crates/spiralcore-mvm-flowmux/tests/authenticated_stream.rs" || exit 1
touch "$root/source/crates/spiralcore-mvm-flowmux/tests/authenticated_stream.rs" || exit 1
cd "$root/source" || exit 1
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/source-before.sha256" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
/home/callard/.cargo/bin/cargo +1.97.1 test --manifest-path "$manifest" --offline --locked --release --test authenticated_stream --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.name=="authenticated_stream" and .executable!=null)|.executable]|unique' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 1; then exit 1; fi
cp "$(jq -r '.[0]' "$receipt/emitted.json")" "$root/bin/terminal-negative-before/authenticated_stream" || exit 1
chmod 500 "$root/bin/terminal-negative-before/authenticated_stream" || exit 1
sha256sum "$root/bin/terminal-negative-before/authenticated_stream" > "$receipt/binary-before.sha256" || exit 1
timeout 15s "$root/bin/terminal-negative-before/authenticated_stream" tls_close_ --nocapture --test-threads=1 > "$receipt/tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/tests.exit"
cat "$receipt/tests.txt"
sha256sum -c "$receipt/binary-before.sha256" > "$receipt/binary-after.txt" || exit 1
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after.txt" || exit 1
exit "$result"
