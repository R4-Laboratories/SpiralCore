#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/green-02"
mkdir -p "$receipt" "$root/bin/green-02" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cp "$root/overlay.tar.gz" "$root/overlay.sha256" "$receipt/" || exit 1
cd "$root/source" || exit 1
tar -xzf "$receipt/overlay.tar.gz" || exit 1
sha256sum -c "$receipt/overlay.sha256" > "$receipt/import-check.txt" || exit 1
while read -r hash file; do touch "$file" || exit 1; done < "$receipt/overlay.sha256"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/source-before.sha256" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
cargo=/home/callard/.cargo/bin/cargo
"$cargo" +1.97.1 test --manifest-path "$manifest" --offline --locked --release --test reader_completion --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.name=="reader_completion" and .executable!=null)|.executable]|unique' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 1; then exit 1; fi
cp "$(jq -r '.[0]' "$receipt/emitted.json")" "$root/bin/green-02/reader_completion" || exit 1
chmod 500 "$root/bin/green-02/reader_completion" || exit 1
sha256sum "$root/bin/green-02/reader_completion" > "$receipt/binary-before.sha256" || exit 1
timeout 10s "$root/bin/green-02/reader_completion" --nocapture --test-threads=1 > "$receipt/tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/tests.exit"
cat "$receipt/tests.txt"
sha256sum -c "$receipt/binary-before.sha256" > "$receipt/binary-after.txt" || exit 1
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after.txt" || exit 1
if test "$result" != 0; then exit "$result"; fi
"$cargo" +1.97.1 clippy --manifest-path "$manifest" --offline --locked --release --test reader_completion -- -D warnings > "$receipt/clippy.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/clippy.exit"
if test "$result" != 0; then tail -n 75 "$receipt/clippy.txt"; exit "$result"; fi
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after-clippy.txt" || exit 1
