#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/completion-fence-red"
mkdir -p "$receipt" "$root/bin/completion-fence-red" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cp "$root/overlay.tar.gz" "$root/overlay.sha256" "$receipt/" || exit 1
cd "$root/source" || exit 1
tar -xzf "$receipt/overlay.tar.gz" || exit 1
sha256sum -c "$receipt/overlay.sha256" > "$receipt/import-check.txt" || exit 1
while read -r hash file; do touch "$file" || exit 1; done < "$receipt/overlay.sha256"
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/source-before.sha256" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
/home/callard/.cargo/bin/cargo +1.97.1 test --manifest-path "$manifest" --offline --locked --release --lib --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.kind==["lib"] and .executable!=null)|.executable]|unique' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 1; then exit 1; fi
cp "$(jq -r '.[0]' "$receipt/emitted.json")" "$root/bin/completion-fence-red/lib" || exit 1
chmod 500 "$root/bin/completion-fence-red/lib" || exit 1
sha256sum "$root/bin/completion-fence-red/lib" > "$receipt/binary-before.sha256" || exit 1
timeout 10s "$root/bin/completion-fence-red/lib" completion_requires_live_delivery_fence_at_the_terminal_barrier --nocapture --test-threads=1 > "$receipt/tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/tests.exit"
cat "$receipt/tests.txt"
sha256sum -c "$receipt/binary-before.sha256" > "$receipt/binary-after.txt" || exit 1
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after.txt" || exit 1
exit "$result"
