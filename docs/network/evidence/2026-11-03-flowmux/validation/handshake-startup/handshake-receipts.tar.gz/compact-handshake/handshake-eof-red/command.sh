#!/bin/bash
set -u
root=/var/tmp/spiralcore-flowmux-reader-20261104
receipt="$root/validation/handshake-eof-red"
mkdir -p "$receipt" "$root/bin/handshake-eof-red" || exit 1
if test -e "$receipt/build.exit"; then exit 2; fi
cp "$root/handshake-eof-red.rs" "$root/source/crates/spiralcore-mvm-flowmux/tests/tls_handshake_eof.rs" || exit 1
touch "$root/source/crates/spiralcore-mvm-flowmux/tests/tls_handshake_eof.rs" || exit 1
cd "$root/source" || exit 1
find . -type f -print0 | sort -z | xargs -0 sha256sum > "$receipt/source-before.sha256" || exit 1
export CARGO_HOME=/home/callard/.cargo
export CARGO_TARGET_DIR=/var/tmp/spiralcore-flowmux-20261103/target
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
unset RUSTC_WRAPPER RUSTC_WORKSPACE_WRAPPER RUSTFLAGS CARGO_ENCODED_RUSTFLAGS LLVM_PROFILE_FILE
manifest="$root/source/crates/spiralcore-mvm-flowmux/Cargo.toml"
/home/callard/.cargo/bin/cargo +1.97.1 test --manifest-path "$manifest" --offline --locked --release --test tls_handshake_eof --no-run --message-format=json > "$receipt/build.json" 2> "$receipt/build.stderr"
result=$?
printf '%s\n' "$result" > "$receipt/build.exit"
if test "$result" != 0; then tail -n 75 "$receipt/build.stderr"; exit "$result"; fi
jq -s '[.[]|select(.reason=="compiler-artifact" and .target.name=="tls_handshake_eof" and .executable!=null)|.executable]|unique' "$receipt/build.json" > "$receipt/emitted.json" || exit 1
if test "$(jq length "$receipt/emitted.json")" != 1; then exit 1; fi
cp "$(jq -r '.[0]' "$receipt/emitted.json")" "$root/bin/handshake-eof-red/tls_handshake_eof" || exit 1
chmod 500 "$root/bin/handshake-eof-red/tls_handshake_eof" || exit 1
sha256sum "$root/bin/handshake-eof-red/tls_handshake_eof" > "$receipt/binary-before.sha256" || exit 1
timeout 10s "$root/bin/handshake-eof-red/tls_handshake_eof" --nocapture --test-threads=1 > "$receipt/tests.txt" 2>&1
result=$?
printf '%s\n' "$result" > "$receipt/tests.exit"
cat "$receipt/tests.txt"
sha256sum -c "$receipt/binary-before.sha256" > "$receipt/binary-after.txt" || exit 1
sha256sum -c --quiet "$receipt/source-before.sha256" > "$receipt/source-after.txt" || exit 1
exit "$result"
