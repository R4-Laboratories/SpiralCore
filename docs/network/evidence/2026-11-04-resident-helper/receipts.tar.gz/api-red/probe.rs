fn main(){ let _ = spiralcore_mvm_live::installed_parent::InstalledResident::start_owned_host_agent; }
