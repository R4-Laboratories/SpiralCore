//! Supervisor-owned retained ciphertext debt. No VM or deletion authority.
use crate::{
    installed_owner::{
        Epoch,
        retained_telemetry::{
            CanonicalRecoveryLayout, LiveRetainedCatalog, MAX_ENTRIES, OriginRecord,
            RetainedRecord,
            recovery::{Observations, PinnedEntry},
        },
    },
    installed_resources::{
        ImportedManagedReservation, ManagedClaim, ManagedReservation, ManagedResourceBudget,
    },
    installed_supervisor::{InstalledAuthority, InstalledSupervisor, SupervisorError},
};
use mvm_core::runtime_state_protection::{
    RuntimeStateProtection, TELEMETRY_RECORDS_FILE, TELEMETRY_RECORDS_KEY_FILE,
};
use std::{
    fs::File,
    os::{
        fd::AsRawFd,
        unix::fs::{MetadataExt, OpenOptionsExt},
    },
    path::Path,
    sync::{Arc, Mutex, Weak},
};

type Result<T> = std::result::Result<T, SupervisorError>;
pub(crate) const RECORD_BYTES: u64 = 8 << 20;
// Two <=8KiB catalog records, two <=4KiB status files, two <=1KiB
// wrapped keys, and one <=1KiB protection marker fit below this ceiling.
// The owned status writer still needs its explicit encoded-size gate before
// profile activation. These are logical bytes, not filesystem block/RSS proof.
pub(crate) use mvm_core::runtime_state_protection::INSTALLED_TELEMETRY_SIDECAR_BYTES as SIDECAR_BYTES;
pub(crate) const FIXED_DISK_BYTES: u64 = 8192;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Phase {
    Reserved,
    Protecting,
    Protected,
    Binding,
    Bound,
    Sealing,
    Sealed,
}
#[derive(Clone)]
enum InventoryFunding {
    Fresh(ManagedReservation),
    Imported(ImportedManagedReservation),
}
impl InventoryFunding {
    fn fresh_serial(&self) -> Option<u64> {
        match self {
            Self::Fresh(reservation) => Some(reservation.serial()),
            Self::Imported(_) => None,
        }
    }
    fn check_current(&self) -> Result<()> {
        match self {
            Self::Fresh(reservation) => reservation.check_current(),
            Self::Imported(reservation) => reservation.check_current(),
        }
        .map_err(Into::into)
    }
    fn check_retained_identity(&self) -> Result<()> {
        match self {
            Self::Fresh(reservation) => reservation.check_retained_identity(),
            Self::Imported(reservation) => reservation.check_retained_identity(),
        }
        .map_err(Into::into)
    }
}
struct Entry {
    tenant: [u8; 32],
    session: [u8; 32],
    parent: u64,
    reservation: InventoryFunding,
    phase: Phase,
    record: Option<RetainedRecord>,
    directory: Option<File>,
    files: Option<(File, File)>,
    historical: Option<PinnedEntry>,
    observation: Observations,
    marker: Option<File>,
}
impl Entry {
    fn published_record(&self) -> Option<&RetainedRecord> {
        self.record
            .as_ref()
            .or_else(|| self.historical.as_ref().map(|row| &row.record))
    }
}
struct RetainedTable {
    entries: [Option<Entry>; MAX_ENTRIES],
    catalog: Option<LiveRetainedCatalog>,
}
impl RetainedTable {
    fn empty() -> Self {
        Self {
            entries: std::array::from_fn(|_| None),
            catalog: None,
        }
    }
    fn held(&self, history: Option<&LiveHistory>) -> HeldRows {
        if let Some(history) = history {
            HeldRows::Versioned(
                self.entries
                    .iter()
                    .flatten()
                    .filter_map(|entry| {
                        Some(OriginRecord {
                            origin: entry
                                .historical
                                .as_ref()
                                .map_or(history.epoch, |row| row.origin),
                            record: entry.published_record()?.clone(),
                        })
                    })
                    .collect(),
            )
        } else {
            HeldRows::Legacy(
                self.entries
                    .iter()
                    .flatten()
                    .filter_map(|entry| entry.record.clone())
                    .collect(),
            )
        }
    }
}
enum HeldRows {
    Legacy(Vec<RetainedRecord>),
    Versioned(Vec<OriginRecord>),
}
pub(crate) struct LiveHistory {
    pub(crate) layout: CanonicalRecoveryLayout,
    pub(crate) epoch: Epoch,
}
pub(crate) struct RetainedTelemetryInventory {
    authority: Arc<InstalledAuthority>,
    budget: ManagedResourceBudget,
    metadata: InventoryFunding,
    table: Mutex<RetainedTable>,
    history: Option<LiveHistory>,
}
/// Original in-process lookup only; it cannot be reconstructed from a catalog.
pub(crate) struct RetainedTelemetryScope {
    original: Weak<RetainedTelemetryInventory>,
    slot: usize,
    serial: u64,
}
impl RetainedTelemetryInventory {
    pub(crate) fn from_recovered(
        authority: Arc<InstalledAuthority>,
        budget: ManagedResourceBudget,
        metadata: ImportedManagedReservation,
        history: LiveHistory,
        catalog: LiveRetainedCatalog,
        rows: [Option<(PinnedEntry, ImportedManagedReservation)>; MAX_ENTRIES],
    ) -> Arc<Self> {
        let entries = rows.map(|row| {
            row.map(|(original, reservation)| Entry {
                tenant: original.record.tenant,
                session: original.record.session,
                parent: original.record.parent,
                reservation: InventoryFunding::Imported(reservation),
                phase: Phase::Sealed,
                record: None,
                directory: None,
                files: None,
                historical: Some(original),
                observation: Observations::default(),
                marker: None,
            })
        });
        Arc::new(Self {
            authority,
            budget,
            metadata: InventoryFunding::Imported(metadata),
            table: Mutex::new(RetainedTable {
                entries,
                catalog: Some(catalog),
            }),
            history: Some(history),
        })
    }
    pub(crate) fn new(supervisor: &InstalledSupervisor) -> Result<Arc<Self>> {
        supervisor.require_canonical_profile()?;
        if RECORD_BYTES != mvm_vmm::host::telemetry_provisioning::DEFAULT_RECORDS_BYTE_CAP
            || SIDECAR_BYTES != 32 << 10
        {
            return Err(SupervisorError::Profile);
        }
        let budget = supervisor.managed_resources().clone();
        let metadata = budget.reserve(
            [0xd2; 32],
            ManagedClaim {
                host_metadata_bytes: 1 << 20,
                cache_disk_bytes: FIXED_DISK_BYTES,
                ..Default::default()
            },
        )?;
        Ok(Arc::new(Self {
            authority: supervisor.disk_authority(),
            budget,
            metadata: InventoryFunding::Fresh(metadata),
            table: Mutex::new(RetainedTable::empty()),
            history: None,
        }))
    }
    pub(crate) fn is_empty(&self) -> Result<bool> {
        Ok(self
            .table
            .lock()
            .map_err(|_| SupervisorError::State)?
            .entries
            .iter()
            .all(Option::is_none))
    }
    #[cfg(test)]
    pub(crate) fn witness_sealed_row(&self, parent: u64, expected_rows: usize) -> Result<u64> {
        self.metadata.check_retained_identity()?;
        let (record, funding, directory, records, key) = {
            let table = self.table.lock().map_err(|_| SupervisorError::State)?;
            let mut entries = table.entries.iter().flatten();
            if entries.clone().count() != expected_rows {
                return Err(SupervisorError::State);
            }
            let entry = entries
                .find(|entry| entry.parent == parent)
                .ok_or(SupervisorError::State)?;
            if entry.phase != Phase::Sealed
                // Fresh inventories write v1 and have no v2 catalog handle.
                || table.catalog.is_some() != self.history.is_some()
            {
                return Err(SupervisorError::State);
            }
            let record = entry.record.as_ref().ok_or(SupervisorError::State)?;
            if record.phase != 4 || record.parent != parent || record.session != entry.session {
                return Err(SupervisorError::State);
            }
            let directory = entry.directory.as_ref().ok_or(SupervisorError::State)?;
            let (records, key) = entry.files.as_ref().ok_or(SupervisorError::State)?;
            (
                record.clone(),
                entry.reservation.clone(),
                directory.try_clone()?,
                records.try_clone()?,
                key.try_clone()?,
            )
        };
        funding.check_retained_identity()?;
        let protection = self.protection_for(&record.state)?;
        protection.check_state(&record.state, &directory)?;
        if original_file(&directory, TELEMETRY_RECORDS_FILE, &records, RECORD_BYTES)?
            != record.record_id
            || original_file(&directory, TELEMETRY_RECORDS_KEY_FILE, &key, 1024)? != record.key_id
            || records.metadata()?.len() != record.sealed_len
        {
            return Err(SupervisorError::State);
        }
        Ok(record.sealed_len)
    }

    pub(crate) fn reserve_for_endpoint(
        self: &Arc<Self>,
        tenant: [u8; 32],
        session: [u8; 32],
        parent: u64,
    ) -> Result<RetainedTelemetryScope> {
        if tenant == [0; 32] || session == [0; 32] || parent == 0 {
            return Err(SupervisorError::Profile);
        }
        // No inventory lock is held during original ledger/epoch checks.
        let reservation = self.budget.reserve(
            tenant,
            ManagedClaim {
                cache_disk_bytes: RECORD_BYTES + SIDECAR_BYTES,
                ..Default::default()
            },
        )?;
        let serial = reservation.serial();
        let mut table = self.table.lock().map_err(|_| SupervisorError::State)?;
        let entries = &mut table.entries;
        if entries
            .iter()
            .flatten()
            .any(|entry| entry.session == session)
        {
            return Err(SupervisorError::State);
        }
        let slot = entries
            .iter()
            .position(Option::is_none)
            .ok_or(SupervisorError::Busy)?;
        entries[slot] = Some(Entry {
            tenant,
            session,
            parent,
            reservation: InventoryFunding::Fresh(reservation),
            phase: Phase::Reserved,
            record: None,
            directory: None,
            files: None,
            historical: None,
            observation: Observations::default(),
            marker: None,
        });
        Ok(RetainedTelemetryScope {
            original: Arc::downgrade(self),
            slot,
            serial,
        })
    }
    fn same_scope(self: &Arc<Self>, scope: &RetainedTelemetryScope) -> Result<()> {
        if !scope
            .original
            .upgrade()
            .is_some_and(|original| Arc::ptr_eq(self, &original))
        {
            return Err(SupervisorError::Profile);
        }
        self.metadata.check_current()?;
        Ok(())
    }
    fn entry<'a>(
        entries: &'a mut [Option<Entry>; MAX_ENTRIES],
        scope: &RetainedTelemetryScope,
    ) -> Result<&'a mut Entry> {
        entries
            .get_mut(scope.slot)
            .and_then(Option::as_mut)
            .filter(|entry| entry.reservation.fresh_serial() == Some(scope.serial))
            .ok_or(SupervisorError::State)
    }
    fn protection_for(&self, path: &Path) -> Result<RuntimeStateProtection> {
        if let Some(history) = &self.history {
            return match history.layout.acquire_protection(path) {
                Ok(guard) => Ok(guard),
                Err(crate::installed_owner::OwnerError::Io(error))
                    if error.kind() == std::io::ErrorKind::WouldBlock =>
                {
                    Err(error.into())
                }
                Err(error) => {
                    self.authority.close_admission();
                    Err(error.into())
                }
            };
        }
        let parent = path.parent().ok_or(SupervisorError::Profile)?;
        let parent_file = File::options()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(parent)?;
        Ok(RuntimeStateProtection::acquire(parent, &parent_file)?)
    }
    fn revalidate_history(
        &self,
        table: &mut RetainedTable,
        protection: &RuntimeStateProtection,
    ) -> Result<()> {
        let Some(history) = &self.history else {
            return Ok(());
        };
        let result = (|| -> Result<()> {
            for entry in table.entries.iter_mut().flatten() {
                if let Some(row) = &entry.historical {
                    entry.reservation.check_retained_identity()?;
                    row.revalidate_held(&history.layout, protection, &mut entry.observation)?;
                }
            }
            Ok(())
        })();
        if result.is_err() {
            self.authority.close_admission();
        } else {
            for entry in table.entries.iter_mut().flatten() {
                entry.observation = Observations::default();
            }
        }
        result
    }
    fn advance_catalog(
        &self,
        held: &HeldRows,
        catalog: &mut Option<LiveRetainedCatalog>,
        old: &RetainedRecord,
        next: &RetainedRecord,
    ) -> Result<()> {
        self.authority
            .with_disk_owner(|owner, epoch| match (held, catalog) {
                (HeldRows::Legacy(held), None) => {
                    owner.update_retained_telemetry(epoch, old, next, held)
                }
                (HeldRows::Versioned(held), Some(pin)) => {
                    owner.update_retained_telemetry_v2(epoch, old, next, held, pin)
                }
                _ => Err(crate::installed_owner::OwnerError::Fenced),
            })
    }
    pub(crate) fn prepare_state(
        self: &Arc<Self>,
        scope: &RetainedTelemetryScope,
        path: &Path,
        directory: &File,
    ) -> Result<()> {
        self.same_scope(scope)?;
        let protection = self.protection_for(path)?;
        protection.check_state(path, directory)?;
        let meta = directory.metadata()?;
        if meta.mode() & 0o7777 != 0o700 || path.as_os_str().len() > 4096 {
            return Err(SupervisorError::Profile);
        }
        let mut table = self.table.lock().map_err(|_| SupervisorError::State)?;
        self.revalidate_history(&mut table, &protection)?;
        if table.entries.iter().flatten().any(|entry| {
            entry.published_record().is_some_and(|record| {
                record.state == path
                    || (record.state_device, record.state_inode) == (meta.dev(), meta.ino())
            })
        }) {
            return Err(SupervisorError::State);
        }
        let held = table.held(self.history.as_ref());
        let RetainedTable { entries, catalog } = &mut *table;
        let entry = Self::entry(entries, scope)?;
        if entry.phase != Phase::Reserved {
            return Err(SupervisorError::State);
        }
        // Arm custody and retain the actual pin before any durable side effect.
        entry.directory = Some(directory.try_clone()?);
        entry.phase = Phase::Protecting;
        let record = RetainedRecord {
            tenant: entry.tenant,
            session: entry.session,
            parent: entry.parent,
            serial: scope.serial,
            records: RECORD_BYTES,
            sidecars: SIDECAR_BYTES,
            state: path.to_owned(),
            state_device: meta.dev(),
            state_inode: meta.ino(),
            phase: 1,
            record_id: (0, 0),
            key_id: (0, 0),
            sealed_len: 0,
            sealed_sha256: [0; 32],
        };
        entry.record = Some(record.clone());
        let prepared = self
            .authority
            .with_disk_owner(|owner, epoch| match (&held, catalog) {
                (HeldRows::Legacy(held), None) => {
                    owner.protect_retained_telemetry(epoch, &record, directory, held)
                }
                (HeldRows::Versioned(held), Some(pin)) => owner.protect_retained_telemetry_v2(
                    epoch,
                    &record,
                    directory,
                    held,
                    pin,
                    &mut entry.marker,
                ),
                _ => Err(crate::installed_owner::OwnerError::Fenced),
            })
            .and_then(|()| protection.check_state(path, directory).map_err(Into::into));
        if let Err(error) = prepared {
            self.authority.close_admission();
            return Err(error);
        }
        entry.record.as_mut().ok_or(SupervisorError::State)?.phase = 2;
        entry.phase = Phase::Protected;
        Ok(())
    }
    pub(crate) fn bind_files(
        self: &Arc<Self>,
        scope: &RetainedTelemetryScope,
        path: &Path,
        directory: &File,
        records: &File,
        wrapped_key: &File,
    ) -> Result<()> {
        self.same_scope(scope)?;
        let protection = self.protection_for(path)?;
        protection.check_state(path, directory)?;
        crate::installed_owner::retained_telemetry::require_private_retained_directory(directory)?;
        let mut table = self.table.lock().map_err(|_| SupervisorError::State)?;
        self.revalidate_history(&mut table, &protection)?;
        let held = table.held(self.history.as_ref());
        let RetainedTable { entries, catalog } = &mut *table;
        let entry = Self::entry(entries, scope)?;
        if entry.phase != Phase::Protected {
            return Err(SupervisorError::State);
        }
        let old = entry.record.as_ref().ok_or(SupervisorError::State)?.clone();
        let meta = directory.metadata()?;
        if old.state != path || (old.state_device, old.state_inode) != (meta.dev(), meta.ino()) {
            return Err(SupervisorError::Profile);
        }
        require_records_access(records)?;
        let record_id = original_file(directory, TELEMETRY_RECORDS_FILE, records, RECORD_BYTES)?;
        let key_id = original_file(directory, TELEMETRY_RECORDS_KEY_FILE, wrapped_key, 1024)?;
        let files = (records.try_clone()?, wrapped_key.try_clone()?);
        entry.files = Some(files);
        entry.phase = Phase::Binding;
        let mut next = old.clone();
        next.phase = 3;
        next.record_id = record_id;
        next.key_id = key_id;
        let bound = (|| -> Result<()> {
            records.sync_all()?;
            wrapped_key.sync_all()?;
            directory.sync_all()?;
            self.advance_catalog(&held, catalog, &old, &next)?;
            protection.check_state(path, directory)?;
            Ok(())
        })();
        if let Err(error) = bound {
            self.authority.close_admission();
            return Err(error);
        }
        entry.record = Some(next);
        entry.phase = Phase::Bound;
        Ok(())
    }
    /// The original positive endpoint receipt is required before final sync.
    /// Sealing never deletes data or releases retained disk debt. A failed
    /// pre-binding transaction requires separate original recovery custody.
    #[cfg(feature = "canonical-host")]
    pub(crate) fn seal_after_endpoint(
        self: &Arc<Self>,
        scope: &RetainedTelemetryScope,
        receipt: &mvm_client::EndpointRetirement,
        guard: &Arc<dyn mvm_core::host_lifetime::EndpointPartitionGuard>,
        projection: &mvm_core::host_lifetime::EndpointPartitionProjection,
    ) -> Result<()> {
        use sha2::{Digest, Sha256};
        use std::os::unix::fs::FileExt;
        if !receipt.retains_partition_guard(guard)
            || receipt.projection() != projection
            || !scope
                .original
                .upgrade()
                .is_some_and(|original| Arc::ptr_eq(self, &original))
        {
            return Err(SupervisorError::Profile);
        }
        self.metadata.check_retained_identity()?;
        let mut table = self.table.lock().map_err(|_| SupervisorError::State)?;
        let entry = Self::entry(&mut table.entries, scope)?;
        if entry.session != projection.session
            || entry.parent != projection.binding.grant_serial
            || projection
                .store
                .as_ref()
                .is_none_or(|store| store.tenant != entry.tenant)
        {
            return Err(SupervisorError::Profile);
        }
        if entry.phase == Phase::Sealed {
            return Ok(());
        }
        if entry.phase != Phase::Bound {
            return Err(SupervisorError::State);
        }
        let old = entry.record.as_ref().ok_or(SupervisorError::State)?.clone();
        let directory = entry
            .directory
            .as_ref()
            .ok_or(SupervisorError::State)?
            .try_clone()?;
        // Match preparation/binding lock order: protection, then inventory,
        // then original catalog owner. No table is held while acquiring it.
        drop(table);
        let protection = self.protection_for(&old.state)?;
        protection.check_state(&old.state, &directory)?;
        crate::installed_owner::retained_telemetry::require_private_retained_directory(&directory)?;
        let mut table = self.table.lock().map_err(|_| SupervisorError::State)?;
        self.revalidate_history(&mut table, &protection)?;
        let held = table.held(self.history.as_ref());
        let RetainedTable { entries, catalog } = &mut *table;
        let entry = Self::entry(entries, scope)?;
        if entry.phase != Phase::Bound || entry.record.as_ref() != Some(&old) {
            return Err(SupervisorError::State);
        }
        let (records, key) = entry.files.as_ref().ok_or(SupervisorError::State)?;
        require_records_access(records)?;
        if original_file(&directory, TELEMETRY_RECORDS_FILE, records, RECORD_BYTES)?
            != old.record_id
            || original_file(&directory, TELEMETRY_RECORDS_KEY_FILE, key, 1024)? != old.key_id
        {
            return Err(SupervisorError::Profile);
        }
        entry.phase = Phase::Sealing;
        records.sync_all()?;
        key.sync_all()?;
        let length = records.metadata()?.len();
        let mut offset = 0;
        let mut buffer = [0_u8; 8192];
        let mut digest = Sha256::new();
        while offset < length {
            let count = records.read_at(
                &mut buffer[..usize::try_from((length - offset).min(8192))
                    .map_err(|_| SupervisorError::State)?],
                offset,
            )?;
            if count == 0 {
                return Err(SupervisorError::State);
            }
            digest.update(&buffer[..count]);
            offset += count as u64;
        }
        if records.metadata()?.len() != length {
            return Err(SupervisorError::State);
        }
        directory.sync_all()?;
        let mut next = old.clone();
        next.phase = 4;
        next.sealed_len = length;
        next.sealed_sha256 = digest.finalize().into();
        if let Err(error) = self.advance_catalog(&held, catalog, &old, &next) {
            self.authority.close_admission();
            return Err(error);
        }
        protection.check_state(&old.state, &directory)?;
        entry.record = Some(next);
        entry.phase = Phase::Sealed;
        Ok(())
    }
}

fn require_records_access(records: &File) -> Result<()> {
    // SAFETY: F_GETFL observes flags on this live original File descriptor.
    let flags = unsafe { libc::fcntl(records.as_raw_fd(), libc::F_GETFL) };
    if flags < 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    // The canonical producer appends through this same open-file description;
    // later sealing reads it without changing the shared writer offset.
    if flags & libc::O_ACCMODE != libc::O_RDWR || flags & libc::O_APPEND == 0 {
        return Err(SupervisorError::Profile);
    }
    Ok(())
}

fn original_file(directory: &File, name: &str, actual: &File, cap: u64) -> Result<(u64, u64)> {
    let name = std::ffi::CString::new(name).map_err(|_| SupervisorError::Profile)?;
    // SAFETY: fixed canonical name and live original directory; fresh FD.
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            name.as_ptr(),
            libc::O_RDONLY | libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK,
        )
    };
    if fd < 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    use std::os::fd::FromRawFd;
    // SAFETY: successful openat returned this fresh, uniquely owned descriptor.
    let named = unsafe { File::from_raw_fd(fd) };
    crate::installed_owner::retained_telemetry::require_private_retained_file(&named)?;
    crate::installed_owner::retained_telemetry::require_private_retained_file(actual)?;
    let expected = named.metadata()?;
    let held = actual.metadata()?;
    for meta in [&expected, &held] {
        mvm_core::private_fs::require_current_owner(meta)?;
        if !meta.is_file() || meta.mode() & 0o7777 != 0o600 || meta.nlink() != 1 || meta.len() > cap
        {
            return Err(SupervisorError::Profile);
        }
    }
    if (expected.dev(), expected.ino()) != (held.dev(), held.ino()) {
        return Err(SupervisorError::Profile);
    }
    Ok((held.dev(), held.ino()))
}

impl Drop for RetainedTelemetryInventory {
    fn drop(&mut self) {
        let table = self
            .table
            .get_mut()
            .unwrap_or_else(|error| error.into_inner());
        if table.entries.iter().any(Option::is_some) {
            self.authority.close_admission();
            // Preserve the complete bounded original table, file pins and
            // credits. The durable catalog also denies a fresh zero epoch.
            let held = std::mem::replace(table, RetainedTable::empty());
            std::mem::forget(held);
            std::mem::forget(self.metadata.clone());
            if let Some(history) = self.history.take() {
                std::mem::forget(history);
            }
        }
    }
}
