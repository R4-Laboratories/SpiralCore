//! One installed native guest witness. The caller owns the measured startup
//! budget, original admission and the verified host-agent enrollment.
use super::*;
use anyhow::{Context, bail, ensure};
use mvm_client::guest::{ProcWaitEvent, wait_process};
use mvm_core::plan::ExecutionPlan;
use std::{
    net::Ipv4Addr,
    os::unix::fs::MetadataExt as _,
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
    thread,
    time::{Duration, Instant},
};

mod native_peer;
mod native_plan;

fn launched_process(service: &InstalledResident, id: ResidentId) -> Result<(&str, &str)> {
    let live = service
        .live
        .as_ref()
        .context("original resident unavailable")?;
    let State::Running(outcome) = &live.slot(id)?.state else {
        bail!("original native guest did not reach running");
    };
    ensure!(outcome.machine.name == native_plan::NAME);
    Ok((
        &outcome.machine.name,
        outcome
            .process
            .as_deref()
            .context("guest readback process missing")?,
    ))
}

fn read_guest_marker(name: &str, process: &str) -> Result<()> {
    let expected = b"spiralcore-guest-readback-exact\n";
    let mut marker = Vec::with_capacity(expected.len());
    let mut extra = false;
    let terminal = wait_process(name, process, Some(15), |event| match event {
        ProcWaitEvent::Stdout { chunk }
            if chunk.len() <= expected.len().saturating_sub(marker.len()) =>
        {
            marker.extend_from_slice(chunk);
        }
        ProcWaitEvent::Stdout { .. } | ProcWaitEvent::Stderr { .. } => extra = true,
        _ => {}
    })?;
    ensure!(
        matches!(terminal, ProcWaitEvent::Exit { code: 0 }),
        "guest readback process failed: {terminal:?}"
    );
    ensure!(
        !extra && marker == expected,
        "guest did not report exact readback"
    );
    Ok(())
}

struct NativeCredit(Option<ManagedReservation>);

impl NativeCredit {
    fn release(&mut self) {
        drop(self.0.take());
    }
}

impl Drop for NativeCredit {
    fn drop(&mut self) {
        if let Some(credit) = self.0.take() {
            // An unfinished native phase keeps its charge until process exit.
            std::mem::forget(credit);
        }
    }
}

fn run_roundtrip(
    service: &mut InstalledResident,
    runtime: &tokio::runtime::Runtime,
    id: ResidentId,
    plan: &ExecutionPlan,
    peer: native_peer::NativePeer,
    host_public: [u8; 32],
    disk: ManagedReservation,
    root: &Path,
) -> Result<(native_peer::NativePeerResult, u64, u64)> {
    let grant = service
        .live
        .as_ref()
        .context("original resident unavailable")?
        .slot(id)?
        .owner
        .grant
        .clone();
    let state = mvm_core::config::vm_state_dir(&grant.binding.vm_name);
    let deadline = Instant::now() + Duration::from_secs(75);
    let cancelled = AtomicBool::new(false);
    let mut disk = NativeCredit(Some(disk));

    let (guest, peer, unused) = thread::scope(|scope| {
        let worker = scope.spawn(|| {
            let session = loop {
                if cancelled.load(Ordering::Acquire) {
                    bail!("resident launch failed before original peer enrollment");
                }
                if let Some(session) = grant
                    .lifecycle
                    .lock()
                    .map_err(|_| anyhow!("original VM lifecycle poisoned"))?
                    .admitted_session
                {
                    break session;
                }
                ensure!(
                    Instant::now() < deadline,
                    "original endpoint session missing"
                );
                thread::sleep(Duration::from_millis(5));
            };
            peer.enroll(plan, native_plan::NAME, state, session, host_public)?
                .serve(deadline)
        });
        let boot = runtime.block_on(service.drive_once());
        let unused = boot.as_ref().is_ok_and(|progress| {
            progress.id == id && progress.state == ResidentStatus::UnusedRetired
        });
        let guest = (|| {
            let progress = boot?;
            ensure!(
                progress.id == id && progress.state == ResidentStatus::Running,
                "original native launch failed: {:?}, diagnostics={:?}",
                progress.state,
                service.last_error(id).ok().flatten()
            );
            let (name, process) = launched_process(service, id)?;
            read_guest_marker(name, process)
        })();
        if guest.is_err() {
            cancelled.store(true, Ordering::Release);
        }
        let peer = worker
            .join()
            .map_err(|_| anyhow!("native peer panicked"))
            .and_then(|result| result);
        (guest, peer, unused)
    });
    drop(grant);

    // Stop through the original owner even if either half of transfer failed.
    // Do not treat an uncertain cleanup as success or release its custody.
    let stopped = (|| {
        if unused {
            return Ok(());
        }
        service.request_stop(id)?;
        let progress = runtime.block_on(service.drive_once())?;
        ensure!(
            progress.id == id && progress.state == ResidentStatus::Retired,
            "original native retirement failed: {:?}, diagnostics={:?}",
            progress.state,
            service.last_error(id).ok().flatten()
        );
        Ok::<(), anyhow::Error>(())
    })();
    if let Err(error) = &guest {
        eprintln!("guest failure before original shutdown: {error:#}");
    }
    if let Err(error) = &peer {
        eprintln!("peer failure before original shutdown: {error:#}");
    }
    if guest.is_ok()
        && let Ok(peer) = &peer
    {
        eprintln!(
            "byte-exact guest and peer readback: sent={} received={}",
            peer.sent_bytes, peer.received_bytes
        );
        eprintln!("exact peer measurements: {peer:?}");
    }
    stopped?;
    let runtime_allocated = if guest.is_ok() && peer.is_ok() && !unused {
        ensure!(
            std::fs::read_dir(root.join("tmp"))?.next().transpose()?.is_none(),
            "fixture staging remains after stop"
        );
        retained_runtime_bytes(root, native_plan::NAME)?
    } else {
        0
    };
    if runtime_allocated != 0 || unused {
        disk.release();
    }
    if !unused {
        eprintln!("original native and endpoint retirement confirmed");
    }
    let finish = if unused {
        service.try_finish().map(|()| 0)
    } else {
        finish_with_sealed_telemetry(service, id.serial)
    };
    if let Err(error) = guest {
        if let Err(cleanup) = finish {
            eprintln!("original shutdown after launch failure: {cleanup:#}");
        }
        return Err(error);
    }
    Ok((peer?, finish?, runtime_allocated))
}

fn finish_with_sealed_telemetry(service: &mut InstalledResident, parent: u64) -> Result<u64> {
    use crate::{
        installed_retained::{FIXED_DISK_BYTES, RECORD_BYTES, SIDECAR_BYTES},
        installed_supervisor::SupervisorError,
    };
    let sealed = service
        .supervisor
        .as_ref()
        .context("supervisor missing")?
        .retained_telemetry_inventory()?
        .witness_sealed_row(parent)
        .context("verify the sealed original telemetry row")?;
    let stopped = service.try_finish();
    ensure!(
        service.live.is_none(),
        "original helper or resident still live"
    );
    match stopped {
        Err(error)
            if matches!(
                error.downcast_ref::<SupervisorError>(),
                Some(SupervisorError::Busy)
            ) => {}
        other => bail!("expected sealed telemetry to retain original installation: {other:?}"),
    }
    let snapshot = service.usage()?;
    // A successful snapshot already ruled out a corrupt ledger. Its
    // compatibility field marks admission closed after try_finish.
    ensure!(
        snapshot.fenced && snapshot.active_reservations == 3,
        "post-retirement managed snapshot differs: {snapshot:?}"
    );
    ensure!(
        snapshot.usage
            == ManagedClaim {
                host_metadata_bytes: MIB,
                cache_disk_bytes: FIXED_DISK_BYTES + RECORD_BYTES + SIDECAR_BYTES + RETAINED_RUNTIME_QUOTE,
                ..Default::default()
            },
        "non-retained native credit remains: {:?}",
        snapshot.usage
    );
    Ok(sealed)
}

const MIB: u64 = 1024 * 1024;
const RETAINED_RUNTIME_QUOTE: u64 = 112 * MIB;

fn retained_runtime_bytes(root: &Path, name: &str) -> Result<u64> {
    let vm = root.join("mvm/runtime-evidence").join(name);
    let mut generation = None;
    for item in std::fs::read_dir(&vm)? {
        let item = item?;
        if item.file_name() == "lifecycle.lock" {
            continue;
        }
        ensure!(
            generation.is_none()
                && item.file_type()?.is_dir()
                && item.file_name().to_string_lossy().starts_with("portable-runtime-"),
            "unexpected retained runtime generation"
        );
        generation = Some(item.path());
    }
    let generation = generation.context("no retained runtime generation")?;
    let mut blocks = 0_u64;
    let mut charge = |path: &Path, directory: bool| -> Result<()> {
        let metadata = std::fs::symlink_metadata(path)?;
        mvm_core::private_fs::require_current_owner(&metadata)?;
        ensure!(
            if directory {
                metadata.is_dir() && metadata.mode() & 0o7777 == 0o700
            } else {
                metadata.is_file() && metadata.mode() & 0o7777 == 0o400
                    && metadata.nlink() == 1
            },
            "retained runtime object differs"
        );
        blocks = blocks.checked_add(metadata.blocks()).context("runtime blocks overflow")?;
        Ok(())
    };
    charge(&vm, true)?;
    charge(&generation, true)?;
    let mut count = 0;
    for file in std::fs::read_dir(&generation)? {
        let file = file?;
        ensure!(
            count < 7
                && matches!(file.file_name().to_str(),
                    Some("bundle.mvmpkg" | "initramfs.cpio.gz" | "kernel" | "overlay.ext4"
                         | "overlay.verity" | "rootfs" | "rootfs.verity")),
            "unexpected retained runtime file"
        );
        charge(&file.path(), false)?;
        count += 1;
    }
    ensure!(count == 7, "incomplete retained runtime generation");
    let bytes = blocks.checked_mul(512).context("runtime disk bytes overflow")?;
    ensure!(bytes > 0 && bytes <= RETAINED_RUNTIME_QUOTE, "retained runtime quote exceeded");
    Ok(bytes)
}

fn quote(key: &str, cap: u64) -> Result<u64> {
    let value: u64 = std::env::var(key)?.parse()?;
    ensure!(
        value > 0 && value <= cap,
        "native fixture quote out of range"
    );
    Ok(value)
}

#[test]
#[ignore = "requires the pinned Firecracker installation and measured startup quotes"]
fn native_signed_guest_roundtrip_and_original_retirement() -> Result<()> {
    use crate::{
        installed_owner::{InstallationKey, InstallationOwner},
        installed_supervisor::InstalledConfig,
    };
    use mvm_core::host_lifetime::EndpointPartitionLimits;
    use mvm_hostd::plan_admission::InMemoryNonceLedger;

    ensure!(std::env::var("SPIRALCORE_RUN_INSTALLED_WITNESS")? == "1");
    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT").context("fixture root missing")?,
    );
    ensure!(root.parent() == Some(std::path::Path::new("/home/callard")));
    ensure!(
        root.file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| name.starts_with(".scw-"))
    );
    ensure!(root.canonicalize()? == root);
    let home = mvm_core::config::mvm_home_strict()?;
    ensure!(home == root.join("mvm"));
    ensure!(!mvm_core::config::vm_state_dir(native_plan::NAME).exists());
    let bind: Ipv4Addr = std::env::var("SPIRALCORE_WICK_PRIVATE_IP")?.parse()?;
    let startup_bytes = quote("SPIRALCORE_NATIVE_STARTUP_RESIDENT_BYTES", 160 * MIB)?;
    let disk_bytes = quote("SPIRALCORE_NATIVE_STARTUP_DISK_BYTES", 224 * MIB)?;

    let elapsed = Instant::now();
    let cpu = cpu_time::ProcessTime::now();
    let peer = native_peer::NativePeer::bind(bind)?;
    let policy = peer.network_policy()?;
    let config = InstalledConfig::canonical_native_profile();
    let owner = InstallationOwner::initialize(
        &root.join("installation"),
        InstallationKey {
            installation: [83; 32],
            profile: config.profile_hash(),
        },
    )?;
    let supervisor = InstalledSupervisor::start(owner, config)?;
    let mut service =
        InstalledResident::prepare(supervisor, LocalBackend::with_hypervisor("firecracker"))?;
    let operator = mvm_core::config::mvm_config_dir_at(&home);
    ensure!(std::fs::read(operator.join("config.toml"))? == b"[egress_proxy]\n");
    let keys = mvm_core::config::mvm_keys_dir();
    ensure!(!keys.exists(), "native fixture key home must be fresh");
    let signer = mvm_hostd::audit::host_keypair::load_or_init_at(&keys)?;
    let host_public = signer.verifying_key().to_bytes();
    drop(signer);

    let limits = EndpointPartitionLimits {
        host_plaintext_bytes: MIB,
        host_codec_bytes: 8 * MIB,
        host_carrier_bytes: 8 * MIB,
        host_metadata_bytes: 70 * MIB,
        host_stack_bytes: 24 * MIB,
        cache_disk_bytes: 32 * MIB,
        staging_disk_bytes: 16 * MIB,
        workers: 7,
        max_streams: 1,
    };
    let supervisor = service.supervisor.as_ref().unwrap();
    let live = service.live.as_mut().unwrap();
    let provider = Arc::get_mut(&mut live.provider).context("provider prematurely published")?;
    provider.configure_endpoints(
        supervisor,
        super::super::endpoint::QualifiedEndpointProfile::fixture(limits),
    )?;
    provider.configure_host_agent(
        supervisor,
        "local",
        super::super::host_agent::QualifiedHostAgentProfile::fixture_with_cold_operator(
            ManagedClaim {
                host_plaintext_bytes: 40 * MIB,
                host_metadata_bytes: 12 * MIB,
                host_stack_bytes: 32 * MIB,
                workers: 2,
                ..Default::default()
            },
            operator,
            Some("on".into()),
        ),
    )?;
    let pool = provider.shared.pool.clone();
    mvm_hostd::host_lifetime_parent::install(live.provider.clone())?;
    service.start_owned_host_agent()?;

    let selection = pool.reserve(
        tenant_tag("local"),
        ManagedClaim {
            host_metadata_bytes: MIB,
            ..Default::default()
        },
    )?;
    let native = native_plan::NativeRequest::verified(&root, peer.address())?;
    let request = native.request()?;
    drop(selection);
    let ledger = InMemoryNonceLedger::new();
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?;
    // Verify the endpoint and boot tail fit while admission owns the token.
    // The original grant funds startup separately until Runtime completes it.
    let prepare = || {
        let disk = pool.reserve(
            tenant_tag("local"),
            ManagedClaim {
                host_metadata_bytes: 32 * MIB,
                staging_disk_bytes: disk_bytes,
                ..Default::default()
            },
        )?;
        let endpoint = pool.reserve(
            tenant_tag("local"),
            ManagedClaim {
                host_plaintext_bytes: limits.host_plaintext_bytes,
                host_codec_bytes: limits.host_codec_bytes,
                host_carrier_bytes: limits.host_carrier_bytes,
                host_metadata_bytes: limits.host_metadata_bytes,
                host_stack_bytes: limits.host_stack_bytes,
                cache_disk_bytes: limits.cache_disk_bytes,
                staging_disk_bytes: limits.staging_disk_bytes,
                workers: u64::from(limits.workers),
                ..Default::default()
            },
        )?;
        drop(endpoint);
        let retained_runtime = pool.reserve(
            tenant_tag("local"),
            ManagedClaim {
                cache_disk_bytes: RETAINED_RUNTIME_QUOTE,
                ..Default::default()
            },
        )?;
        Ok::<_, anyhow::Error>((startup_bytes, (disk, retained_runtime)))
    };
    let mut peer_plan = None;
    let prepared = service.begin_launch_admitted_with_preflight(
        request,
        "local",
        &QualifiedAdmissionFunding {
            metadata_bytes: 160 * MIB,
            retained_metadata_bytes: 128 * 1024,
        },
        || {
            let token = native.admit(&policy, &ledger)?;
            peer_plan = Some(token.plan().clone());
            Ok(token)
        },
        prepare,
    );
    let (id, (disk, retained_runtime)) = match prepared {
        Ok(value) => value,
        Err(error) => {
            service.try_finish()?;
            return Err(error);
        }
    };
    let admission = elapsed.elapsed();

    // This bounded fixture keeps the retained charge even after the native
    // reader exits. Reopening or reclaiming it needs product-level custody.
    let _retained_runtime = NativeCredit(Some(retained_runtime));
    let (result, sealed_bytes, runtime_allocated) = run_roundtrip(
        &mut service,
        &runtime,
        id,
        &peer_plan.context("original signed network plan missing")?,
        peer,
        host_public,
        disk,
        &root,
    )?;
    ensure!(result.received_bytes == 11_600 && result.sent_bytes == 11_600);
    println!(
        "{}",
        serde_json::json!({
            "peer": result,
            "guest_readback_exact": true,
            "original_retirement": true,
            "sealed_telemetry_bytes": sealed_bytes,
            "admission_elapsed_ns": admission.as_nanos(),
            "host_process_cpu_ns": cpu.elapsed().as_nanos(),
            "wall_with_retirement_ns": elapsed.elapsed().as_nanos(),
            "startup_resident_quote": startup_bytes,
            "startup_disk_quote": disk_bytes,
            "retained_runtime_disk_quote": RETAINED_RUNTIME_QUOTE,
            "retained_runtime_allocated_bytes": runtime_allocated,
        })
    );
    Ok(())
}
