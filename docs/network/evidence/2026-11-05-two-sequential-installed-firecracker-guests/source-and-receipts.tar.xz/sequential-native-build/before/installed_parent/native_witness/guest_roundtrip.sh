set -eu
target_host=$1
target_port=$2
busybox=$0
proxy_port=${3:-1080}
scratch=$("$busybox" mktemp -d)
trap '"$busybox" rm -r "$scratch"' EXIT
i=0
while [ "$i" -lt 400 ]; do
    printf '%s\n' '{"kind":"flowmux","value":1}'
    i=$((i + 1))
done > "$scratch/expected"
{
    printf 'CONNECT %s:%s HTTP/1.1\r\nHost: %s:%s\r\n\r\n' "$target_host" "$target_port" "$target_host" "$target_port"
    "$busybox" cat "$scratch/expected"
} | "$busybox" nc -n -w 12 127.0.0.1 "$proxy_port" > "$scratch/reply"
{
    cr=$(printf '\r')
    IFS= read -r status
    [ "$status" = "HTTP/1.1 200 Connection established${cr}" ]
    IFS= read -r end_headers
    [ "$end_headers" = "$cr" ]
    "$busybox" cat > "$scratch/recovered"
} < "$scratch/reply"
"$busybox" cmp "$scratch/expected" "$scratch/recovered"
printf '%s\n' 'spiralcore-guest-readback-exact'
