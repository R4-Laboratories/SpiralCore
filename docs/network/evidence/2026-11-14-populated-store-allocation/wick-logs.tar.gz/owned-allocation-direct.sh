#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export TMPDIR="$q/owned-allocation-tmp"
cd "$q/owned-allocation"
sha256sum -c "$q/owned-allocation-reviewed-source.sha256" > "$q/owned-allocation-direct-source-before.txt"
executable=$(sed -n 's/^     Running tests\/owned_store_allocation.rs (\(.*\))$/\1/p' "$q/owned-allocation-reviewed-focused.log")
[[ "$(realpath "$executable")" == "$q/source/.mvm-test/target/release/deps/owned_store_allocation-"* ]]
sha256sum "$executable" > "$q/owned-allocation-executable-before.sha256"
"$executable" --list --format terse > "$q/owned-allocation-test-list.txt"
/usr/bin/time -v "$executable" --exact populated_owned_stores_recover_and_refuse_overload_with_requested_heap_accounting --show-output --test-threads=1 > "$q/owned-allocation-direct.log" 2>&1
sha256sum "$executable" > "$q/owned-allocation-executable-after.sha256"
cmp "$q/owned-allocation-executable-before.sha256" "$q/owned-allocation-executable-after.sha256"
sha256sum -c "$q/owned-allocation-reviewed-source.sha256" > "$q/owned-allocation-direct-source-after.txt"
