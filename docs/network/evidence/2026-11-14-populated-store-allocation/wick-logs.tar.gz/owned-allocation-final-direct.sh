#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export TMPDIR="$q/owned-allocation-tmp"
cd "$q/owned-allocation"
sha256sum -c "$q/owned-allocation-bound-source.sha256" > "$q/owned-allocation-final-direct-source-before.txt"
executable=$(sed -n 's/^     Running tests\/owned_store_allocation.rs (\(.*\))$/\1/p' "$q/owned-allocation-bound-focused.log")
[[ "$(realpath "$executable")" == "$q/source/.mvm-test/target/release/deps/owned_store_allocation-"* ]]
sha256sum "$executable" > "$q/owned-allocation-final-executable-before.sha256"
/usr/bin/time -v "$executable" --exact populated_owned_stores_recover_and_refuse_overload_with_requested_heap_accounting --show-output --test-threads=1 > "$q/owned-allocation-final-direct.log" 2>&1
sha256sum "$executable" > "$q/owned-allocation-final-executable-after.sha256"
cmp "$q/owned-allocation-final-executable-before.sha256" "$q/owned-allocation-final-executable-after.sha256"
sha256sum -c "$q/owned-allocation-bound-source.sha256" > "$q/owned-allocation-final-direct-source-after.txt"
