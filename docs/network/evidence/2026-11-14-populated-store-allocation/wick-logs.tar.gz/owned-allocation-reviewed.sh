#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/owned-allocation-tmp"
cd "$q/owned-allocation"
sha256sum -c "$q/owned-allocation-reviewed-source.sha256" > "$q/owned-allocation-reviewed-before.txt"
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store_allocation --test owned_store --test owned_store_resources -- --show-output --test-threads=1 > "$q/owned-allocation-reviewed-focused.log" 2>&1
/usr/bin/time -v cargo test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned::tests:: -- --show-output --test-threads=1 > "$q/owned-allocation-reviewed-primitives.log" 2>&1
/usr/bin/time -v cargo clippy --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets --all-features -- -D warnings > "$q/owned-allocation-reviewed-strict.log" 2>&1
sha256sum -c "$q/owned-allocation-reviewed-source.sha256" > "$q/owned-allocation-reviewed-after.txt"
