#![cfg(any(target_os = "linux", target_os = "macos"))]

//! Populated-store qualification, not a native MVM or allocator-resident bound.
#[path = "support/requested_allocations.rs"]
mod allocations;
#[global_allocator]
static ALLOCATIONS: allocations::RequestedAllocations = allocations::RequestedAllocations;

use spiralcore_transfer::{
    client,
    endpoint::Context,
    protocol::Mode,
    resource_profile::ResourceProfile,
    v1::{
        Capabilities, ObjectEndpoint, OrderedBinding, OrderedLane, OrderedObjectEndpoint,
        OwnedLaneNamespaces, OwnedStoreLease, OwnedStorePolicy,
    },
    wan, Error,
};
use std::{
    fs::{self, File, OpenOptions},
    io::Write,
    os::unix::fs::{DirBuilderExt, OpenOptionsExt},
    path::PathBuf,
    sync::{mpsc, Arc},
    time::Instant,
};

const STORES: usize = 2;
// Existing installed MVM611a3c76 workspace quote; no permit or authority is created here.
const WORKSPACE: u64 = 1 << 20;
const BODY: usize = 16 * 1024;
const APP: &[u8] = b"spiralcore.allocation.application.v1\0";
const ART: &[u8] = b"spiralcore.allocation.artifact.v1\0";

struct Store {
    root: PathBuf,
    context: Context,
    other: Context,
}
impl Store {
    fn new(worker: u8, phase: u8) -> Self {
        let root = std::env::temp_dir().join(format!(
            "sc-owned-allocation-{}-{worker}-{phase}",
            std::process::id()
        ));
        fs::DirBuilder::new().mode(0o700).create(&root).unwrap();
        fs::DirBuilder::new()
            .mode(0o700)
            .create(root.join("store"))
            .unwrap();
        Self {
            root,
            context: wan::context([40 + worker; 32]),
            other: wan::context([60 + worker; 32]),
        }
    }
    fn capture(&self) -> OwnedStoreLease {
        let limits = ResourceProfile::SmallV1.receiver_limits();
        OwnedStoreLease::capture(
            Arc::new(File::open(&self.root).unwrap()),
            "store".as_ref(),
            Arc::new(File::open(self.root.join("store")).unwrap()),
            OwnedStorePolicy::small_v1(
                &limits,
                102,
                OwnedLaneNamespaces::Two(
                    self.context.namespace().unwrap(),
                    self.other.namespace().unwrap(),
                ),
            )
            .unwrap(),
        )
        .unwrap()
    }
    fn open(&self, lease: &OwnedStoreLease) -> ObjectEndpoint<wan::BenchAuthority> {
        let caps = Capabilities::small_v1();
        ObjectEndpoint::open_at_with_resource_profile(
            lease,
            ResourceProfile::SmallV1.receiver_limits(),
            wan::BenchAuthority,
            caps.negotiate(&caps).unwrap(),
            ResourceProfile::SmallV1,
        )
        .unwrap()
    }
    fn ordered(
        &self,
        endpoint: ObjectEndpoint<wan::BenchAuthority>,
    ) -> (OrderedBinding, OrderedObjectEndpoint<wan::BenchAuthority>) {
        let binding = OrderedBinding::new(
            &self.context,
            self.context.namespace().unwrap(),
            0,
            APP,
            ART,
        )
        .unwrap();
        let endpoint =
            OrderedObjectEndpoint::new(endpoint, binding.clone(), &self.context).unwrap();
        (binding, endpoint)
    }
    fn namespace(&self) -> PathBuf {
        self.root
            .join("store")
            .join(spiralcore_transfer::hex(&self.context.namespace().unwrap()))
    }
    fn stage_full_tree(&self) -> Vec<PathBuf> {
        let limits = ResourceProfile::SmallV1.receiver_limits();
        assert_eq!((limits.max_publications, limits.max_states), (64, 32));
        let other = self
            .root
            .join("store")
            .join(spiralcore_transfer::hex(&self.other.namespace().unwrap()));
        fs::DirBuilder::new().mode(0o700).create(other).unwrap();
        let mut paths = Vec::new();
        for index in 0..limits.max_states {
            // Valid long stage names exercise repeated iterator refills without growing a list.
            paths.push(
                self.namespace()
                    .join(format!(".stage-{}-{index}", "7".repeat(240))),
            );
        }
        paths.push(self.root.join("store/.profile-123-456"));
        for path in &paths {
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .mode(0o600)
                .open(path)
                .unwrap();
            file.write_all(b"retained recovery stage\0").unwrap();
        }
        paths
    }
}
impl Drop for Store {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.root).unwrap();
    }
}
fn body(index: usize) -> Vec<u8> {
    let mut bytes = vec![0x51; BODY];
    bytes[..8].copy_from_slice(&(index as u64).to_be_bytes());
    bytes[BODY - 3..].fill(0);
    bytes
}
#[derive(Default)]
struct Costs {
    application: u64,
    request: u64,
    reply: u64,
    sender_cpu_ns: u128,
    receiver_cpu_ns: u128,
    readback_cpu_ns: u128,
}
fn populate(store: &Store, costs: &mut Costs) -> OwnedStoreLease {
    let lease = store.capture();
    let (_, mut endpoint) = store.ordered(store.open(&lease));
    let binding = OrderedBinding::new(
        &store.context,
        store.context.namespace().unwrap(),
        0,
        APP,
        ART,
    )
    .unwrap();
    for index in 0..64 {
        let bytes = body(index);
        let cpu = cpu_time::ThreadTime::now();
        let mut receive = 0;
        let stats = client::transfer_batched(
            &bytes,
            Mode::Raw,
            None,
            binding.transfer_id(OrderedLane::Application, index as u64),
            false,
            |frames| {
                let cpu = cpu_time::ThreadTime::now();
                let replies = frames
                    .iter()
                    .map(|frame| {
                        endpoint.handle(
                            OrderedLane::Application,
                            index as u64,
                            &store.context,
                            frame,
                            0,
                        )
                    })
                    .collect();
                receive += cpu.elapsed().as_nanos();
                replies
            },
        )
        .unwrap();
        costs.sender_cpu_ns += cpu.elapsed().as_nanos().checked_sub(receive).unwrap();
        costs.receiver_cpu_ns += receive;
        let cpu = cpu_time::ThreadTime::now();
        assert_eq!(
            endpoint.read_object(&store.context, stats.object).unwrap(),
            bytes
        );
        costs.readback_cpu_ns += cpu.elapsed().as_nanos();
        costs.application += bytes.len() as u64;
        costs.request += stats.request_bytes;
        costs.reply += stats.response_bytes;
    }
    assert_eq!(endpoint.snapshot(&store.context).unwrap().publications, 64);
    drop(endpoint);
    lease
}

struct Gate {
    notify: mpsc::SyncSender<u8>,
    wait: mpsc::Receiver<u8>,
}
impl Gate {
    fn meet(&self, phase: u8) {
        self.notify.try_send(phase).unwrap();
        assert_eq!(
            self.wait
                .recv_timeout(std::time::Duration::from_secs(5))
                .unwrap(),
            phase
        );
    }
}

fn run_store(worker: u8, gate: Gate) -> Costs {
    let mut costs = Costs::default();
    {
        let store = Store::new(worker, 0);
        let lease = populate(&store, &mut costs);
        let stages = store.stage_full_tree();
        // Stop the previous core owner; recovery captures the same private directory anew.
        drop(lease);
        gate.meet(0);
        let mut lease = store.capture();
        let endpoint = store.open(&lease);
        assert!(stages.iter().all(|path| !path.exists()));
        let (_, mut endpoint) = store.ordered(endpoint);
        assert_eq!(endpoint.snapshot(&store.context).unwrap().publications, 64);
        for index in 0..64 {
            let bytes = body(index);
            assert_eq!(
                endpoint
                    .read_object(&store.context, spiralcore_transfer::object_id(&bytes))
                    .unwrap(),
                bytes
            );
        }
        drop(endpoint);
        let owner = File::open(store.root.join("store/.owner")).unwrap();
        gate.meet(1);
        lease.retire_contents().unwrap();
        assert_eq!(fs::read_dir(store.root.join("store")).unwrap().count(), 0);
        assert!(matches!(
            owner.try_lock(),
            Err(fs::TryLockError::WouldBlock)
        ));
        drop(lease);
        owner.try_lock().unwrap();
    }
    {
        let store = Store::new(worker, 1);
        let mut lease = populate(&store, &mut costs);
        let stages = store.stage_full_tree();
        let saved: Vec<_> = (0..64)
            .map(|index| {
                let id = spiralcore_transfer::object_id(&body(index));
                let path = store
                    .namespace()
                    .join(format!("{}.object", spiralcore_transfer::hex(&id)));
                let bytes = fs::read(&path).unwrap();
                (path, bytes)
            })
            .collect();
        let overflow = store.root.join("store/overflow");
        OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(&overflow)
            .unwrap();
        let owner = File::open(store.root.join("store/.owner")).unwrap();
        gate.meet(2);
        assert_eq!(lease.retire_contents(), Err(Error::Limit));
        assert!(matches!(
            owner.try_lock(),
            Err(fs::TryLockError::WouldBlock)
        ));
        assert!(stages.iter().all(|path| path.exists()));
        for (path, bytes) in saved {
            assert_eq!(fs::read(path).unwrap(), bytes);
        }
        assert!(overflow.exists());
        // This failed lease is held until this fixture ends; no refund is asserted.
        drop(lease);
    }
    costs
}

#[test]
fn populated_owned_stores_recover_and_refuse_overload_with_requested_heap_accounting() {
    const CHILD: &str = "SC_OWNED_ALLOCATION_CHILD";
    if std::env::var_os(CHILD).is_none() {
        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "populated_owned_stores_recover_and_refuse_overload_with_requested_heap_accounting",
                "--show-output",
                "--test-threads=1",
            ])
            .env(CHILD, "1")
            .output()
            .unwrap();
        assert!(
            output.status.success(),
            "{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        let stdout = String::from_utf8(output.stdout).unwrap();
        assert!(stdout.contains("test result: ok. 1 passed; 0 failed"));
        assert!(stdout.contains("OWNED_ALLOCATION "));
        print!("{stdout}");
        return;
    }
    let before = allocations::snapshot();
    let clock = Instant::now();
    let cpu = cpu_time::ProcessTime::now();
    let (a, a_rx) = mpsc::sync_channel(1);
    let (b, b_rx) = mpsc::sync_channel(1);
    let gates = [
        Gate {
            notify: a,
            wait: b_rx,
        },
        Gate {
            notify: b,
            wait: a_rx,
        },
    ];
    let results = std::thread::scope(|scope| {
        let workers: Vec<_> = gates
            .into_iter()
            .enumerate()
            .map(|(worker, gate)| scope.spawn(move || run_store(worker as u8, gate)))
            .collect();
        workers
            .into_iter()
            .map(|worker| worker.join())
            .collect::<Vec<_>>()
    });
    let costs: Vec<_> = results.into_iter().map(Result::unwrap).collect();
    let measured = allocations::snapshot();
    let operation = ResourceProfile::SmallV1.operation_charge().unwrap();
    let funded = (operation + WORKSPACE) * STORES as u64;
    assert!(
        (measured.1 as u64) <= funded,
        "requested Rust heap exceeded quoted aggregate"
    );
    let row = serde_json::json!({"stores":STORES,"publications_per_store":64,"recovery_stages_per_store":32,
        "admitted_entry_count":101,"overflow_entry_count":102,"declared_workspace_per_store":WORKSPACE,
        "declared_operation_per_store":operation,"aggregate_declared_bytes":funded,
        "rust_live_before":before.0,"rust_live_after":measured.0,"rust_peak_requested":measured.1,
        "rust_cumulative_requested":measured.2,"wall_ns":clock.elapsed().as_nanos(),"process_cpu_ns":cpu.elapsed().as_nanos(),
        "application_bytes":costs.iter().map(|c|c.application).sum::<u64>(),
        "request_frame_bytes":costs.iter().map(|c|c.request).sum::<u64>(),
        "reply_frame_bytes":costs.iter().map(|c|c.reply).sum::<u64>(),
        "sender_outside_dispatch_cpu_ns":costs.iter().map(|c|c.sender_cpu_ns).sum::<u128>(),
        "receiver_dispatch_cpu_ns":costs.iter().map(|c|c.receiver_cpu_ns).sum::<u128>(),
        "initial_readback_cpu_ns":costs.iter().map(|c|c.readback_cpu_ns).sum::<u128>(),
        "exact_readbacks":true,"retirement_overload_preserved_all_bytes":true,"original_lock_retained_on_refusal":true,
        "scope":"instrumented host process; requested Rust allocations only; no direct libc/allocator overhead/native stacks/RSS/MVM/WAN bound"});
    println!("OWNED_ALLOCATION {row}");
}
