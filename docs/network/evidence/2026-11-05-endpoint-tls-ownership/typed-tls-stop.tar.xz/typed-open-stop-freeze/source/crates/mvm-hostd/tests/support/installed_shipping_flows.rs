//! Process-only peers for the actual shipping controller. No VM/quota grant.
use anyhow::{Result, ensure};
use ed25519_dalek::SigningKey;
use mvm_contract::{
    peer::{PeerBinding, PeerName},
    policy::network_policy::{
        CooperatingPayloadPolicy, CooperatingTcpPeer, NetworkPolicy, PayloadMappingProfile,
    },
    protocol::network_flow::{Opcode, hello::Handshake},
};
use mvm_core::net::session::Session;
use mvm_vmm::host::network_endpoint_spawn::AdmittedNetworkPlan;
use std::{
    io::Read,
    net::TcpListener,
    os::{
        fd::AsRawFd,
        unix::net::{UnixListener, UnixStream},
    },
    path::Path,
    thread::JoinHandle,
    time::Duration,
};

use super::installed_factory::{self as factory, TARGET, receive, send};

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum FlowCase {
    Mapped,
    Unmapped,
    PartialAuth,
    StalledTls,
}
const UNMAPPED: &str = "plain.mvm.peer";

pub(crate) struct OriginalPeer {
    case: FlowCase,
    listener: Option<TcpListener>,
    identity: spiralcore_mvm_flowmux::tls::PinnedIdentity,
    worker: Option<JoinHandle<()>>,
    setup_event: Option<UnixListener>,
}
impl OriginalPeer {
    pub(crate) fn new(case: FlowCase) -> Result<Self> {
        let listener = TcpListener::bind("127.0.0.1:0")?;
        listener.set_nonblocking(true)?;
        Ok(Self {
            case,
            listener: Some(listener),
            identity: factory::identity(&SigningKey::from_bytes(&[8; 32])),
            worker: None,
            setup_event: None,
        })
    }
    pub(crate) fn policy(&self) -> Result<NetworkPolicy> {
        let address = self.listener.as_ref().unwrap().local_addr()?;
        let mut peers = vec![PeerBinding {
            name: PeerName::parse(TARGET)?,
            port: 443,
            host_addr: address.ip().to_string(),
            host_port: address.port(),
        }];
        if self.case == FlowCase::Unmapped {
            peers.push(PeerBinding {
                name: PeerName::parse(UNMAPPED)?,
                port: 443,
                host_addr: address.ip().to_string(),
                host_port: address.port(),
            });
        }
        Ok(NetworkPolicy::deny_all()
            .with_peers(peers)
            .with_payload_mapping(Some(CooperatingPayloadPolicy::new(vec![
                CooperatingTcpPeer {
                    host: TARGET.into(),
                    port: 443,
                    server_name: TARGET.into(),
                    spki_sha256: self.identity.spki_sha256(),
                    profile: PayloadMappingProfile::SpiralCoreObjectStreamSmallV1,
                },
            ])?)))
    }
    pub(crate) fn start(&mut self, plan: &AdmittedNetworkPlan, state: &Path) -> Result<()> {
        if matches!(self.case, FlowCase::Mapped | FlowCase::StalledTls) {
            let case = if self.case == FlowCase::StalledTls {
                let event = UnixListener::bind(state.join("setup-seen.sock"))?;
                event.set_nonblocking(true)?;
                self.setup_event = Some(event);
                factory::Case::StalledTls
            } else {
                factory::Case::Duplex
            };
            let listener = self.listener.take().unwrap();
            let address = listener.local_addr()?;
            let identity = factory::identity(&SigningKey::from_bytes(&[8; 32]));
            let config = serde_json::json!({
                "admitted_network_plan": plan,
                "flowmux_identity": {"session_id": hex::encode([3; 32])},
            });
            let state = state.to_owned();
            self.worker = Some(std::thread::spawn(move || {
                factory::peer(listener, address, identity, config, case, state);
            }));
        }
        Ok(())
    }
    pub(crate) fn join_after_stop(&mut self) -> Result<()> {
        self.worker
            .take()
            .expect("original cooperating peer")
            .join()
            .map_err(|_| anyhow::anyhow!("original cooperating peer failed after stop"))
    }
    pub(crate) fn exchange(
        &mut self,
        guest: &mut UnixStream,
        session: &mut Session,
    ) -> Result<bool> {
        send(
            guest,
            session,
            Opcode::Hello,
            0,
            &Handshake::local("shipping-payload-fixture").encode(),
        );
        ensure!(receive(guest, session).0 == Opcode::HelloAck);
        let target = if self.case != FlowCase::Unmapped {
            TARGET
        } else {
            UNMAPPED
        };
        send(
            guest,
            session,
            Opcode::OpenTcp,
            1,
            format!("{target}:443").as_bytes(),
        );
        if self.case == FlowCase::StalledTls {
            let listener = self.setup_event.as_ref().unwrap();
            let mut event = libc::pollfd {
                fd: listener.as_raw_fd(),
                events: libc::POLLIN,
                revents: 0,
            };
            // SAFETY: bounded wait on the original test event descriptor. The
            // source peer writes only after reading the first actual TLS byte.
            ensure!(
                unsafe { libc::poll(&mut event, 1, 3000) } > 0,
                "original TLS setup event missing"
            );
            let (mut notification, _) = listener.accept()?;
            notification.set_read_timeout(Some(Duration::from_secs(1)))?;
            let mut byte = [0; 1];
            notification.read_exact(&mut byte)?;
            ensure!(byte == [1]);
            eprintln!("original admitted TLS handshake is blocked before parent stop");
            return Ok(true);
        }
        let (opcode, id, body) = receive(guest, session);
        if self.case == FlowCase::Unmapped {
            // Check only after the response: old Opened implies connect already
            // happened; no timeout/sleep can hide a late connection here.
            let zero_dial = match self.listener.as_ref().unwrap().accept() {
                Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => true,
                Ok((socket, _)) => {
                    drop(socket);
                    false
                }
                Err(error) => return Err(error.into()),
            };
            eprintln!("unmapped original response={opcode:?} zero_dial={zero_dial}");
            return Ok(opcode == Opcode::Refused && id == 1 && zero_dial);
        }
        ensure!(
            opcode == Opcode::Opened && id == 1,
            "mapped open refused: {}",
            String::from_utf8_lossy(&body)
        );
        let expected = factory::payload();
        send(guest, session, Opcode::Data, 1, &expected);
        send(guest, session, Opcode::HalfClose, 1, &[]);
        let mut received = Vec::with_capacity(expected.len());
        loop {
            let (opcode, id, body) = receive(guest, session);
            ensure!(id == 1);
            match opcode {
                Opcode::WindowUpdate => {}
                Opcode::Data => {
                    ensure!(
                        received.len() + body.len() <= expected.len(),
                        "excess application bytes"
                    );
                    received.extend_from_slice(&body);
                }
                Opcode::HalfClose => break,
                other => anyhow::bail!("unexpected mapped frame {other:?}"),
            }
        }
        ensure!(received == expected, "exact original guest response bytes");
        self.worker
            .take()
            .unwrap()
            .join()
            .map_err(|_| anyhow::anyhow!("original cooperating peer failed"))?;
        eprintln!(
            "actual mapped application readbacks {} bytes each direction; canonical artifacts verified at original peer",
            expected.len()
        );
        Ok(true)
    }
}
impl Drop for OriginalPeer {
    fn drop(&mut self) {
        // The canonical peer has its original bounded I/O deadline. Never
        // discard its original handle on a fixture refusal/error path.
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}
