//! Split control enforcement and actual public-default compatibility.
use super::*;
use crate::policy::PiiPolicy;

fn bounded(pattern: &[u8]) -> Vec<u8> {
    let mut result = Vec::with_capacity(32_768);
    while result.len() < 32_768 {
        result.extend_from_slice(&pattern[..pattern.len().min(32_768 - result.len())]);
    }
    while std::str::from_utf8(&result).is_err() {
        result.pop();
    }
    result.resize(32_768, b' ');
    result
}
fn orders() -> Vec<Vec<usize>> {
    fn visit(prefix: &mut Vec<usize>, used: u8, out: &mut Vec<Vec<usize>>) {
        for index in 0..5 {
            if used & (1 << index) == 0 {
                prefix.push(index);
                out.push(prefix.clone());
                visit(prefix, used | (1 << index), out);
                prefix.pop();
            }
        }
    }
    let mut result = Vec::with_capacity(325);
    visit(&mut Vec::with_capacity(5), 0, &mut result);
    assert_eq!(result.len(), 325);
    result
}
#[test]
fn split_controls_are_reported_and_both_builder_stages_refuse_independently() {
    let policy = PiiPolicy::default();
    let base = PiiRedactor::owned_pii_requirements(&policy).unwrap();
    assert_eq!(base.nfa_size_limit_bytes, 524_288);
    assert_eq!(base.rule_nfa_size_limit_bytes, 131_072);
    assert_eq!(base.dfa_cache_limit_bytes, 262_144);
    assert_eq!(base.nest_limit, 64);
    assert_eq!(base.max_concurrent_searches, 1);
    for (set, rule) in [(1, 131_072), (524_288, 1)] {
        let mut controls = base;
        controls.nfa_size_limit_bytes = set;
        controls.rule_nfa_size_limit_bytes = rule;
        let result =
            PiiRedactor::build_owned(PiiRedactor::owned_selection(&policy).unwrap(), controls);
        assert!(
            matches!(
                result,
                Err(PiiPolicyError::OwnedPolicy(
                    "owned PII regex controls refused construction"
                ))
            ),
            "a builder stage ignored its enforced control"
        );
    }
}
#[test]
fn public_split_defaults_preserve_all_325_orders_and_repeated_searches() {
    let cases = [
        bounded(b"synthetic@example.invalid 001-01-0001 4111111111111111 +12025550123 GB82WEST12345698765432\n"),
        bounded("\u{03bb}\u{754c} no-at-domain 000-00-0000 1111111111111 +abcdef GB00INVALID000000000000 \n".as_bytes()),
        bounded(b"ordinary-synthetic-telemetry-without-sensitive-shaped-fields; "),
    ];
    let all = orders();
    for (index, order) in all.iter().enumerate() {
        let policy = PiiPolicy {
            mode: Some("redact".into()),
            categories: order
                .iter()
                .map(|&i| DEFAULT_RULES[i].name.to_owned())
                .collect(),
        };
        let facts = PiiRedactor::owned_pii_requirements(&policy).unwrap();
        assert_eq!(
            (facts.nfa_size_limit_bytes, facts.rule_nfa_size_limit_bytes),
            (524_288, 131_072)
        );
        let scanner = PiiRedactor::curated_owned(&policy).unwrap();
        let legacy = PiiRedactor::from_policy(&policy).unwrap().unwrap();
        assert_eq!(
            scanner.redact(&cases[0]),
            legacy.redact(&cases[0]),
            "split public selection {} differed",
            index + 1
        );
    }
    let policies = [
        PiiPolicy {
            mode: Some("redact".into()),
            categories: vec![],
        },
        PiiPolicy {
            mode: Some("redact".into()),
            categories: vec!["iban".into(), "email".into(), "credit_card".into()],
        },
    ];
    let mut searches = 0;
    for policy in &policies {
        let scanner = PiiRedactor::curated_owned(policy).unwrap();
        let legacy = PiiRedactor::from_policy(policy).unwrap().unwrap();
        for bytes in &cases {
            let expected = legacy.redact(bytes);
            for _ in 0..9 {
                assert_eq!(scanner.redact(bytes), expected);
                searches += 1;
            }
        }
    }
    assert_eq!(searches, 54);
    for mode in [
        None,
        Some("detect"),
        Some("redact"),
        Some("refuse"),
        Some("disabled"),
    ] {
        let policy = PiiPolicy {
            mode: mode.map(str::to_owned),
            categories: vec![],
        };
        let scanner = PiiRedactor::curated_owned(&policy).unwrap();
        let legacy = PiiRedactor::from_policy(&policy)
            .unwrap()
            .unwrap_or_else(PiiRedactor::with_default_rules);
        assert_eq!(scanner.mode(), legacy.mode());
        assert_eq!(scanner.scan(&cases[0]), legacy.scan(&cases[0]));
        assert_eq!(
            scanner.match_spans(&cases[0]),
            legacy.match_spans(&cases[0])
        );
        assert_eq!(scanner.redact(&cases[0]), legacy.redact(&cases[0]));
    }
    println!(
        "{{\"scope\":\"public-split-default-compatibility\",\"set_nfa\":524288,\"rule_nfa\":131072,\"ordered_policies\":325,\"exact_legacy_tuples\":325,\"representative_searches\":54,\"default_mode_cases\":5}}"
    );
}
