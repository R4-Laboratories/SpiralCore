#!/bin/bash
set -euo pipefail
root=/var/tmp/spiralcore-pii-dual-20261104
out="$root/validation/dual-strict"
mkdir -p "$out"
cd "$root/source"
sha256sum crates/mvm-core/src/pii.rs crates/mvm-core/src/owned_capacity_tests.rs crates/mvm-core/src/owned_dual_tests.rs crates/mvm-hostd/src/telemetry_collector/owned.rs crates/mvm-hostd/src/telemetry_collector/owned_dual_model_tests.rs crates/mvm-hostd/src/installed_endpoint/auxiliary_tests.rs Cargo.toml Cargo.lock "$root/audit-flow-intermediate.toml" > "$out/source-before.sha256"
set +e
CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/var/tmp/spiralcore-pii-capacity-20261104/target CARGO_PROFILE_RELEASE_LTO=false /home/callard/.cargo/bin/cargo +1.97.1 clippy --config "$root/audit-flow-intermediate.toml" --release --offline --locked -p mvm-core --no-default-features --features host-state --lib --message-format=json -- -D clippy::all > "$out/core.jsonl" 2> "$out/core.stderr"
s=$?
printf '%s\n' "$s" > "$out/core.exit"
set -e
test "$s" -eq 0
set +e
CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/var/tmp/spiralcore-pii-capacity-20261104/target CARGO_PROFILE_RELEASE_LTO=false /home/callard/.cargo/bin/cargo +1.97.1 clippy --config "$root/audit-flow-intermediate.toml" --release --offline --locked -p mvm-hostd --lib --message-format=json -- -D clippy::all > "$out/hostd.jsonl" 2> "$out/hostd.stderr"
s=$?
printf '%s\n' "$s" > "$out/hostd.exit"
set -e
sha256sum -c "$out/source-before.sha256" > "$out/source-check.txt"
python3 - "$out" <<'PY'
import json,pathlib,sys
out=pathlib.Path(sys.argv[1]);summary={}
for name in ['core','hostd']:
 rows=[json.loads(x) for x in (out/(name+'.jsonl')).read_text().splitlines()];messages=[x for x in rows if x.get('reason')=='compiler-message'];summary[name]={'exit':int((out/(name+'.exit')).read_text()),'warnings':sum(x['message']['level']=='warning' for x in messages),'errors':sum(x['message']['level']=='error' for x in messages)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
PY
exit "$s"
