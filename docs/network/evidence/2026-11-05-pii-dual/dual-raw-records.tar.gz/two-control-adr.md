# ADR: Separate owned PII set and individual-rule NFA controls

Date: 2026-11-04. Author role: scoped independent Architect (`pii_512_review`).

**Status: DESIGN APPROVED for a separately authorized bounded implementation and qualification. No production change or runtime acceptance is approved by this ADR.** Root retains author/lane dispatch authority. The selected512 predecessor and its independent review remain immutable. No builds, source edits, new agents or outside comments were performed for this ADR.

## Context and evidence boundary

The existing Core `OwnedPiiRequirements` exposes one `nfa_size_limit_bytes=524288`, consumed by both the actual combined `RegexSetBuilder` and every canonical per-rule `RegexBuilder`. DFA is262144, nesting64 and maximum concurrent searches1. `curated_owned` obtains the actual query and invokes the private `build_owned`; callers cannot pass altered requirements to that public production constructor. Hostd queries those same facts, accepts one exact qualified profile and computes its checked requested-workspace declaration before construction under the original component permit.

Read the actual selected512 Core leaf/query/builders and Hostd collector/scanner requirement code from the retained handoff. The singleton packet's actual Core production prefix matches that selected512 baseline; its appended tests do not implement split controls. The reviewed Hostd custody-reference body is not a sync input for another owner's newer producer. The author must rebase the narrow scanner guard/model change onto the coherent current owner-approved Hostd source and requalify that closure.

The actual fixed25 singleton cases comprise five canonical rules times five registered uniform caps. The raw records contain25 unique pairs,19 accepted,6 refused and38 exact legacy tuple comparisons. All five singleton pairs pass131072 and524288. A successful singleton at131072 built BOTH its one-pattern Set and its individual Regex with the unchanged canonical pattern/options; therefore that observation is sufficient compatibility evidence for each same individual Regex at131072 in this fixed source/configuration. It does not prove aggregate simultaneous memory, all-input behavior, a mathematical minimum or broader platform qualification.

A refusal from the current common static error does NOT locate a failing stage or prove an individual Regex needs that much space. The rejected combined256/128 experiment likewise does not, by itself, isolate the combined Set as the failing stage. Keep512 for the combined Set because that complete ordered-policy profile is qualified and no smaller complete uniform profile passed; do not claim a proven minimum combined-Set requirement. Fresh execution under the actual split controls is mandatory.

The singleton semantic object used LTOoff. Its results cannot inherit the predecessor's LTO/public allocator qualification or establish a speed/heap/network improvement.

## Decision: one additional scalar fact

Append exactly one public field to `OwnedPiiRequirements`:

`pub rule_nfa_size_limit_bytes: usize`

The actual owned query returns `nfa_size_limit_bytes=524288` and `rule_nfa_size_limit_bytes=131072`. Keep the existing field name for the combined Set, with explicit documentation; do not rename existing consumers unnecessarily or add per-rule arrays, generalized runtime profiles, a public mutable-controls constructor, new policy fields or new authority.

Required field documentation:

- `nfa_size_limit_bytes`: approximate NFA construction cap actually supplied to the single combined RegexSet. It is also the maximum per-engine NFA cap in this exact selected owned profile; it is not a sum/aggregate scanner heap/RSS bound and no longer means that every individual Regex receives this same cap.
- `rule_nfa_size_limit_bytes`: uniform approximate NFA construction cap supplied separately to each canonical individual Regex; no per-category exception or silent fallback.
- Existing DFA/nesting/concurrency/count fields retain their current meaning. The type and query describe enforced controls and selected engine counts, not a reservation, capability or memory proof.

Keep the production path:

```text
owned policy -> Core query { k, k+1, S512, R128, D256, nest64, concurrency1 }
                    |                            |
                    v                            v
       Hostd exact guard + checked model     private Core build_owned
                    |                        SetBuilder(S), RegexBuilder(R) x k
                    v                            |
       original same-pool component charge -----+-> actual owned scanner lifetime
```

SetBuilder continues to receive `.size_limit(requirements.nfa_size_limit_bytes)`. Each original individual RegexBuilder instead receives `.size_limit(requirements.rule_nfa_size_limit_bytes)`. Both retain explicit Unicode true, original DFA262144/nest64, canonical patterns/order/validators and static refusal errors. `curated_owned` must continue to obtain its own actual query rather than accept caller controls. Test-only mutation stays private to Core unit tests.

## Hostd guard and checked declaration

The existing entry point `owned_scanner_requested_bytes(policy)` must query through the existing StreamRedaction wrapper, which forwards the actual Core facts rather than duplicating the requirements type or inventing a cheaper policy quote. Accept the one exact profile: S524288, R131072, D262144, nest64, concurrency1, k<=5 and regex_objects==k+1, with existing canonical-selection invariants unchanged. Reject unsupported profile mismatches; do not accept a range or substitute constants for mismatching query facts.

A small private facts-to-charge helper is permitted if needed to test the real guard. If introduced, the production entry point must delegate to that single helper using its actual query, and unit tests must exercise that same helper. It may not be a public arbitrary-profile API, second quota or copied accounting implementation.

Using actual queried values, define:

```text
EngineBound(N,D) = 8*N + 2*D + 1_048_576 + 40_960
CompilerOverlap(S,R) = 8*max(S,R) + 1_048_576
Scanner(k,S,R,D) = EngineBound(S,D) + k*EngineBound(R,D)
                   + CompilerOverlap(S,R)
```

Use checked conversions/multiplication/addition at every variable arithmetic step. Compute max(S,R) from the actual facts even though this exact profile fixes S>R. Preserve the8x multiplier, each engine's2xDFA term, every fixed term and compiler overlap; no coefficient discount follows from singleton success. There is exactly one Set and k individual Regex objects. Do not multiply the Set's larger cap by all engines, omit the Set, omit per-engine fixed/cache terms or replace the compiler-overlap term with the smaller rule cap.

At S524288/R131072/D262144:

| Term | Bytes |
|---|---:|
| Single Set EngineBound |5,808,128|
| Each rule EngineBound |2,662,400|
| CompilerOverlap |5,242,880|
| Scanner k=1 |13,713,408|
| Scanner k=2 |16,375,808|
| Scanner k=3 |19,038,208|
| Scanner k=4 |21,700,608|
| Scanner k=5 |24,363,008|

Maximum uniform512 declaration was40,091,648. The difference15,728,640 is15MiB per maximal scanner. This is a smaller source-enforced declared workspace under preserved model assumptions, not measured heap/RSS reclaimed or a formal bound.

`owned_collector_requirements` retains its actual separate metadata27,394,048 and all worker/native stack terms. The prospective maximal total is27,394,048+24,363,008=51,757,056 versus67,485,696. Preserve same-pool charge-before-construction, original permit custody and conservative cleanup/quarantine lifetime. Never reprice/refund an existing scanner or lower other metadata, helper, queue, main/worker/native-stack, carrier/TLS, reader/relay or session terms as part of this change.

## Interface compatibility and versioning

This is an internal Rust control-facts/model revision, not an MVM wire/protocol/envelope/capability/DNS/rate/audit-authority change. The existing requirements type has no stable ABI or serialization contract being extended by this design; introduce neither Serde/repr nor a wire field/version.

Adding a public Rust struct field can break exhaustive struct initializers and destructuring patterns. Document that source-compatibility consequence and inventory every actual consumer in the coherent Core/Hostd/SDK/adapter graph. Rebuild/update affected consumers against one pinned Core revision under the repository's crate-release policy; do not advertise this as universally source-compatible merely because it is additive. Preserve existing field meanings except the now-explicit Set-versus-rule distinction. Do not add a gratuitous runtime version field. Pin the new internal source/model revision and evidence separately from the prior512 revision; follow existing crate version/release requirements where applicable.

An old Hostd model seeing the new query may still conservatively price all engines at512, but that is not qualification of the new quote or an acceptable evidence substitution. A new Hostd expecting the added field cannot consume an old Core definition. Mixed closures cannot obtain split-profile acceptance. Verify there is one actual Core source and no stale/copy implementation supplying different facts to builder and accounting paths.

## Required RED/GREEN and qualification sequence

1. **Freeze baseline and preserve history.** Obtain Root's lane/owner confirmation, use a new owned source closure, retain selected512 and singleton snapshots/packets, and pin Core/Contract/Hostd/manifest/lock/config/test sources. No dependency refresh, VM, raw payload store, multiplier change or wider producer sync. Record exact baseline source and binaries.
2. **Genuine field-absence RED.** Add the focused public query contract test expecting both fields and exact selected values; against actual prior512 Core it must fail for the absent field. Retain the compiler diagnostic and distinguish expected API absence from unrelated compiler/lock failures. This compile RED alone is not enforcement/guard evidence.
3. **Independent actual Aux60MiB RED before product changes.** Add a focused actual AuxiliaryLedger admission fixture that uses existing public requirement queries and an actual60MiB=62,914,560 prepaid metadata domain, with existing separately supplied stack credit. The old source-derived collector67,485,696 request must refuseWouldBlock. The test's desired post-change admission must fail for that actual reason. Do not calculate the new51,757,056 quote in a shadow ledger to manufacture RED.
4. **Minimal coherent product change.** Add/document the one fact, assign actual builder stages, require both exact caps in Hostd, and implement the one checked formula above. Preserve non-scanner requirements and same-pool custody. Update existing assertions and necessary affected Rust consumers only.
5. **Actual Aux GREEN and guard checks.** Against the selected split source, the SAME60MiB fixture must obtain actual scanner24,363,008 / collector51,757,056 from the actual query/model and admit. Its remainder is11,157,504; the SAME ledger must refuse remainder+1 and a duplicate Collector claim. Test the actual private guard/model rejecting unsupported Set/Rule values independently, plus unchanged DFA/nest/concurrency/count mismatches, without exposing mutable runtime controls. Prove that the product guard and public query are the source of the quote.
6. **Fresh default/control/enforcement tests.** Public facts assert S512/R128 and all unchanged fields/counts. Private tests set only S to1 with R at the qualified default and require refusal; separately set only R to1 with S at its qualified default and require refusal. These make ignoring either field observable. Keep static error/no-payload behavior and no fallback. Test empty/default, disabled with selected categories, detect/redact/refuse, Unicode/near misses, validators and unknown/duplicate/oversize refusal through original public APIs.
7. **Fresh325 compatibility under actual public split defaults.** Run all325 nonempty ordered canonical policies through `curated_owned`, without mutated controls, and compare exact masked bytes AND ordered rule-name tuple against unchanged legacy behavior. Include the prior maximal ordering and default/full-set safety cases. Run the fixed54 representative first/repeat searches and five default/mode cases under the split defaults. Reject the profile on any constructor/equality failure; no policy removal, category omission, option change or fallback. This is fresh split-profile evidence; old uniform512 or singleton passes cannot substitute.
8. **One fresh public allocator treatment.** Reuse the reviewed single-thread actual public witness with minimal query/report updates to emit BOTH control facts outside measured windows, preserve its generator/order/input/allocator accounting and protect/hash the new actual binary. Execute one new325-constructor run and one bounded sample against the split query. Verify325 unique completed rows, exact legacy tuples, every postdrop delta0, sticky faults absent, actual peak/retained/search/coexistence observations and source/binary/lock stability. Label any reused semantic/allocator coverage overlap rather than summing duplicate executions into unique tests. Preserve prior raw results unchanged; do not retag a uniform512 binary as split. Actual allocation may remain unchanged.
9. **Exact closure checks and independent review.** Focused Core and Hostd/ledger tests, scoped strict Clippy/checks and the required actual consumer closure must pass on the final source. Retain every failed attempt and distinguish LTO/features/configurations. Obtain independent Code/Rust/Security/privacy-compliance review after implementation; this Architect ADR is not an independent review of its eventual code. Revalidate exact release source before any integration/merge. Any source-model/query/builder/guard divergence blocks acceptance.

### Historical private test trap

Existing capacity and singleton test helpers mutate only `nfa_size_limit_bytes`. After the new field exists, that would silently turn an old uniform-cap experiment into a Set-only variation while individual rules stay at the new128 default. For any retained executable historical-uniform test, explicitly set BOTH fields to its registered candidate before invoking private build_owned. Otherwise preserve that test solely in the immutable historical snapshot and use a newly named two-control helper. Do not relabel existing25/325 results or silently change their treatment meaning. Public split qualification must always use the unmodified query facts.

## Alternatives and consequences

- **Uniform128 for every engine:** rejected as an accepted implementation route by the actual prior finite failures; it cannot replace qualified512 default behavior.
- **Reduce only accounting:** rejected; new lower quote requires actual per-stage controls and exact Hostd agreement.
- **Per-rule cap arrays/stage-specific dynamic tuning:** rejected for this bounded change; uniform128 is the demonstrated common singleton cap and avoids new policy/authority/configuration surfaces.
- **Rename the existing cap or expose caller controls:** rejected as unnecessary interface expansion. Keep one added scalar and the original private builder.
- **Keep uniform512:** valid conservative rollback when no split profile qualifies. Roll back the coherent query/builder/guard/model together for future construction while preserving original live-object permits and evidence.

The cost is one additional internal fact, required consumer source updates and fresh whole-closure qualification. The potential benefit is15MiB less declared scanner envelope per maximal endpoint. This design makes no causal CPU, physical memory, energy, networking or application-performance claim.

## Capacity and delivery gates remain OPEN

The unchanged partial worksheet becomes one endpoint162,867,132, leaving105,568,324 under268,435,456. Two endpoints become237,653,880, leaving30,781,576 before all remaining positive terms. These values are conditional arithmetic, not a fit, capacity or RSS result. Root/helper/native supplements, carrier/TLS, reader/relay, bootstrap and persistent-session terms remain separately charged and require a complete source-coupled worksheet and native execution. The256MiB tenant ceiling stays unchanged.

One or two endpoint capacity, sustained concurrency/fairness/backpressure/recovery/tails, supported Linux/macOS/Windows native roles, real WAN, outside-contributor delivery and FIPS/CUI remain OPEN. No gate is closed by25 singleton constructor outcomes or by this ADR.

## Source/evidence pins used for this decision

- selected512 Core handback: `d5e850eb54be8c2313b934967fb30ca04649cff32105e5545a78c4a1fcb6b984`.
- selected512 Hostd custody-reference leaf (guard/model/query context only, NOT whole-body sync): `c882da894ac7c95033cefc632553dd980f24bd39ef932c2bee3d59bab09c72d8`.
- unchanged prior independent review: `7d2d07533eae778e4a04b8ab7374e672cfcf6a3827b60a7c748aca214af09610`.
- singleton plan: `426bc979843dce3753a23a13dc4f01d98092f4bc9344bddc99099ed0bdbdc8ab`.
- singleton proposal: `bdd7a0ba589261ccbd5a9ffb5adeb24bc4c9879d6208c5c2a0c847bb98594c5a`.
- singleton archive: `1a45689e60966cbcc1fb7a73e746453a2909084ce57b68fbf760aac731bd18da` (89,448 bytes;22 members;21 member hashes verified).
- singleton actual Core with test modules: `53dfa366045e37b5244649f8888f796bf100a7792ce16176a800f84c7a3daf2a`; production prefix matched selected512.
- singleton test source: `5852eabe213fde4ab43a843ac1dbc07bd251f5dc7d43af2fe175947c59c2f84e`.
- recorded singleton protected semantic object: `b45e5268bde11bb0ec12ab7eb8d6f5c3ff73e4a02ea39765efddfe35df5f6cdb`; original remote binary not independently executed/rehashed by Architect.

Logical roster `5e31d33c344d39b0` revalidated; actual Architect role active. This ADR approves only the narrow design described above and its explicitly gated authoring/qualification sequence.
