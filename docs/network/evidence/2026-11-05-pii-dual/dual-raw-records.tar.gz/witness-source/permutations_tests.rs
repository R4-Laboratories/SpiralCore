#[path = "permutations.rs"]
mod permutations;

#[test]
fn enumerates_every_nonempty_ordered_five_rule_selection_once() {
    let choices = permutations::all_policy_orders();
    assert_eq!(choices.len(), 325);
    let mut counts = [0; 5];
    let mut unique = std::collections::BTreeSet::new();
    for choice in choices {
        assert!((1..=5).contains(&choice.len()));
        let mut mask = 0u8;
        for &index in &choice {
            assert!(index < 5);
            assert_eq!(mask & (1 << index), 0);
            mask |= 1 << index;
        }
        counts[choice.len() - 1] += 1;
        assert!(unique.insert(choice));
    }
    assert_eq!(counts, [5, 20, 60, 120, 120]);
}
