# Owned scanner requested-allocation witness

Architect-approved isolated measurement, 2026-11-04. No copied scanner or codec.
Use the actual frozen owned mvm-core constructor and one main thread. Product
and gate files stay unchanged. This measures requested Rust allocations and CPU
only, not native/C allocation, RSS, a formal arbitrary-input bound or FIPS.

1. Counter arithmetic missing-API RED, then checked allocation/deallocation/
   realloc/live-baseline implementation. Flags on impossible arithmetic.
2. Wrap System GlobalAlloc: count successful operations only. No allocation or
   logging inside allocator callbacks. Report realloc old+new overlap separately
   as conservative accounting, not an observed allocator-internal peak.
3. Prepare bounded synthetic inputs before the scanner baseline. Construct,
   first search/redact, repeated search/redact and drop on the same thread,
   without scanner clones. Compare actual legacy/owned results outside the
   owned measurement window. Record source pins, controls, requested heap,
   thread CPU and wall time; preserve probe overhead rather than subtracting it.
4. Execute from one frozen MVM closure on Wick, only after a heavy build lane
   becomes free. Protect binary and compare source before/after. Retain failures
   and compact source/results; do not import payload stores or build trees.

## Preregistered finite constructor extension

Before executing the extension, enumerate every nonempty ordered subset of the
five actual DEFAULT_RULES: 5 +20 +60 +120 +120 =325. No foreign/custom pattern is
admitted. For each configuration measure the actual owned constructor in the
same binary/OS/feature closure, check canonical legacy output outside that
window, then drop and record retained-state delta. Default/disabled reuse the
full canonical pattern set; modes do not change the compiled regex machines.
This exhausts the admitted constructor selections, not every search input,
allocator implementation, CPU target, OS or whole-process/RSS state. Search
workspace still needs the 32KiB input/cache-capacity source model and stress.
