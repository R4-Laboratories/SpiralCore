/// The actual admitted constructor has five fixed rules and rejects duplicates.
/// Enumerate every nonempty ordered selection; no regex implementation is copied.
pub fn all_policy_orders() -> Vec<Vec<usize>> {
    fn visit(prefix: &mut Vec<usize>, used: u8, result: &mut Vec<Vec<usize>>) {
        for index in 0..5 {
            if used & (1 << index) != 0 {
                continue;
            }
            prefix.push(index);
            result.push(prefix.clone());
            visit(prefix, used | (1 << index), result);
            prefix.pop();
        }
    }
    let mut result = Vec::with_capacity(325);
    visit(&mut Vec::with_capacity(5), 0, &mut result);
    result
}
