//! Measurement-only System wrapper. Allocator usable size/C allocations/RSS
//! are deliberately outside these requested-byte counters.
use crate::accounting::Accounting;
use std::alloc::{GlobalAlloc, Layout, System};

pub static COUNTERS: Accounting = Accounting::new();
pub struct Tracked;

// SAFETY: Every operation delegates exactly once to System with the caller's
// original valid pointer/layout. Counter operations allocate nothing, log
// nothing and never unwind on arithmetic faults. This wrapper owns no memory.
unsafe impl GlobalAlloc for Tracked {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: GlobalAlloc's caller supplied the valid layout.
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() {
            COUNTERS.allocate(layout.size());
        }
        pointer
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        // SAFETY: The same caller layout is forwarded to System.
        let pointer = unsafe { System.alloc_zeroed(layout) };
        if !pointer.is_null() {
            COUNTERS.allocate(layout.size());
        }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        // SAFETY: The original pointer/layout belongs to this System wrapper.
        unsafe { System.dealloc(pointer, layout) };
        COUNTERS.deallocate(layout.size());
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: GlobalAlloc's caller supplies the original allocation and
        // valid nonzero new size, forwarded unchanged to System.
        let next = unsafe { System.realloc(pointer, layout, new_size) };
        if !next.is_null() {
            COUNTERS.reallocate(layout.size(), new_size);
        }
        next
    }
}
