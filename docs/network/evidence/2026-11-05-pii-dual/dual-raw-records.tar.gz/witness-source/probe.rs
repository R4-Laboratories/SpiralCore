//! Synthetic, single-thread scanner witness; no networking or customer data.
mod accounting;
mod allocator;
mod permutations;
use allocator::{COUNTERS, Tracked};
use cpu_time::ThreadTime;
use mvm_core::{pii::PiiRedactor, policy::PiiPolicy};
use std::{hint::black_box, time::Instant};

#[global_allocator]
static ALLOCATOR: Tracked = Tracked;

#[derive(Clone, Copy)]
struct Row {
    selection: usize,
    policy: &'static str,
    case: &'static str,
    phase: &'static str,
    input_bytes: usize,
    operations: usize,
    before: accounting::Snapshot,
    after: accounting::Snapshot,
    cpu_ns: u128,
    wall_ns: u128,
}
fn measured<T>(
    policy: &'static str,
    case: &'static str,
    phase: &'static str,
    input_bytes: usize,
    operations: usize,
    operation: impl FnOnce() -> T,
) -> (T, Row) {
    let cpu = ThreadTime::now();
    let wall = Instant::now();
    let before = COUNTERS.begin_phase();
    let result = operation();
    black_box(&result);
    let after = COUNTERS.snapshot();
    let cpu_ns = cpu.elapsed().as_nanos();
    let wall_ns = wall.elapsed().as_nanos();
    assert!(!before.fault && !after.fault, "allocator accounting fault");
    assert!(
        after.peak >= before.live && after.realloc_overlap_peak >= before.live,
        "nonmonotonic phase high-water mark"
    );
    (
        result,
        Row {
            selection: 0,
            policy,
            case,
            phase,
            input_bytes,
            operations,
            before,
            after,
            cpu_ns,
            wall_ns,
        },
    )
}
fn emit(row: Row) {
    // All labels are local static literals; no payload, policy or match values.
    println!(
        "{{\"scope\":\"synthetic-requested-rust-allocation\",\"selection_index\":{},\"policy\":\"{}\",\"case\":\"{}\",\"phase\":\"{}\",\"input_bytes\":{},\"operations\":{},\"live_before\":{},\"live_after\":{},\"peak_above_baseline\":{},\"conservative_realloc_overlap_above_baseline\":{},\"thread_cpu_ns\":{},\"wall_ns\":{}}}",
        row.selection,
        row.policy,
        row.case,
        row.phase,
        row.input_bytes,
        row.operations,
        row.before.live,
        row.after.live,
        row.after.peak - row.before.live,
        row.after.realloc_overlap_peak - row.before.live,
        row.cpu_ns,
        row.wall_ns,
    );
}
fn bounded(pattern: &[u8]) -> Vec<u8> {
    assert!(!pattern.is_empty() && std::str::from_utf8(pattern).is_ok());
    let mut result = Vec::with_capacity(32_768);
    while result.len() < 32_768 {
        result.extend_from_slice(&pattern[..pattern.len().min(32_768 - result.len())]);
    }
    while std::str::from_utf8(&result).is_err() {
        result.pop();
    }
    result.resize(32_768, b' ');
    result
}
fn main() {
    assert_eq!(usize::BITS, 64, "unqualified probe word size");
    assert_single_thread();
    match std::env::args().nth(1).as_deref() {
        Some("--all-constructors") => {
            all_constructors();
            return;
        }
        None => {}
        Some(_) => panic!("unsupported probe option"),
    }
    // Inputs and policies are prepared before scanner measurement. These are
    // fixed generated examples, not captures from users, guests or a network.
    let cases = [
        ("dense-five-rules", bounded(b"synthetic@example.invalid 001-01-0001 4111111111111111 +12025550123 GB82WEST12345698765432\n")),
        ("unicode-and-near-misses", bounded("\u{03bb}\u{754c} no-at-domain 000-00-0000 1111111111111 +abcdef GB00INVALID000000000000 \n".as_bytes())),
        ("ascii-no-matches", bounded(b"ordinary-synthetic-telemetry-without-sensitive-shaped-fields; ")),
    ];
    let policies = [
        (
            "all-five",
            PiiPolicy {
                mode: Some("redact".into()),
                categories: vec![],
            },
        ),
        (
            "reordered-three",
            PiiPolicy {
                mode: Some("redact".into()),
                categories: vec!["iban".into(), "email".into(), "credit_card".into()],
            },
        ),
    ];
    let _warm_clock = ThreadTime::now();
    let preparation = COUNTERS.snapshot();
    assert!(!preparation.fault);
    println!(
        "{{\"scope\":\"probe-preparation\",\"live_requested_bytes\":{},\"input_capacity_bytes\":{},\"measurement_thread_count\":1,\"native_rss_claim\":false}}",
        preparation.live,
        cases
            .iter()
            .map(|(_, bytes)| bytes.capacity())
            .sum::<usize>()
    );
    for (policy_name, policy) in &policies {
        let facts = PiiRedactor::owned_pii_requirements(policy).expect("fixed owned policy");
        println!(
            "{{\"scope\":\"enforced-controls-not-total-heap\",\"policy\":\"{}\",\"rules\":{},\"regex_objects\":{},\"nfa_limit\":{},\"rule_nfa_limit\":{},\"hybrid_cache_limit\":{},\"max_concurrency\":{}}}",
            policy_name,
            facts.rule_count,
            facts.regex_objects,
            facts.nfa_size_limit_bytes,
            facts.rule_nfa_size_limit_bytes,
            facts.dfa_cache_limit_bytes,
            facts.max_concurrent_searches
        );
        let baseline = COUNTERS.snapshot();
        let (scanner, construction) = measured(policy_name, "none", "construct", 0, 1, || {
            PiiRedactor::curated_owned(policy).expect("fixed owned scanner must compile")
        });
        emit(construction);
        // Fixed-size observations stay on stack; no reporting allocations in
        // the search windows. The same scanner is never cloned or migrated.
        let mut observations = [None, None, None];
        for (index, (case, bytes)) in cases.iter().enumerate() {
            let ((masked, names), first) =
                measured(policy_name, case, "first-redact", bytes.len(), 1, || {
                    scanner.redact(black_box(bytes))
                });
            emit(first);
            observations[index] = Some((masked, names));
            let ((), repeated) =
                measured(policy_name, case, "repeated-redact", bytes.len(), 8, || {
                    for _ in 0..8 {
                        black_box(scanner.redact(black_box(bytes)));
                    }
                });
            emit(repeated);
        }
        let ((), dropped) = measured(policy_name, "none", "drop-scanner", 0, 1, || drop(scanner));
        emit(dropped);
        // Verification is deliberately outside all owned scanner windows.
        let legacy = PiiRedactor::from_policy(policy)
            .expect("fixed legacy policy")
            .expect("enabled policy");
        for ((_, bytes), actual) in cases.iter().zip(observations.iter()) {
            assert_eq!(
                actual.as_ref().unwrap(),
                &legacy.redact(bytes),
                "owned/legacy result mismatch"
            );
        }
        drop(legacy);
        drop(observations);
        let final_state = COUNTERS.snapshot();
        assert!(!final_state.fault);
        println!(
            "{{\"scope\":\"verified-policy-complete\",\"policy\":\"{}\",\"legacy_output_equal\":true,\"baseline_live\":{},\"after_live\":{}}}",
            policy_name, baseline.live, final_state.live
        );
    }
    assert_single_thread();
}

fn assert_single_thread() {
    assert_eq!(std::env::consts::OS, "linux", "this witness requires Linux");
    assert_eq!(
        std::fs::read_dir("/proc/self/task").unwrap().count(),
        1,
        "measurement has another live thread"
    );
}

fn all_constructors() {
    use mvm_core::pii::DEFAULT_RULES;
    assert_eq!(DEFAULT_RULES.len(), 5, "canonical rule profile changed");
    let orders = permutations::all_policy_orders();
    assert_eq!(orders.len(), 325);
    let body = bounded(b"synthetic@example.invalid 001-01-0001 4111111111111111 +12025550123 GB82WEST12345698765432\n");
    let _warm_clock = ThreadTime::now();
    println!(
        "{{\"scope\":\"finite-constructor-intent\",\"selections\":325,\"one_observed_thread\":true,\"search_inputs_exhausted\":false,\"native_rss_bound\":false}}"
    );
    let mut max_peak = 0;
    let mut max_overlap = 0;
    let mut max_retained = 0;
    let mut max_drop_delta: i128 = 0;
    for (index, order) in orders.iter().enumerate() {
        let policy = PiiPolicy {
            mode: Some("redact".into()),
            categories: order
                .iter()
                .map(|&i| DEFAULT_RULES[i].name.to_owned())
                .collect(),
        };
        let facts = PiiRedactor::owned_pii_requirements(&policy).expect("split owned facts");
        assert_eq!(facts.nfa_size_limit_bytes, 524_288);
        assert_eq!(facts.rule_nfa_size_limit_bytes, 131_072);
        assert_eq!(facts.dfa_cache_limit_bytes, 262_144);
        assert_eq!(facts.rule_count, order.len());
        assert_eq!(facts.regex_objects, order.len() + 1);
        println!(
            "{{\"scope\":\"split-controls-outside-measurement\",\"selection_index\":{},\"set_nfa\":{},\"rule_nfa\":{},\"dfa\":{},\"rules\":{},\"regex_objects\":{}}}",
            index + 1,
            facts.nfa_size_limit_bytes,
            facts.rule_nfa_size_limit_bytes,
            facts.dfa_cache_limit_bytes,
            facts.rule_count,
            facts.regex_objects
        );
        println!(
            "{{\"scope\":\"constructor-selection\",\"selection_index\":{},\"rule_indices\":{:?}}}",
            index + 1,
            order
        );
        let baseline = COUNTERS.snapshot();
        let (scanner, mut construction) =
            measured("finite-325", "ordered-subset", "construct", 0, 1, || {
                PiiRedactor::curated_owned(&policy).expect("admitted fixed selection")
            });
        construction.selection = index + 1;
        max_peak = max_peak.max(construction.after.peak - construction.before.live);
        max_overlap =
            max_overlap.max(construction.after.realloc_overlap_peak - construction.before.live);
        max_retained = max_retained.max(
            construction
                .after
                .live
                .checked_sub(construction.before.live)
                .expect("constructor live delta"),
        );
        emit(construction);
        // Equality work is not included in constructor allocation/CPU rows.
        let legacy = PiiRedactor::from_policy(&policy).unwrap().unwrap();
        assert!(
            scanner.redact(&body) == legacy.redact(&body),
            "finite selection semantic mismatch"
        );
        drop(legacy);
        let ((), mut dropped) =
            measured("finite-325", "ordered-subset", "drop-scanner", 0, 1, || {
                drop(scanner)
            });
        dropped.selection = index + 1;
        emit(dropped);
        let after = COUNTERS.snapshot();
        assert!(!after.fault);
        let delta = after.live as i128 - baseline.live as i128;
        max_drop_delta = max_drop_delta.max(delta);
        println!(
            "{{\"scope\":\"finite-selection-verified\",\"selection_index\":{},\"legacy_output_equal\":true,\"post_drop_live_delta\":{}}}",
            index + 1,
            delta
        );
    }
    assert_single_thread();
    println!(
        "{{\"scope\":\"finite-constructor-complete\",\"exhaustive_constructor_selections\":325,\"max_requested_peak\":{},\"max_conservative_realloc_overlap\":{},\"max_compiled_retained\":{},\"max_post_drop_live_delta\":{},\"search_input_bound_claim\":false,\"rss_bound_claim\":false}}",
        max_peak, max_overlap, max_retained, max_drop_delta
    );
}
