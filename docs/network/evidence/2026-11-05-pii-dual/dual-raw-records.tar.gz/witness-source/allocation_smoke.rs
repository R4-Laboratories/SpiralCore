mod accounting;
mod allocator;
use allocator::{COUNTERS, Tracked};
use std::hint::black_box;

#[global_allocator]
static ALLOCATOR: Tracked = Tracked;

fn main() {
    let baseline = COUNTERS.begin_phase();
    let mut bytes = vec![17u8; 4096];
    black_box(&mut bytes);
    let allocated = COUNTERS.snapshot();
    assert_eq!(
        allocated.live - baseline.live,
        4096,
        "actual allocation was not tracked"
    );
    bytes.reserve_exact(4096);
    bytes.resize(8192, 23);
    black_box(&mut bytes);
    assert!(bytes[..4096].iter().all(|byte| *byte == 17));
    assert!(bytes[4096..].iter().all(|byte| *byte == 23));
    let grown = COUNTERS.snapshot();
    assert_eq!(grown.live - baseline.live, 8192);
    assert_eq!(grown.realloc_overlap_peak - baseline.live, 12_288);
    drop(bytes);
    let released = COUNTERS.snapshot();
    assert_eq!(released.live, baseline.live);
    assert!(!released.fault);
    println!("PASS: actual System allocation/realloc/drop and byte preservation");
}
