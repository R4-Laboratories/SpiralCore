//! Arithmetic tests only; these do not claim actual scanner memory bounds.
#[path = "accounting.rs"]
mod accounting;
use accounting::Accounting;

#[test]
fn live_and_peak_follow_allocations_and_deallocations() {
    let state = Accounting::new();
    state.allocate(100);
    state.allocate(40);
    state.deallocate(100);
    let snapshot = state.snapshot();
    assert_eq!((snapshot.live, snapshot.peak), (40, 140));
    assert!(!snapshot.fault);
}

#[test]
fn successful_realloc_reports_separate_conservative_overlap() {
    let state = Accounting::new();
    state.allocate(100);
    state.reallocate(100, 200);
    let snapshot = state.snapshot();
    assert_eq!((snapshot.live, snapshot.peak), (200, 200));
    assert_eq!(snapshot.realloc_overlap_peak, 300);
    state.deallocate(200);
    assert_eq!(state.snapshot().live, 0);
    assert!(!state.snapshot().fault);
}

#[test]
fn phase_reset_keeps_preexisting_live_allocations() {
    let state = Accounting::new();
    state.allocate(500);
    state.deallocate(400);
    let baseline = state.begin_phase();
    assert_eq!(baseline.live, 100);
    state.allocate(25);
    let after = state.snapshot();
    assert_eq!(
        (after.live, after.peak, after.realloc_overlap_peak),
        (125, 125, 125)
    );
    assert!(!after.fault);
}

#[test]
fn impossible_deallocation_fences_without_wrapping() {
    let state = Accounting::new();
    state.allocate(12);
    state.deallocate(13);
    assert!(state.snapshot().fault);
    assert_eq!(state.snapshot().live, 12);
}

#[test]
fn impossible_growth_fences_without_wrapping() {
    let state = Accounting::new();
    state.allocate(usize::MAX);
    state.allocate(1);
    assert!(state.snapshot().fault);
    assert_eq!(state.snapshot().live, usize::MAX);
}
