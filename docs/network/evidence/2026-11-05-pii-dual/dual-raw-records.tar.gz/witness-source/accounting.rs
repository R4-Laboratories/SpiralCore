use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Snapshot {
    pub live: usize,
    pub peak: usize,
    pub realloc_overlap_peak: usize,
    pub fault: bool,
}

/// Requested-byte accounting only. Native allocator overhead is not visible.
pub struct Accounting {
    live: AtomicUsize,
    peak: AtomicUsize,
    overlap: AtomicUsize,
    fault: AtomicBool,
}

impl Accounting {
    pub const fn new() -> Self {
        Self {
            live: AtomicUsize::new(0),
            peak: AtomicUsize::new(0),
            overlap: AtomicUsize::new(0),
            fault: AtomicBool::new(false),
        }
    }

    pub fn allocate(&self, bytes: usize) {
        match self
            .live
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |live| {
                live.checked_add(bytes)
            }) {
            Ok(previous) => {
                let current = previous + bytes;
                self.peak.fetch_max(current, Ordering::SeqCst);
                self.overlap.fetch_max(current, Ordering::SeqCst);
            }
            Err(_) => self.fault.store(true, Ordering::SeqCst),
        }
    }

    pub fn deallocate(&self, bytes: usize) {
        if self
            .live
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |live| {
                live.checked_sub(bytes)
            })
            .is_err()
        {
            self.fault.store(true, Ordering::SeqCst);
        }
    }

    /// Called only after successful realloc. old+new is a conservative API
    /// overlap: System may have grown in place or used a different strategy.
    pub fn reallocate(&self, old: usize, new: usize) {
        if let Some(overlap) = self.live.load(Ordering::SeqCst).checked_add(new) {
            self.overlap.fetch_max(overlap, Ordering::SeqCst);
        } else {
            self.fault.store(true, Ordering::SeqCst);
        }
        self.deallocate(old);
        self.allocate(new);
    }

    /// Single-measurement-thread boundary. Never zero preexisting live bytes.
    /// No allocation is performed while setting the phase high-water marks.
    pub fn begin_phase(&self) -> Snapshot {
        let live = self.live.load(Ordering::SeqCst);
        self.peak.store(live, Ordering::SeqCst);
        self.overlap.store(live, Ordering::SeqCst);
        self.snapshot()
    }

    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            live: self.live.load(Ordering::SeqCst),
            peak: self.peak.load(Ordering::SeqCst),
            realloc_overlap_peak: self.overlap.load(Ordering::SeqCst),
            fault: self.fault.load(Ordering::SeqCst),
        }
    }
}
