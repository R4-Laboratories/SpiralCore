use std::{fs, io::Read};
fn main() {
    let path = std::env::args().nth(1).expect("trusted probe record path");
    let mut text = String::new();
    fs::File::open(path).unwrap().take(1_048_577).read_to_string(&mut text).unwrap();
    assert!(text.len() <= 1_048_576, "probe record limit");
    // Producer labels/schema are fixed local literals, never payload strings.
    let constructors = text.lines().filter(|line| line.contains("\"phase\":\"construct\"")).count();
    assert_eq!(constructors, 325, "finite constructor pass was not executed");
    assert!(text.lines().any(|line| line.contains("\"exhaustive_constructor_selections\":325")),
        "missing exhaustive completion marker");
    println!("PASS: 325 actual constructor rows and completion marker");
}
