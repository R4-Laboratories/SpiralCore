//! Contract RED/GREEN against the actual Core public query.
use mvm_core::{pii::PiiRedactor, policy::PiiPolicy};
fn main() {
    let facts = PiiRedactor::owned_pii_requirements(&PiiPolicy::default()).unwrap();
    assert_eq!(facts.nfa_size_limit_bytes, 524_288);
    assert_eq!(facts.rule_nfa_size_limit_bytes, 131_072);
    assert_eq!(facts.dfa_cache_limit_bytes, 262_144);
    assert_eq!(facts.nest_limit, 64);
    assert_eq!(facts.max_concurrent_searches, 1);
}
