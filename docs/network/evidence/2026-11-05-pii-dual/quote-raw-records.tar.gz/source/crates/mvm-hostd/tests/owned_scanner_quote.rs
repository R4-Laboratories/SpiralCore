//! External composer contract: a checked quote is numeric data, not a permit.
use mvm_core::policy::RedactionPolicy;
use mvm_hostd::telemetry_collector::{
    owned_collector_requirements, owned_scanner_requested_bytes,
};

#[test]
fn external_composer_uses_the_canonical_scanner_quote() {
    let policy = RedactionPolicy::default();
    let scanner = owned_scanner_requested_bytes(&policy).unwrap();
    let collector = owned_collector_requirements().unwrap();
    assert_eq!(scanner, 24_363_008);
    assert_eq!(collector.known_metadata_bytes.checked_add(scanner), Some(51_757_056));
}

#[test]
fn external_composer_cannot_quote_an_unsupported_policy() {
    let mut policy = RedactionPolicy::default();
    policy.default.pii.categories = vec!["not-a-canonical-pii-category".to_owned()];
    assert!(owned_scanner_requested_bytes(&policy).is_err());
}
