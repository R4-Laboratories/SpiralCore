from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/var/tmp/spiralcore-scanner-quote-20261105');source=root/'source';phase=sys.argv[1];out=root/'validation'/phase;out.mkdir(parents=True)
paths=[p for p in source.rglob('*') if p.is_file() and '.git' not in p.parts and 'target' not in p.parts]
paths += [p for p in Path('/var/tmp/spiralcore-canonical-lifetime-20261103/dependency-handshake-1025').rglob('*') if p.is_file()]
paths += [root/'audit-flow-intermediate.toml']
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
args=['/home/callard/.cargo/bin/cargo','+1.97.1','test','--config',str(root/'audit-flow-intermediate.toml'),'--release','--offline','--locked','-p','mvm-hostd','--test','owned_scanner_quote','--no-run','--message-format=json']
env=dict(os.environ,CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/var/tmp/spiralcore-pii-capacity-20261104/target',CARGO_PROFILE_RELEASE_LTO='false')
(out/'command.json').write_text(json.dumps({'argv':args,'cwd':str(source),'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_LTO']}},indent=2)+'\n')
start=time.monotonic()
with (out/'build.jsonl').open('w') as stdout,(out/'build.stderr').open('w') as stderr:
 p=subprocess.Popen(args,cwd=source,env=env,stdout=stdout,stderr=stderr);print('phase',phase,'cargo_pid',p.pid,flush=True);status=p.wait()
(out/'build.exit').write_text(str(status)+'\n')
after={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in before};assert before==after
(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
rows=[json.loads(s) for s in (out/'build.jsonl').read_text().splitlines()]
errors=[{'code':r['message']['code'],'message':r['message']['message']} for r in rows if r.get('reason')=='compiler-message' and r['message']['level']=='error']
print(json.dumps({'phase':phase,'exit':status,'elapsed_s':time.monotonic()-start,'source_count':len(before),'errors':errors}),flush=True)
sys.exit(status)
