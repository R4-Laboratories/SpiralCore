//! Closed old-epoch debt custody. No issuer, deletion or epoch transition API.
use super::*;
use crate::{
    installed_resources::{ClosedRetainedFunding, ManagedSnapshot},
    installed_supervisor::{InstalledAuthority, SupervisorError},
};
use mvm_core::runtime_state_protection::{
    RETAINED_TELEMETRY_MARKER_FILE, RuntimeStateProtection, TELEMETRY_COLLECTOR_STATUS_FILE,
    TELEMETRY_RECORDS_FILE, TELEMETRY_RECORDS_KEY_FILE,
};
use std::os::unix::fs::FileExt;

type RecoveryResult<T> = std::result::Result<T, SupervisorError>;

/// Compiled compatibility, never a caller-supplied profile or limit grant.
pub(crate) struct RetainedRecoveryCompatibility {
    profile: [u8; 32],
}
impl RetainedRecoveryCompatibility {
    pub(crate) fn published_v1() -> RecoveryResult<Self> {
        if !cfg!(all(
            target_os = "linux",
            target_arch = "x86_64",
            target_pointer_width = "64"
        )) {
            return Err(SupervisorError::Profile);
        }
        // Actual protected old Linux/x64 source+profile fixture, not current
        // include_bytes-derived config. Other profiles require qualification.
        Ok(Self {
            profile: [
                0xfc, 0xa2, 0xaf, 0x7e, 0x09, 0xa0, 0xb8, 0xf0, 0x78, 0x2b, 0x32, 0x3d, 0x09, 0x33,
                0x4c, 0x96, 0x83, 0xd9, 0x09, 0x79, 0x6b, 0x91, 0x8e, 0xff, 0x49, 0x52, 0x27, 0xb6,
                0xf2, 0x7c, 0x4f, 0x0f,
            ],
        })
    }
}

/// Actual trusted canonical parent, not authority reconstructed from a row.
pub(crate) struct CanonicalRecoveryLayout {
    path: PathBuf,
    directory: File,
    id: ObjectId,
}
impl CanonicalRecoveryLayout {
    pub(crate) fn from_trusted_parent(path: &Path, directory: File) -> Result<Self> {
        if path.as_os_str().len() > 4096 {
            return Err(OwnerError::InvalidStorage);
        }
        let original = Self {
            path: path.to_owned(),
            id: object_id(&directory)?,
            directory,
        };
        original.check()?;
        Ok(original)
    }
    fn check(&self) -> Result<()> {
        check_private(&self.directory, true)?;
        check_filesystem(&self.directory)?;
        // SAFETY: F_GETFL only observes this live original descriptor.
        let flags = unsafe { libc::fcntl(self.directory.as_raw_fd(), libc::F_GETFL) };
        if flags < 0 {
            return Err(io::Error::last_os_error().into());
        }
        if flags & libc::O_ACCMODE != libc::O_RDONLY
            || object_id(&self.directory)? != self.id
            || object_id(&open_root(&self.path)?)? != self.id
        {
            return Err(OwnerError::InvalidStorage);
        }
        Ok(())
    }
    fn duplicate(&self) -> Result<Self> {
        self.check()?;
        Ok(Self {
            path: self.path.clone(),
            directory: self.directory.try_clone()?,
            id: self.id,
        })
    }
}

/// Private original kernel exclusion, consumed by the closed authority.
pub(crate) struct RetainedExclusion {
    owner: InstallationOwner,
    holders: File,
    epoch: Epoch,
}
impl RetainedExclusion {
    pub(crate) fn into_parts(self) -> (InstallationOwner, File, Epoch) {
        (self.owner, self.holders, self.epoch)
    }
}

pub(crate) struct RecoveryStartFailure {
    error: SupervisorError,
    owner: Option<Box<InstallationOwner>>,
    funding: Option<ClosedRetainedFunding>,
}
impl fmt::Debug for RecoveryStartFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("closed retained recovery preparation refused; custody retained")
    }
}
impl Drop for RecoveryStartFailure {
    fn drop(&mut self) {
        // One bounded original exclusion per failed attempt. A second attempt
        // cannot acquire owner EX in this process while this custody survives.
        if let Some(owner) = self.owner.take() {
            std::mem::forget(owner);
        }
        if let Some(funding) = self.funding.take() {
            std::mem::forget(funding);
        }
    }
}

impl InstallationOwner {
    pub(crate) fn prepare_retained_recovery(
        self,
        compatibility: &RetainedRecoveryCompatibility,
        layout: &CanonicalRecoveryLayout,
    ) -> std::result::Result<RetainedRecovery, RecoveryStartFailure> {
        let checked = (|| -> RecoveryResult<_> {
            let current = self.current()?;
            if current.phase != Phase::Active
                || current.generation == 0
                || current.key.profile != compatibility.profile
                || self.supervisor.is_some()
                || crate::installed_retained::RECORD_BYTES != 8 << 20
                || crate::installed_retained::SIDECAR_BYTES != 32 << 10
            {
                return Err(SupervisorError::Profile);
            }
            layout.check()?;
            let holders = self.holders_for_transition()?;
            self.current()?;
            Ok((
                Epoch {
                    key: current.key,
                    generation: current.generation,
                },
                holders,
            ))
        })();
        let (epoch, holders) = match checked {
            Ok(value) => value,
            Err(error) => {
                return Err(RecoveryStartFailure {
                    error,
                    owner: Some(Box::new(self)),
                    funding: None,
                });
            }
        };
        let authority = InstalledAuthority::from_retained_recovery(RetainedExclusion {
            owner: self,
            holders,
            epoch,
        });
        let funding = ClosedRetainedFunding::new(authority);
        if let Err(error) = funding.fund_metadata() {
            return Err(RecoveryStartFailure {
                error: error.into(),
                owner: None,
                funding: Some(funding),
            });
        }
        let layout = match layout.duplicate() {
            Ok(layout) => layout,
            Err(error) => {
                return Err(RecoveryStartFailure {
                    error: error.into(),
                    owner: None,
                    funding: Some(funding),
                });
            }
        };
        Ok(RetainedRecovery {
            held: Some(Box::new(Custody {
                funding,
                layout,
                epoch,
                protection: None,
                catalog: None,
                catalog_bytes: Vec::new(),
                entries: std::array::from_fn(|_| None),
                failed: false,
            })),
        })
    }
}

struct PinnedEntry {
    record: RetainedRecord,
    directory: File,
    marker: Option<File>,
    records: Option<File>,
    key: Option<File>,
    status: Option<File>,
}
struct Custody {
    funding: ClosedRetainedFunding,
    layout: CanonicalRecoveryLayout,
    epoch: Epoch,
    protection: Option<RuntimeStateProtection>,
    catalog: Option<File>,
    catalog_bytes: Vec<u8>,
    entries: [Option<PinnedEntry>; MAX_ENTRIES],
    failed: bool,
}

pub(crate) struct RetainedRecovery {
    held: Option<Box<Custody>>,
}
impl RetainedRecovery {
    pub(crate) fn adopt_closed(
        mut self,
    ) -> std::result::Result<ClosedRetainedDebt, RecoveryBlocked> {
        let outcome = self
            .held
            .as_mut()
            .ok_or(SupervisorError::State)
            .and_then(|held| held.adopt());
        match outcome {
            Ok(()) => Ok(ClosedRetainedDebt { recovery: self }),
            Err(error) => {
                if let Some(held) = self.held.as_mut() {
                    held.failed = true;
                }
                Err(RecoveryBlocked {
                    error,
                    recovery: self,
                })
            }
        }
    }
}
impl Drop for RetainedRecovery {
    fn drop(&mut self) {
        // Until a separately reviewed transfer/disposition exists, retain the
        // COMPLETE bounded table, ledger and original locks through uncertainty.
        if let Some(held) = self.held.take() {
            std::mem::forget(held);
        }
    }
}
pub(crate) struct RecoveryBlocked {
    error: SupervisorError,
    recovery: RetainedRecovery,
}
impl fmt::Debug for RecoveryBlocked {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("closed retained recovery refused; same custody retained")
    }
}
pub(crate) struct RetainedDebtSnapshot {
    pub(crate) entries: usize,
    pub(crate) unresolved: usize,
    pub(crate) managed: ManagedSnapshot,
}
pub(crate) struct ClosedRetainedDebt {
    recovery: RetainedRecovery,
}
impl ClosedRetainedDebt {
    pub(crate) fn snapshot(&self) -> RecoveryResult<RetainedDebtSnapshot> {
        let held = self.recovery.held.as_ref().ok_or(SupervisorError::State)?;
        if held.failed {
            return Err(SupervisorError::State);
        }
        let entries = held.entries.iter().flatten();
        Ok(RetainedDebtSnapshot {
            entries: entries.clone().count(),
            unresolved: entries.filter(|entry| entry.record.phase != 4).count(),
            managed: held.funding.snapshot()?,
        })
    }
    pub(crate) fn revalidate(&mut self) -> RecoveryResult<()> {
        let held = self.recovery.held.as_mut().ok_or(SupervisorError::State)?;
        let result = held.revalidate();
        if result.is_err() {
            held.failed = true;
        }
        result
    }
}

fn bounded_bytes(file: &File, cap: usize) -> Result<Vec<u8>> {
    let length = usize::try_from(file.metadata()?.len()).map_err(|_| OwnerError::Fenced)?;
    if length > cap {
        return Err(OwnerError::Fenced);
    }
    let mut bytes = vec![0; length];
    file.read_exact_at(&mut bytes, 0)?;
    if file.metadata()?.len() != length as u64 {
        return Err(OwnerError::Fenced);
    }
    Ok(bytes)
}
fn present(directory: &File, name: &str) -> Result<bool> {
    let name = CString::new(name).map_err(|_| OwnerError::InvalidStorage)?;
    let mut stat = std::mem::MaybeUninit::<libc::stat>::uninit();
    // SAFETY: live directory, fixed NUL-terminated name and writable output.
    if unsafe {
        libc::fstatat(
            directory.as_raw_fd(),
            name.as_ptr(),
            stat.as_mut_ptr(),
            libc::AT_SYMLINK_NOFOLLOW,
        )
    } == 0
    {
        return Ok(true);
    }
    let error = io::Error::last_os_error();
    if error.raw_os_error() == Some(libc::ENOENT) {
        Ok(false)
    } else {
        Err(error.into())
    }
}
fn optional_file(directory: &File, name: &str, cap: usize) -> Result<Option<File>> {
    if !present(directory, name)? {
        return Ok(None);
    }
    let file = open_at(directory, name, libc::O_RDONLY)?;
    require_private_retained_file(&file)?;
    if file.metadata()?.len() > cap as u64 {
        return Err(OwnerError::Fenced);
    }
    Ok(Some(file))
}
fn same_optional(a: &Option<File>, b: &Option<File>) -> Result<bool> {
    match (a, b) {
        (Some(a), Some(b)) => Ok(object_id(a)? == object_id(b)?),
        (None, None) => Ok(true),
        _ => Ok(false),
    }
}

impl Custody {
    fn read_original(&self) -> RecoveryResult<(File, Vec<u8>, Catalog)> {
        self.funding.check()?;
        self.funding.authority().with_disk_owner(|owner, epoch| {
            owner.active_binding(epoch)?;
            if epoch != self.epoch {
                return Err(OwnerError::StaleEpoch);
            }
            let mut beacon = Vec::with_capacity(112);
            beacon.extend_from_slice(b"SCRETB01");
            beacon.extend_from_slice(&epoch.key.installation);
            beacon.extend_from_slice(&epoch.key.profile);
            beacon.extend_from_slice(&epoch.generation.to_le_bytes());
            beacon.extend_from_slice(&Sha256::digest(&beacon));
            if bounded_bytes(&owner._owner, 112)? != beacon {
                return Err(OwnerError::Fenced);
            }
            owner
                .storage
                .absent_names(&[CATALOG_INTENT, CATALOG_NEXT])?;
            let file = open_at(&owner.storage.directory, CATALOG, libc::O_RDONLY)?;
            let bytes = bounded_bytes(&file, MAX_BYTES)?;
            let catalog = Catalog::decode(&bytes, epoch)?;
            if catalog.entries.is_empty() {
                return Err(OwnerError::Fenced);
            }
            owner.active_binding(epoch)?;
            Ok((file, bytes, catalog))
        })
    }
    fn adopt(&mut self) -> RecoveryResult<()> {
        let (file, bytes, catalog) = self.read_original()?;
        self.catalog = Some(file);
        self.catalog_bytes = bytes;
        let mut tenants = [[0; 32]; MAX_ENTRIES];
        for (at, row) in catalog.entries.iter().enumerate() {
            tenants[at] = row.tenant;
        }
        self.funding.fund_rows(&tenants[..catalog.entries.len()])?;
        self.layout.check()?;
        self.protection = Some(RuntimeStateProtection::acquire(
            &self.layout.path,
            &self.layout.directory,
        )?);
        // All historical ceilings are charged before opening a row's data.
        for (at, record) in catalog.entries.into_iter().enumerate() {
            self.entries[at] = Some(self.pin(record)?);
        }
        self.revalidate()
    }
    fn pin(&self, record: RetainedRecord) -> RecoveryResult<PinnedEntry> {
        if !record.valid() || record.state.parent() != Some(self.layout.path.as_path()) {
            return Err(SupervisorError::Profile);
        }
        let directory = open_root(&record.state)?;
        let expected = ObjectId {
            device: record.state_device,
            inode: record.state_inode,
        };
        if object_id(&directory)? != expected {
            return Err(SupervisorError::Profile);
        }
        let protection = self.protection.as_ref().ok_or(SupervisorError::State)?;
        protection.check_state(&record.state, &directory)?;
        let marker = optional_file(&directory, RETAINED_TELEMETRY_MARKER_FILE, 224)?;
        if let Some(marker) = &marker {
            if bounded_bytes(marker, 224)? != record.marker(self.epoch) {
                return Err(SupervisorError::State);
            }
        } else if record.phase != 1 {
            return Err(SupervisorError::State);
        }
        let records = optional_file(&directory, TELEMETRY_RECORDS_FILE, 8 << 20)?;
        let key = optional_file(&directory, TELEMETRY_RECORDS_KEY_FILE, 1024)?;
        let status = optional_file(&directory, TELEMETRY_COLLECTOR_STATUS_FILE, 4096)?;
        if record.phase >= 3 {
            let records = records.as_ref().ok_or(SupervisorError::State)?;
            let key = key.as_ref().ok_or(SupervisorError::State)?;
            if object_id(records)?
                != (ObjectId {
                    device: record.record_id.0,
                    inode: record.record_id.1,
                })
                || object_id(key)?
                    != (ObjectId {
                        device: record.key_id.0,
                        inode: record.key_id.1,
                    })
            {
                return Err(SupervisorError::Profile);
            }
            if record.phase == 4 {
                if records.metadata()?.len() != record.sealed_len {
                    return Err(SupervisorError::State);
                }
                let mut digest = Sha256::new();
                let mut buffer = [0; 8192];
                let mut offset = 0;
                while offset < record.sealed_len {
                    let limit = usize::try_from((record.sealed_len - offset).min(8192))
                        .map_err(|_| SupervisorError::State)?;
                    let count = records.read_at(&mut buffer[..limit], offset)?;
                    if count == 0 {
                        return Err(SupervisorError::State);
                    }
                    digest.update(&buffer[..count]);
                    offset += count as u64;
                }
                if digest.finalize().as_slice() != record.sealed_sha256
                    || records.metadata()?.len() != record.sealed_len
                {
                    return Err(SupervisorError::State);
                }
            }
        }
        protection.check_state(&record.state, &directory)?;
        require_private_retained_directory(&directory)?;
        Ok(PinnedEntry {
            record,
            directory,
            marker,
            records,
            key,
            status,
        })
    }
    fn revalidate(&self) -> RecoveryResult<()> {
        if self.failed {
            return Err(SupervisorError::State);
        }
        self.layout.check()?;
        let (named, bytes, _) = self.read_original()?;
        if bytes != self.catalog_bytes
            || object_id(&named)?
                != object_id(self.catalog.as_ref().ok_or(SupervisorError::State)?)?
        {
            return Err(SupervisorError::State);
        }
        for entry in self.entries.iter().flatten() {
            let fresh = self.pin(entry.record.clone())?;
            if object_id(&fresh.directory)? != object_id(&entry.directory)?
                || !same_optional(&fresh.marker, &entry.marker)?
                || !same_optional(&fresh.records, &entry.records)?
                || !same_optional(&fresh.key, &entry.key)?
                || !same_optional(&fresh.status, &entry.status)?
            {
                return Err(SupervisorError::State);
            }
        }
        self.funding.check()?;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::os::unix::fs::PermissionsExt;

    #[test]
    #[ignore = "requires the protected previous-product executable"]
    fn malformed_marker_retains_the_original_state_pin_in_blocked_custody() {
        let binary = std::env::var_os("SPIRALCORE_OLD_RETAINED_BIN")
            .expect("explicit protected old product executable required");
        let binary = PathBuf::from(binary);
        let expected = "45ddf9d61f3bdb853f554788645aa3a176aac9294712f7da482755d33e996659";
        let actual = Sha256::digest(std::fs::read(&binary).unwrap());
        let actual: String = actual.iter().map(|byte| format!("{byte:02x}")).collect();
        assert_eq!(actual, expected, "old fixture executable identity changed");
        let home = tempfile::Builder::new()
            .permissions(fs::Permissions::from_mode(0o700))
            .tempdir()
            .unwrap();
        let status = std::process::Command::new(&binary)
            .args([
                "--exact",
                "installed_supervisor::retained_tests::retained_recovery_old_process_fixture",
                "--test-threads=1",
            ])
            .env("SPIRALCORE_OLD_RETAINED_FIXTURE", home.path())
            .status()
            .unwrap();
        assert!(status.success());
        let state = home.path().join("vms/retained-before-restart");
        let original = File::open(&state).unwrap();
        let original_id = object_id(&original).unwrap();
        let marker = state.join(RETAINED_TELEMETRY_MARKER_FILE);
        let mut bytes = fs::read(&marker).unwrap();
        bytes[0] ^= 1;
        fs::write(&marker, &bytes).unwrap();
        let compatibility = RetainedRecoveryCompatibility::published_v1().unwrap();
        let key = InstallationKey {
            installation: [121; 32],
            profile: compatibility.profile,
        };
        let owner = InstallationOwner::open(&home.path().join("installation"), key).unwrap();
        let parent = home.path().join("vms");
        let layout =
            CanonicalRecoveryLayout::from_trusted_parent(&parent, File::open(&parent).unwrap())
                .unwrap();
        let recovery = owner
            .prepare_retained_recovery(&compatibility, &layout)
            .unwrap();
        let blocked = match recovery.adopt_closed() {
            Ok(_) => panic!("malformed marker was accepted"),
            Err(blocked) => blocked,
        };
        let held = blocked.recovery.held.as_ref().unwrap();
        let snapshot = held.funding.snapshot().unwrap();
        assert_eq!(
            snapshot.usage.cache_disk_bytes,
            (8 << 20) + (32 << 10) + 8192
        );
        assert!(snapshot.fenced);
        let pinned = held.entries[0]
            .as_ref()
            .expect("late validation error dropped the original state pin");
        assert_eq!(object_id(&pinned.directory).unwrap(), original_id);
        assert_eq!(
            fs::read(&marker).unwrap(),
            bytes,
            "recovery changed denied evidence"
        );
        assert!(matches!(
            InstallationOwner::open(&home.path().join("installation"), key),
            Err(OwnerError::Busy)
        ));
    }
}
