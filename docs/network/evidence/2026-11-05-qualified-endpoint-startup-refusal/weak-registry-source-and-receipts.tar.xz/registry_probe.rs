//! The actual Hostd registry leaf with original Core/Hostd binding types.

mod plan_admission {
    pub use mvm_hostd::plan_admission::AdmittedPlan;
}

#[cfg_attr(strong_registry, path = "strong.rs")]
#[cfg_attr(not(strong_registry), path = "weak.rs")]
mod registry;

use anyhow::Result;
use mvm_core::host_lifetime::{CoreCurrentParentPermit, HostLaunchBinding};
use plan_admission::AdmittedPlan;
use registry::ParentAdmissionProvider;
use std::sync::{
    Arc,
    atomic::{AtomicUsize, Ordering},
};

struct OriginalProvider {
    drop_receipt: Arc<AtomicUsize>,
}

impl Drop for OriginalProvider {
    fn drop(&mut self) {
        self.drop_receipt.fetch_add(1, Ordering::SeqCst);
    }
}

impl ParentAdmissionProvider for OriginalProvider {
    fn bind(
        &self,
        _admitted: &AdmittedPlan,
        _binding: &HostLaunchBinding,
    ) -> Result<Arc<dyn CoreCurrentParentPermit>> {
        anyhow::bail!("this registry control issues no launch authority")
    }
}

#[test]
fn last_original_call_releases_provider_and_expiry_refuses_lookup_and_reinstall() {
    std::hint::black_box(registry::bind_current);
    assert!(registry::require_installed().is_err());
    let drop_receipt = Arc::new(AtomicUsize::new(0));
    let original: Arc<dyn ParentAdmissionProvider> = Arc::new(OriginalProvider {
        drop_receipt: drop_receipt.clone(),
    });
    let weak = Arc::downgrade(&original);
    registry::install(original.clone()).unwrap();
    assert!(registry::install(original.clone()).is_err());
    let call = registry::require_installed().unwrap().clone();
    assert!(Arc::ptr_eq(&call, &original));
    drop(original);
    assert_eq!(drop_receipt.load(Ordering::SeqCst), 0);
    assert!(weak.upgrade().is_some());
    println!("in-flight call retained the exact original provider");
    drop(call);
    assert!(
        weak.upgrade().is_none(),
        "registry retained the last original provider"
    );
    assert_eq!(drop_receipt.load(Ordering::SeqCst), 1);
    assert!(registry::require_installed().is_err());
    let replacement: Arc<dyn ParentAdmissionProvider> = Arc::new(OriginalProvider {
        drop_receipt: Arc::new(AtomicUsize::new(0)),
    });
    assert!(registry::install(replacement).is_err());
    assert!(registry::require_installed().is_err());
    println!("original provider dropped once and the expired registry refused replacement");
}
