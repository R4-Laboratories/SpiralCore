# Installed Hostd provider registry ownership

The protected first native build-ready manifest identifies the strong Hostd leaf as 569ebf575d4853e04620883f277b650f94ecc0365146db72f796d4401c4ff07b. The patch applies the previously reviewed and published weak-registry mechanism from MVM f708539f0c2317acf2e74f8f7833d6072a5abafe to that exact preimage. The resulting leaf 2b8d3a4e2fc7928123d057dd495b64d2f52b932e7cb4854d8cf12c2df3cc0f3a preserves the newer bind_config and bind_current implementations.

The same standalone Rust test includes each actual registry leaf and links the exact native build-ready Core and Hostd RLibs for its canonical binding types. Both builds pass. The strong leaf preserves the exact in-flight original pointer, then reproduces the retained-provider failure after the last legitimate owner drops. The weak leaf preserves the in-flight pointer, destroys the original exactly once at final release and refuses subsequent lookup and same-process replacement. The protected sources and binaries match before and after execution.

The current fixture observes an instrumented original provider and does not mint a launch permit. The separately preserved historical f708 fixture exercised the real supervisor's provider credit and final drain. This packet does not execute native boot or the composed resident's final cleanup.
