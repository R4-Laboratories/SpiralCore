from pathlib import Path
import hashlib,json,subprocess
a=Path('/var/tmp/spiralcore-native-assets-20261105')
r=a/'provider-registry';out=r/'receipt';out.mkdir()
build=a/'installed-witness/native-build-ready'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
strong='569ebf575d4853e04620883f277b650f94ecc0365146db72f796d4401c4ff07b'
assert json.loads((build/'source-before.json').read_text())['sdk']['crates/mvm-hostd/src/host_lifetime_parent.rs']==strong
assert json.loads((build/'source-after.json').read_text())['sdk']['crates/mvm-hostd/src/host_lifetime_parent.rs']==strong
assert digest(r/'strong.rs')==strong
assert digest(r/'weak.rs')=='2b8d3a4e2fc7928123d057dd495b64d2f52b932e7cb4854d8cf12c2df3cc0f3a'
assert digest(r/'reviewed-f708.rs')=='678f8336b19779298488471316eccf328cb63264c659d30fd38369cc37ac1a3a'
events=[json.loads(line) for line in (build/'build.out').read_text().splitlines()]
hostd_entry,=[e for e in events if e.get('target',{}).get('name')=='mvm_hostd' and any(p.endswith('.rlib') for p in e.get('filenames',[]))]
hostd=Path(next(p for p in hostd_entry['filenames'] if p.endswith('.rlib')))
deps=hostd.parent
fp=deps.parent/'.fingerprint'
hostd_fp=fp/f'mvm-hostd-{hostd.stem.rsplit("-",1)[1]}'/'lib-mvm_hostd.json'
extern={'mvm_hostd':hostd}
for _,crate,_,pin in json.loads(hostd_fp.read_text())['deps']:
 if crate not in ('anyhow','mvm_core'): continue
 matches=[p for p in fp.glob(f'*/lib-{crate}') if p.read_text().strip()==pin.to_bytes(8,'little').hex()]
 match,=matches
 extern[crate]=deps/f'lib{crate}-{match.parent.name.rsplit("-",1)[1]}.rlib'
assert set(extern)=={'mvm_hostd','mvm_core','anyhow'}
inputs=[r/n for n in ('strong.rs','weak.rs','reviewed-f708.rs','weak-registry.patch','registry_probe.rs','probe.py')]
inputs += [hostd_fp, *extern.values(),build/'source-before.json',build/'source-after.json']
pins={str(p):digest(p) for p in inputs}
(out/'inputs.json').write_text(json.dumps(pins,indent=2))
(out/'hostd-artifact.json').write_text(json.dumps(hostd_entry,indent=2))
def run(argv,name):
 (out/f'{name}.argv.json').write_text(json.dumps(argv,indent=2))
 with (out/f'{name}.txt').open('w') as log:
  rc=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT,timeout=120).returncode
 (out/f'{name}.exit').write_text(f'{rc}\n')
 return rc
rustc='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin/rustc'
argv=[rustc,'--test','--edition=2024','-C','opt-level=1','-L',f'dependency={deps}',str(r/'registry_probe.rs')]
for crate,path in extern.items():
 argv+=['--extern',f'{crate}={path}']
binaries={}
for case in ('strong','weak'):
 binary=out/f'protected-{case}'
 params=argv+['-o',str(binary)]
 if case=='strong':params+=['--cfg','strong_registry']
 assert run(params,case+'-compile')==0, (out/f'{case}-compile.txt').read_text()
 pin=digest(binary)
 assert run([str(binary),'--exact','last_original_call_releases_provider_and_expiry_refuses_lookup_and_reinstall','--nocapture'],case+'-execute')==(101 if case=='strong' else 0)
 assert digest(binary)==pin
 binaries[str(binary)]=pin
 contents=(out/f'{case}-execute.txt').read_text()
 assert 'in-flight call retained the exact original provider' in contents
 assert ('registry retained the last original provider' if case=='strong' else 'provider dropped once and the expired registry refused replacement') in contents
 print(contents,end='')
assert all(digest(Path(p))==h for p,h in (pins|binaries).items())
(out/'binaries.json').write_text(json.dumps(binaries,indent=2))
(out/'readbacks.exit').write_text('0\n')
