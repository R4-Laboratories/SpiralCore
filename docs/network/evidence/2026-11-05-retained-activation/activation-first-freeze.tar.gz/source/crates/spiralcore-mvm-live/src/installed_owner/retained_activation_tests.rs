//! Functional owner/File/ledger fixtures only. These tests never create a
//! NativeReceipt/EndpointRetirement or qualify a production native model.
use super::*;
use mvm_core::vm_backend::BackendKind;
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};

fn backend() -> BackendKind {
    if cfg!(target_os = "linux") {
        BackendKind::Firecracker
    } else {
        BackendKind::Hvf
    }
}

// Match the existing Root config_tests::admitted pattern: the canonical host
// signer receives the explicit original private fixture key directory. Do not
// mutate process-global HOME/MVM_HOME or import unavailable SDK test features.
fn actual_admission(home: &Path, captured: BackendKind) -> mvm_hostd::plan_admission::AdmittedPlan {
    use mvm_core::plan::{
        PlanSeccompTier, SecretReleasePolicy, SynthesisInput, Variant, synthesize_plan,
    };
    use mvm_hostd::plan_admission::{
        InMemoryNonceLedger, RunPosture, SystemClock, admit_plan_for_run,
    };
    let input = SynthesisInput::builder()
        .vm_name("retained-restart-functional")
        .tenant("local")
        .backend_name(if captured == BackendKind::Mock {
            "mock"
        } else if cfg!(target_os = "linux") {
            "firecracker"
        } else {
            "hvf"
        })
        .image_name("synthetic-recovery-no-guest")
        .image_sha256("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
        .seccomp_tier(PlanSeccompTier::Standard)
        .secret_release(SecretReleasePolicy::None)
        .secrets(vec![])
        .network_mode(Default::default())
        .cpus(1)
        .mem_mib(1024)
        .disk_mib(0)
        .boot_timeout_secs(30)
        .destroy_on_exit(true)
        .shares(vec![])
        .redaction(Default::default())
        .reversible_replacement(Default::default())
        .audit_labels(Default::default())
        .services(vec![])
        .stream_edges(vec![])
        .stream_retention(Default::default())
        .build()
        .unwrap();
    admit_plan_for_run(
        &synthesize_plan(&input).unwrap(),
        &SystemClock,
        &InMemoryNonceLedger::new(),
        Some(&home.join("admission-keys")),
        None,
        None,
        RunPosture::on_backend(Variant::Dev, captured),
    )
    .unwrap()
}

#[test]
#[ignore = "functional same-ledger historical+new-row IO; no native capability"]
fn activated_inventory_preserves_history_and_funds_new_row_without_second_metadata() {
    let home = super::tests::sealed_format_filesystem_fixture();
    let committed = super::tests::review_prepare(home.path())
        .commit_closed()
        .unwrap();
    let binding = committed.binding().unwrap();
    let epoch = Epoch {
        key: binding.key,
        generation: binding.generation,
    };
    let path = home.path().join("installation").join(CATALOG);
    let old_catalog = CatalogV2::decode(&fs::read(&path).unwrap(), epoch).unwrap();
    let old_beacon = fs::read(home.path().join("installation").join(OWNER)).unwrap();
    let old_marker = fs::read(
        old_catalog.entries[0]
            .record
            .state
            .join(RETAINED_TELEMETRY_MARKER_FILE),
    )
    .unwrap();
    let prepared = committed.prepare_live_inventory().unwrap();
    let before = prepared.snapshot().unwrap().managed.usage;
    let vms = home.path().join("vms");
    let parent = File::open(&vms).unwrap();
    assert!(
        matches!(RuntimeStateProtection::acquire(&vms, &parent), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
    );
    let independent_holder = File::options()
        .read(true)
        .write(true)
        .open(binding.root.join(HOLDERS))
        .unwrap();
    use rustix::fs::{FlockOperation, flock};
    assert_eq!(
        flock(&independent_holder, FlockOperation::NonBlockingLockShared)
            .unwrap_err()
            .raw_os_error(),
        libc::EWOULDBLOCK
    );
    let admitted = actual_admission(home.path(), backend());
    let original_image = admitted.plan().image.sha256.as_ptr();
    let original_envelope = serde_json::to_vec(admitted.signed()).unwrap();
    let activated = prepared
        .activate(
            super::transition::RetainedActivationProfile::fixture(backend()),
            admitted,
        )
        .unwrap();
    assert!(matches!(
        InstallationOwner::open(&binding.root, binding.key),
        Err(OwnerError::Busy)
    ));
    assert_eq!(
        flock(
            &independent_holder,
            FlockOperation::NonBlockingLockExclusive
        )
        .unwrap_err()
        .raw_os_error(),
        libc::EWOULDBLOCK
    );
    flock(&independent_holder, FlockOperation::NonBlockingLockShared).unwrap();
    drop(independent_holder);
    drop(RuntimeStateProtection::acquire(&vms, &parent).unwrap());
    assert_eq!(
        activated.admitted().plan().image.sha256.as_ptr(),
        original_image
    );
    assert_eq!(
        serde_json::to_vec(activated.admitted().signed()).unwrap(),
        original_envelope
    );
    let supervisor = activated.supervisor();
    let inventory = supervisor.retained_telemetry_inventory().unwrap();
    assert_eq!(
        supervisor.managed_resources().snapshot().unwrap().usage,
        before
    );
    let scope = inventory
        .reserve_for_endpoint([122; 32], [202; 32], 1)
        .unwrap();
    let state = home.path().join("vms").join("new-functional-row");
    fs::DirBuilder::new().mode(0o700).create(&state).unwrap();
    let directory = File::open(&state).unwrap();
    // This must acquire a fresh independent protection OFD. Keeping recovery's
    // short EX serialization guard forever would self-refuse this real call.
    inventory.prepare_state(&scope, &state, &directory).unwrap();
    let current = CatalogV2::decode(&fs::read(&path).unwrap(), epoch).unwrap();
    assert_eq!(current.entries.len(), 2);
    assert_eq!(current.entries[0].origin, old_catalog.entries[0].origin);
    assert!(current.entries[0].record == old_catalog.entries[0].record);
    assert_eq!(current.entries[1].origin, epoch);
    assert_eq!(current.entries[1].record.phase, 2);
    assert_eq!(current.entries[1].record.session, [202; 32]);
    let records = File::options()
        .read(true)
        .append(true)
        .create_new(true)
        .mode(0o600)
        .open(state.join(TELEMETRY_RECORDS_FILE))
        .unwrap();
    let key = File::options()
        .read(true)
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(state.join(TELEMETRY_RECORDS_KEY_FILE))
        .unwrap();
    inventory
        .bind_files(&scope, &state, &directory, &records, &key)
        .unwrap();
    let bound = CatalogV2::decode(&fs::read(&path).unwrap(), epoch).unwrap();
    assert_eq!(bound.entries.len(), 2);
    assert_eq!(bound.entries[0].origin, old_catalog.entries[0].origin);
    assert!(bound.entries[0].record == old_catalog.entries[0].record);
    assert_eq!(bound.entries[1].origin, epoch);
    assert_eq!(bound.entries[1].record.phase, 3);
    assert_eq!(
        fs::read(home.path().join("installation").join(OWNER)).unwrap(),
        old_beacon
    );
    assert_eq!(
        fs::read(
            old_catalog.entries[0]
                .record
                .state
                .join(RETAINED_TELEMETRY_MARKER_FILE)
        )
        .unwrap(),
        old_marker
    );
    let after = supervisor.managed_resources().snapshot().unwrap();
    assert_eq!(after.usage.host_metadata_bytes, 1 << 20);
    assert_eq!(
        after.usage.cache_disk_bytes,
        before.cache_disk_bytes + (8 << 20) + (32 << 10)
    );
}

#[test]
#[ignore = "functional16-total saturation after one-use activation, no native fleet"]
fn activated_inventory_sixteen_historical_rows_refuse_new_scope_without_refund() {
    let home = super::live_tests::sixteen_original_history_filesystem_fixture();
    let prepared = super::tests::review_prepare(home.path())
        .commit_closed()
        .unwrap()
        .prepare_live_inventory()
        .unwrap();
    let before = prepared.snapshot().unwrap().managed.usage;
    let admitted = actual_admission(home.path(), backend());
    let activated = prepared
        .activate(
            super::transition::RetainedActivationProfile::fixture(backend()),
            admitted,
        )
        .unwrap();
    let supervisor = activated.supervisor();
    let inventory = supervisor.retained_telemetry_inventory().unwrap();
    assert!(
        inventory
            .reserve_for_endpoint([122; 32], [203; 32], 1)
            .is_err()
    );
    let after = supervisor.managed_resources().snapshot().unwrap();
    assert_eq!(after.usage, before);
    assert_eq!(after.active_reservations, 17);
}

#[test]
#[ignore = "actual opaque admission backend mismatch retains original closed owner"]
fn activation_refuses_foreign_backend_without_losing_closed_custody() {
    let home = super::tests::sealed_format_filesystem_fixture();
    let committed = super::tests::review_prepare(home.path())
        .commit_closed()
        .unwrap();
    let binding = committed.binding().unwrap();
    let catalog_path = home.path().join("installation").join(CATALOG);
    let before = fs::read(&catalog_path).unwrap();
    let prepared = committed.prepare_live_inventory().unwrap();
    let admitted = actual_admission(home.path(), BackendKind::Mock);
    let refused = prepared.activate(
        super::transition::RetainedActivationProfile::fixture(backend()),
        admitted,
    );
    assert!(refused.is_err());
    assert!(matches!(
        InstallationOwner::open(&binding.root, binding.key),
        Err(OwnerError::Busy)
    ));
    let vms = home.path().join("vms");
    let parent = File::open(&vms).unwrap();
    assert!(
        matches!(RuntimeStateProtection::acquire(&vms, &parent), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
    );
    assert_eq!(fs::read(&catalog_path).unwrap(), before);
    drop(refused);
    assert!(matches!(
        InstallationOwner::open(&binding.root, binding.key),
        Err(OwnerError::Busy)
    ));
    assert!(
        matches!(RuntimeStateProtection::acquire(&vms, &parent), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
    );
}

#[test]
#[ignore = "injected failure after actual holder conversion preserves original charged custody"]
fn activation_late_refusal_keeps_converted_holder_owner_and_protection() {
    use rustix::fs::{FlockOperation, flock};
    let home = super::tests::sealed_format_filesystem_fixture();
    let committed = super::tests::review_prepare(home.path())
        .commit_closed()
        .unwrap();
    let binding = committed.binding().unwrap();
    let prepared = committed.prepare_live_inventory().unwrap();
    let before = prepared.snapshot().unwrap().managed;
    let vms = home.path().join("vms");
    let parent = File::open(&vms).unwrap();
    let holder = File::options()
        .read(true)
        .write(true)
        .open(binding.root.join(HOLDERS))
        .unwrap();
    let admitted = actual_admission(home.path(), backend());
    super::transition::refuse_after_conversion();
    let failure = match prepared.activate(
        super::transition::RetainedActivationProfile::fixture(backend()),
        admitted,
    ) {
        Ok(_) => panic!("injected post-conversion refusal opened admission"),
        Err(failure) => failure,
    };
    let after = failure.pending_snapshot();
    assert!(after.fenced);
    assert_eq!(after.usage, before.usage);
    assert_eq!(after.active_reservations, before.active_reservations);
    drop(failure);
    assert!(matches!(
        InstallationOwner::open(&binding.root, binding.key),
        Err(OwnerError::Busy)
    ));
    assert!(
        matches!(RuntimeStateProtection::acquire(&vms, &parent), Err(error) if error.kind() == io::ErrorKind::WouldBlock)
    );
    assert_eq!(
        flock(&holder, FlockOperation::NonBlockingLockExclusive)
            .unwrap_err()
            .raw_os_error(),
        libc::EWOULDBLOCK
    );
    flock(&holder, FlockOperation::NonBlockingLockShared).unwrap();
}
