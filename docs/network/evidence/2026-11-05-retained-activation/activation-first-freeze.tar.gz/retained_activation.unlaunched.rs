//! Move actual closed retained custody into one pending active supervisor.
use super::*;
use crate::{
    host_budget::HostTransportBudget,
    installed_resources::{ImportedManagedReservation, PendingRetainedFunding},
    installed_retained::{LiveHistory, RetainedTelemetryInventory},
    installed_supervisor::{InstalledConfig, InstalledSupervisor},
};
use mvm_core::vm_backend::BackendKind;
use mvm_hostd::plan_admission::AdmittedPlan;

#[cfg(test)]
thread_local! {
    static REFUSE_AFTER_CONVERSION: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}
#[cfg(test)]
pub(crate) fn refuse_after_conversion() {
    REFUSE_AFTER_CONVERSION.with(|value| value.set(true));
}

/// Only a qualified host role/model may construct this proof. The initial
/// fixture constructor exercises filesystem/ledger behavior in tests.
pub(crate) struct RetainedActivationProfile {
    config: InstalledConfig,
    backend: BackendKind,
}
impl RetainedActivationProfile {
    #[cfg(test)]
    pub(crate) fn fixture(backend: BackendKind) -> Self {
        Self {
            config: InstalledConfig::canonical_native_profile(),
            backend,
        }
    }

    fn check(&self, expected: Epoch, admitted: &AdmittedPlan) -> RecoveryResult<()> {
        let native = if cfg!(target_os = "linux") {
            BackendKind::Firecracker
        } else if cfg!(all(target_os = "macos", target_arch = "aarch64")) {
            BackendKind::Hvf
        } else {
            return Err(SupervisorError::Profile);
        };
        if self.backend != native || self.config.profile_hash() != expected.key.profile {
            return Err(SupervisorError::Profile);
        }
        admitted
            .check_unlaunched_for_backend(self.backend)
            .map_err(|_| SupervisorError::Profile)
    }
}

/// The ownership movers require this private checked admission, rather than
/// accepting an epoch or boolean as the activation gate.
pub(crate) struct ActivationAdmission<'a> {
    profile: &'a RetainedActivationProfile,
    admitted: &'a AdmittedPlan,
    epoch: Epoch,
}
impl ActivationAdmission<'_> {
    pub(crate) fn current_epoch(&self) -> RecoveryResult<Epoch> {
        self.profile.check(self.epoch, self.admitted)?;
        Ok(self.epoch)
    }
}

pub(crate) struct ActivatedRetainedService {
    supervisor: InstalledSupervisor,
    admitted: AdmittedPlan,
}
impl ActivatedRetainedService {
    pub(crate) fn supervisor(&self) -> &InstalledSupervisor {
        &self.supervisor
    }
    pub(crate) fn admitted(&self) -> &AdmittedPlan {
        &self.admitted
    }
    pub(crate) fn into_launch_parts(self) -> (InstalledSupervisor, AdmittedPlan) {
        (self.supervisor, self.admitted)
    }
}

struct ActivationAttempt {
    closed: ClosedRetainedDebt,
    pending: Option<PendingRetainedFunding>,
}
pub(crate) struct RetainedActivationFailure {
    _error: SupervisorError,
    _attempt: Box<ActivationAttempt>,
    _admitted: Box<AdmittedPlan>,
}
#[cfg(test)]
impl RetainedActivationFailure {
    pub(crate) fn pending_snapshot(&self) -> ManagedSnapshot {
        self._attempt
            .pending
            .as_ref()
            .unwrap()
            .budget()
            .snapshot()
            .unwrap()
    }
}
impl fmt::Debug for RetainedActivationFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        #[cfg(test)]
        return f
            .debug_tuple("retained activation refused")
            .field(&self._error)
            .finish();
        #[cfg(not(test))]
        f.write_str("retained activation refused; original custody retained")
    }
}
struct PreparedParts {
    transport: HostTransportBudget,
    metadata: ImportedManagedReservation,
    rows: [Option<ImportedManagedReservation>; MAX_ENTRIES],
}
impl ActivationAttempt {
    fn prepare(
        &mut self,
        profile: &RetainedActivationProfile,
        admitted: &AdmittedPlan,
    ) -> RecoveryResult<PreparedParts> {
        PreparedRetainedInventory::check_locked(&mut self.closed)?;
        let held = self
            .closed
            .recovery
            .held
            .as_mut()
            .ok_or(SupervisorError::State)?;
        let epoch = held.epoch;
        let admission = ActivationAdmission {
            profile,
            admitted,
            epoch,
        };
        admission.current_epoch()?;
        if held.protection.is_none()
            || held.catalog.is_none()
            || CatalogV2::decode(&held.catalog_bytes, epoch)?.mode != CatalogMode::Active
        {
            return Err(SupervisorError::State);
        }
        let funding = held.funding.take().ok_or(SupervisorError::State)?;
        self.pending = Some(match funding.prepare_activation(&admission) {
            Ok(pending) => pending,
            Err(original) => {
                held.rebind_failure = Some(original);
                return Err(SupervisorError::State);
            }
        });
        #[cfg(test)]
        if REFUSE_AFTER_CONVERSION.with(|value| value.replace(false)) {
            return Err(SupervisorError::State);
        }
        let pending = self.pending.as_ref().expect("actual pending funding");
        let mut tenants = [[0; 32]; MAX_ENTRIES];
        let mut count = 0;
        for row in held.entries.iter().flatten() {
            tenants[count] = row.record.tenant;
            count += 1;
        }
        let (metadata, rows) = pending.imported_tickets(&tenants[..count])?;
        if held
            .entries
            .iter()
            .zip(&rows)
            .any(|(row, ticket)| row.is_some() != ticket.is_some())
        {
            return Err(SupervisorError::State);
        }
        // Closed checks ran before conversion. Check the same original pins
        // with the still-held protection guard after the native conversion.
        held.revalidate_rows()?;
        let transport = profile.config.retained_activation_transport(pending)?;
        admission.current_epoch()?;
        Ok(PreparedParts {
            transport,
            metadata,
            rows,
        })
    }
}
impl PreparedRetainedInventory {
    pub(in crate::installed_owner::retained_telemetry::recovery) fn activate(
        self,
        profile: RetainedActivationProfile,
        admitted: AdmittedPlan,
    ) -> std::result::Result<ActivatedRetainedService, RetainedActivationFailure> {
        let (closed, poisoned) = match self.original.into_inner() {
            Ok(original) => (original, false),
            Err(error) => (error.into_inner(), true),
        };
        let mut attempt = Box::new(ActivationAttempt {
            closed,
            pending: None,
        });
        let result = if poisoned {
            Err(SupervisorError::State)
        } else {
            attempt.prepare(&profile, &admitted)
        };
        let PreparedParts {
            transport,
            metadata,
            rows,
        } = match result {
            Ok(parts) => parts,
            Err(error) => {
                if let Some(held) = attempt.closed.recovery.held.as_mut() {
                    held.failed = true;
                }
                return Err(RetainedActivationFailure {
                    _error: error,
                    _attempt: attempt,
                    _admitted: Box::new(admitted),
                });
            }
        };
        // Everything fallible has finished. Move the original pins and the
        // funded slot tickets into the one table before opening new admission.
        let Custody {
            layout,
            epoch,
            protection,
            catalog,
            entries,
            ..
        } = *attempt
            .closed
            .recovery
            .held
            .take()
            .expect("checked actual custody");
        let pending = attempt.pending.take().expect("actual pending funding");
        let mut tickets = rows.into_iter();
        let rows = entries.map(|row| {
            let ticket = tickets.next().expect("fixed original slot count");
            row.map(|row| (row, ticket.expect("checked original ticket")))
        });
        let inventory = RetainedTelemetryInventory::from_recovered(
            pending.authority(),
            pending.budget().clone(),
            metadata,
            LiveHistory { layout, epoch },
            LiveRetainedCatalog::from_committed(catalog.expect("checked original catalog")),
            rows,
        );
        let supervisor =
            InstalledSupervisor::assemble_retained_activation(&pending, transport, inventory);
        let activated = ActivatedRetainedService {
            supervisor,
            admitted,
        };
        pending.commit_open();
        // Final successful handoff only. Owner EX and the converted holder SH
        // remain inside the new authority. Live mutations use fresh guards.
        drop(protection);
        Ok(activated)
    }
}
