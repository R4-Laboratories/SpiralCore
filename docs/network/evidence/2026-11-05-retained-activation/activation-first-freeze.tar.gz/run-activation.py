"""Run the frozen activation component batch on Wick with an explicitly loaned target."""
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

base = Path("/var/tmp/spiralcore-retained-activation-20261105")
source = base / "source"
prior = Path("/var/tmp/spiralcore-retained-catalog-20261104/validation/recovery-old-fixture-baseline")
target, label = sys.argv[1:3]
assert Path(target).is_absolute()
assert label == Path(label).name and label not in ("", ".", "..")
strict = "--strict" in sys.argv[3:]
out = base / "validation" / label
out.mkdir(parents=True, exist_ok=False)
inputs = {
    "root": (source, "one-use-overlay/root-resolved-one-use.json"),
    "sdk": (base / "sdk", "one-use-overlay/sdk-resolved-one-use.json"),
    "core": (base / "core-1025", "core-1025-source-before.json"),
}
fixture_paths = [
    "installation/state.bin",
    "installation/owner.lock",
    "installation/.retained-telemetry.bin",
    "vms/retained-before-restart/.installed-retained-telemetry",
]


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def write(name, obj):
    (out / name).write_text(json.dumps(obj, indent=2) + "\n")


def readbacks(phase):
    changed = {}
    for kind, (root, manifest) in inputs.items():
        expected = json.loads((base / manifest).read_text())
        observed = {key: sha(root / key) if (root / key).is_file() else None for key in expected}
        write(f"{kind}-source-{phase}.json", observed)
        changed[kind] = [key for key in expected if expected[key] != observed[key]]
    write(f"source-changes-{phase}.json", changed)
    return not any(changed.values())


def invoke(name, argv, env, capture="stdout"):
    write(f"{name}.command.json", {
        "argv": argv, "cwd": str(source), "started_unix": time.time(),
        "env": {key: env[key] for key in explicit},
        "umask": "0077",
    })
    with (out / f"{name}.{capture}").open("w") as stdout, (out / f"{name}.stderr").open("w") as stderr:
        process = subprocess.Popen(argv, env=env, cwd=source, stdout=stdout, stderr=stderr, umask=0o077)
        (out / f"{name}.pid").write_text(f"{process.pid}\n")
        print(name, process.pid, flush=True)
        code = process.wait()
    (out / f"{name}.exit").write_text(f"{code}\n")
    return code


def messages(name):
    result = []
    for line in (out / f"{name}.jsonl").read_text().splitlines():
        try:
            result.append(json.loads(line))
        except ValueError:
            pass
    write(f"{name}.diagnostics.json", [
        {"package_id": event.get("package_id"), "level": event["message"]["level"],
         "code": event["message"].get("code"), "message": event["message"]["message"]}
        for event in result if event.get("reason") == "compiler-message"
    ])
    return result


def fixture_identity():
    return {"old-test": sha(prior / "protected-test"), **{
        key: sha(prior / "old-process-state" / key) for key in fixture_paths
    }}


assert readbacks("before"), "frozen source mismatch"
fixture = fixture_identity()
assert fixture["old-test"] == "45ddf9d61f3bdb853f554788645aa3a176aac9294712f7da482755d33e996659"
write("fixture-before.json", fixture)
manifest = source / "crates/spiralcore-mvm-live/Cargo.toml"
cargo = ["/home/callard/.cargo/bin/cargo", "+1.97.1"]
options = [
    "--release", "--offline", "--locked", "--jobs", "1", "--manifest-path", str(manifest),
    "--config", str(base / "component-overlay.toml"), "--features", "linux-host,canonical-host",
    "--lib", "--message-format=json",
]
binary = out / "protected-test"
code = 1
with tempfile.TemporaryDirectory(prefix=".retained-activation-test-", dir="/home/callard") as scratch:
    explicit = {
        "CARGO_TARGET_DIR": target, "CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0",
        "SPIRALCORE_OLD_RETAINED_BIN": str(prior / "protected-test"),
        "SPIRALCORE_OLD_RETAINED_STATE": str(prior / "old-process-state"),
        "TMPDIR": scratch,
    }
    env = dict(os.environ, **explicit)
    try:
        code = invoke("build", [*cargo, "test", *options, "--no-run"], env, "jsonl")
        events = messages("build")
        if code == 0:
            artifacts = {
                event["executable"] for event in events
                if event.get("reason") == "compiler-artifact" and event.get("executable")
                and event["target"]["name"] == "spiralcore_mvm_live" and event["profile"]["test"]
            }
            original, = artifacts
            shutil.copy2(original, binary)
            binary.chmod(0o500)
            write("binary-before.json", {"original": original, "sha256": sha(binary)})
            common = [str(binary), "--test-threads=1", "--nocapture"]
            root = "installed_owner::retained_telemetry::recovery::"
            cases = [
                ("activation", 4, ["--ignored", root + "activation_tests::"]),
                ("closed-inventory", 3, ["--ignored", root + "live_tests::"]),
                ("transfer-controls", 14, ["--ignored", root + "tests::b2_"]),
                ("size-guard", 1, ["--exact", root + "transition::size_tests::fixed_transfer_observer_fits_assigned_metadata_envelope"]),
            ]
            for name, count, selection in cases:
                status = invoke(name, [*common, *selection], env)
                results = re.findall(r"^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", (out / f"{name}.stdout").read_text(), re.M)
                actual = tuple(map(int, results[-1])) if results else None
                write(f"{name}.count.json", {"expected_passed": count, "actual": actual})
                if code == 0 and (status or actual != (count, 0, 0)):
                    code = status or 1
            if strict and code == 0:
                code = invoke("strict", [*cargo, "clippy", *options, "--tests", "--", "-D", "clippy::all"], env, "jsonl")
                messages("strict")
    finally:
        source_current = readbacks("after")
        new_fixture = fixture_identity()
        write("fixture-after.json", new_fixture)
        if binary.is_file():
            final = sha(binary)
            write("binary-after.json", {"sha256": final})
            assert final == json.loads((out / "binary-before.json").read_text())["sha256"]
        assert source_current and new_fixture == fixture
(out / "batch.exit").write_text(f"{code}\n")
sys.exit(code)
