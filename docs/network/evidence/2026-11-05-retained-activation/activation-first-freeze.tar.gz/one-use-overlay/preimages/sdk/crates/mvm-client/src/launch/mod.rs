//! Persistent + transient launch lifecycle through [`LocalBackend`].
//!
//! Both modes route through the one canonical admitted-boot seam
//! (`mvm_hostd::run::admit_and_boot_local`): the plan is synthesized, signed,
//! verified, window-checked, replay-checked, and chain-audited before the
//! backend sees a byte of launch config. Volume attachments resolve through
//! the local volume service (exclusive leases, RAII rollback on a failed
//! boot) and typed secret references are validated fail-closed and recorded
//! as metadata-only sidecars before any boot.

pub mod boot_order;
pub mod budget_charge;
pub mod built_pack;
pub mod bundle_runtime;
pub mod canonical_linux;
pub mod detached;
pub mod grants_report;
pub mod machine_start;
pub mod manifest_ref;
pub mod offline_attachment;
pub mod offline_revocation;
pub mod persistent;
mod request;
pub(crate) use request::persisted_spec_from_request;
pub mod runtime_overlay;
pub mod runtime_source;
pub mod start_params;
pub mod startup_budget;
#[cfg(test)]
mod tests;
mod transient;
mod unbooted;
#[cfg(unix)]
mod outcome_stop;
#[cfg(unix)]
mod host_lifetime_preflight;
#[cfg(unix)]
pub use host_lifetime_preflight::{
    AdmittedHostLifetimeLaunchFailure, HostLifetimeLaunchFailure,
    UnusedAdmittedHostLifetimePreparation, UnusedHostLifetimePreparation,
};

use unbooted::DefinitionOrigin;

pub use request::{
    AccessMode, HostLifetimeIntent, LaunchNetworkPolicy, LaunchRequest, LaunchRequestBuilder, LaunchSource,
    LaunchVolumeSpec, LifecycleMode, MachineSecretRef,
};

use std::path::PathBuf;
use std::sync::Arc;

use mvm_core::client::dto::{MachineId, MachineState, MachineStatus};
use mvm_core::client::{MvmError, Result};
use mvm_core::config::{machine_spec_path, machine_state_dir, machine_state_root, vm_state_dir};
use mvm_core::domain::instance::InstanceReadiness;
use mvm_core::plan::ExecutionPlan;
use mvm_core::protocol::vm_backend::{VmId, VmStatus};
use mvm_hostd::audit::emitter::{AuditEmitter, ExitRecord};
pub(crate) use mvm_hostd::audit::unsealed::{UnsealedEnd, UnsealedReason, record_unsealed_end};
use mvm_hostd::plan_admission::{AdmittedPlan, InMemoryNonceLedger, StartedMachine, SystemClock};
use mvm_hostd::run::{LocalRunContext, LocalRunRequest, admit_and_boot_local};
use mvm_runtime::AnyBackend;
use mvm_runtime::machine::persist as mp;

use crate::local::LocalBackend;
use crate::registration::{MachineRegistration, register_machine};
use crate::secret::SecretService;
use crate::volume::{
    AdmittedProfile, AttachmentRequest, LaunchLeaseRequest, LocalVolumeService, UnlockPolicy,
    VolumeService,
};

/// The tenant every locally-launched machine is admitted and scoped under —
/// mirrors the admission seam's fixed local tenant label.
const LOCAL_TENANT: &str = "local";

/// The result of a successful launch: the machine's observed state plus the
/// admitted plan identity (for correlation with the chain-signed audit log).
#[derive(Debug)]
pub struct LaunchOutcome {
    #[cfg(unix)]
    pub(crate) host_lifetime: Option<Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
    #[cfg(unix)]
    retirement: std::sync::Mutex<Option<mvm_runtime::workload_runner::OwnedRetirement>>,
    #[cfg(unix)]
    retirement_stopping: std::sync::atomic::AtomicBool,
    pub machine: MachineState,
    /// Content-addressed id of the admitted plan.
    pub plan_id: String,
    /// The token naming the request's command in the guest, when it carried
    /// one; the command keeps running after the launch returns.
    pub process: Option<String>,
    /// The admitted authority object used for this boot.
    ///
    /// Fleet stream orchestration needs the exact admitted plan to open the
    /// consumer's default-deny input route. Exposing that object keeps the
    /// caller from admitting a second copy with a second nonce merely to gain
    /// an input capability.
    pub admitted: AdmittedPlan,
    pub(crate) mode: LifecycleMode,
    pub(crate) plan: ExecutionPlan,
    /// When this process admitted the boot, for measuring the launch-to-exit
    /// wall span. `None` when this outcome was not built from a fresh launch
    /// in this process (there is no honest span to report), which keeps the
    /// wall metric `unavailable` rather than fabricated.
    pub(crate) launched_at: Option<std::time::Instant>,
}

#[cfg(unix)]
impl LaunchOutcome {
    /// Move the sealed endpoint owner once, without keeping the VM receipt
    /// mutex held during the parent's original disk cleanup.
    pub fn take_endpoint_retirement(&self) -> Result<Option<crate::EndpointRetirement>> {
        outcome_stop::check_idle(&self.retirement_stopping).map_err(crate::local::backend_err)?;
        let mut guard = self.retirement.try_lock().map_err(crate::local::backend_err)?;
        let receipt = guard.as_mut().ok_or_else(|| {
            crate::local::backend_err("original outcome has no positive owned retirement")
        })?;
        Ok(receipt.take_endpoint_retirement())
    }

    /// Borrow the sealed positive cleanup receipt without cloning or exporting
    /// ownership. The callback only validates/retires already-drained parent
    /// owners: never await, perform endpoint I/O or clean disk under this lock.
    pub fn with_owned_retirement<R>(
        &self,
        inspect: impl FnOnce(&mvm_runtime::workload_runner::OwnedRetirement) -> R,
    ) -> Result<R> {
        outcome_stop::check_idle(&self.retirement_stopping).map_err(crate::local::backend_err)?;
        let guard = self.retirement.try_lock().map_err(crate::local::backend_err)?;
        let receipt = guard.as_ref().ok_or_else(|| {
            crate::local::backend_err("original outcome has no positive owned retirement")
        })?;
        Ok(inspect(receipt))
    }
}

/// Exit report for a waited-on transient machine.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ExitReport {
    /// Captured workload exit code, when the guest reported one before
    /// shutdown; `None` when no capture exists (e.g. the hermetic mock).
    pub exit_code: Option<i32>,
}

/// The observed end of a CLI-owned transient run whose plan was already
/// admitted before boot. A missing exit code is never represented as zero.
pub struct TransientExitAudit<'a> {
    pub signed_plan_json: &'a str,
    pub vm_name: &'a str,
    pub backend: &'a str,
    pub exit_code: Option<i32>,
    pub completed: bool,
}

/// Options for [`LocalBackend::remove_machine_with`].
#[derive(Debug, Clone, Copy, Default)]
pub struct RemoveOptions {
    /// Explicitly requested force flow: stop a RUNNING persistent machine
    /// before removal. Without it, removing a running persistent machine is
    /// refused.
    pub force: bool,
}

struct CommandStartFailure {
    command: anyhow::Error,
    stop: Result<()>,
}

impl CommandStartFailure {
    fn into_error(self) -> MvmError {
        let reason = match self.stop {
            Ok(()) => format!("{:#}", self.command),
            Err(stop) => format!("{:#}; rollback stop failed: {stop}", self.command),
        };
        MvmError::Backend { reason }
    }
}

/// Generate a name for a nameless transient launch.
fn generated_transient_name() -> String {
    let n: u64 = rand::random();
    format!("transient-{:012x}", n & 0xffff_ffff_ffff)
}

/// RFC 3339 expiry timestamp `ttl_seconds` from now, or `None`.
fn expires_at_from_ttl(ttl_seconds: Option<u64>) -> Option<String> {
    ttl_seconds
        .map(|secs| (chrono::Utc::now() + chrono::Duration::seconds(secs as i64)).to_rfc3339())
}

/// Best-effort chain-signed emitter under the host signer. Audit emission is
/// tamper-evidence, not part of the admission decision: a construction
/// failure warns and the boot proceeds unaudited-on-chain (CLI parity).
fn build_audit_emitter() -> Option<AuditEmitter> {
    let signer = match mvm_hostd::audit::host_keypair::load_or_init() {
        Ok(signer) => signer,
        Err(e) => {
            tracing::warn!(error = %e, "host signer unavailable; skipping chain audit emission");
            return None;
        }
    };
    match AuditEmitter::new(signer.signing) {
        Ok(emitter) => Some(emitter.with_receipts()),
        Err(e) => {
            tracing::warn!(error = %e, "audit emitter unavailable; skipping chain audit emission");
            None
        }
    }
}

/// Record and seal a CLI-owned transient run before its state directory is
/// removed. The signed envelope comes from the admitted launch configuration;
/// an invalid signature cannot create an exit claim or a session seal.
pub fn record_transient_exit(exit: TransientExitAudit<'_>) -> Result<()> {
    let (emitter, plan) = match verified_transient_plan(exit.signed_plan_json) {
        Ok(verified) => verified,
        Err(e) => {
            record_unsealed_end(
                None,
                UnsealedEnd::new(exit.vm_name, UnsealedReason::NoVerifiedPlan).error(&e),
            );
            return Err(e);
        }
    };
    seal_transient_end(
        &emitter,
        &plan,
        TransientEnd {
            vm_name: exit.vm_name,
            backend: exit.backend,
            exit_code: exit.exit_code,
            completed: exit.completed,
        },
    )
}

/// Record that a CLI-owned transient run ended without a seal because its VM
/// could not be shown to be stopped. A session whose guest may still be
/// running is not sealed, but its end is still put on the record: chain-signed
/// under the admitted plan when that plan verifies, in the local audit log
/// when it does not.
pub fn record_transient_stop_failure(exit: TransientExitAudit<'_>, error: &str) {
    let end = UnsealedEnd::new(exit.vm_name, UnsealedReason::StopFailed).error(error);
    match verified_transient_plan(exit.signed_plan_json) {
        Ok((emitter, plan)) => record_unsealed_end(Some((&emitter, &plan)), end),
        Err(_) => record_unsealed_end(None, end),
    }
}

/// The admitted plan carried in a transient run's signed envelope, verified
/// under the host signer, and the emitter to record its end with.
fn verified_transient_plan(signed_plan_json: &str) -> Result<(AuditEmitter, ExecutionPlan)> {
    let signed: mvm_core::plan::SignedExecutionPlan =
        serde_json::from_str(signed_plan_json).map_err(crate::local::backend_err)?;
    let signer =
        mvm_hostd::audit::host_keypair::load_or_init().map_err(crate::local::backend_err)?;
    let signer_id = mvm_hostd::audit::host_keypair::host_signer_id();
    let plan = mvm_core::plan::verify_plan(&signed, &[(signer_id.as_str(), &signer.verifying)])
        .map_err(crate::local::backend_err)?;
    let emitter = AuditEmitter::new(signer.signing)
        .map(AuditEmitter::with_receipts)
        .map_err(crate::local::backend_err)?;
    Ok((emitter, plan))
}

/// How a transient run whose VM has already been stopped ended.
pub(crate) struct TransientEnd<'a> {
    pub(crate) vm_name: &'a str,
    pub(crate) backend: &'a str,
    /// The observed exit code; `None` when none was observed, never zero.
    pub(crate) exit_code: Option<i32>,
    /// Whether the workload ran to an exit, as opposed to a failed dispatch.
    pub(crate) completed: bool,
}

/// Close a transient run's session under its admitted `plan`: `plan.exited`
/// with the observed exit and captured usage, then the seal (`exited`, or
/// `failed` for a run that did not complete), then the closing root.
///
/// Each step runs only if the one before it was written, so a failure leaves
/// the session `UNSEALED` rather than sealed over a missing exit record. The
/// caller stops the VM first: sealing a session whose VM may still be running
/// would close a narrative the guest can still extend.
pub(crate) fn seal_transient_end(
    emitter: &AuditEmitter,
    plan: &ExecutionPlan,
    end: TransientEnd<'_>,
) -> Result<()> {
    let state_dir = vm_state_dir(end.vm_name);
    let mut usage = mvm_core::usage_capture::read_captured(&state_dir);
    usage.host_state_bytes = mvm_core::usage_capture::host_state_bytes(&state_dir);
    let reason = if end.completed {
        mvm_hostd::audit::session::SealReason::Exited
    } else {
        mvm_hostd::audit::session::SealReason::Failed
    };
    // The exit record, the seal and the closing root reach the disk in one
    // flush, as admission's records do. Nothing acts on any of them before
    // this returns, so syncing each on its own bought no ordering; it bought
    // one serial fsync per record on a path the caller waits on. A flush that
    // fails is a seal that failed, and is recorded as one.
    let closed = emitter.batched(|| {
        emitter.emit_exit_record(
            plan,
            ExitRecord {
                exit_code: end.exit_code,
                backend: end.backend,
                usage,
            },
        )?;
        emitter.seal_session(plan, reason)?;
        // The session is sealed from here: a root that fails to publish
        // weakens a later consistency check but leaves the seal in place.
        Ok(emitter.publish_root(&plan.tenant.0).map(drop))
    });
    let published = match closed {
        Ok(published) => published,
        Err(e) => {
            let e = crate::local::backend_err(format!("{e:#}"));
            record_unsealed_end(
                Some((emitter, plan)),
                UnsealedEnd::new(end.vm_name, UnsealedReason::SealFailed).error(&e),
            );
            return Err(e);
        }
    };
    if let Err(e) = published {
        tracing::warn!(
            error = %format!("{e:#}"),
            machine = end.vm_name,
            "could not publish an audit root at exit; the session is sealed but a later \
             consistency check has one fewer point to verify against"
        );
        return Err(crate::local::backend_err(format!("{e:#}")));
    }
    mvm_hostd::audit::witness::flush_configured(emitter.audit_dir(), &plan.tenant.0);
    Ok(())
}

/// The records that close a waited-for run, written best-effort: the workload
/// already ran, so a failure here is reported rather than failing the exit
/// report.
struct ClosingRecords<'a> {
    plan: &'a ExecutionPlan,
    machine: &'a str,
    memory_limit_exceeded: Option<&'a mvm_core::spawn_scope::MemoryLimitExceeded>,
    exit: ExitRecord<'a>,
}

impl ClosingRecords<'_> {
    /// Write them, and say whether the closing root was published.
    ///
    /// The exit record, the seal and the closing root reach the disk in one
    /// flush, as admission's records and the transient path do. Nothing acts
    /// on any of them before this returns, so syncing each on its own bought
    /// no ordering; it bought one serial fsync per record on a path the
    /// caller waits on.
    fn record(&self, emitter: &AuditEmitter) -> bool {
        let (plan, name) = (self.plan, self.machine);
        let closed = emitter.batched(|| {
            if let Some(exceeded) = self.memory_limit_exceeded {
                emitter.emit_memory_limit_exceeded(plan, exceeded)?;
            }
            emitter.emit_exit_record(plan, self.exit)?;
            emitter.seal_session(plan, mvm_hostd::audit::session::SealReason::Exited)?;
            Ok(emitter.publish_root(&plan.tenant.0).map(drop))
        });
        match closed {
            Ok(Ok(())) => true,
            Ok(Err(e)) => {
                tracing::warn!(
                    error = %format!("{e:#}"),
                    machine = name,
                    "could not publish an audit root at exit; the log stays intact but a later \
                     consistency check has one fewer point to verify against"
                );
                // The seal is on disk; only the root failed.
                true
            }
            Err(e) => {
                tracing::warn!(error = %format!("{e:#}"), machine = name, "audit closing records failed (non-fatal)");
                record_unsealed_end(
                    Some((emitter, plan)),
                    UnsealedEnd::new(name, UnsealedReason::SealFailed).error(format!("{e:#}")),
                );
                false
            }
        }
    }
}

/// Seal the session of a persistent machine that was just stopped, then publish
/// the closing root over it. Best-effort for the same reason as at exit: the
/// machine is already stopped, and a missing seal is reported by
/// `trust audit verify` as `UNSEALED` rather than hidden.
pub(crate) fn seal_stopped_session(plan: &mvm_core::plan::ExecutionPlan, machine: &str) {
    let Some(emitter) = build_audit_emitter() else {
        record_unsealed_end(
            None,
            UnsealedEnd::new(machine, UnsealedReason::SealFailed)
                .error(format!("no host audit emitter for plan {}", plan.plan_id.0)),
        );
        return;
    };
    if let Err(e) = mvm_hostd::supervisor::session_expiry::seal_stopped_session(&emitter, plan) {
        record_unsealed_end(
            Some((&emitter, plan)),
            UnsealedEnd::new(machine, UnsealedReason::SealFailed).error(format!("{e:#}")),
        );
    }
}

/// Record that a session's VM could not be stopped, so it was not sealed:
/// chain-signed under `plan` when there is one, locally otherwise.
pub(crate) fn record_session_stop_failure(
    plan: Option<&mvm_core::plan::ExecutionPlan>,
    machine: &str,
    error: &str,
) {
    let end = UnsealedEnd::new(machine, UnsealedReason::StopFailed).error(error);
    match (plan, build_audit_emitter()) {
        (Some(plan), Some(emitter)) => record_unsealed_end(Some((&emitter, plan)), end),
        _ => record_unsealed_end(None, end),
    }
}

impl LocalBackend {
    /// The secret lifecycle service to validate/record references through:
    /// the injected one, else the production-wired local service.
    fn secrets(&self) -> Result<Arc<SecretService>> {
        if let Some(service) = &self.secret_service {
            return Ok(service.clone());
        }
        SecretService::local()
            .map(Arc::new)
            .map_err(|e| crate::local::backend_err(format!("secret service: {e}")))
    }

    /// Clear a machine's secret-reference sidecar through the same seam
    /// [`SecretService::clear_machine_references`] wraps. Idempotent.
    fn clear_secret_refs(&self, name: &str) -> Result<()> {
        match &self.secret_service {
            Some(service) => service
                .clear_machine_references(name)
                .map_err(|e| crate::local::backend_err(format!("clearing secret refs: {e}"))),
            None => crate::secret::refs::clear_refs(&machine_state_root(), name)
                .map_err(|e| crate::local::backend_err(format!("clearing secret refs: {e:#}"))),
        }
    }

    /// Whether `name` is running: prefer the VMM that owns the started VM
    /// (state-dir marker), falling back to this client's backend so the
    /// hermetic mock stays observable.
    fn machine_running(&self, name: &str) -> bool {
        #[cfg(unix)]
        if mvm_core::host_lifetime::require_no_installed_native(name).is_err() {
            // Occupied/uncertain is a refusal here, never a positive running
            // or exit receipt reconstructed from this marker.
            return true;
        }
        let status = match AnyBackend::for_started_vm(name) {
            Some(owner) => owner.status(&VmId(name.to_string())),
            None => self.backend.status(&VmId(name.to_string())),
        };
        matches!(status, Ok(VmStatus::Running))
    }

    /// Resolve the backend handle for a launch: the request override when it
    /// names a different hypervisor (validated selectable), else this
    /// client's own backend.
    fn launch_backend(&self, override_name: Option<&str>) -> Result<BackendHandle<'_>> {
        match override_name {
            Some(name) if name != self.backend.name() => {
                crate::boot::require_hypervisor_selectable(name)?;
                Ok(BackendHandle::Owned(AnyBackend::from_hypervisor(name)))
            }
            _ => Ok(BackendHandle::Borrowed(&self.backend)),
        }
    }
}

/// A borrowed-or-owned backend handle (`AnyBackend` is not `Clone`, so `Cow`
/// can't carry it). Borrowing the client's own backend keeps the hermetic
/// in-memory mock observable across the launch verbs.
enum BackendHandle<'a> {
    Borrowed(&'a AnyBackend),
    Owned(AnyBackend),
}

impl std::ops::Deref for BackendHandle<'_> {
    type Target = AnyBackend;

    fn deref(&self) -> &AnyBackend {
        match self {
            BackendHandle::Borrowed(backend) => backend,
            BackendHandle::Owned(backend) => backend,
        }
    }
}

/// The resolved inputs for one admitted boot — the shared core both
/// lifecycle modes (and the trait's `run_machine`) reach.
pub(crate) struct BootParams {
    #[cfg(unix)]
    pub(crate) original_admitted: Option<Box<AdmittedPlan>>,
    #[cfg(unix)]
    pub(crate) host_lifetime: Option<Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
    pub(crate) name: String,
    pub(crate) source: LaunchSource,
    pub(crate) profile: String,
    pub(crate) cpus: u32,
    pub(crate) memory_mib: u32,
    pub(crate) backend_override: Option<String>,
    pub(crate) volumes: Vec<mvm_core::vm_backend::VmVolume>,
    pub(crate) transient: bool,
    /// The request's permission set, carried into the signed plan and — for
    /// its egress dimension — into the policy the gate enforces.
    pub(crate) grants: Option<mvm_contract::grants::Grants>,
    /// A fleet-issued signed plan to admit instead of synthesizing one.
    /// `Some` only when the launch request carried one; admission then
    /// verifies it against the operator-pinned `trusted_plan_signers` and the
    /// plan becomes the authority for sizing, grants, and teardown intent.
    pub(crate) signed_plan: Option<mvm_core::plan::SignedExecutionPlan>,
    /// Path to an operator-authored campaign declaration, when one was asked
    /// for. Read and validated here, so a malformed declaration refuses the
    /// launch instead of producing a boot with no campaign on it.
    pub(crate) assurance_campaign: Option<std::path::PathBuf>,
    pub(crate) secrets: crate::admission::secrets::ResolvedPlanSecrets,
}

impl LocalBackend {
    /// Resolve the per-backend workload kernel: every kernel-booting backend
    /// boots a verified kernel from the CLI-populated cache.
    ///
    /// One arm serves all of them. Firecracker and the qemu dev tier used to
    /// take a separate branch that accepted the cache path on `is_file()`, so
    /// the backend that carries real workloads on Linux booted whatever sat at
    /// the expected filename while HVF next door required a digest match.
    pub(crate) fn resolve_workload_kernel(backend: &AnyBackend) -> Result<Option<PathBuf>> {
        machine_start::cached_workload_kernel(backend.name())
            .map(|kernel| kernel.map(PathBuf::from))
            .map_err(|e| crate::local::backend_err(format!("{e:#}")))
    }

    /// Boot one machine through the canonical signed-plan admission seam.
    /// The chain-signed `plan.admitted`/`plan.launched`/`plan.failed`
    /// entries are emitted inside the seam; any failure returns with no VM
    /// created.
    pub(crate) async fn boot_admitted(&self, params: BootParams) -> Result<StartedMachine> {
        let backend = self.launch_backend(params.backend_override.as_deref())?;
        // Crash/unclean-stop leftovers in the per-VM runtime dir (notably a
        // stale substitution-endpoint socket) make the fresh endpoint die
        // binding it before its ready handshake; a non-running machine owns
        // no live state there, so recover by starting from an empty dir.
        #[cfg(unix)]
        let installed = params.host_lifetime.is_some();
        #[cfg(not(unix))]
        let installed = false;
        #[cfg(unix)]
        if params.original_admitted.is_some() && !installed {
            return Err(MvmError::InvalidSpec {
                reason: "original admitted launch requires its installed host lifetime".into(),
            });
        }
        if !installed && !self.machine_running(&params.name) {
            remove_vm_runtime_dirs(&params.name)?;
        }
        let (rootfs, kernel_path, verity_path, roothash, registry_pack_image) = match &params.source
        {
            LaunchSource::Image(image) => {
                let rootfs = crate::local::resolve_local_rootfs(image, &params.name).await?;
                let (verity, hash) = crate::local::host_verity_sidecars(&rootfs);
                (
                    rootfs,
                    Self::resolve_workload_kernel(&backend)?,
                    verity.map(PathBuf::from),
                    hash,
                    None,
                )
            }
            LaunchSource::RegistryPack { pin } => {
                let image =
                    built_pack::resolve_built_pack_image(pin, backend.name(), &params.profile)
                        .map_err(|error| crate::local::backend_err(format!("{error:#}")))?;
                (
                    PathBuf::from(image.rootfs_path),
                    image.kernel_path.map(PathBuf::from),
                    image.verity_path.map(PathBuf::from),
                    image.roothash,
                    Some(pin.clone()),
                )
            }
            LaunchSource::Built { .. } => {
                return Err(MvmError::InvalidSpec {
                    reason: "a manifest-built workload boots as a persistent machine".into(),
                });
            }
        };

        let req = LocalRunRequest {
            name: params.name.clone(),
            rootfs_path: rootfs,
            kernel_path,
            verity_path,
            roothash,
            cpus: params.cpus,
            mem_mib: params.memory_mib,
            backend_name: backend.name().to_string(),
            volumes: params.volumes,
            destroy_on_exit: params.transient,
            grants: params.grants.clone(),
            secret_release: params.secrets.secret_release,
            secrets: params.secrets.secrets,
            signed_plan: params.signed_plan.clone(),
            registry_pack_image,
        };

        // A plan the host signs itself carries a fresh random nonce, so a
        // per-launch ledger is enough. A plan someone else signed can be
        // submitted again until it expires, so its nonce is recorded in the
        // host's durable ledger, shared by every launch. A ledger that cannot
        // be opened refuses the launch. Keys dir `None` → the host signer at
        // the configured keys dir.
        #[cfg(unix)]
        let consuming = params.original_admitted.is_some();
        #[cfg(not(unix))]
        let consuming = false;
        let ledger = if consuming {
            None
        } else if params.signed_plan.is_some() {
            Some(InMemoryNonceLedger::durable().map_err(|e| {
                crate::local::backend_err(format!(
                    "opening the plan replay ledger {}: {e}",
                    mvm_core::config::plan_nonce_dir().display()
                ))
            })?)
        } else {
            Some(InMemoryNonceLedger::new())
        };
        let clock = SystemClock;
        let emitter = build_audit_emitter().map(std::sync::Arc::new);

        // Read the declaration before the boot: a campaign an operator asked
        // for and that turns out to be malformed must refuse the launch, not
        // produce a running workload with no campaign attached to it.
        #[cfg(unix)]
        let campaign_grants = match &params.original_admitted {
            Some(admitted) => admitted.plan().grants.as_ref(),
            None => params.grants.as_ref(),
        };
        #[cfg(not(unix))]
        let campaign_grants = params.grants.as_ref();
        let campaign = match (&params.assurance_campaign, &emitter) {
            (Some(path), Some(emitter)) => Some(
                Self::build_campaign(path, emitter, &backend, campaign_grants)
                    .map_err(|e| crate::local::backend_err(format!("{e:#}")))?,
            ),
            (Some(_), None) => {
                return Err(crate::local::backend_err(
                    "an assurance campaign was declared but this process writes no audit chain, \
                     so nothing the campaign did could be recorded"
                        .to_string(),
                ));
            }
            (None, _) => None,
        };

        #[cfg(unix)]
        if let Some(admitted) = params.original_admitted {
            let owner = params.host_lifetime.ok_or_else(|| MvmError::InvalidSpec {
                reason: "original admitted launch has no installed host lifetime".into(),
            })?;
            return mvm_hostd::run::boot_admitted_local_with_host_lifetime(
                &backend,
                &req,
                *admitted,
                emitter.as_deref(),
                campaign.as_ref(),
                owner,
            )
            .map_err(|e| crate::local::backend_err(format!("{e:#}")));
        }
        let ledger = ledger.ok_or_else(|| crate::local::backend_err("admission ledger absent"))?;

        #[cfg(unix)]
        if let Some(owner) = params.host_lifetime {
            return mvm_hostd::run::admit_and_boot_local_with_host_lifetime(
                &backend,
                &req,
                LocalRunContext {
                    clock: &clock,
                    ledger: &ledger,
                    host_signer_keys_dir: None,
                    emitter: emitter.as_deref(),
                    assurance: campaign.as_ref(),
                },
                owner,
            )
            .map_err(|e| crate::local::backend_err(format!("{e:#}")));
        }
        admit_and_boot_local(
            &backend,
            &req,
            LocalRunContext {
                clock: &clock,
                ledger: &ledger,
                host_signer_keys_dir: None,
                emitter: emitter.as_deref(),
                assurance: campaign.as_ref(),
            },
        )
        .map_err(|e| crate::local::backend_err(format!("{e:#}")))
    }

    /// Load a declared campaign and bind it to this boot.
    ///
    /// The policy handed to the probe is the one the launch was granted, so a
    /// probe asks the same question the workload's own egress would: an
    /// operator cannot widen what a campaign observes by writing a different
    /// policy into the declaration, because the declaration carries none.
    fn build_campaign(
        path: &std::path::Path,
        emitter: &std::sync::Arc<AuditEmitter>,
        backend: &AnyBackend,
        grants: Option<&mvm_contract::grants::Grants>,
    ) -> anyhow::Result<mvm_hostd::assurance_session::CampaignRequest> {
        let declaration = mvm_hostd::assurance_session::load_declaration(path)?;
        // The policy handed to the probe is the launch's own granted egress, so
        // a probe asks exactly the question the workload's traffic would. A
        // declaration carries no policy of its own, so an operator cannot widen
        // what a campaign observes by writing one.
        let policy = grants
            .and_then(|g| g.egress.as_ref())
            .map(|egress| {
                mvm_core::policy::network_policy::NetworkPolicy::allow_list(egress.allow.clone())
            })
            .unwrap_or_else(mvm_core::policy::network_policy::NetworkPolicy::deny_all);
        Ok(mvm_hostd::assurance_session::CampaignRequest {
            declaration,
            emitter: std::sync::Arc::clone(emitter),
            policy_ceiling: mvm_hostd::assurance_session::default_policy_ceiling(),
            policy,
            backend: format!("{:?}", backend.kind()).to_lowercase(),
            now_unix_ms: std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| u64::try_from(d.as_millis()).unwrap_or(u64::MAX))
                .unwrap_or(0),
        })
    }

    /// Fail-closed admission validation of typed secret references, then
    /// persist the metadata-only sidecar. Runs on every admission that
    /// declares references; a machine with any invalid reference must not
    /// boot (and nothing is recorded for it).
    fn validate_and_record_secret_refs(&self, name: &str, refs: &[MachineSecretRef]) -> Result<()> {
        if refs.is_empty() {
            return Ok(());
        }
        let service = self.secrets()?;
        service
            .validate_for_admission(LOCAL_TENANT, refs)
            .map_err(|e| MvmError::Rejected {
                reason: format!("secret reference admission refused: {e}"),
            })?;
        service
            .record_machine_references(name, refs)
            .map_err(|e| crate::local::backend_err(format!("recording secret refs: {e}")))
    }

    /// Register the request's typed volume attachments for `name`. An
    /// identical existing registration is reused; a guest path already
    /// claimed by a different volume/access is a conflict.
    fn register_volume_attachments(
        &self,
        name: &str,
        volumes: &[LaunchVolumeSpec],
        profile: AdmittedProfile,
    ) -> Result<()> {
        if volumes.is_empty() {
            return Ok(());
        }
        let service = launch_volume_service();
        let existing = service
            .list_attachments(name)
            .map_err(|e| crate::local::backend_err(format!("listing attachments: {e:#}")))?;
        for spec in volumes {
            let identical = existing.iter().any(|a| {
                a.guest_path == spec.guest_path
                    && a.volume == spec.volume
                    && a.access == spec.access
            });
            if identical {
                continue;
            }
            if existing.iter().any(|a| a.guest_path == spec.guest_path) {
                return Err(MvmError::Conflict {
                    reason: format!(
                        "guest path {:?} is already attached with a different volume or \
                         access mode; detach it first",
                        spec.guest_path
                    ),
                });
            }
            let request = AttachmentRequest::builder(name, &spec.volume)
                .and_then(|b| {
                    b.guest_path(&spec.guest_path)
                        .access(spec.access)
                        .profile(profile)
                        .build()
                })
                .map_err(|e| MvmError::InvalidSpec {
                    reason: format!("volume attachment {:?}: {e:#}", spec.volume),
                })?;
            service.prepare_attachment(&request).map_err(|e| {
                crate::local::backend_err(format!("attaching {:?}: {e:#}", spec.volume))
            })?;
        }
        Ok(())
    }

    /// Resolve `name`'s registered attachments and take exclusive leases for
    /// this launch (locked managed volumes unlock just in time and re-seal
    /// on release).
    fn acquire_leases(
        &self,
        name: &str,
        profile: AdmittedProfile,
    ) -> Result<crate::volume::LaunchPreparation> {
        let request = LaunchLeaseRequest::builder(name)
            .map_err(|e| MvmError::InvalidSpec {
                reason: format!("{e:#}"),
            })?
            .profile(profile)
            .unlock(UnlockPolicy::JustInTime)
            .build();
        launch_volume_service()
            .acquire_launch_lease(&request)
            .map_err(|e| crate::local::backend_err(format!("volume leases for {name:?}: {e:#}")))
    }
}

/// The volume service a library launch admits volumes through.
///
/// A launch can unlock, attach, and lease managed volumes, so it needs the
/// platform's storage detector rather than the deny-all default. Unit tests
/// supply synthetic evidence instead of running host tools against a
/// temporary directory.
pub(crate) fn launch_volume_service() -> LocalVolumeService {
    #[cfg(not(test))]
    {
        LocalVolumeService::with_system_host_encryption_probe()
    }
    #[cfg(test)]
    {
        crate::volume::test_support::service()
    }
}

impl LocalBackend {
    /// Refuse a transient launch whose name is already claimed — by a
    /// persisted definition (that name is managed via the persistent verbs)
    /// or by a live VM.
    fn ensure_transient_name_free(&self, name: &str) -> Result<()> {
        #[cfg(unix)]
        mvm_core::host_lifetime::require_no_installed_native(name)
            .map_err(crate::local::backend_err)?;
        if machine_spec_path(name).exists() {
            return Err(MvmError::Conflict {
                reason: format!(
                    "a persistent machine named {name:?} exists; use the persistent \
                     lifecycle verbs (or another name)"
                ),
            });
        }
        if self.machine_running(name) {
            return Err(MvmError::Conflict {
                reason: format!("a machine named {name:?} is already running"),
            });
        }
        Ok(())
    }

    /// Reconcile + persist the declarative definition for a persistent
    /// launch. A same-config definition is reused; a different config is
    /// refused without `force` and recreated (stopping any old instance)
    /// with it. Never boots. Says whether the definition was written from
    /// nothing, which decides whether a failure later in the launch removes it.
    fn persist_definition(
        &self,
        request: &LaunchRequest,
        name: &str,
    ) -> Result<(mp::MachineSpec, DefinitionOrigin)> {
        #[cfg(unix)]
        mvm_core::host_lifetime::require_no_installed_native(name)
            .map_err(crate::local::backend_err)?;
        let desired = persisted_spec_from_request(request, name);
        let existing = if machine_spec_path(name).exists() {
            Some(mp::load_machine_spec(name).map_err(crate::local::backend_err)?)
        } else {
            None
        };
        let reconcile = mp::reconcile_machine_spec(existing.as_ref(), &desired, request.force)
            .map_err(|e| MvmError::Conflict {
                reason: format!("{e:#}"),
            })?;
        match reconcile {
            mp::SpecReconcile::Create => {
                // The exists() above only informed the reconcile decision;
                // it is not relied on for exclusivity. Another creator can
                // still win the race between that check and this write, but
                // `save_machine_spec`'s write is itself exclusive below, so
                // a lost race surfaces here as an `already exists` failure
                // rather than a clobber — map it to the same conflict a
                // caller gets from a pre-existing spec, instead of a
                // generic backend error.
                mp::save_machine_spec(&desired, false).map_err(|err| {
                    if mvm_core::atomic_io::is_already_exists(&err) {
                        MvmError::Conflict {
                            reason: err.to_string(),
                        }
                    } else {
                        crate::local::backend_err(err)
                    }
                })?;
                mvm_core::audit_emit!(ConfigChange, vm: name, "action=machine.create mode=persistent");
                Ok((desired, DefinitionOrigin::Created))
            }
            mp::SpecReconcile::Reuse => Ok((
                existing.expect("reuse implies an existing spec"),
                DefinitionOrigin::Existing,
            )),
            mp::SpecReconcile::Recreate { changed } => {
                if self.machine_running(name) {
                    self.stop_for_recreate(name)?;
                }
                mp::overwrite_machine_spec(&desired).map_err(crate::local::backend_err)?;
                mvm_core::audit_emit!(
                    ConfigChange,
                    vm: name,
                    "action=machine.recreate changed={changed}"
                );
                Ok((desired, DefinitionOrigin::Existing))
            }
        }
    }

    /// Refuse destructive follow-up when the existing instance cannot be stopped.
    fn stop_for_recreate(&self, name: &str) -> Result<()> {
        let vid = VmId(name.to_string());
        let result = match AnyBackend::for_started_vm(name) {
            Some(owner) => owner.stop(&vid),
            None => self.backend.stop(&vid),
        };
        result.map(|_| ()).map_err(|error| {
            crate::local::backend_err(format!("stopping machine {name:?}: {error:#}"))
        })
    }

    /// Retain one original installation lifetime through the canonical launch.
    /// This owner is resource custody; canonical signed admission still runs.
    #[cfg(unix)]
    pub async fn launch_with_host_lifetime(
        &self,
        request: LaunchRequest,
        lifetime: mvm_core::host_lifetime::PreparedHostLifetime,
    ) -> Result<LaunchOutcome> {
        self.try_launch_with_host_lifetime(request, lifetime)
            .await
            .map_err(HostLifetimeLaunchFailure::into_error)
    }

    /// Preserve the same unused preparation only on the four direct pure
    /// preflight refusals. Conversion and every later error remain uncertain.
    #[cfg(unix)]
    pub async fn try_launch_with_host_lifetime(
        &self,
        mut request: LaunchRequest,
        lifetime: mvm_core::host_lifetime::PreparedHostLifetime,
    ) -> std::result::Result<LaunchOutcome, HostLifetimeLaunchFailure> {
        if let Err(error) = self.check_installed_launch_preflight(&request) {
            return Err(HostLifetimeLaunchFailure::unused(error, lifetime));
        }
        request.host_lifetime = Some(
            self.bind_installed_launch_lifetime(&request, lifetime)
                .map_err(HostLifetimeLaunchFailure::converted)?,
        );
        self.launch(request)
            .await
            .map_err(HostLifetimeLaunchFailure::converted)
    }

    /// Launch using the exact already-admitted token and original preparation.
    /// Pure preflight refusal returns both unchanged; after conversion, the
    /// original runtime/parent custody governs uncertainty and teardown.
    /// No replacement plan, signature, or nonce spend is performed.
    #[cfg(unix)]
    pub async fn try_launch_admitted_with_host_lifetime(
        &self,
        mut request: LaunchRequest,
        lifetime: mvm_core::host_lifetime::PreparedHostLifetime,
        admitted: AdmittedPlan,
    ) -> std::result::Result<LaunchOutcome, AdmittedHostLifetimeLaunchFailure> {
        let preflight = self.check_installed_launch_preflight(&request).and_then(|()| {
            admitted
                .check_current_for_backend(self.backend.kind())
                .map_err(crate::local::backend_err)?;
            let plan = admitted.plan();
            let binding = lifetime.binding();
            if request.signed_plan.is_some()
                || request.host_lifetime.is_some()
                || !plan.post_run.destroy_on_exit
                || request.name.as_deref() != Some(binding.vm_name.as_str())
                || binding.backend != self.backend.kind()
                || request.cpus != plan.resources.cpus
                || u64::from(request.memory_mib) != plan.resources.mem_mib
                || request.cpus != binding.cpus
                || request.memory_mib != binding.memory_mib
            {
                return Err(MvmError::InvalidSpec {
                    reason: "installed request differs from its original admitted plan or lifetime"
                        .into(),
                });
            }
            Ok(())
        });
        if let Err(error) = preflight {
            return Err(AdmittedHostLifetimeLaunchFailure::unused(error, lifetime, admitted));
        }
        request.host_lifetime = Some(
            self.bind_installed_launch_lifetime(&request, lifetime)
                .map_err(AdmittedHostLifetimeLaunchFailure::converted)?,
        );
        self.launch_inner(request, Some(Box::new(admitted)))
            .await
            .map_err(AdmittedHostLifetimeLaunchFailure::converted)
    }

    #[cfg(unix)]
    fn check_installed_launch_preflight(&self, request: &LaunchRequest) -> Result<()> {
        if request.mode != LifecycleMode::Transient || request.name.is_none() {
            return Err(MvmError::InvalidSpec {
                reason: "installed host lifetime requires an explicitly named transient launch"
                    .into(),
            });
        }
        if request
            .backend
            .as_deref()
            .is_some_and(|name| name != self.backend.name())
        {
            return Err(MvmError::InvalidSpec {
                reason: "installed host lifetime requires the original LocalBackend".into(),
            });
        }
        mvm_hostd::host_lifetime_parent::require_installed().map_err(crate::local::backend_err)?;
        if !self.backend.supports_host_lifetime() {
            return Err(MvmError::InvalidSpec {
                reason: "backend has no original installed native lifetime".into(),
            });
        }
        Ok(())
    }

    #[cfg(unix)]
    fn bind_installed_launch_lifetime(
        &self,
        request: &LaunchRequest,
        lifetime: mvm_core::host_lifetime::PreparedHostLifetime,
    ) -> Result<Arc<mvm_core::host_lifetime::HostLifetimeAnchor>> {
        let intent = request.host_lifetime_intent();
        let anchor = lifetime.into_anchor();
        let mut shape = mvm_core::vm_backend::VmStartConfig {
            name: intent.name.ok_or_else(|| MvmError::InvalidSpec {
                reason: "installed name missing".into(),
            })?,
            cpus: intent.cpus,
            memory_mib: intent.memory_mib,
            ..Default::default()
        };
        if anchor.binding().backend != self.backend.kind() {
            return Err(MvmError::InvalidSpec {
                reason: "installed lifetime backend differs".into(),
            });
        }
        anchor.bind_to_config(&mut shape).map_err(crate::local::backend_err)?;
        Ok(anchor)
    }

    /// Install the original owned host-agent registrar before any installed launch.
    #[cfg(unix)]
    pub fn with_installed_host_agent(
        self,
        registrar: mvm_vmm::host::host_agent_spawn::OwnedHostAgentRegistrar,
    ) -> Result<Self> {
        self.install_owned_host_agent(registrar)?;
        Ok(self)
    }

    /// Bind the original registrar without moving or replacing this backend.
    /// The underlying runner retains its install-once and no-active-launch guard.
    #[cfg(unix)]
    pub fn install_owned_host_agent(
        &self,
        registrar: mvm_vmm::host::host_agent_spawn::OwnedHostAgentRegistrar,
    ) -> Result<()> {
        self.backend
            .install_owned_host_agent(registrar)
            .map_err(crate::local::backend_err)
    }

    /// Stop only the retained original native owner. No backend reconstruction.
    #[cfg(unix)]
    pub async fn stop_owned(&self, outcome: &LaunchOutcome) -> Result<()> {
        let anchor = outcome
            .host_lifetime
            .as_ref()
            .ok_or_else(|| MvmError::InvalidSpec {
                reason: "launch outcome has no original installed owner".into(),
            })?;
        if anchor.binding().vm_name != outcome.machine.id.0
            || anchor.binding().backend != self.backend.kind()
        {
            return Err(MvmError::InvalidSpec {
                reason: "installed launch outcome substituted".into(),
            });
        }
        let id = VmId(outcome.machine.id.0.clone());
        outcome_stop::run(&outcome.retirement, &outcome.retirement_stopping, anchor, || {
            self.backend.stop_owned(&id, anchor)?;
            self.backend.take_owned_retirement(&id, anchor)
        }).map_err(crate::local::backend_err)
    }

    /// Recover failed launch cleanup only through this original backend's
    /// retained native record. Keep the linear receipt through parent release.
    /// Unknown/consumed records never become successful cleanup by absence.
    #[cfg(unix)]
    pub async fn stop_owned_pending(&self,
        binding: &mvm_core::host_lifetime::HostLaunchBinding)
        -> Result<mvm_runtime::workload_runner::OwnedRetirement> {
        if binding.backend != self.backend.kind() {
            return Err(MvmError::InvalidSpec {
                reason: "pending installed backend differs from original".into(),
            });
        }
        self.backend.stop_owned_pending(binding).map_err(crate::local::backend_err)?;
        self.backend.take_owned_retirement_pending(binding).map_err(crate::local::backend_err)
    }

    /// Launch a machine from a fully-validated typed request. Transient
    /// requests boot immediately and are cleaned up on exit/TTL; persistent
    /// requests persist their definition first, then boot from it — both
    /// through the one canonical signed-admission seam.
    pub async fn launch(&self, request: LaunchRequest) -> Result<LaunchOutcome> {
        self.launch_inner(
            request,
            #[cfg(unix)]
            None,
        )
        .await
    }

    async fn launch_inner(
        &self,
        request: LaunchRequest,
        #[cfg(unix)] original_admitted: Option<Box<AdmittedPlan>>,
    ) -> Result<LaunchOutcome> {
        #[cfg(unix)]
        if original_admitted.is_some()
            && (request.mode != LifecycleMode::Transient || request.host_lifetime.is_none())
        {
            return Err(MvmError::InvalidSpec {
                reason: "original admission requires an installed transient launch".into(),
            });
        }
        if let LaunchSource::RegistryPack { pin } = &request.source {
            let backend = self.launch_backend(request.backend.as_deref())?;
            built_pack::resolve_built_pack_image(pin, backend.name(), &request.profile)
                .map_err(|error| crate::local::backend_err(format!("{error:#}")))?;
        }
        match request.mode {
            LifecycleMode::Transient => self.launch_transient(
                request,
                #[cfg(unix)]
                original_admitted,
            ).await,
            LifecycleMode::Persistent => {
                let name = request
                    .name
                    .clone()
                    .expect("validated: persistent requests carry a name");
                let (_, origin) = self.create_definition(&request, &name)?;
                let booted = self.boot_persistent(&name, &request).await;
                let outcome = self.discard_definition_on_failure(&name, origin, booted)?;
                match self.start_requested_command(outcome, &request) {
                    Ok(outcome) => Ok(outcome),
                    // A later name-based observation cannot erase a known stop error.
                    Err(failure) if failure.stop.is_err() => Err(failure.into_error()),
                    Err(failure) => {
                        self.discard_definition_on_failure(&name, origin, Err(failure.into_error()))
                    }
                }
            }
        }
    }

    /// Persist a machine definition (spec + secret-reference sidecar +
    /// typed volume attachments) without booting. Persistent mode only.
    pub fn create_from_request(&self, request: &LaunchRequest) -> Result<MachineState> {
        if request.mode != LifecycleMode::Persistent {
            return Err(MvmError::InvalidSpec {
                reason: "create (persist without boot) requires a persistent request".into(),
            });
        }
        if !request.command.is_empty() {
            // The command is started on the machine once it is up, not
            // recorded in its definition; accepting one here would drop it.
            return Err(MvmError::InvalidSpec {
                reason: "create persists a definition without booting it, so it has no \
                         command to start; pass the command when running the machine"
                    .into(),
            });
        }
        let name = request
            .name
            .clone()
            .expect("validated: persistent requests carry a name");
        let (spec, _) = self.create_definition(request, &name)?;
        Ok(MachineState {
            id: MachineId(name.clone()),
            name,
            status: MachineStatus::Stopped,
            cpus: spec.cpus,
            memory_mib: request.memory_mib,
            profile: Some(spec.profile),
            ..Default::default()
        })
    }

    /// The persistent create path: reconcile + persist the spec, validate +
    /// record secret references, register typed volume attachments. A
    /// refusal removes a definition this call wrote.
    fn create_definition(
        &self,
        request: &LaunchRequest,
        name: &str,
    ) -> Result<(mp::MachineSpec, DefinitionOrigin)> {
        let (spec, origin) = self.persist_definition(request, name)?;
        let recorded = self
            .validate_and_record_secret_refs(name, &request.secret_refs)
            .and_then(|()| {
                self.register_volume_attachments(
                    name,
                    &request.volumes,
                    AdmittedProfile::from_profile_name(&request.profile),
                )
            });
        self.discard_definition_on_failure(name, origin, recorded.map(|()| (spec, origin)))
    }

    /// Boot a persistent definition that was just created/reconciled from
    /// `request` (TTL and backend override honored from the request).
    ///
    /// The reconciled on-disk definition — not the request — is the boot
    /// authority: the `Reuse` arm keeps an earlier definition, so the spec
    /// is re-checked for in-process bootability and the sidecar's recorded
    /// secret references are re-validated fail-closed even when this
    /// request carries none.
    async fn boot_persistent(&self, name: &str, request: &LaunchRequest) -> Result<LaunchOutcome> {
        if self.machine_running(name) {
            return Err(MvmError::Conflict {
                reason: format!("machine {name:?} is already running"),
            });
        }
        let mut spec = mp::load_machine_spec(name).map_err(crate::local::backend_err)?;
        ensure_spec_bootable_in_process(&spec)?;
        self.validate_sidecar_refs(name)?;
        let launched_at = std::time::Instant::now();
        let (started, backend) = self
            .boot_spec(
                &mut spec,
                request.backend.as_deref(),
                !request.command.is_empty(),
            )
            .await?;
        if let Some(ttl) = request.ttl_seconds {
            detached::apply_ttl(name, std::time::Duration::from_secs(ttl))?;
        }
        let plan = started.admitted.plan().clone();
        let outcome = LaunchOutcome {
            #[cfg(unix)]
            host_lifetime: None,
            #[cfg(unix)]
            retirement: std::sync::Mutex::new(None),
            #[cfg(unix)]
            retirement_stopping: std::sync::atomic::AtomicBool::new(false),
            machine: MachineState {
                id: MachineId(name.to_string()),
                name: name.to_string(),
                status: MachineStatus::Running,
                backend,
                cpus: spec.cpus,
                memory_mib: request.memory_mib,
                profile: Some(spec.profile.clone()),
                expires_at: expires_at_from_ttl(request.ttl_seconds),
                ..Default::default()
            },
            plan_id: started.admitted.plan_id().0.clone(),
            process: None,
            admitted: started.admitted,
            mode: LifecycleMode::Persistent,
            plan,
            launched_at: Some(launched_at),
        };
        Ok(outcome)
    }

    /// Boot a persisted definition through the admitted start the CLI's
    /// `machine run -d` and `machine start` use, resolving an image source to
    /// a rootfs first. Returns the start and the backend it booted on.
    ///
    /// Crash leftovers in the per-VM runtime dir (a stale substitution-endpoint
    /// socket above all) make the fresh endpoint die binding it, so a machine
    /// that is not running starts from an empty dir.
    async fn boot_spec(
        &self,
        spec: &mut mp::MachineSpec,
        backend_override: Option<&str>,
        has_ad_hoc_argv: bool,
    ) -> Result<(machine_start::MachineStart, String)> {
        let backend = backend_override
            .map(str::to_string)
            .unwrap_or_else(|| self.backend.name().to_string());
        if !self.machine_running(&spec.name) {
            remove_vm_runtime_dirs(&spec.name)?;
        }
        let image = match spec.image.clone() {
            Some(reference) => Some(
                machine_start::resolve_boot_image(&reference, &spec.name)
                    .await
                    .map_err(|e| crate::local::backend_err(format!("{e:#}")))?,
            ),
            None => None,
        };
        let host = machine_start::EmbedderStartHost::new(image, &spec.profile)
            .with_secret_service(self.secrets()?)
            .with_backend(&self.backend);
        let started = detached::boot_recorded(
            spec,
            &host,
            machine_start::MachineStartParams {
                hypervisor: &backend,
                has_ad_hoc_argv,
            },
        )
        .map_err(|e| crate::local::backend_err(format!("{e:#}")))?;
        Ok((started, backend))
    }

    /// Start the request's command in the machine the launch just booted, and
    /// record its token on the outcome. A command failure attempts stop and
    /// retains its actual result until the caller decides whether to clean up.
    fn start_requested_command(
        &self,
        mut outcome: LaunchOutcome,
        request: &LaunchRequest,
    ) -> std::result::Result<LaunchOutcome, CommandStartFailure> {
        if request.command.is_empty() {
            return Ok(outcome);
        }
        let name = outcome.machine.name.clone();
        let started = self.command_starter.start(
            &name,
            detached::BootCommand {
                argv: request.command.clone(),
                env: request.env.clone(),
                cwd: request.cwd.clone(),
            },
        );
        match started {
            Ok(token) => {
                outcome.process = Some(token);
                Ok(outcome)
            }
            Err(command) => {
                #[cfg(unix)]
                if let Some(anchor) = &outcome.host_lifetime {
                    return Err(CommandStartFailure { command,
                        stop:self.backend.stop_owned(&VmId(name),anchor)
                            .map_err(crate::local::backend_err) });
                }
                Err(CommandStartFailure { command, stop:self.stop_for_recreate(&name) })
            }
        }
    }

    /// Re-validate the secret references recorded in `name`'s sidecar —
    /// the fail-closed gate every persistent admission passes, whether the
    /// references arrived with this request or with an earlier create.
    fn validate_sidecar_refs(&self, name: &str) -> Result<()> {
        let refs = crate::secret::refs::load_refs(&machine_state_root(), name)
            .map_err(|e| crate::local::backend_err(format!("loading secret refs: {e:#}")))?
            .map(|record| record.references)
            .unwrap_or_default();
        if refs.is_empty() {
            return Ok(());
        }
        self.secrets()?
            .validate_for_admission(LOCAL_TENANT, &refs)
            .map_err(|e| MvmError::Rejected {
                reason: format!("secret reference admission refused: {e}"),
            })
    }

    /// Shared tail of both launch paths: acquire volume leases, boot through
    /// admission, commit leases, register + track readiness.
    async fn attach_lease_and_boot(
        &self,
        name: &str,
        request: &LaunchRequest,
        transient: bool,
        #[cfg(unix)] original_admitted: Option<Box<AdmittedPlan>>,
    ) -> Result<LaunchOutcome> {
        let launched_at = std::time::Instant::now();
        let profile = AdmittedProfile::from_profile_name(&request.profile);
        let mut preparation = self.acquire_leases(name, profile)?;
        let volumes: Vec<mvm_core::vm_backend::VmVolume> = preparation
            .volumes
            .iter()
            .map(|volume| mvm_core::vm_backend::VmVolume {
                materialized_image: None,
                volume_label: None,
                host: volume.host.clone(),
                guest: volume.guest.clone(),
                size: volume.size.clone(),
                read_only: volume.read_only,
                kind: volume.kind,
                encrypted: volume.encrypted,
            })
            .collect();

        let secret_refs = if transient {
            request.secret_refs.clone()
        } else {
            crate::admission::secrets::load_machine_secret_refs(name)
                .map_err(crate::local::backend_err)?
        };
        let secrets = if secret_refs.is_empty() {
            crate::admission::secrets::ResolvedPlanSecrets::default()
        } else {
            crate::admission::secrets::ResolvedPlanSecrets::from_machine_refs(&secret_refs)
                .bind_approval(self.secrets()?.as_ref(), LOCAL_TENANT)
                .map_err(crate::local::backend_err)?
        };
        let started = self
            .boot_admitted(BootParams {
                #[cfg(unix)]
                original_admitted,
                #[cfg(unix)]
                host_lifetime: request.host_lifetime.clone(),
                name: name.to_string(),
                source: request.source.clone(),
                profile: request.profile.clone(),
                cpus: request.cpus,
                memory_mib: request.memory_mib,
                backend_override: request.backend.clone(),
                volumes,
                transient,
                grants: request.grants.clone(),
                signed_plan: request.signed_plan.clone(),
                assurance_campaign: request.assurance_campaign.clone(),
                secrets,
            })
            .await?;
        preparation.commit();

        self.register_started(name, request, transient);
        Ok(self.launch_outcome(name, request, started, transient, launched_at))
    }

    /// Post-boot bookkeeping: name-registry registration (with TTL),
    /// host-observed readiness, and — for a persistent machine — the
    /// last-started stamp on its spec. All best-effort: the machine is up.
    fn register_started(&self, name: &str, request: &LaunchRequest, transient: bool) {
        register_machine(&MachineRegistration {
            expires_at: expires_at_from_ttl(request.ttl_seconds),
            vm_dir: vm_state_dir(name).to_string_lossy().into_owned(),
            ..MachineRegistration::minimal(name, "none")
        });
        crate::record_readiness(name, InstanceReadiness::LaunchAccepted);
        if !transient && let Ok(mut spec) = mp::load_machine_spec(name) {
            spec.last_started_at = Some(mvm_core::util::time::utc_now());
            if let Err(e) = mp::overwrite_machine_spec(&spec) {
                tracing::warn!(error = %e, machine = name, "stamping last_started_at failed (non-fatal)");
            }
        }
    }

    /// Assemble the outcome for a successful admitted boot.
    fn launch_outcome(
        &self,
        name: &str,
        request: &LaunchRequest,
        started: StartedMachine,
        transient: bool,
        launched_at: std::time::Instant,
    ) -> LaunchOutcome {
        let plan = started.admitted.plan().clone();
        LaunchOutcome {
            #[cfg(unix)]
            host_lifetime: request.host_lifetime.clone(),
            #[cfg(unix)]
            retirement: std::sync::Mutex::new(None),
            #[cfg(unix)]
            retirement_stopping: std::sync::atomic::AtomicBool::new(false),
            machine: MachineState {
                id: MachineId(started.vm_id.0.clone()),
                name: name.to_string(),
                status: MachineStatus::Running,
                backend: self
                    .launch_backend(request.backend.as_deref())
                    .map(|b| b.name().to_string())
                    .unwrap_or_default(),
                cpus: request.cpus,
                memory_mib: request.memory_mib,
                profile: Some(request.profile.clone()),
                expires_at: expires_at_from_ttl(request.ttl_seconds),
                ..Default::default()
            },
            plan_id: started.admitted.plan_id().0.clone(),
            process: None,
            admitted: started.admitted,
            mode: if transient {
                LifecycleMode::Transient
            } else {
                LifecycleMode::Persistent
            },
            plan,
            launched_at: Some(launched_at),
        }
    }
}

/// Refusals for persisted-spec shapes a library start cannot honor (fail
/// closed, never silently ignore a persisted field): the start path boots an
/// image, a built manifest or a deployment, and its volumes arrive as typed
/// attachments; the CLI-only shapes stay with `mvmctl machine start`.
fn ensure_spec_bootable_in_process(spec: &mp::MachineSpec) -> Result<()> {
    let unsupported = |what: &str| MvmError::InvalidSpec {
        reason: format!(
            "machine {:?} declares {what}, which a library start cannot honor; use the CLI's \
             `machine start`",
            spec.name
        ),
    };
    if spec.runtime_pack {
        return Err(unsupported("a runtime-pack source"));
    }
    if !spec.volumes.is_empty() {
        return Err(unsupported(
            "CLI-grammar volume strings (use typed attachments)",
        ));
    }
    if !spec.init.is_empty() {
        return Err(unsupported("init commands"));
    }
    if spec.registry_pack_image.is_some() {
        machine_start::validate_registry_pack_source(spec).map_err(|error| {
            MvmError::InvalidSpec {
                reason: format!("invalid registry pack source: {error:#}"),
            }
        })?;
    }
    if spec.image.is_none()
        && spec.manifest.is_none()
        && spec.deployment.is_none()
        && spec.registry_pack_image.is_none()
    {
        return Err(MvmError::InvalidSpec {
            reason: format!(
                "machine {:?} has no image, manifest or deployment source",
                spec.name
            ),
        });
    }
    Ok(())
}

impl LocalBackend {
    /// Start a stopped persistent machine from its persisted definition:
    /// sidecar secret references re-validated fail-closed, registered
    /// attachments re-resolved and leased, then the canonical admitted boot.
    /// Starting a machine that is already running returns its state.
    pub async fn start_persistent(&self, name: &str) -> Result<MachineState> {
        let spec = mp::load_machine_spec(name).map_err(|e| MvmError::NotFound {
            id: format!("{name}: {e}"),
        })?;
        if self.machine_running(name) {
            return Ok(MachineState {
                id: MachineId(name.to_string()),
                name: name.to_string(),
                status: MachineStatus::Running,
                cpus: spec.cpus,
                ..Default::default()
            });
        }
        ensure_spec_bootable_in_process(&spec)?;
        self.validate_sidecar_refs(name)?;
        let mut spec = spec;
        let (_, backend) = self.boot_spec(&mut spec, None, false).await?;
        let memory_mib = mvm_core::util::parse_human_size(&spec.memory).unwrap_or_default();
        Ok(MachineState {
            id: MachineId(name.to_string()),
            name: name.to_string(),
            status: MachineStatus::Running,
            backend,
            cpus: spec.cpus,
            memory_mib,
            profile: Some(spec.profile.clone()),
            ..Default::default()
        })
    }

    /// Restart a persistent machine: stop it when running (spec kept), then
    /// start it again from its persisted definition.
    pub async fn restart_persistent(&self, name: &str) -> Result<MachineState> {
        if self.machine_running(name) {
            use mvm_core::client::MvmClient as _;
            self.stop_machine(&MachineId(name.to_string())).await?;
        }
        self.start_persistent(name).await
    }

    /// Remove a machine. For a persistent definition this is the separate
    /// confirmed action that deletes the spec: a RUNNING persistent machine
    /// is refused unless `options.force` explicitly requests the reviewed
    /// force flow (stop, then remove). A spec-less name gets transient
    /// semantics: stop + idempotent session cleanup. Removing an absent
    /// machine is `Ok`. A failed stop preserves the definition and resources;
    /// force does not bypass that failure.
    pub async fn remove_machine_with(&self, id: &MachineId, options: RemoveOptions) -> Result<()> {
        let name = id.0.as_str();
        let has_spec = machine_spec_path(name).exists();
        if has_spec {
            if self.machine_running(name) {
                if !options.force {
                    return Err(MvmError::Conflict {
                        reason: format!(
                            "machine {name:?} is running; stop it first, or explicitly \
                             request the force removal flow"
                        ),
                    });
                }
                self.stop_for_recreate(name)?;
            }
            self.remove_definition(name)?;
            mvm_core::audit_emit!(
                ConfigChange,
                vm: name,
                "action=machine.remove mode=persistent force={force}",
                force = options.force,
            );
            return Ok(());
        }
        // Transient semantics: stop whatever is live, then idempotent cleanup.
        self.cleanup_transient(name)
    }

    /// Release every session-owned resource `name` holds: registered volume
    /// attachments, attachment leases (re-sealing just-in-time unlocks),
    /// secret-reference sidecar, name-registry entry. Idempotent.
    fn release_session_resources(&self, name: &str) -> Result<()> {
        #[cfg(unix)]
        mvm_core::host_lifetime::require_no_installed_native(name)
            .map_err(crate::local::backend_err)?;
        let service = LocalVolumeService::new();
        match service.list_attachments(name) {
            Ok(attachments) => {
                for attachment in attachments {
                    if let Err(e) = service.detach(name, &attachment.guest_path) {
                        tracing::warn!(error = %e, machine = name, guest = %attachment.guest_path, "detach during cleanup failed");
                    }
                }
            }
            Err(e) => {
                tracing::warn!(error = %e, machine = name, "listing attachments during cleanup failed");
            }
        }
        service
            .release_owner_leases(name)
            .map_err(|e| crate::local::backend_err(format!("releasing volume leases: {e:#}")))?;
        self.clear_secret_refs(name)?;
        crate::local::deregister_from_name_registry(name);
        Ok(())
    }

    /// Idempotent transient cleanup: stop the VM when live, release every
    /// session-owned resource, and drop the per-VM state dirs. Safe to call
    /// repeatedly and on names that never launched. An attempted stop error
    /// returns before any session resource is released.
    pub fn cleanup_transient(&self, name: &str) -> Result<()> {
        #[cfg(unix)]
        mvm_core::host_lifetime::require_no_installed_native(name)
            .map_err(crate::local::backend_err)?;
        if self.machine_running(name) {
            self.stop_for_recreate(name)?;
        }
        self.release_session_resources(name)?;
        remove_vm_runtime_dirs(name)?;
        // The state dir under machines/ only carries session sidecars for a
        // transient (no machine.json); never touch a persistent definition.
        if !machine_spec_path(name).exists() {
            remove_dir_if_present(&machine_state_dir(name))?;
        }
        Ok(())
    }
}

impl LocalBackend {
    /// Wait for a transient launch to run to completion, report its captured
    /// exit code, and clean up its session-owned resources. Polls the owning
    /// backend; fails with a timeout error if the machine is still running
    /// after `timeout`. The `plan.exited` chain entry carries the exit code.
    pub fn wait_for_exit(
        &self,
        outcome: &LaunchOutcome,
        poll: std::time::Duration,
        timeout: std::time::Duration,
    ) -> Result<ExitReport> {
        #[cfg(unix)]
        if outcome.host_lifetime.is_some() {
            return Err(crate::local::backend_err("installed wait requires the original resident lifecycle; no name-based exit observation"));
        }
        let name = outcome.machine.name.clone();
        let deadline = std::time::Instant::now() + timeout;
        while self.machine_running(&name) {
            if std::time::Instant::now() >= deadline {
                return Err(crate::local::backend_err(format!(
                    "machine {name:?} still running after {}s",
                    timeout.as_secs()
                )));
            }
            std::thread::sleep(poll);
        }
        self.report_exit(outcome)
    }

    /// Report an already-exited machine's captured exit code, emit the
    /// chain-signed `plan.exited` entry, and (for a transient) run the
    /// idempotent cleanup.
    pub fn report_exit(&self, outcome: &LaunchOutcome) -> Result<ExitReport> {
        #[cfg(unix)]
        if outcome.host_lifetime.is_some() {
            return Err(crate::local::backend_err("installed exit reporting requires original native retirement; sidecars are not an exit proof"));
        }
        let name = outcome.machine.name.as_str();
        let state_dir = vm_state_dir(name);
        let exit_code = mvm_core::exit_capture::read_captured(&state_dir);
        // Capture fidelity: a missing capture is recorded as uncaptured,
        // never attested as exit 0.
        //
        // Whatever the process that owned the VM managed to observe. An
        // absent sidecar reads as all-unavailable, which is the honest
        // answer for a tier that cannot observe, a run that crashed before
        // teardown, and a backend that has not been taught to write one yet.
        let mut usage = mvm_core::usage_capture::read_captured(&state_dir);
        // Two dimensions the host observes about itself, so they hold on
        // every backend regardless of what the VMM could report.
        usage.host_state_bytes = mvm_core::usage_capture::host_state_bytes(&state_dir);
        if let Some(span) = outcome.launched_at.map(|at| at.elapsed()) {
            usage.wall_ms = mvm_core::usage_capture::wall_ms(span);
        }
        // Read before cleanup: a transient's state dir, which names the scope,
        // is removed below.
        let memory_limit_exceeded =
            mvm_core::spawn_scope::ScopeProbe::default().memory_limit_exceeded(&state_dir);
        if let Some(emitter) = build_audit_emitter() {
            let closing = ClosingRecords {
                plan: &outcome.plan,
                machine: name,
                memory_limit_exceeded: memory_limit_exceeded.as_ref(),
                exit: ExitRecord {
                    exit_code,
                    backend: &outcome.machine.backend,
                    usage,
                },
            };
            // `record` owns the batch: one flush for the run's closing
            // records, a failed flush recorded there as an unsealed end.
            // Batching here again would nest, which the emitter refuses.
            if closing.record(&emitter) {
                mvm_hostd::audit::witness::flush_configured(
                    emitter.audit_dir(),
                    &outcome.plan.tenant.0,
                );
            }
        }
        if outcome.mode == LifecycleMode::Transient {
            self.cleanup_transient(name)?;
        }
        Ok(ExitReport { exit_code })
    }

    /// Stop and clean every transient machine whose registry TTL has lapsed
    /// at `now` (RFC 3339). Persistent definitions are never touched — their
    /// TTL semantics stay with the idle reaper. Returns the reaped names.
    pub fn reap_expired_transients(&self, now_rfc3339: &str) -> Result<Vec<String>> {
        let Some(now) = mvm_core::util::time::parse_iso8601(now_rfc3339) else {
            return Err(MvmError::InvalidSpec {
                reason: format!("invalid RFC 3339 timestamp {now_rfc3339:?}"),
            });
        };
        let registry = mvm_runtime::vm::name_registry::VmNameRegistry::load(
            &mvm_runtime::vm::name_registry::registry_path(),
        )
        .unwrap_or_default();
        let expired: Vec<String> = registry
            .vms
            .iter()
            .filter(|(name, reg)| {
                !machine_spec_path(name).exists()
                    && matches!(
                        reg.expires_at
                            .as_deref()
                            .and_then(mvm_core::util::time::parse_iso8601),
                        Some(exp) if exp < now
                    )
            })
            .map(|(name, _)| name.clone())
            .collect();
        let mut reaped = Vec::with_capacity(expired.len());
        for name in expired {
            self.cleanup_transient(&name)?;
            reaped.push(name);
        }
        reaped.sort();
        Ok(reaped)
    }
}

/// Drop a VM's runtime state *and* the directory its sockets live in; see
/// [`mvm_runtime::vm::reconcile::remove_runtime_dirs`].
fn remove_vm_runtime_dirs(name: &str) -> Result<()> {
    #[cfg(unix)]
    mvm_core::host_lifetime::require_no_installed_native(name)
        .map_err(crate::local::backend_err)?;
    mvm_runtime::vm::reconcile::remove_runtime_dirs(&vm_state_dir(name))
        .map_err(|e| crate::local::backend_err(format!("removing runtime state of {name:?}: {e}")))
}

/// Clear a stopped machine's runtime dirs before it starts again, as
/// [`LocalBackend`]'s own boot does. A launch that finds a stopped instance's
/// leftovers refuses the name (HVF treats them as evidence it cannot discard
/// itself), so every start path that is not that boot -- a restart, a
/// reconfigure, a recreate -- has to clear them first. A machine that is still
/// running owns its dirs and is left alone.
fn discard_stopped_runtime_state(hypervisor: &str, name: &str) -> Result<()> {
    if crate::backend_is_running(hypervisor, name) {
        return Ok(());
    }
    remove_vm_runtime_dirs(name)
}

/// Remove a directory tree, treating "already absent" as success.
fn remove_dir_if_present(dir: &std::path::Path) -> Result<()> {
    match std::fs::remove_dir_all(dir) {
        Ok(()) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(crate::local::backend_err(format!(
            "removing {}: {e}",
            dir.display()
        ))),
    }
}
