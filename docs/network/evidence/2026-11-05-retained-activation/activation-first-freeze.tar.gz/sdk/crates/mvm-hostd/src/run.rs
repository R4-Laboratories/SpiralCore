//! In-process local-run seam: boot a host-materialized rootfs through the
//! signed-plan admission gate without shelling out to the CLI.
//!
//! [`admit_and_boot_local`] is the thin, safe-by-default entrypoint the
//! `mvm-client` local backend calls. It hashes the already-materialized
//! `rootfs.ext4`, synthesizes an `ExecutionPlan` with the conservative facade
//! defaults (deny-all egress, standard seccomp, no bundle, no host-fs shares),
//! plus any metadata-only secret bindings resolved by the caller, and hands
//! the whole thing to [`admit_and_start`]. The
//! backend never boots until the plan is signed, verified, inside its validity
//! window, and non-replayed — the same gate `mvmctl run` and `mvmctl machine run` go through.
//!
//! Bundle pins, deps volumes, and per-destination redaction remain absent. The
//! facade does carry typed secret references, which the client validates and
//! lowers before this seam; values remain host-only. Egress is likewise
//! explicit: an egress *grant* is carried, and the launch
//! config's policy is derived from it, so the plan the boot was signed under
//! and the policy the gate reads come from one authored value.
//!
//! One request shape skips synthesis: a `LocalRunRequest` carrying a
//! `signed_plan` admits that externally-signed envelope instead — verified
//! against the operator-pinned `trusted_plan_signers`, never re-signed under
//! the host key — with the plan body (not the request's sizing fields) as the
//! authority for what boots.

use std::path::{Path, PathBuf};

use anyhow::{Context, Result};
use mvm_core::plan::{PlanSeccompTier, SecretBinding, SecretReleasePolicy, SynthesisInput};
use mvm_core::vm_backend::{VmStartConfig, VmVolume};
use mvm_runtime::AnyBackend;

use crate::audit::emitter::AuditEmitter;
use crate::plan_admission::{
    AdmitAndStartParams, Clock, InMemoryNonceLedger, StartedMachine, admit_and_start,
};

/// The tenant every locally-run machine is admitted under. Local runs are
/// single-tenant by construction (one host, one operator), so the audit chain
/// and gateway substrate key off this fixed label rather than a fleet tenant.
pub(crate) const LOCAL_TENANT: &str = "local";

/// A minimal, safe-by-default request to admit and boot a locally-materialized
/// rootfs. The caller resolves the image to `rootfs_path` (and its optional
/// dm-verity sidecars) before constructing this; everything security-relevant
/// that the facade doesn't expose defaults to the most restrictive value.
pub struct LocalRunRequest {
    /// Machine name — also the synthesized plan's `image_name` and the mock
    /// backend's per-VM directory key.
    pub name: String,
    /// Absolute path to the already-materialized ext4 rootfs. Hashed for the
    /// plan's `image_sha256`, so it must exist and be readable.
    pub rootfs_path: PathBuf,
    /// Kernel image path. `None` only for the mock backend, which boots no
    /// kernel; every VMM backend needs one.
    pub kernel_path: Option<PathBuf>,
    /// dm-verity Merkle-tree sidecar, paired with `roothash`. Both `Some` for a
    /// verified-boot rootfs; both `None` otherwise.
    pub verity_path: Option<PathBuf>,
    /// 64-char lowercase-hex dm-verity root hash, paired with `verity_path`.
    pub roothash: Option<String>,
    pub cpus: u32,
    pub mem_mib: u32,
    /// Backend name recorded in the signed plan (`firecracker`, `libkrun`,
    /// `mock`, …) — must match the backend the caller starts.
    pub backend_name: String,
    /// Volumes to attach. Every entry is baked into the signed plan's
    /// `shares` (same order, `uvol{idx}` tags) and onto the launch config, so
    /// the claim-1 admitted-shares gate passes exactly when the two agree —
    /// no host-fs grant reaches the guest outside the signed plan.
    pub volumes: Vec<VmVolume>,
    /// Recorded plan intent: `true` for a transient run-to-completion
    /// workload, `false` for a persistent machine that outlives the
    /// admitting call.
    pub destroy_on_exit: bool,
    /// What this workload is permitted to consume or reach. Baked into the
    /// signed plan and checked against the host's ceiling during admission; the
    /// egress dimension additionally becomes the launch config's network
    /// policy, so what the gate enforces is what the plan was signed for.
    /// `None` keeps the pre-grant baseline: no CPU cap, no wall-clock bound,
    /// deny-all egress.
    pub grants: Option<mvm_contract::grants::Grants>,
    /// Metadata-only secret bindings resolved by the caller. Raw values stay
    /// behind the host substitution endpoint.
    pub secrets: Vec<SecretBinding>,
    pub secret_release: SecretReleasePolicy,
    /// An externally-signed plan to admit instead of synthesizing and
    /// self-signing one — a fleet-issued plan whose signer the operator pinned
    /// in the host config's `trusted_plan_signers`.
    ///
    /// When present, the plan is the authority: sizing, grants, and teardown
    /// intent come from it (the `cpus` / `mem_mib` / `grants` /
    /// `destroy_on_exit` fields above are not consulted), and the resolved
    /// rootfs must hash to the plan's pinned image digest. `None` is every
    /// ordinary local run, which synthesizes its plan as before.
    pub signed_plan: Option<mvm_core::plan::SignedExecutionPlan>,
    /// Exact registry image identity, never a saved payload path. The signed
    /// plan must carry this pin and final host boot verification reopens it.
    pub registry_pack_image: Option<mvm_core::registry_pack::PackPin>,
}

/// Admission substrate for a local run: the clock and replay ledger that drive
/// the validity-window + nonce checks, plus an optional host-signer keys dir
/// override (production passes `None` → `~/.mvm/keys/`; tests inject a tempdir).
pub struct LocalRunContext<'a> {
    pub clock: &'a dyn Clock,
    pub ledger: &'a InMemoryNonceLedger,
    pub host_signer_keys_dir: Option<&'a Path>,
    /// Chain-signed audit emitter for `plan.admitted` / `plan.launched` /
    /// `plan.failed` entries around this admission. `None` skips emission
    /// (the caller owns its own audit wiring, e.g. the CLI's up path).
    pub emitter: Option<&'a AuditEmitter>,
    /// An operator-declared assurance campaign to open against this boot.
    ///
    /// `None` — the default everywhere except a run that explicitly asked for
    /// one — means no assurance work happens at all, so campaign discovery
    /// never sits on the ordinary launch path.
    pub assurance: Option<&'a crate::assurance_session::CampaignRequest>,
}

/// Build the signed-plan host-fs grant list from the launch volume set. The
/// `uvol{idx}` tag matches the id the backend assigns when it attaches each
/// volume (same `VmStartConfig.volumes` order), so the admitted grants line
/// up 1:1 with what actually gets attached — the claim-1 check compares them.
pub fn shares_from_vm_volumes(volumes: &[VmVolume]) -> Vec<mvm_core::plan::HostShareGrant> {
    volumes
        .iter()
        .enumerate()
        .map(|(idx, v)| mvm_core::plan::HostShareGrant {
            tag: format!("uvol{idx}"),
            host_path: v.host.clone(),
            guest_path: v.guest.clone(),
            kind: if v.materialized_image.is_some() {
                mvm_core::plan::ShareKind::DirShare
            } else {
                mvm_core::plan::ShareKind::Disk
            },
            read_only: v.read_only,
            encrypted: v.encrypted,
            content_sha256: None,
        })
        .collect()
}

/// Attach the verity-sealed runtime overlay (the guest-binary disk carrying
/// the agent) from the cache, through the same resolver the CLI's boot paths
/// consume (`RuntimeOverlayResolver` + `resolve_cached_runtime_overlay`).
/// This is only a cache selection: `attach_guest_runtime` authenticates the
/// complete overlay/initramfs pair before publishing it to a launch config.
/// A missing overlay fails closed; no build or download runs here.
pub(crate) fn attach_runtime_overlay_from_cache(
    config: &mut VmStartConfig,
    backend_name: &str,
) -> Result<()> {
    use mvm_build::runtime_overlay::{RuntimeOverlayResolver, resolve_cached_runtime_overlay};
    // Every backend that boots a kernel boots the universal initramfs, and
    // that initramfs mounts the overlay. `apple-container` is the HVF runner
    // with another kernel image, so it needs the overlay exactly as HVF does.
    if !mvm_runtime::universal_initramfs::KERNEL_BOOTING_HYPERVISORS.contains(&backend_name) {
        return Ok(());
    }
    let cache_root = PathBuf::from(mvm_core::config::mvm_cache_dir());
    let resolver = RuntimeOverlayResolver::new(cache_root, env!("CARGO_PKG_VERSION").to_string());
    match resolve_cached_runtime_overlay(&resolver, mvm_core::arch::GuestArch::host()) {
        Ok(artifact) => {
            config.runtime_overlay_path = Some(artifact.overlay_ext4.display().to_string());
            config.runtime_overlay_verity_path = Some(artifact.sidecar.display().to_string());
            config.runtime_overlay_roothash = Some(artifact.roothash);
            config.runtime_overlay_version = Some(artifact.version);
            Ok(())
        }
        Err(e) => Err(anyhow::anyhow!(
            "runtime overlay required for {backend_name} boot but unavailable: {e}"
        )),
    }
}

/// Attach what a rootfs boot's guest runtime comes from: the runtime overlay
/// carrying the agent, and the universal initramfs that supplies `/init` and
/// mounts that overlay at `/mvm/runtime`.
///
/// The two go together. An overlay with no initramfs is never mounted, and a
/// runtime-lean rootfs then has no `/init` at all: the guest panics before
/// userspace and the host sees only an agent that never answers. The
/// initramfs comes from the same resolution every other launch path uses.
pub(crate) fn attach_guest_runtime(config: &mut VmStartConfig, backend_name: &str) -> Result<()> {
    if !mvm_runtime::universal_initramfs::KERNEL_BOOTING_HYPERVISORS.contains(&backend_name) {
        return Ok(());
    }
    let mut selected = config.clone();
    attach_runtime_overlay_from_cache(&mut selected, backend_name)?;
    let cache = PathBuf::from(mvm_core::config::mvm_cache_dir());
    let version = env!("CARGO_PKG_VERSION");
    let arch = mvm_core::arch::GuestArch::host();
    selected.runtime_release_proof = match &config.runtime_release_proof {
        Some(proof) => Some(proof.clone()),
        None => mvm_build::guest_runtime::cached_runtime_release_proof(&cache, version, arch)?,
    };
    selected.unsigned_runtime_development = selected.runtime_release_proof.is_none();
    selected.source_runtime_archive_sha256 = if selected.unsigned_runtime_development {
        let checked =
            mvm_build::guest_runtime::source::check_source_runtime(&cache, version, arch)?;
        if let Some(expected) = config.source_runtime_archive_sha256.as_deref() {
            anyhow::ensure!(
                expected == checked.archive_sha256(),
                "source runtime archive differs from the originally selected archive"
            );
        }
        Some(checked.archive_sha256().to_owned())
    } else {
        None
    };
    let initramfs = mvm_fs::initramfs::InitramfsResolver::new(cache.join("initramfs"), version)
        .resolve(&arch.to_string())
        .context("cached initramfs required for local boot; prepare the guest runtime first")?;
    selected.initrd_path = Some(initramfs.image_path.display().to_string());
    mvm_runtime::runtime_evidence::verify_runtime_for_launch(
        &selected,
        mvm_runtime::runtime_evidence::MIN_GUEST_RPC_PROTOCOL_VERSION,
    )?;
    *config = selected;
    Ok(())
}

/// Admit `req` through the signed-plan gate and boot it on `backend`.
///
/// On success the plan was either synthesized here and signed under the host
/// key, or — when `req.signed_plan` carries a fleet-issued envelope — verified
/// against the operator-pinned `trusted_plan_signers`; in both cases it was
/// verified, inside its validity window, and non-replayed before the backend
/// saw a single byte of launch config. Any failure returns with no VM created.
pub fn admit_and_boot_local(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    ctx: LocalRunContext<'_>,
) -> Result<StartedMachine> {
    admit_and_boot_local_inner(
        backend,
        req,
        ctx,
        #[cfg(unix)]
        None,
    )
}

/// Same admission and original nonce, with an in-process installation owner.
#[cfg(unix)]
pub fn admit_and_boot_local_with_host_lifetime(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    ctx: LocalRunContext<'_>,
    owner: std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>,
) -> Result<StartedMachine> {
    admit_and_boot_local_inner(backend, req, ctx, Some(owner))
}

fn admit_and_boot_local_inner(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    ctx: LocalRunContext<'_>,
    #[cfg(unix)] owner: Option<std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
) -> Result<StartedMachine> {
    anyhow::ensure!(
        req.volumes
            .iter()
            .all(|volume| volume.materialized_image.is_none()),
        "raw local admission does not accept materialized directory images; \
         route them through instruction admission with explicit source identity"
    );
    let sha = mvm_core::crypto::image_verify::sha256_file_cached(&req.rootfs_path)
        .with_context(|| format!("hashing rootfs at {}", req.rootfs_path.display()))?;

    // An externally-signed plan takes the other admission door: verified
    // against the operator-pinned signer set, never synthesized or re-signed
    // under the host key.
    if let Some(signed) = req.signed_plan.as_ref() {
        return admit_signed_and_boot_local(
            backend,
            req,
            signed,
            &sha,
            ctx,
            #[cfg(unix)]
            owner,
        );
    }

    // Pin the kernel into the signed plan. Deliberately the uncached digest: a
    // path+mtime-keyed cache can hand back a stale hash, which for an integrity
    // pin would defeat the point of having one.
    let kernel_sha = req
        .kernel_path
        .as_ref()
        .map(|k| {
            mvm_core::crypto::image_verify::sha256_file(k)
                .with_context(|| format!("hashing kernel at {}", k.display()))
        })
        .transpose()?;

    // With no egress grant the deny-all default stands; a granted allow-list
    // is projected onto it, so the policy the gate enforces, and the seccomp
    // tier the guest installs, derive from the grants the plan is signed for.
    let network_policy = match req.grants.as_ref() {
        Some(grants) if grants.egress.is_some() => {
            mvm_contract::grants::projection::network_policy_from_grants(grants)
        }
        _ => mvm_core::network_policy::NetworkPolicy::deny_all(),
    };

    let synthesis = SynthesisInput {
        outputs: Vec::new(),
        grants: req.grants.clone(),
        stream_edges: Vec::new(),
        kernel_sha256: kernel_sha.as_deref(),
        network_mode: Default::default(),
        ingress: Vec::new(),
        vm_name: &req.name,
        tenant: Some(LOCAL_TENANT),
        backend_name: &req.backend_name,
        image_name: &req.name,
        image_sha256: &sha,
        image_cosign_bundle: None,
        intent: None,
        seccomp_tier: mvm_core::plan::workload_seccomp_tier(
            PlanSeccompTier::Standard,
            &network_policy,
            &[],
            &[],
            // The local run request carries no GPU grant.
            false,
        ),
        network_policy_ref: None,
        fs_policy_ref: None,
        egress_policy_ref: None,
        tool_policy_ref: None,
        secret_release: req.secret_release,
        secrets: req.secrets.clone(),
        audit_event_prefix: None,
        cpus: req.cpus,
        mem_mib: u64::from(req.mem_mib),
        disk_mib: 0,
        boot_timeout_secs: 60,
        // A persistent local machine outlives the admitting call; a transient
        // run-to-completion workload records the teardown intent.
        destroy_on_exit: req.destroy_on_exit,
        bundle_pin: None,
        deps_volume: None,
        shares: shares_from_vm_volumes(&req.volumes),
        assets: req
            .registry_pack_image
            .iter()
            .map(|pin| {
                mvm_core::plan::AssetIdentity::new(
                    mvm_core::plan::AssetKind::RegistryPack,
                    pin.reference().to_string(),
                    pin.manifest_sha256().as_str(),
                )
            })
            .collect::<Result<Vec<_>, _>>()?,
        redaction: Default::default(),
        reversible_replacement: Default::default(),
        tools: Default::default(),
        caller_commitment: None,
        audit_labels: Default::default(),
        agent_verbs: None,
        services: Vec::new(),
        extensions: Vec::new(),
        stream_retention: Default::default(),
        attestation_mode: mvm_contract::plan::AttestationMode::Noop,
    };

    let path_string = |p: &Path| p.to_string_lossy().into_owned();
    let mut config = VmStartConfig {
        name: req.name.clone(),
        rootfs_path: path_string(&req.rootfs_path),
        kernel_path: req.kernel_path.as_deref().map(path_string),
        verity_path: req.verity_path.as_deref().map(path_string),
        roothash: req.roothash.clone(),
        cpus: req.cpus,
        memory_mib: req.mem_mib,
        volumes: req.volumes.clone(),
        tenant_id: Some(LOCAL_TENANT.to_string()),
        network_policy,
        ..Default::default()
    };
    #[cfg(unix)]
    if let Some(owner) = owner {
        owner.bind_to_config(&mut config)?;
    }
    attach_guest_runtime(&mut config, &req.backend_name)?;

    admit_and_start(
        backend,
        AdmitAndStartParams {
            synthesis: &synthesis,
            config,
            clock: ctx.clock,
            ledger: ctx.ledger,
            host_signer_keys_dir: ctx.host_signer_keys_dir,
            bundle_ctx: None,
            extension_ctx: None,
            variant: mvm_core::plan::Variant::Dev,
            policy_bundle: None,
            emitter: ctx.emitter,
            // The local boot path launches unsealed (`sealed: false` above)
            // and issues no attenuated verb grant, so it is not the tier whose
            // admission has to be provable afterwards. Stated rather than
            // defaulted: a run that silently picks its own audit durability is
            // how this control erodes.
            audit_durability: crate::audit::durability::AuditDurability::BestEffort,
            assurance: ctx.assurance,
        },
    )
}

/// Admit an externally-signed plan through
/// [`crate::plan_admission::admit_signed_plan_for_run`] and boot it on
/// `backend` — the local-run tail for the fleet-issued seam.
///
/// The admitted plan, not the request, decides what runs: sizing, grants, and
/// teardown intent are read from the verified plan body, and the resolved
/// rootfs must hash to the image digest the plan pins — otherwise the host
/// would be booting bytes the signer never authorized. The caller's
/// `cpus`/`mem_mib`/`grants`/`destroy_on_exit` are not consulted here;
/// `admit_and_boot_local` only routes here when `req.signed_plan` is set.
fn admit_signed_and_boot_local(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    signed: &mvm_core::plan::SignedExecutionPlan,
    rootfs_sha: &str,
    ctx: LocalRunContext<'_>,
    #[cfg(unix)] owner: Option<std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
) -> Result<StartedMachine> {
    use crate::plan_admission::RunPosture;

    let posture = RunPosture::on_backend(mvm_core::plan::Variant::Dev, backend.kind());
    let admitted = crate::plan_admission::admit_signed_plan_for_run(
        signed, ctx.clock, ctx.ledger, None, posture,
    )?;
    boot_admitted_local_verified(
        backend,
        req,
        admitted,
        rootfs_sha,
        ctx.emitter,
        ctx.assurance,
        #[cfg(unix)]
        owner,
    )
}

/// Boot the original admitted authority with the original installation owner.
///
/// This route never synthesizes, signs or admits a replacement plan and never
/// spends another nonce. It owns the canonical launch-route admission event;
/// callers must not record a second `plan.admitted` event for this launch.
#[cfg(unix)]
pub fn boot_admitted_local_with_host_lifetime(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    admitted: crate::plan_admission::AdmittedPlan,
    emitter: Option<&AuditEmitter>,
    assurance: Option<&crate::assurance_session::CampaignRequest>,
    owner: std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>,
) -> Result<StartedMachine> {
    boot_admitted_local_inner(backend, req, admitted, emitter, assurance, Some(owner))
}

#[cfg(unix)]
fn boot_admitted_local_inner(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    admitted: crate::plan_admission::AdmittedPlan,
    emitter: Option<&AuditEmitter>,
    assurance: Option<&crate::assurance_session::CampaignRequest>,
    #[cfg(unix)] owner: Option<std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
) -> Result<StartedMachine> {
    admitted.check_not_dispatched()?;
    let rootfs_sha = mvm_core::crypto::image_verify::sha256_file_cached(&req.rootfs_path)
        .with_context(|| format!("hashing rootfs at {}", req.rootfs_path.display()))?;
    boot_admitted_local_verified(
        backend,
        req,
        admitted,
        &rootfs_sha,
        emitter,
        assurance,
        #[cfg(unix)]
        owner,
    )
}

fn boot_admitted_local_verified(
    backend: &AnyBackend,
    req: &LocalRunRequest,
    admitted: crate::plan_admission::AdmittedPlan,
    rootfs_sha: &str,
    emitter: Option<&AuditEmitter>,
    assurance: Option<&crate::assurance_session::CampaignRequest>,
    #[cfg(unix)] owner: Option<std::sync::Arc<mvm_core::host_lifetime::HostLifetimeAnchor>>,
) -> Result<StartedMachine> {
    use crate::plan_admission::{StartAdmittedParams, start_admitted};
    admitted.check_unlaunched_for_backend(backend.kind())?;
    anyhow::ensure!(
        req.backend_name == backend.name(),
        "local request backend differs from actual backend"
    );
    anyhow::ensure!(
        req.volumes
            .iter()
            .all(|volume| volume.materialized_image.is_none()),
        "raw local admission does not accept materialized directory images; route them through instruction admission with explicit source identity"
    );
    let plan = admitted.plan();
    if let Some(pin) = &req.registry_pack_image {
        anyhow::ensure!(
            plan.asset_identities.iter().any(|asset| {
                asset.kind == mvm_core::plan::AssetKind::RegistryPack
                    && asset.name == pin.reference().to_string()
                    && asset.digest == pin.manifest_sha256().as_str()
            }),
            "signed plan does not authorize the requested built registry image pin"
        );
    }

    // The plan pins the workload image by digest; the resolved rootfs must BE
    // that image. Synthesized plans get this by construction (synthesis stamps
    // the hash it just measured); an externally-signed plan gets it by
    // comparison.
    if rootfs_sha != plan.image.sha256 {
        anyhow::bail!(
            "the signed plan pins image sha256 {} but the resolved rootfs at {} hashes to \
             {rootfs_sha}; refusing to boot an image the plan does not authorize",
            plan.image.sha256,
            req.rootfs_path.display(),
        );
    }

    let path_string = |p: &Path| p.to_string_lossy().into_owned();
    let mut config = VmStartConfig {
        name: req.name.clone(),
        rootfs_path: path_string(&req.rootfs_path),
        kernel_path: req.kernel_path.as_deref().map(path_string),
        verity_path: req.verity_path.as_deref().map(path_string),
        roothash: req.roothash.clone(),
        cpus: plan.resources.cpus,
        memory_mib: u32::try_from(plan.resources.mem_mib)
            .context("plan memory does not fit the launch config")?,
        volumes: req.volumes.clone(),
        tenant_id: Some(plan.tenant.0.clone()),
        // The plan's egress grant projects onto the launch config's policy,
        // exactly as a synthesized plan's does: what the gate enforces is what
        // the plan was signed for. No grant means deny-all.
        network_policy: match plan.grants.as_ref() {
            Some(grants) if grants.egress.is_some() => {
                mvm_contract::grants::projection::network_policy_from_grants(grants)
            }
            _ => mvm_core::network_policy::NetworkPolicy::deny_all(),
        },
        ..Default::default()
    };
    #[cfg(unix)]
    if let Some(owner) = owner {
        owner.bind_to_config(&mut config)?;
    }
    attach_guest_runtime(&mut config, &req.backend_name)?;

    crate::audit::durability::record_admission(
        emitter,
        plan,
        admitted.signer_id(),
        crate::audit::durability::AuditDurability::BestEffort,
    )?;

    start_admitted(StartAdmittedParams {
        backend,
        admitted,
        config,
        policy_bundle: None,
        emitter,
        assurance,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::plan_admission::SystemClock;
    use mvm_core::util::test_env::TestEnv;

    /// A local run over the mock backend admits a signed plan and boots — no
    /// subprocess, no CLI. Proves the seam the local backend calls is real.
    #[test]
    fn admit_and_boot_local_over_mock_boots_admitted_plan() {
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        let keys = tempfile::tempdir().unwrap();

        let rootfs = data.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"not-a-real-ext4-but-hashable\n").unwrap();

        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let clock = SystemClock;
        let req = LocalRunRequest {
            name: "local-run-seam-test".into(),
            rootfs_path: rootfs,
            kernel_path: None,
            verity_path: None,
            roothash: None,
            cpus: 1,
            mem_mib: 128,
            backend_name: "mock".into(),
            volumes: Vec::new(),
            destroy_on_exit: false,
            grants: None,
            secrets: vec![SecretBinding {
                name: "API_KEY".into(),
                source: mvm_core::plan::SecretSource::Keystore {
                    address: "openai".into(),
                },
                destinations: Vec::new(),
                approval_required: false,
            }],
            secret_release: SecretReleasePolicy::PlanBound,
            signed_plan: None,
            registry_pack_image: None,
        };

        let started = admit_and_boot_local(
            &backend,
            &req,
            LocalRunContext {
                clock: &clock,
                ledger: &ledger,
                host_signer_keys_dir: Some(keys.path()),
                emitter: None,
                assurance: None,
            },
        )
        .expect("admit + boot over mock");

        assert_eq!(started.vm_id.0, "local-run-seam-test");
        assert_eq!(started.admitted.plan().tenant.0, LOCAL_TENANT);
        // The plan was actually signed under the host key (proves admission,
        // not a stub): a signer id is present and the plan bound the exact
        // rootfs bytes we handed it (64-hex sha256) on our backend.
        assert!(!started.admitted.signer_id().is_empty());
        assert_eq!(started.admitted.plan().image.sha256.len(), 64);
        assert_eq!(started.admitted.plan().runtime_profile.0, "mock");
        assert_eq!(
            started.admitted.plan().admission_profile.secret_release,
            SecretReleasePolicy::PlanBound
        );
        assert_eq!(started.admitted.plan().secrets, req.secrets);
    }

    #[test]
    fn raw_local_admission_refuses_ro_and_rw_materialized_images_before_boot() {
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        let rootfs = data.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"hashable rootfs\n").unwrap();
        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let clock = SystemClock;

        for read_only in [false, true] {
            let req = LocalRunRequest {
                name: format!("raw-materialized-{read_only}"),
                rootfs_path: rootfs.clone(),
                kernel_path: None,
                verity_path: None,
                roothash: None,
                cpus: 1,
                mem_mib: 128,
                backend_name: "mock".into(),
                volumes: vec![VmVolume {
                    host: data.path().display().to_string(),
                    guest: "/data".into(),
                    read_only,
                    materialized_image: Some(data.path().join("source.ext4").display().to_string()),
                    ..Default::default()
                }],
                destroy_on_exit: false,
                grants: None,
                secrets: Vec::new(),
                secret_release: SecretReleasePolicy::PlanBound,
                signed_plan: None,
                registry_pack_image: None,
            };
            let error = admit_and_boot_local(
                &backend,
                &req,
                LocalRunContext {
                    clock: &clock,
                    ledger: &ledger,
                    host_signer_keys_dir: Some(data.path()),
                    emitter: None,
                    assurance: None,
                },
            )
            .expect_err("raw materialized images must not reach the backend");
            assert!(
                error.to_string().contains("raw local admission"),
                "{error:#}"
            );
        }
    }

    /// The launch volume set is baked into the signed plan's shares in the
    /// same order and with matching tags/kinds, so the claim-1 gate passes
    /// exactly when the attached volumes are the admitted ones.
    #[test]
    fn shares_mirror_the_launch_volume_set() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let volumes = vec![
            VmVolume {
                materialized_image: None,
                volume_label: None,
                host: "/h/work.ext4".into(),
                guest: "/data/work".into(),
                size: "16M".into(),
                read_only: true,
                kind: VmVolumeKind::Disk,
                encrypted: false,
            },
            VmVolume {
                materialized_image: Some("/state/src.ext4".to_string()),
                volume_label: None,
                host: "/h/src".into(),
                guest: "/data/src".into(),
                size: String::new(),
                read_only: false,
                kind: VmVolumeKind::Disk,
                encrypted: false,
            },
        ];
        let shares = shares_from_vm_volumes(&volumes);
        assert_eq!(shares.len(), 2);
        assert_eq!(shares[0].tag, "uvol0");
        assert_eq!(shares[0].kind, mvm_core::plan::ShareKind::Disk);
        assert!(shares[0].read_only);
        assert_eq!(shares[1].tag, "uvol1");
        assert_eq!(shares[1].kind, mvm_core::plan::ShareKind::DirShare);
        assert_eq!(shares[1].guest_path, "/data/src");
        assert!(shares_from_vm_volumes(&[]).is_empty());
    }

    /// A boot with a volume passes the claim-1 admitted-shares gate (the
    /// plan's shares and the config's volumes come from one source), and the
    /// wired emitter records the admitted → launched pair.
    #[test]
    fn admit_and_boot_local_admits_volumes_and_emits_chain_entries() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        let keys = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();

        let rootfs = data.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"hashable\n").unwrap();
        let volume = data.path().join("work.ext4");
        std::fs::write(&volume, b"volume-bytes\n").unwrap();

        let signer = crate::audit::host_keypair::load_or_init_at(keys.path()).unwrap();
        let emitter =
            crate::audit::emitter::AuditEmitter::with_dir(signer.signing, audit.path()).unwrap();

        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let clock = SystemClock;
        let req = LocalRunRequest {
            name: "local-run-volumes".into(),
            rootfs_path: rootfs,
            kernel_path: None,
            verity_path: None,
            roothash: None,
            cpus: 1,
            mem_mib: 128,
            backend_name: "mock".into(),
            volumes: vec![VmVolume {
                materialized_image: None,
                volume_label: None,
                host: volume.to_string_lossy().into_owned(),
                guest: "/data/work".into(),
                size: String::new(),
                read_only: true,
                kind: VmVolumeKind::Disk,
                encrypted: false,
            }],
            destroy_on_exit: true,
            grants: None,
            secrets: Vec::new(),
            secret_release: SecretReleasePolicy::None,
            signed_plan: None,
            registry_pack_image: None,
        };
        let started = admit_and_boot_local(
            &backend,
            &req,
            LocalRunContext {
                clock: &clock,
                ledger: &ledger,
                host_signer_keys_dir: Some(keys.path()),
                emitter: Some(&emitter),
                assurance: None,
            },
        )
        .expect("admitted boot with a volume");
        assert_eq!(started.admitted.plan().shares.len(), 1);
        assert_eq!(started.admitted.plan().shares[0].guest_path, "/data/work");
        assert!(started.admitted.plan().post_run.destroy_on_exit);

        let chain = std::fs::read_to_string(audit.path().join("local.jsonl")).unwrap();
        assert!(chain.contains("plan.admitted"), "got: {chain}");
        assert!(chain.contains("plan.launched"), "got: {chain}");
    }

    /// A refusal in a post-admission gate (here the SDK-sidecar gate: a
    /// volume at the sidecar mount point with no SDK service binding) still
    /// terminates the chain — `plan.admitted` is followed by a `plan.failed`
    /// naming the refusing stage, never left dangling.
    #[test]
    fn gate_refusal_after_admission_emits_plan_failed() {
        use mvm_core::vm_backend::{VmVolume, VmVolumeKind};
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        let keys = tempfile::tempdir().unwrap();
        let audit = tempfile::tempdir().unwrap();

        let rootfs = data.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"hashable\n").unwrap();
        let sidecar = data.path().join("sdk.ext4");
        std::fs::write(&sidecar, b"sidecar-bytes\n").unwrap();

        let signer = crate::audit::host_keypair::load_or_init_at(keys.path()).unwrap();
        let emitter =
            crate::audit::emitter::AuditEmitter::with_dir(signer.signing, audit.path()).unwrap();

        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let clock = SystemClock;
        let req = LocalRunRequest {
            name: "local-run-gate-refusal".into(),
            rootfs_path: rootfs,
            kernel_path: None,
            verity_path: None,
            roothash: None,
            cpus: 1,
            mem_mib: 128,
            backend_name: "mock".into(),
            volumes: vec![VmVolume {
                materialized_image: None,
                volume_label: None,
                host: sidecar.to_string_lossy().into_owned(),
                guest: mvm_core::plan::SDK_SIDECAR_GUEST_PATH.into(),
                size: String::new(),
                read_only: true,
                kind: VmVolumeKind::Disk,
                encrypted: false,
            }],
            destroy_on_exit: true,
            grants: None,
            secrets: Vec::new(),
            secret_release: SecretReleasePolicy::None,
            signed_plan: None,
            registry_pack_image: None,
        };
        let err = admit_and_boot_local(
            &backend,
            &req,
            LocalRunContext {
                clock: &clock,
                ledger: &ledger,
                host_signer_keys_dir: Some(keys.path()),
                emitter: Some(&emitter),
                assurance: None,
            },
        )
        .expect_err("the SDK-sidecar gate must refuse");
        assert!(
            format!("{err:#}").contains("binds no SDK host service"),
            "got: {err:#}"
        );

        let chain = std::fs::read_to_string(audit.path().join("local.jsonl")).unwrap();
        assert!(chain.contains("plan.admitted"), "got: {chain}");
        assert!(chain.contains("plan.failed"), "got: {chain}");
        assert!(chain.contains("sdk-sidecar"), "got: {chain}");
        assert!(
            !chain.contains("plan.launched"),
            "a refused launch must not read as launched: {chain}"
        );
    }

    /// The overlay attachment mirrors the CLI's matrix: workload VMM
    /// backends probe the version-keyed cache and fail closed on a miss;
    /// non-VMM backends (the mock) skip entirely.
    #[test]
    fn runtime_overlay_attachment_fails_closed_on_a_cold_cache() {
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());

        // Mock backend: never probed, fields untouched.
        let mut config = VmStartConfig::default();
        attach_runtime_overlay_from_cache(&mut config, "mock").expect("mock skips");
        assert!(config.runtime_overlay_path.is_none());

        // A real backend with a cold cache fails closed. There is no second
        // arm any more: the overlay is the only source of the guest binaries,
        // so "boot anyway with nothing attached" is not a posture a backend
        // can select.
        let mut config = VmStartConfig {
            ..Default::default()
        };
        let err = attach_runtime_overlay_from_cache(&mut config, "firecracker")
            .expect_err("a cold cache must refuse");
        assert!(
            err.to_string().contains("runtime overlay required"),
            "got: {err:#}"
        );
    }

    /// A local boot of a rootfs gets the universal initramfs with its runtime
    /// overlay. Without it a runtime-lean rootfs has no `/init`, and the guest
    /// panics before userspace; that is what every transient in-process launch
    /// did while this path attached the overlay alone.
    #[test]
    fn cached_runtime_propagates_checked_source_and_refuses_tampering_without_fallback() {
        for (backend, target) in ["hvf", "apple-container"].into_iter().flat_map(|backend| {
            ["overlay", "initramfs", "release-triplet", "explicit-proof"]
                .map(|target| (backend, target))
        }) {
            let data = tempfile::tempdir().unwrap();
            let mut env = TestEnv::new();
            env.isolate_mvm_home(data.path());
            crate::test_fixtures::install_runtime_overlay(data.path());
            let mut config = VmStartConfig {
                kernel_path: Some("/kernel".into()),
                ..Default::default()
            };
            attach_guest_runtime(&mut config, backend).unwrap();
            assert!(config.unsigned_runtime_development);
            assert!(config.runtime_release_proof.is_none());
            mvm_runtime::runtime_evidence::verify_runtime_for_launch(
                &config,
                mvm_runtime::runtime_evidence::MIN_GUEST_RPC_PROTOCOL_VERSION,
            )
            .unwrap();
            let mut request = VmStartConfig::default();
            match target {
                "overlay" => {
                    std::fs::write(config.runtime_overlay_path.as_ref().unwrap(), b"tampered")
                        .unwrap()
                }
                "initramfs" => {
                    std::fs::write(config.initrd_path.as_ref().unwrap(), b"tampered").unwrap()
                }
                "release-triplet" => {
                    let directory = data
                        .path()
                        .join("cache/guest-runtime/releases")
                        .join(env!("CARGO_PKG_VERSION"));
                    std::fs::create_dir_all(&directory).unwrap();
                    let asset =
                        mvm_build::guest_bins::guest_bins_archive_name(env!("CARGO_PKG_VERSION"));
                    std::fs::write(directory.join(format!("{asset}.sha256")), b"invalid").unwrap();
                }
                "explicit-proof" => {
                    request.runtime_release_proof =
                        Some(mvm_core::protocol::runtime_release::RuntimeReleaseProof {
                            archive: data.path().join("absent-archive"),
                            checksum: data.path().join("absent-checksum"),
                            signature_bundle: data.path().join("absent-bundle"),
                            archive_sha256: "ab".repeat(32),
                            version: env!("CARGO_PKG_VERSION").into(),
                            arch: mvm_core::arch::GuestArch::host(),
                        });
                }
                _ => unreachable!(),
            }
            assert!(
                attach_guest_runtime(&mut request, backend).is_err(),
                "{backend}: {target}"
            );
            assert!(
                request.runtime_overlay_path.is_none(),
                "failed selection must be atomic"
            );
            assert!(
                !request.unsigned_runtime_development,
                "failure must not grant source admission"
            );
        }
    }

    #[test]
    fn a_local_boot_attaches_the_initramfs_that_mounts_its_overlay() {
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        crate::test_fixtures::install_runtime_overlay(data.path());

        // Every kernel-booting backend, so one that boots the initramfs
        // without the overlay it mounts cannot slip in again.
        for backend in mvm_runtime::universal_initramfs::KERNEL_BOOTING_HYPERVISORS {
            let mut config = VmStartConfig {
                rootfs_path: "/rootfs.ext4".into(),
                kernel_path: Some("/vmlinux".into()),
                ..Default::default()
            };
            attach_guest_runtime(&mut config, backend).expect("both artifacts are cached");
            assert!(
                config.runtime_overlay_path.is_some(),
                "{backend}: the overlay carries the agent"
            );
            let initrd = config
                .initrd_path
                .unwrap_or_else(|| panic!("{backend}: a rootfs boot needs the initramfs"));
            assert!(
                initrd.starts_with(&data.path().join("cache").display().to_string()),
                "{backend}: the initramfs comes from the host cache: {initrd}"
            );
        }
    }

    /// The mock boots no kernel, so it resolves neither artifact.
    #[test]
    fn the_mock_boot_resolves_no_guest_runtime() {
        let data = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(data.path());
        let mut config = VmStartConfig {
            rootfs_path: "/rootfs.ext4".into(),
            kernel_path: Some("/vmlinux".into()),
            ..Default::default()
        };
        attach_guest_runtime(&mut config, "mock").expect("the mock needs nothing");
        assert!(config.runtime_overlay_path.is_none());
        assert!(config.initrd_path.is_none());
    }

    /// A missing rootfs fails at the hash step, before any admission or boot.
    #[test]
    fn admit_and_boot_local_missing_rootfs_fails_before_boot() {
        let keys = tempfile::tempdir().unwrap();
        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        let clock = SystemClock;
        let req = LocalRunRequest {
            name: "missing-rootfs".into(),
            rootfs_path: PathBuf::from("/nonexistent/rootfs.ext4"),
            kernel_path: None,
            verity_path: None,
            roothash: None,
            cpus: 1,
            mem_mib: 128,
            backend_name: "mock".into(),
            volumes: Vec::new(),
            destroy_on_exit: false,
            grants: None,
            secrets: Vec::new(),
            secret_release: SecretReleasePolicy::None,
            signed_plan: None,
            registry_pack_image: None,
        };
        let err = admit_and_boot_local(
            &backend,
            &req,
            LocalRunContext {
                clock: &clock,
                ledger: &ledger,
                host_signer_keys_dir: Some(keys.path()),
                emitter: None,
                assurance: None,
            },
        )
        .unwrap_err();
        assert!(err.to_string().contains("hashing rootfs"));
    }
}

#[cfg(test)]
mod signed_boot_tests {
    //! The fleet-issued door of the local-run seam, end to end over the
    //! hermetic mock backend: admit an externally-signed plan and boot it —
    //! or refuse and boot nothing.
    use super::*;
    #[cfg(unix)]
    include!("run/admitted_boot_tests.rs");
    use crate::plan_admission::SystemClock;
    use ed25519_dalek::SigningKey;
    use mvm_core::plan::test_support::PlanFixture;
    use mvm_core::user_config::{MvmConfig, TrustedPlanSigner};
    use mvm_core::util::test_env::TestEnv;

    fn fleet_key() -> SigningKey {
        SigningKey::from_bytes(&[42u8; 32])
    }

    /// Isolate `MVM_HOME` and write the host config; the trusted-signer set
    /// lives in operator config, so a test that wants a trusting host has to
    /// be one.
    fn host_with(cfg: MvmConfig) -> (TestEnv, tempfile::TempDir) {
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(home.path());
        mvm_core::user_config::save(&cfg, None).unwrap();
        (env, home)
    }

    fn pinned_host() -> (TestEnv, tempfile::TempDir) {
        host_with(MvmConfig {
            trusted_plan_signers: vec![TrustedPlanSigner {
                signer_id: "fleet-prod".to_string(),
                ed25519_pubkey_hex: hex::encode(fleet_key().verifying_key().as_bytes()),
            }],
            ..MvmConfig::default()
        })
    }

    /// A request whose signed plan pins the exact bytes of `rootfs`.
    fn signed_request(
        name: &str,
        rootfs: &Path,
        plan: mvm_core::plan::ExecutionPlan,
    ) -> LocalRunRequest {
        LocalRunRequest {
            name: name.to_string(),
            rootfs_path: rootfs.to_path_buf(),
            kernel_path: None,
            verity_path: None,
            roothash: None,
            cpus: 1,
            mem_mib: 128,
            backend_name: "mock".into(),
            volumes: Vec::new(),
            destroy_on_exit: true,
            grants: None,
            secrets: Vec::new(),
            secret_release: SecretReleasePolicy::None,
            signed_plan: Some(mvm_core::plan::sign_plan(&plan, &fleet_key(), "fleet-prod")),
            registry_pack_image: None,
        }
    }

    fn boot(req: &LocalRunRequest) -> Result<StartedMachine> {
        let backend = AnyBackend::from_hypervisor("mock");
        let ledger = InMemoryNonceLedger::new();
        admit_and_boot_local(
            &backend,
            req,
            LocalRunContext {
                clock: &SystemClock,
                ledger: &ledger,
                host_signer_keys_dir: None,
                emitter: None,
                assurance: None,
            },
        )
    }

    #[test]
    fn a_fleet_signed_plan_boots_through_the_local_seam() {
        let (_env, home) = pinned_host();
        let rootfs = home.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"fleet workload bytes\n").unwrap();
        let sha = mvm_core::crypto::image_verify::sha256_file(&rootfs).unwrap();

        let mut plan = PlanFixture::new()
            .runtime_profile("mock")
            .tenant("fleet-tenant")
            .build();
        plan.image.sha256 = sha;
        let req = signed_request("fleet-vm", &rootfs, plan);

        let started = boot(&req).expect("a pinned fleet-signed plan admits and boots");
        assert_eq!(started.vm_id.0, "fleet-vm");
        assert_eq!(started.admitted.signer_id(), "fleet-prod");
        assert_eq!(started.admitted.plan().tenant.0, "fleet-tenant");
    }

    #[test]
    fn a_fleet_signed_plan_is_refused_when_the_host_pins_nobody() {
        let (_env, home) = host_with(MvmConfig::default());
        let rootfs = home.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"fleet workload bytes\n").unwrap();
        let sha = mvm_core::crypto::image_verify::sha256_file(&rootfs).unwrap();

        let mut plan = PlanFixture::new().runtime_profile("mock").build();
        plan.image.sha256 = sha;
        let req = signed_request("fleet-vm-refused", &rootfs, plan);

        let err = boot(&req).expect_err("an unpinned host must refuse");
        assert!(
            format!("{err:#}").contains("pins no trusted plan signers"),
            "got: {err:#}"
        );
    }

    #[test]
    fn a_rootfs_that_is_not_the_pinned_image_is_refused() {
        let (_env, home) = pinned_host();
        let rootfs = home.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"bytes the plan did not authorize\n").unwrap();

        // The plan pins the fixture's digest, not this rootfs's — a validly
        // signed plan booting different bytes must not pass.
        let plan = PlanFixture::new().runtime_profile("mock").build();
        let req = signed_request("fleet-vm-wrong-image", &rootfs, plan);

        let err = boot(&req).expect_err("an image mismatch must refuse the boot");
        assert!(
            format!("{err:#}").contains("refusing to boot an image the plan does not authorize"),
            "got: {err:#}"
        );
    }
}
