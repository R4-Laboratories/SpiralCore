//! Public original Core API checks; no copied PII implementation or controls API.
use mvm_core::{pii::PiiRedactor, policy::PiiPolicy};
#[test]
fn selected_owned_controls_are_source_coupled_and_unchanged_elsewhere() {
    let facts = PiiRedactor::owned_pii_requirements(&PiiPolicy::default()).unwrap();
    assert_eq!(facts.nfa_size_limit_bytes, 524_288);
    assert_eq!(facts.dfa_cache_limit_bytes, 262_144);
    assert_eq!(facts.nest_limit, 64);
    assert_eq!(facts.max_concurrent_searches, 1);
    assert_eq!((facts.rule_count, facts.regex_objects), (5, 6));
}
#[test]
fn default_disabled_and_modes_keep_original_byte_name_and_match_semantics() {
    let input = "\u{03bb}\u{754c} synthetic@example.invalid 001-01-0001 4111111111111111 +12025550123 GB82WEST12345698765432 invalid000-00-0000".as_bytes();
    for mode in [
        None,
        Some("detect"),
        Some("redact"),
        Some("refuse"),
        Some("disabled"),
    ] {
        let policy = PiiPolicy {
            mode: mode.map(str::to_owned),
            categories: vec![],
        };
        let owned = PiiRedactor::curated_owned(&policy).unwrap();
        let legacy = PiiRedactor::from_policy(&policy)
            .unwrap()
            .unwrap_or_else(PiiRedactor::with_default_rules);
        assert_eq!(owned.mode(), legacy.mode());
        assert_eq!(owned.redact(input), legacy.redact(input));
        assert_eq!(owned.scan(input), legacy.scan(input));
        assert_eq!(owned.match_spans(input), legacy.match_spans(input));
    }
    let disabled = PiiPolicy {
        mode: Some("disabled".into()),
        categories: vec!["email".into()],
    };
    assert_eq!(
        PiiRedactor::owned_pii_requirements(&disabled)
            .unwrap()
            .rule_count,
        5
    );
    assert_eq!(
        PiiRedactor::curated_owned(&disabled).unwrap().redact(input),
        PiiRedactor::with_default_rules().redact(input)
    );
}
#[test]
fn invalid_categories_and_modes_refuse_without_payload_in_errors_or_fallback() {
    for policy in [
        PiiPolicy {
            mode: Some("private-invalid-mode".into()),
            categories: vec![],
        },
        PiiPolicy {
            mode: None,
            categories: vec!["private-unknown-category".into()],
        },
        PiiPolicy {
            mode: None,
            categories: vec!["email".into(), "email".into()],
        },
        PiiPolicy {
            mode: None,
            categories: vec!["email".into(); 6],
        },
    ] {
        let error = PiiRedactor::owned_pii_requirements(&policy).unwrap_err();
        assert!(!error.to_string().contains("private-"));
        assert!(PiiRedactor::curated_owned(&policy).is_err());
    }
}
