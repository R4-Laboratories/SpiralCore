#!/bin/sh
set -eu
cd /var/tmp/spiralcore-pii-capacity-20261104/requested-witness
out=validation/selected-512
test ! -e "$out"
mkdir -p "$out/protected"
capture() {
  python3 - "$1" <<'PY'
import hashlib,json,pathlib,sys
base=pathlib.Path('/var/tmp/spiralcore-pii-capacity-20261104/source')
paths=[]
for name in ('mvm-core','mvm-contract'):
    paths.extend(p for p in (base/'crates'/name).rglob('*') if p.is_file())
paths.extend(base/name for name in ('Cargo.toml','Cargo.lock'))
probe=pathlib.Path.cwd()
paths.extend(p for p in probe.iterdir() if p.is_file())
paths.extend(p for p in (probe/'validation/selected-512/protected').iterdir() if p.is_file())
rows={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
pathlib.Path(sys.argv[1]).write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n')
PY
}
capture "$out/source-before.json"
set +e
CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/var/tmp/spiralcore-pii-capacity-20261104/target /home/callard/.cargo/bin/cargo +1.97.1 build --release --offline --locked --message-format=json > "$out/build.jsonl" 2> "$out/build.txt"
status=$?
set -e
printf '%s\n' "$status" > "$out/build.exit"
test "$status" -eq 0
cp /var/tmp/spiralcore-pii-capacity-20261104/requested-witness-target/release/owned-pii-requested-witness "$out/protected/probe"
chmod 500 "$out/protected/probe"
/home/callard/.cargo/bin/rustc +1.97.1 --edition=2024 -O verify_constructor_count.rs -o "$out/protected/verify-count"
chmod 500 "$out/protected/verify-count"
sha256sum "$out/protected/"* > "$out/binary-before.sha256"
set +e
/usr/bin/time -v "$out/protected/probe" --all-constructors > "$out/constructors.jsonl" 2> "$out/constructors.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$out/constructors.exit"
test "$status" -eq 0
"$out/protected/verify-count" "$out/constructors.jsonl" > "$out/count-verifier.txt"
set +e
/usr/bin/time -v "$out/protected/probe" > "$out/sample.jsonl" 2> "$out/sample.stderr"
status=$?
set -e
printf '%s\n' "$status" > "$out/sample.exit"
test "$status" -eq 0
capture "$out/source-after.json"
sha256sum -c "$out/binary-before.sha256" > "$out/binary-check.txt"
python3 - "$out" <<'PY'
import json,pathlib,sys
out=pathlib.Path(sys.argv[1]); before=json.loads((out/'source-before.json').read_text()); after=json.loads((out/'source-after.json').read_text())
assert all(after.get(k)==v for k,v in before.items()),'source input changed'
assert set(after)-set(before)=={str(pathlib.Path.cwd()/out/'protected/probe'),str(pathlib.Path.cwd()/out/'protected/verify-count')},'unexpected new source input'
rows=[json.loads(line) for line in (out/'constructors.jsonl').read_text().splitlines()]
construct=[r for r in rows if r.get('phase')=='construct']; verified=[r for r in rows if r.get('scope')=='finite-selection-verified']
assert len(construct)==len(verified)==325
summary={'source_inputs_verified':len(before),'constructors':len(construct),'exact_legacy_comparisons':len(verified),'completion':rows[-1],'all_post_drop_deltas':[r['post_drop_live_delta'] for r in verified]}
(out/'summary.json').write_text(json.dumps(summary,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='all_post_drop_deltas'},sort_keys=True))
PY
