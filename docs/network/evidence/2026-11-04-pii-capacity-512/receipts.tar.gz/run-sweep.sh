#!/bin/bash
set -euo pipefail
root=/var/tmp/spiralcore-pii-capacity-20261104
out="$root/validation/private-sweep"
mkdir -p "$out/protected"
cd "$root/source"
python3 - "$out/source-before.json" <<'PY'
import pathlib,hashlib,json,sys
root=pathlib.Path.cwd(); paths=[p for c in ['mvm-core','mvm-contract'] for p in (root/'crates'/c).rglob('*') if p.is_file()];paths += [root/'Cargo.toml',root/'Cargo.lock']
pathlib.Path(sys.argv[1]).write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)},indent=2)+'\n')
PY
printf '%s\n' 'CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR=/var/tmp/spiralcore-pii-capacity-20261104/target cargo +1.97.1 test --release --offline --locked -p mvm-core --no-default-features --features host-state --lib fixed_owned_nfa_candidates_preserve_all_ordered_policies_and_search_samples --no-run --message-format=json' > "$out/command.txt"
set +e
CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_TARGET_DIR="$root/target" /home/callard/.cargo/bin/cargo +1.97.1 test --release --offline --locked -p mvm-core --no-default-features --features host-state --lib fixed_owned_nfa_candidates_preserve_all_ordered_policies_and_search_samples --no-run --message-format=json > "$out/build.jsonl" 2> "$out/build.stderr" &
pid=$!
echo "cargo_pid=$pid"
wait "$pid"
s=$?
printf '%s\n' "$s" > "$out/build.exit"
set -e
test "$s" -eq 0
python3 - "$out" <<'PY'
import json,pathlib,shutil,sys,hashlib
out=pathlib.Path(sys.argv[1]); rows=[json.loads(x) for x in (out/'build.jsonl').read_text().splitlines()]; binaries=[x['executable'] for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x.get('target',{}).get('name')=='mvm_core'];assert len(binaries)==1,binaries
p=out/'protected/core-tests';shutil.copyfile(binaries[0],p);p.chmod(0o500);(out/'binary-before.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p)+'\n')
PY
set +e
/usr/bin/time -v "$out/protected/core-tests" fixed_owned_nfa_candidates_preserve_all_ordered_policies_and_search_samples --test-threads=1 --nocapture > "$out/test.stdout" 2> "$out/test.stderr"
s=$?
printf '%s\n' "$s" > "$out/test.exit"
set -e
sha256sum -c "$out/binary-before.sha256" > "$out/binary-check.txt"
python3 - "$out" <<'PY'
import pathlib,hashlib,json,sys
out=pathlib.Path(sys.argv[1]); before=json.loads((out/'source-before.json').read_text());after={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in before};assert before==after;(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');print('source_verified',len(after))
PY
cat "$out/test.stdout"
exit "$s"
