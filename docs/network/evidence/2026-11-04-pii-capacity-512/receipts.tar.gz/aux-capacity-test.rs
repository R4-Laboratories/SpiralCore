#[test]
fn canonical_owned_collector_fits_existing_eighty_mib_auxiliary_credit() {
    use crate::telemetry_collector::{
        owned_scanner_requested_bytes, owned_collector_requirements,
    };
    let policy = mvm_core::policy::RedactionPolicy::default();
    let facts = owned_collector_requirements().unwrap();
    let scanner = owned_scanner_requested_bytes(&policy).unwrap();
    let requested = facts.known_metadata_bytes.checked_add(scanner).unwrap();
    let prepaid = 80_u64 << 20;
    println!(
        "{{\"scope\":\"actual-auxiliary-collector-admission\",\"prepaid_metadata\":{prepaid},\"scanner_requested\":{scanner},\"collector_requested\":{requested}}}"
    );
    let ledger = credits(facts.known_rust_stack_bytes, prepaid);
    ledger
        .reserve(
            Component::Collector,
            facts.known_rust_stack_bytes,
            requested,
            || Ok(()),
        )
        .expect("canonical collector must fit existing prepaid auxiliary credit");
    // The SAME ledger still refuses a byte past its actual remainder; no
    // second pool, refill or live-object repricing is exercised here.
    assert_eq!(
        ledger
            .reserve(Component::Controller, 0, prepaid - requested + 1, || Ok(()))
            .unwrap_err()
            .kind(),
        io::ErrorKind::WouldBlock
    );
    assert_eq!(
        ledger
            .reserve(Component::Collector, 0, 0, || Ok(()))
            .unwrap_err()
            .kind(),
        io::ErrorKind::AlreadyExists
    );
}
