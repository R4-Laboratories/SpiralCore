#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/worker-mvm-focused"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_HOME="$q/worker-mvm-test-state"
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-worker-mvm.XXXXXX)
mkdir -m 700 -p "$MVM_HOME"
cd "$q/worker-funding-mvm-work"
rustfmt --edition 2024 crates/mvm-hostd/src/installed_endpoint/controller/network.rs crates/mvm-hostd/src/installed_endpoint/controller/network/worker_tests.rs crates/mvm-hostd/tests/registered_direct_tcp.rs
find . -type f ! -path './.git/*' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
systemctl --user show sc-worker-mvm-focused -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
rustc -Vv > "$out-toolchain.txt"
finish() {
  rc=$?
  trap - EXIT
  find . -type f ! -path './.git/*' -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
  cmp "$out-before.sha256" "$out-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline -p mvm-hostd --lib --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
exe=$(python3 - "$out-build.jsonl" <<'PY'
import json,sys
rows=[json.loads(s) for s in open(sys.argv[1])]
paths=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='mvm_hostd' and r.get('profile',{}).get('test') and r.get('executable')]
assert len(paths)==1,paths
print(paths[0])
PY
)
sha256sum "$exe" > "$out-executable-before.sha256"
/usr/bin/time -v -o "$out-tests-time.txt" "$exe" installed_endpoint::controller::network::worker_tests:: --test-threads=1 --nocapture > "$out-tests.txt" 2>&1
grep -E '^test result: ok\. 1 passed; 0 failed;' "$out-tests.txt"
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt"
echo WORKER_MVM_FOCUSED_VERIFIED
