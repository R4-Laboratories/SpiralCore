#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/worker-mvm-full"
umask 0022
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/worker-mvm-full-state" MVM_DEV_ENV_KEEP_INHERITED=1
mkdir -m700 -p "$MVM_HOME"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_GPU_TEST_EXPECT_NATIVE=1 PYTHONDONTWRITEBYTECODE=1
export UV_CACHE_DIR="$q/qualification-cache/uv" npm_config_cache="$q/qualification-cache/npm"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-oq.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
ulimit -Sn 4096
ulimit -S -s 8192
cd "$q/worker-funding-mvm-work"
source scripts/dev-env.sh
sha256sum -c "$q/worker-mvm-final-inputs.sha256" > "$out-inputs-before.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-before.sha256"
cmp "$q/worker-mvm-final-inputs.sha256" "$out-file-set-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  sha256sum -c "$q/worker-mvm-final-inputs.sha256" > "$out-inputs-after.txt" || rc=90
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-after.sha256"
  cmp "$q/worker-mvm-final-inputs.sha256" "$out-file-set-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  if [ "$rc" -eq 0 ]; then
    echo WORKER_MVM_FULL_SOURCE_VERIFIED
  fi
  exit "$rc"
}
trap finish EXIT
{ printf 'soft=%s\nhard=%s\n' "$(ulimit -Sn)" "$(ulimit -Hn)"; stat -c '%U %a %n' "$TMPDIR"; cat /proc/driver/nvidia/version; } > "$out-prerequisites.txt"
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-worker-mvm-full -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
cargo metadata --locked --offline --format-version=1 > "$out-metadata.json"
jq -e --arg source 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' '[.packages[] | select(.name|test("^(spiralcore-|uor-r4-object-store)"))] as $core | ($core|length)==5 and all($core[];.source==$source)' "$out-metadata.json" > "$out-pin-check.txt"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
/usr/bin/time -v -o "$out-clippy-time.txt" cargo clippy --locked --offline --workspace -- -D warnings > "$out-clippy.txt" 2>&1
/usr/bin/time -v -o "$out-check-time.txt" cargo check --locked --offline --workspace --all-targets > "$out-check.txt" 2>&1
/usr/bin/time -v -o "$out-bdd-time.txt" cargo check --locked --offline -p mvm-conformance --all-targets --features bdd > "$out-bdd.txt" 2>&1
/usr/bin/time -v -o "$out-footprint-time.txt" cargo run --locked --offline -p xtask --bin xtask -- check-rust-footprint > "$out-footprint.txt" 2>&1
/usr/bin/time -v -o "$out-policy-time.txt" cargo run --locked --offline -p xtask --bin xtask -- check-all > "$out-policy.txt" 2>&1
/usr/bin/time -v -o "$out-tests-time.txt" cargo test --locked --offline --workspace -- --test-threads=1 > "$out-tests.txt" 2>&1
