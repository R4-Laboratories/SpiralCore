#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/worker-addressed-receipt"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
umask 0022
ulimit -Sn 4096
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-worker-ack.XXXXXX)
cd "$q/original-worker-funding-work"
sha256sum -c "$q/worker-sdk-final-inputs.sha256" > "$out-inputs-before.txt"
touch crates/spiralcore-mvm-journal-host/tests/addressed.rs
finish() {
  rc=$?
  trap - EXIT
  sha256sum -c "$q/worker-sdk-final-inputs.sha256" > "$out-inputs-after.txt" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  if [[ "$rc" == 0 ]]; then echo WORKER_ADDRESSED_RECEIPT_VERIFIED; fi
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
executable=$(jq -ers '[.[] | select(.reason == "compiler-artifact" and .target.name == "addressed" and .profile.test and .executable) | .executable] | select(length == 1) | first' "$out-build.jsonl")
sha256sum "$executable" > "$out-executable-before.sha256"
/usr/bin/time -v -o "$out-application-time.txt" "$executable" --test-threads=1 --nocapture > "$out-application-output.txt" 2>&1
grep -E '^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;' "$out-application-output.txt"
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt"
