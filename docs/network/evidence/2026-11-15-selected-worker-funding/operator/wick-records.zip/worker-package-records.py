from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

q = Path('/var/tmp/sc-direct-flowmux.iptmjZre')
prefixes = ('original-worker-red', 'worker-mvm-', 'worker-sdk-', 'worker-footprint-',
            'worker-addressed-receipt-', 'worker-registered-')
extras = {'worker-count-tests.py', 'worker-coherent-executables.py', 'worker-graphs.sh',
          'worker-matched-metadata.sh', 'worker-addressed.sh', 'worker-registered.sh',
          'worker-package-records.py'}
suffixes = {'.txt', '.json', '.jsonl', '.sha256', '.sh', '.py', '.jq', '.md', '.rs', '.stderr'}
units = ['sc-original-worker-red', 'sc-worker-mvm-focused', 'sc-worker-mvm-full',
         'sc-worker-sdk-qualified', 'sc-worker-sdk-final', 'sc-worker-addressed',
         'sc-worker-registered', 'sc-worker-mvm-coherent', 'sc-worker-footprint-fresh',
         'sc-worker-footprint-zero-debug']
states = []
for unit in units:
    result = subprocess.run(['systemctl', '--user', 'show', unit, '-p', 'ActiveState',
                             '-p', 'SubState', '-p', 'Result', '-p', 'ExecMainStatus'],
                            capture_output=True, text=True, check=True)
    fields = dict(line.split('=', 1) for line in result.stdout.splitlines())
    assert fields['ActiveState'] in ('inactive', 'failed'), (unit, fields)
    states.append({'unit': unit, **fields})
    log = subprocess.run(['journalctl', '--user', '-u', unit, '--no-pager', '-o', 'cat'],
                         capture_output=True, check=True).stdout
    # Manager logs have a separate filename from every application receipt.
    (q / (unit.removeprefix('sc-') + '-manager-journal.txt')).write_bytes(log)
(q / 'worker-mvm-all-unit-terminal-states.json').write_text(json.dumps(states, indent=2) + '\n')

old = q / 'worker-prior-root-mvm-build.elf'
raw = old.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'a17f9cf1a7c8c8638d8a828458c18104e34e5daec41459ed57c3b6d31218f64e'
old_context = {'file': old.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
               'prior_root_occurrences': raw.count(b'/var/tmp/sc-direct-flowmux.iptmjZre/verified-runtime-owner-work/crates/mvm-build'),
               'candidate_root_occurrences': raw.count(b'/var/tmp/sc-direct-flowmux.iptmjZre/worker-funding-mvm-work/crates/mvm-build'),
               'binary_distributed': False, 'scope': 'retained invalid first full-run mvm-build executable context'}
assert old_context['prior_root_occurrences'] == 15 and old_context['candidate_root_occurrences'] == 0
(q / 'worker-mvm-prior-root-observation.json').write_text(json.dumps(old_context, indent=2) + '\n')

paths = [p for p in q.iterdir() if p.is_file() and p.suffix in suffixes
         and (p.name.startswith(prefixes) or p.name in extras)]
paths += [p for p in (q / 'worker-final-graphs').rglob('*') if p.is_file() and p.suffix == '.json']
assert all(not p.is_symlink() for p in paths)
records = []
archive = q / 'worker-qualification-records.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in sorted(paths):
        data = p.read_bytes()
        assert not re.search(rb'https://\S+[?&]sig=', data, re.I), p.name
        assert not re.search(rb'-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----', data), p.name
        name = str(p.relative_to(q))
        records.append({'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        z.writestr(name, data)
    z.writestr('record-index.json', json.dumps({'records': records}, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
receipt = {'archive': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'zip_bytes': archive.stat().st_size, 'records': len(records),
           'record_bytes': sum(r['bytes'] for r in records), 'all_units_terminal': True}
(q / 'worker-qualification-records.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
