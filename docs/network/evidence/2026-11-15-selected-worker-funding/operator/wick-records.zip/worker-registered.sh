#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/worker-registered"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_HOME="$q/worker-registered-state" MVM_DEV_ENV_KEEP_INHERITED=1
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-worker-peer.XXXXXX)
mkdir -m700 "$MVM_HOME"
cd "$q/worker-funding-mvm-work"
source scripts/dev-env.sh
sha256sum -c "$q/worker-mvm-final-inputs.sha256" > "$out-inputs-before.txt"
systemctl --user show sc-worker-registered -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
finish() {
  rc=$?
  trap - EXIT
  sha256sum -c "$q/worker-mvm-final-inputs.sha256" > "$out-inputs-after.txt" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  if [[ "$rc" == 0 ]]; then echo WORKER_REGISTERED_VERIFIED; fi
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline -p mvm-hostd --test registered_direct_tcp --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
python3 - "$out-build.jsonl" "$out" <<'PY'
import json,sys,hashlib,pathlib
rows=[json.loads(line) for line in open(sys.argv[1])]
selected=[]
for name,kind,test in [('registered_direct_tcp','test',True),('mvm-host-agent','bin',False),('mvm-signer-helper','bin',False),('mvm-network-endpoint','bin',False)]:
 paths={r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('target',{}).get('kind')==[kind] and r.get('profile',{}).get('test')==test and r.get('executable')}
 assert len(paths)==1,(name,paths)
 p=pathlib.Path(paths.pop());selected.append({'name':name,'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
pathlib.Path(sys.argv[2]+'-executables.json').write_text(json.dumps(selected,indent=2)+'\n')
pathlib.Path(sys.argv[2]+'-executables-before.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in selected))
pathlib.Path(sys.argv[2]+'-test-path.txt').write_text(selected[0]['path']+'\n')
PY
executable=$(cat "$out-test-path.txt")
/usr/bin/time -v -o "$out-test-time.txt" "$executable" registered_prepare::registered_direct_tcp_transfers_exact_bytes_and_refunds_a_failed_peer --exact --test-threads=1 --nocapture > "$out-tests.txt" 2>&1
grep -E '^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;' "$out-tests.txt"
sha256sum -c "$out-executables-before.sha256" > "$out-executables-after.txt"
