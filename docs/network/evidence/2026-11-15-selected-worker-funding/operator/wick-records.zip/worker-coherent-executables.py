from pathlib import Path
import hashlib
import json
import sys

build = Path(sys.argv[1])
out = sys.argv[2]
root = sys.argv[3]
old = b'/var/tmp/sc-direct-flowmux.iptmjZre/verified-runtime-owner-work'
rows = [json.loads(line) for line in build.read_text().splitlines()]
selected = {}
for row in rows:
    if row.get('reason') != 'compiler-artifact' or not row.get('profile', {}).get('test') or not row.get('executable'):
        continue
    path = Path(row['executable'])
    assert row['target']['src_path'].startswith(root + '/'), row
    data = path.read_bytes()
    assert data.startswith(b'\x7fELF'), str(path)
    prior_root_occurrences = data.count(old)
    assert prior_root_occurrences == 0, (str(path), prior_root_occurrences)
    current_root_occurrences = data.count(root.encode())
    if row['target']['name'] == 'mvm_build':
        assert data.count((root + '/crates/mvm-build').encode()) > 0
        assert row['fresh'] is False, row
    selected[str(path)] = {
        'path': str(path), 'target': row['target']['name'],
        'source_path': row['target']['src_path'], 'package_id': row['package_id'],
        'fresh': row['fresh'], 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'prior_root_occurrences': prior_root_occurrences,
        'current_root_occurrences': current_root_occurrences,
    }
assert len(selected) == 284, len(selected)
assert any(row['target'] == 'mvm_build' for row in selected.values())
records = sorted(selected.values(), key=lambda row: row['path'])
Path(out + '-executables-before.json').write_text(json.dumps(records, indent=2) + '\n')
Path(out + '-executables-before.sha256').write_text(''.join(row['sha256'] + '  ' + row['path'] + '\n' for row in records))
print(json.dumps({'test_executables': len(records), 'bytes': sum(row['bytes'] for row in records), 'prior_root_occurrences': 0, 'mvm_build_current_root_verified': True}))
