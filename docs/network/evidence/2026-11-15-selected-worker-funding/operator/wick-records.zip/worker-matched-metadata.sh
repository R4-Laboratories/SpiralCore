#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo"
cd "$q/original-worker-funding-work"
cargo metadata --locked --offline --format-version=1 --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host > "$q/worker-sdk-metadata.json"
cargo metadata --locked --offline --format-version=1 --manifest-path crates/spiralcore-mvm-adapter/Cargo.toml --features live,conformance,hardware-sha256 > "$q/worker-sdk-crates-spiralcore-mvm-adapter-metadata.json"
cargo metadata --locked --offline --format-version=1 --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux > "$q/worker-sdk-tools-installed-flowmux-witness-metadata.json"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/worker-sdk-matched-metadata-after.sha256"
cmp "$q/worker-sdk-metadata-before.sha256" "$q/worker-sdk-matched-metadata-after.sha256"
/bin/bash "$q/worker-graphs.sh"
