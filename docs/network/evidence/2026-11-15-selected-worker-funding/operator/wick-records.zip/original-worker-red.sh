#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/original-worker-red"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/original-worker-test-state"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
umask 0022
ulimit -Sn 4096
ulimit -S -s 8192
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-worker-red.XXXXXX)
mkdir -m 700 -p "$MVM_HOME"
cd "$q/original-worker-funding-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
systemctl --user show sc-original-worker-red -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
rustc -Vv > "$out-toolchain.txt"
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
exe=$(python3 - "$out-build.jsonl" <<'PY'
import json,sys
rows=[json.loads(s) for s in open(sys.argv[1])]
paths=[r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='spiralcore_mvm_live' and r.get('profile',{}).get('test') and r.get('executable')]
assert len(paths)==1,paths
print(paths[0])
PY
)
sha256sum "$exe" > "$out-executable-before.sha256"
set +e
/usr/bin/time -v -o "$out-time.txt" "$exe" installed_parent::config_tests::object_tcp_profile_refuses_unfunded_selected_workers_before_installation_effects --exact --test-threads=1 --nocapture > "$out-tests.txt" 2>&1
rc=$?
set -e
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
cmp "$out-before.sha256" "$out-after.sha256"
printf '%s\n' "$rc" > "$out-exit.txt"
exit "$rc"
