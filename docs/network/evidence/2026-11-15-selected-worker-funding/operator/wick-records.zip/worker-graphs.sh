#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
mkdir -p "$q/worker-final-graphs"
while read -r label raw root; do
  jq -S --arg root "$root" \
    --arg expected_mvm 'git+https://github.com/Casey-allard/mvm?rev=8345cb682ecbc755c7312ba7a5a28c641aa667d0#8345cb682ecbc755c7312ba7a5a28c641aa667d0' \
    --arg expected_core 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' \
    -f "$q/current-owner-final-graph.jq" "$q/$raw" > "$q/worker-final-graphs/$label-after.json"
  cmp "$q/verified-runtime-final-graphs/$label-after.json" "$q/worker-final-graphs/$label-after.json"
  jq --arg comparison 'identical packages, edges and features after exact source-pin validation' \
    '{packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps|length]|add),features:([.nodes[].features|length]|add),comparison:$comparison}' \
    "$q/worker-final-graphs/$label-after.json" > "$q/worker-final-graphs/$label-summary.json"
  printf '%s: identical\n' "$label"
done <<EOF
live worker-sdk-metadata.json $q/original-worker-funding-work
adapter worker-sdk-crates-spiralcore-mvm-adapter-metadata.json $q/original-worker-funding-work
journal worker-sdk-crates-spiralcore-mvm-journal-host-metadata.json $q/original-worker-funding-work
owner worker-sdk-crates-spiralcore-mvm-live-tests-installed-owner-harness-metadata.json $q/original-worker-funding-work
supervisor worker-sdk-crates-spiralcore-mvm-live-tests-installed-supervisor-harness-metadata.json $q/original-worker-funding-work
witness worker-sdk-tools-installed-flowmux-witness-metadata.json $q/original-worker-funding-work
guest worker-sdk-tools-installed-flowmux-witness-guest-metadata.json $q/original-worker-funding-work
mvm worker-mvm-full-metadata.json $q/worker-funding-mvm-work
EOF
