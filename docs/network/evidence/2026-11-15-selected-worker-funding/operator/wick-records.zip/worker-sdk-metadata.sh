#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo"
cd "$q/original-worker-funding-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/worker-sdk-metadata-before.sha256"
cargo metadata --locked --format-version=1 --manifest-path crates/spiralcore-mvm-live/Cargo.toml > "$q/worker-sdk-metadata.json" 2> "$q/worker-sdk-metadata.stderr"
jq -e --arg source 'git+https://github.com/Casey-allard/mvm?rev=8345cb682ecbc755c7312ba7a5a28c641aa667d0#8345cb682ecbc755c7312ba7a5a28c641aa667d0' '
  [.packages[] | select(.source != null and (.source | startswith("git+https://github.com/Casey-allard/mvm?rev=")))] as $mvm |
  ($mvm | length) > 0 and all($mvm[]; .source == $source)
' "$q/worker-sdk-metadata.json" > "$q/worker-sdk-metadata-pin-check.txt"
for manifest in \
  crates/spiralcore-mvm-adapter/Cargo.toml \
  crates/spiralcore-mvm-journal-host/Cargo.toml \
  crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml \
  crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml \
  tools/installed-flowmux-witness/Cargo.toml \
  tools/installed-flowmux-witness/guest/Cargo.toml; do
  name=${manifest%/Cargo.toml}
  name=${name//\//-}
  cargo metadata --locked --offline --format-version=1 --manifest-path "$manifest" > "$q/worker-sdk-$name-metadata.json" 2> "$q/worker-sdk-$name-metadata.stderr"
done
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/worker-sdk-metadata-after.sha256"
cmp "$q/worker-sdk-metadata-before.sha256" "$q/worker-sdk-metadata-after.sha256"
echo WORKER_SDK_LOCKED_METADATA_VERIFIED
