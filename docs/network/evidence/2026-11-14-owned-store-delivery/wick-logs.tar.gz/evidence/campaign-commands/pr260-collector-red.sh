#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
root="$q/pr260-qualification"
export PATH=/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$root/tmp"
cd "$root"
/usr/bin/time -v cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent::collector_tests::collector_partition_draws_shared_credit_without_a_codec_store -- --exact --nocapture > evidence/collector-red.log 2>&1
