#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
root="$q/pr260-qualification"
export PATH=/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$root/tmp"
cd "$root"
run() { local stage=$1; shift; /usr/bin/time -v "$@" > "evidence/$stage.log" 2>&1 || { tail -40 "evidence/$stage.log"; return 1; }; }
run concurrent cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned::tests::checked_walk_holds_four_transient_fds_at_file_verification -- --exact --nocapture
run flowmux-final-strict cargo +1.97.1 clippy --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets --all-features -- -D warnings
run canonical-final-strict cargo +1.97.1 clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings
# Exercise the supported stack profile explicitly; no deadline or guard changes.
ulimit -S -s > evidence/stack-before-kib.txt
ulimit -S -s 8192
ulimit -S -s > evidence/stack-configured-kib.txt
run collector-final cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent::collector_tests:: -- --test-threads=1
sha256sum -c source.sha256 > evidence/source-final-after.txt
