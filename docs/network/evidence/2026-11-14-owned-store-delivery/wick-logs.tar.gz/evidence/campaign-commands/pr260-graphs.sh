#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin CARGO_HOME="$q/source/.mvm-test/cargo"
for target in x86_64-unknown-linux-gnu aarch64-apple-darwin x86_64-pc-windows-msvc; do
 for phase in base candidate; do
  if [ "$phase" = base ]; then root="$q/pr260-graph-base"; else root="$q/pr260-qualification"; fi
  (cd "$root"; cargo +1.97.1 tree --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --target "$target" -e normal,features) > "$q/pr260-qualification/evidence/graph-$target-$phase.txt"
 done
 diff -u "$q/pr260-qualification/evidence/graph-$target-base.txt" "$q/pr260-qualification/evidence/graph-$target-candidate.txt" > "$q/pr260-qualification/evidence/graph-$target.diff" || [ "$?" = 1 ]
done
