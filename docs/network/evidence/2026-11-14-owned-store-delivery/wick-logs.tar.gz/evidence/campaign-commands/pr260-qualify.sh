#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
root="$q/pr260-qualification"
export PATH=/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR="$root/tmp"
mkdir -m700 -p "$TMPDIR" "$root/evidence"
cd "$root"
run() { local stage=$1; shift; /usr/bin/time -v "$@" > "evidence/$stage.log" 2>&1 || { tail -45 "evidence/$stage.log"; return 1; }; tail -5 "evidence/$stage.log"; }
run primitives cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned::tests:: -- --test-threads=1
run public cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store -- --nocapture --test-threads=1
run resources cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store_resources -- --nocapture --test-threads=1
run transfer-strict cargo +1.97.1 clippy --release --locked --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets --all-features -- -D warnings
run flowmux-strict cargo +1.97.1 clippy --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets --all-features -- -D warnings
run parent cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib installed_parent::endpoint_tests:: -- --test-threads=1
run ledger cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml --all-targets -- --test-threads=1
run flowmux cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml -- --test-threads=1
run canonical cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib -- --test-threads=1
run canonical-strict cargo +1.97.1 clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings
run producer cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --example installed_flowmux_fixture -- --nocapture
run fixture-handoff cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --test fixture_native_handoff -- --test-threads=1
run fixture-export cargo +1.97.1 test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --test fixture_export -- --test-threads=1
