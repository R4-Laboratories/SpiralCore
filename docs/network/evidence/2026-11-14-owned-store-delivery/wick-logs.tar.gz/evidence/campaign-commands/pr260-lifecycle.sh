#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
root="$q/pr260-qualification"
export PATH=/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 TMPDIR="$root/tmp"
cd "$root"
/usr/bin/time -v cargo +1.97.1 test --release --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --test ordered_stream -- --exact four_thousand_distinct_blocks_each_direction_keep_exact_bytes_and_bounded_retention --show-output > evidence/lifecycle.log 2>&1
sha256sum -c source.sha256 > evidence/source-lifecycle-after.txt
