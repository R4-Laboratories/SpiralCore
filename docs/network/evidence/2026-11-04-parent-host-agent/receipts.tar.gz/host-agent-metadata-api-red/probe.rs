use spiralcore_mvm_live::installed_parent::InstalledParentProvider;
pub fn check(provider: &InstalledParentProvider) {
    let _ = provider.prepare_owned_host_agent("local");
}
