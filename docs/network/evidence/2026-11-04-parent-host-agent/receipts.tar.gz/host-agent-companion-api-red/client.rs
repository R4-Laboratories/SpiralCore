pub fn probe(backend: &mvm_client::LocalBackend) {
    let _ = backend.install_owned_host_agent(panic!("metadata-only, never executed"));
}
