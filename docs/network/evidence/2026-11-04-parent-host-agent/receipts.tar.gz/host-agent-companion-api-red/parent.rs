pub fn probe() {
    let _ = <dyn mvm_hostd::host_lifetime_parent::ParentAdmissionProvider>::bind_config;
}
