use mvm_core::host_lifetime::HostLifetimeAnchor;
use std::sync::Arc;
pub fn probe(anchor: &HostLifetimeAnchor, original: &Arc<()>) { let _ = anchor.retains_parent_owner(original); }
