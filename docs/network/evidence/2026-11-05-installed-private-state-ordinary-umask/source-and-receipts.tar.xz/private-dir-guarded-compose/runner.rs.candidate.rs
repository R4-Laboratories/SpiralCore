//! The driver-generic workload start mechanics. `WorkloadRunner` spawns the
//! per-VM host-side gating endpoint, maps the admitted config onto a `VmmSpec`,
//! and boots it through the `VmmDriver` seam — once, over the seam, instead of
//! copied into each backend's `start`. The endpoint spawn is itself behind the
//! `NetworkEndpointSpawner` trait so the runner is unit-testable with no real VM and no
//! real endpoint process.

use anyhow::{Context, Result};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant};

use mvm_core::checkpoint::CheckpointId;
use mvm_core::config::{vm_network_endpoint_socket, vm_state_dir, vms_dir};
use mvm_core::crypto::vmgenid::fresh_generation_token;
use mvm_core::plan::{ExecutionPlan, SecretBinding};
use mvm_core::policy::RedactionPolicy;
use mvm_core::policy::network_policy::NetworkPolicy;
use mvm_core::protocol::broker::ServiceId;
use mvm_core::vm_backend::{
    BackendKind, BackendSecurityProfile, GuestChannelInfo, StandbyClaim, StandbyError,
    StandbyHandle, StandbySpec, StartMode, VmBackend, VmCapabilities, VmExitStatus, VmId, VmInfo,
    VmStartConfig, VmStatus,
};
use mvm_fs::snapshot_store::FsSnapshotStore;

use crate::checkpoint::{
    CaptureVmFullParams, CheckpointChainAnchor, CheckpointStore, VmFullControl,
    capture_vm_full_into_snapshot_store, capture_vm_full_to_trusted_snapshot_backend,
    ensure_child_grants_within_parent, materialized_blob_sha256,
};
use crate::driver::{
    ChildForkRequest, PreloadChildRequest, RunningVm, RunningVmStopTiming, StandbyParentSpawn,
    VmmDriver,
};
use crate::standby_pool::SupervisorStandbyPool;
use crate::vm::name_registry::{VmNameRegistry, acquire_registry_lock, generate_vm_name};
use crate::warm_snapshot::{
    is_trusted_snapshot_id, materialize_child_from_parent, materialize_child_from_trusted_parent,
};
use crate::workload_backend::{EgressSubstitutionTransport, WorkloadBackend};
use crate::workload_runner::child_grant::{ChildGrantIssuer, issue_child_grant};
use crate::workload_runner::claim::{
    ClaimGuards, ClaimRefusal, EndpointSpawnInputs, bind_claim_policy_to_plan,
    bind_plan_to_parent_digest, claim_parent_grant_bound, ensure_child_grants_within_host_ceiling,
};
use crate::workload_runner::standby_boot::{factory_parent_config, slotted_factory_parent_spec};
use mvm_vmm::host::cmdline;
use mvm_vmm::host::egress_shared::{decode_plan_secrets_from_state, plan_stream_retention};
use mvm_vmm::host::network_endpoint_spawn::{
    EndpointTransport, SubstitutionSpawnParams, spawn_network_endpoint,
};
use mvm_vmm::host::spec_map::{WorkloadSpecInputs, workload_spec, workload_vsock_ports};
use mvm_vmm::post_restore::{ChildIdentity, PostRestoreOutcome};

fn prepare_state_directory(config: &VmStartConfig) -> Result<PathBuf> {
    let state = vm_state_dir(&config.name);
    #[cfg(unix)]
    if config.host_lifetime.is_some() {
        mvm_core::naming::validate_vm_name(&config.name)?;
        installed::ensure_private_state_directory(&state)
            .context("prepare installed state directory")?;
        return Ok(state);
    }
    std::fs::create_dir_all(&state)
        .with_context(|| format!("create state dir {}", state.display()))?;
    Ok(state)
}

mod admission;
mod backend;
mod broker;
mod claim_lease;
mod cold_hvf_channel;
mod console_boot;
mod durability;
#[cfg(unix)]
mod installed;
#[cfg(unix)]
pub use installed::OwnedRetirement;
#[cfg(all(test, unix))]
mod installed_broker_tests;
#[cfg(all(test, unix))]
mod installed_tests;
mod parent_verify;
mod preload;
mod refusal;
mod sockets;
mod spawner;
mod warm_claim;

pub use cold_hvf_channel::{ColdHvfChannel, NativeCompletion, OwnedRuntimeLaunch};

struct PreparedWorkloadBoot {
    spec: mvm_vmm::driver::spec::VmmSpec,
    socks: sockets::StandingSockets,
    endpoint: Option<crate::workload_runner::claim::EndpointHandle>,
    trace: Option<mvm_core::launch_trace::LaunchTraceRecorder>,
}

use admission::{admitted_ingress, admitted_network_limits, admitted_tool_rules};
pub use broker::RealBrokerRegistrar;
use claim_lease::WarmClaimLease;
use parent_verify::{reserve_and_verify_parent, schedule_resident_checkpoint_reclaim};
use refusal::{
    admitted_seccomp_tier, refuse, require_admitted_seccomp_tier, require_fresh_child_identity,
    require_late_volumes_mounted,
};
use sockets::standing_sockets;
#[cfg(unix)]
pub use spawner::InstalledSpawnedEndpoint;
pub use spawner::{
    FlowMuxIdentitySource, NetworkEndpointSpawnRequest, NetworkEndpointSpawner,
    RealNetworkEndpointSpawner, SpawnedEndpoint, TelemetryStart,
};
/// What the runner needs to register the per-VM host-services broker after boot.
pub struct BrokerRegisterRequest<'a> {
    /// VM name — the registration's `vm_id`, workload id, and per-VM chain key.
    pub vm_name: &'a str,
    /// Per-VM state dir (audit-signer pid/sock + the daemon tenant-ref marker).
    pub state_dir: &'a Path,
    /// Tenant from the admitted plan. `None` ⇒ unadmitted ⇒ a defused no-op:
    /// no broker services and no BROKER_PORT in the spec, so a stray guest dial
    /// stays `ECONNREFUSED` (fail-closed).
    pub tenant: Option<&'a str>,
    /// The `BROKER_PORT` socket the broker/daemon binds — the same path the spec
    /// wires the guest's `BROKER_PORT` relay to. `None` on the unadmitted path.
    pub broker_listen_socket: Option<&'a Path>,
    /// Host services from the admitted plan. Empty means no broker process is
    /// needed and every broker call remains fail-closed.
    pub services: &'a [ServiceId],
    /// Exact typed capabilities carried by admitted extension bindings.
    pub capability_bindings: &'a [mvm_contract::protocol::agent_capability::CapabilityBinding],
    /// Controller-backed typed services prepared by the admitting process.
    pub service_proxies: &'a [mvm_contract::protocol::broker_control::ServiceProxyBinding],
}

/// Register/spawn the per-VM host-services broker for an admitted workload,
/// returning a guard whose Drop reaps until defused. The claims-12/13 seam:
/// Admitted host services reach the guest over `BROKER_PORT`. Behind a trait so
/// the runner is unit-testable with no real broker subprocess.
pub trait BrokerRegistrar: Send + Sync {
    fn register(&self, req: &BrokerRegisterRequest<'_>) -> Result<BrokerGuard>;
    /// Installed launches must use the original resident helper. Unsupported
    /// implementations never fall back to legacy registration or discovery.
    #[cfg(unix)]
    fn register_installed(
        &self,
        _req: &BrokerRegisterRequest<'_>,
        _original: &mvm_vmm::host::host_agent_spawn::OwnedHostAgentRegistrar,
    ) -> Result<BrokerGuard> {
        anyhow::bail!("installed broker registration unsupported")
    }
}

/// RAII guard around the registered broker services: Drop reaps them until the
/// VM is confirmed up and `defuse`d (the `stop` path then owns teardown). Wraps
/// the existing `ServicesGuard` so no reaping logic is duplicated.
pub struct BrokerGuard(BrokerCustody);

enum BrokerCustody {
    Legacy(mvm_vmm::host::host_agent_spawn::ServicesGuard),
    #[cfg(unix)]
    Installed(Arc<mvm_vmm::host::host_agent_spawn::OwnedVmRegistration>),
}

impl BrokerGuard {
    pub(crate) fn from_services_guard(
        guard: mvm_vmm::host::host_agent_spawn::ServicesGuard,
    ) -> Self {
        Self(BrokerCustody::Legacy(guard))
    }

    /// A guard that reaps nothing on drop — the unadmitted / spawn-failed path.
    fn defused() -> Self {
        Self::from_services_guard(mvm_vmm::host::host_agent_spawn::ServicesGuard::None)
    }

    #[cfg(unix)]
    fn from_owned_registration(
        guard: mvm_vmm::host::host_agent_spawn::OwnedVmRegistration,
    ) -> Self {
        Self(BrokerCustody::Installed(Arc::new(guard)))
    }

    /// Legacy disarm only. Installed registration always retains its original
    /// signed cleanup owner, including if a compatibility caller invokes this.
    pub fn defuse(&mut self) {
        match &mut self.0 {
            BrokerCustody::Legacy(guard) => guard.defuse(),
            #[cfg(unix)]
            BrokerCustody::Installed(_) => {}
        }
    }

    fn shutdown_owned(&mut self) -> Result<()> {
        match &mut self.0 {
            BrokerCustody::Legacy(mvm_vmm::host::host_agent_spawn::ServicesGuard::None) => Ok(()),
            #[cfg(unix)]
            BrokerCustody::Installed(guard) => Arc::get_mut(guard)
                .context("original broker observation in progress; registration retained")?
                .shutdown(),
            _ => anyhow::bail!(
                "original broker cleanup confirmation unavailable; installed owner retained"
            ),
        }
    }

    /// Whether the launch came up with the host services it asked for.
    ///
    /// The guard alone cannot answer this. It records only whether anything was
    /// registered, which is the same `false` for a workload that bound no
    /// service as for one whose registration was skipped — `requested` is what
    /// separates them. Judging on the guard alone marks every workload that
    /// binds no host service as degraded, and a degraded launch is refused as a
    /// sample of a healthy one.
    #[must_use]
    pub fn services_healthy(&self, requested: &[ServiceId]) -> bool {
        requested.is_empty()
            || match &self.0 {
                BrokerCustody::Legacy(guard) => guard.is_registered(),
                #[cfg(unix)]
                BrokerCustody::Installed(_) => true,
            }
    }
}

pub use super::console_stream::{ConsoleCapture, ConsoleStreamer, NoopConsoleStreamer};
/// Everything the runner needs to start a workload: the admitted launch config,
/// its tenant/secrets/redaction/policy, and the kernel cmdline the role above
/// assembled.
pub struct WorkloadLaunchInputs<'a> {
    pub config: &'a VmStartConfig,
    pub tenant: &'a str,
    pub secrets: &'a [SecretBinding],
    pub redaction: &'a RedactionPolicy,
    pub network_policy: &'a NetworkPolicy,
    pub cmdline: String,
}

/// The warm-pool substrate a claim needs beyond the runner's cold-boot fields.
/// Cold boot never carries it, so it is a per-claim context rather than a runner
/// field: the standby pool, the content-addressed checkpoint + snapshot stores,
/// the signed-audit anchor, and the parent's identity a guarded fork consumes.
/// Everything a claim materializes or verifies is reached through here, so a
/// runner constructed for cold boot alone stays unchanged.
pub struct ClaimContext<'a> {
    /// Standby pool the parent is reserved in (marked `Claimed` under the lock).
    pub pool: &'a SupervisorStandbyPool,
    /// Content-addressed checkpoint store the parent + its lineage live in.
    pub checkpoints: &'a CheckpointStore,
    /// Snapshot store backing the O(1) copy-on-write child materialize.
    pub snapshots: &'a FsSnapshotStore,
    /// Resolves each checkpoint's signature-verified creation digest for saved-
    /// state claims. Resident HVF claims use their signed snapshot manifest and
    /// do not load the growing audit chain on the launch path.
    pub anchor: &'a dyn CheckpointChainAnchor,
    /// The content-addressed checkpoint the standby parent was captured as.
    pub parent_checkpoint: &'a CheckpointId,
    /// VM name registry file whose sibling lock serializes the parent reserve
    /// and the child-name mint, so two claims never double-claim one parent.
    pub registry_path: &'a Path,
    /// Host signing authority invoked only after the runner has minted the
    /// final child identity. Grant-less test contexts may omit it; a plan that
    /// requests agent verbs fails closed when it is absent.
    pub grant_issuer: Option<&'a dyn ChildGrantIssuer>,
}

/// The warm-pool substrate a spawn-and-capture needs beyond the runner's
/// cold-boot fields: the checkpoint store the parent is captured into, and the
/// launch whose boot shape the parent must mirror.
pub struct SpawnContext<'a> {
    /// Content-addressed checkpoint store the captured parent is written to.
    pub checkpoints: &'a CheckpointStore,
    /// The already-resolved launch config the parent is being warmed for — the
    /// same value the workload boot consumes, so the parent inherits whatever
    /// the layer above resolved for it (notably the verity-sealed runtime
    /// overlay carrying the guest agent). `None` when the caller is warming the
    /// pool ahead of any launch, which the spawn refuses: a parent has no boot
    /// shape of its own to fall back on.
    pub launch: Option<&'a VmStartConfig>,
}

/// Verified publication inputs used to prepare a paused child during pool
/// refill. The parent has already been audited by the caller, so this context
/// can perform the same content and lineage checks as a claim before cloning.
pub struct PreloadContext<'a> {
    /// Content-addressed checkpoint store containing the captured parent.
    pub checkpoints: &'a CheckpointStore,
    /// Snapshot store backing the copy-on-write child materialization.
    pub snapshots: &'a FsSnapshotStore,
    /// Signed audit anchor for the parent's creation entry.
    pub anchor: &'a dyn CheckpointChainAnchor,
    /// VM-name registry lock source used to avoid colliding with user VMs.
    pub registry_path: &'a Path,
}

/// Starts workloads over the `VmmDriver` seam: spawn the per-VM gating endpoint,
/// map the config to a `VmmSpec`, boot via the driver.
pub struct WorkloadRunner<D: VmmDriver, S: NetworkEndpointSpawner, B: BrokerRegistrar> {
    driver: D,
    spawner: S,
    broker: B,
    console_streamer: Arc<dyn ConsoleStreamer>,
    #[cfg(unix)]
    installed: installed::InstalledSlots,
    #[cfg(unix)]
    installed_agent: std::sync::OnceLock<mvm_vmm::host::host_agent_spawn::OwnedHostAgentRegistrar>,
}

/// Timings for the shared workload-runner stop sequence.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct StopTiming {
    /// Time to reconstruct the live driver handle.
    pub attach: Duration,
    /// Time to reap host-side endpoint and service processes.
    pub endpoint_reaping: Duration,
    /// Time spent in the backend driver termination operation.
    pub driver_kill: Duration,
    /// Time to stop console streaming for the VM.
    pub console_cleanup: Duration,
    /// Total elapsed time for the complete stop sequence.
    pub total: Duration,
    /// Backend-specific detail, when the driver can observe its termination
    /// phases. HVF reports supervisor and PID-file teardown here.
    pub driver_detail: Option<RunningVmStopTiming>,
}

/// Append one kernel-cmdline token, space-separated only when the cmdline is
/// already non-empty: a token on an empty cmdline must not carry a leading
/// space, which the guest's `/init` would read as an empty argument.
fn append_cmdline_token(boot_cmdline: &mut String, token: &str) {
    if !boot_cmdline.is_empty() {
        boot_cmdline.push(' ');
    }
    boot_cmdline.push_str(token);
}

/// Backend-shaped guest→host channel for the GPU endpoint. QEMU's vhost-vsock
/// lets the endpoint bind the real port directly; every other tier proxies the
/// guest dial to a per-VM UDS. A free function so both `WorkloadRunner` and the
/// unit tests name the same binding decision.
fn gpu_endpoint_transport(
    kind: mvm_core::vm_backend::BackendKind,
    state_dir: &std::path::Path,
) -> mvm_vmm::host::network_endpoint_spawn::EndpointTransport {
    use mvm_vmm::host::network_endpoint_spawn::EndpointTransport;
    if kind == mvm_core::vm_backend::BackendKind::Qemu {
        EndpointTransport::Vsock {
            port: mvm_agentd::vsock::GPU_PORT,
        }
    } else {
        EndpointTransport::Uds {
            path: mvm_core::config::vm_vsock_port_socket_at(state_dir, mvm_agentd::vsock::GPU_PORT),
        }
    }
}

/// The trusted-snapshot backend is opt-in: only the exact value `1` enables it.
fn trusted_snapshot_opted_in(value: Option<&str>) -> bool {
    value == Some("1")
}

impl<D: VmmDriver, S: NetworkEndpointSpawner, B: BrokerRegistrar> WorkloadRunner<D, S, B> {
    /// Build a runner over the process's registered console-streaming hook.
    ///
    /// Every production construction site goes through here and none of them
    /// passes a streamer, so picking the hook up from the process registration
    /// is what makes console capture reach all four backends at once — see
    /// [`console_stream`](super::console_stream) for why the wiring is a
    /// registration rather than an argument.
    pub fn new(driver: D, spawner: S, broker: B) -> Self {
        Self {
            driver,
            spawner,
            broker,
            console_streamer: super::console_stream::active_console_streamer(),
            #[cfg(unix)]
            installed: installed::InstalledSlots::default(),
            #[cfg(unix)]
            installed_agent: std::sync::OnceLock::new(),
        }
    }

    /// Install the original resident helper before installed workload launch.
    /// This retains its typed custody; it never discovers/spawns by socket path.
    #[cfg(unix)]
    pub fn install_owned_host_agent(
        &self,
        registrar: mvm_vmm::host::host_agent_spawn::OwnedHostAgentRegistrar,
    ) -> Result<()> {
        anyhow::ensure!(
            !self.installed.has_any()?,
            "installed workload already retained"
        );
        self.installed_agent
            .set(registrar)
            .map_err(|_| anyhow::anyhow!("original installed host agent already configured"))
    }

    /// Override the console-streaming hook for this runner alone, ignoring
    /// whatever the process registered. The seam a test drives its own double
    /// through; production wires the real streamer once at startup instead.
    #[must_use]
    pub fn with_console_streamer(mut self, streamer: Arc<dyn ConsoleStreamer>) -> Self {
        self.console_streamer = streamer;
        self
    }

    /// Whether this runner can keep a saved child VMM paused across claims.
    #[must_use]
    pub fn supports_preloaded_standby(&self) -> bool {
        self.driver.supports_preloaded_standby()
    }

    #[cfg(unix)]
    pub fn supports_host_lifetime(&self) -> bool {
        self.driver.supports_host_lifetime()
    }

    /// How many read-only volumes a claim on this runner's parents can attach.
    #[must_use]
    pub fn late_volume_slots(&self) -> u8 {
        self.driver.late_volume_slots()
    }

    /// Pause/save-memory/resume control over a running VM this runner's VMM
    /// owns — what a checkpoint capture drives. `None` when the VMM has no
    /// memory-capture mechanics to offer.
    #[must_use]
    pub fn vm_full_control(&self, vm_name: &str) -> Option<Box<dyn VmFullControl>> {
        self.driver.vm_full_control(vm_name)
    }

    /// Backend-shaped guest→host channel for the GPU endpoint. QEMU's
    /// vhost-vsock lets the endpoint bind the real port directly; every other
    /// tier proxies the guest dial to a per-VM UDS.
    fn gpu_endpoint_transport(
        kind: mvm_core::vm_backend::BackendKind,
        state_dir: &std::path::Path,
    ) -> mvm_vmm::host::network_endpoint_spawn::EndpointTransport {
        gpu_endpoint_transport(kind, state_dir)
    }

    /// Spawn the optional gating endpoint, compose the spec, and boot. A
    /// secret-free deny-all workload has no egress capability and therefore
    /// carries no endpoint process or guest egress channel.
    pub fn start_workload(&self, inputs: &WorkloadLaunchInputs<'_>) -> Result<Box<dyn RunningVm>> {
        self.start_workload_custodied(inputs, Vec::new())
    }

    /// Start with original writable-image custody, consumed only at final binding.
    pub fn start_workload_custodied(
        &self,
        inputs: &WorkloadLaunchInputs<'_>,
        writable_images: mvm_vmm::driver::prepared_disks::WritableVolumeImages,
    ) -> Result<Box<dyn RunningVm>> {
        if cmdline::uses_installed_payload_anchor(inputs.config) {
            anyhow::ensure!(
                mvm_agentd::vsock::host_signer_pub_token(&inputs.cmdline).is_none(),
                "installed workload cmdline contains an unbound host signer anchor"
            );
        }
        self.require_caller_registration_shape(inputs.config)?;
        #[cfg(unix)]
        if let Some(owner) = &inputs.config.host_lifetime {
            owner.verify_config(inputs.config, self.driver.kind())?;
        }
        let lifecycle =
            crate::runtime_evidence::RuntimeLifecycleLease::acquire(&inputs.config.name)?;
        #[cfg(unix)]
        let installed = match &inputs.config.host_lifetime {
            Some(owner) => {
                prepare_state_directory(inputs.config)?;
                Some(self.installed.reserve(owner)?)
            }
            None => None,
        };
        #[cfg(unix)]
        let startup_workspace = inputs
            .config
            .host_lifetime
            .as_ref()
            .map(|owner| owner.begin_startup_workspace(inputs.config, self.driver.kind()))
            .transpose()?;
        #[cfg(unix)]
        if let Some(owner) = &inputs.config.host_lifetime {
            installed::refuse_unowned(&VmId(inputs.config.name.clone()))?;
            mvm_core::util::atomic_io::write_private_new(
                &installed::marker(&VmId(inputs.config.name.clone())),
                &serde_json::to_vec(owner.binding())?,
            )?;
        }
        anyhow::ensure!(
            !crate::kernel_custody::has_retained_kernel(&lifecycle)?,
            "canonical kernel lifetime for this VM is still unresolved"
        );
        let bound_config = lifecycle.bind(inputs.config)?;
        let kernel_binding = crate::kernel_custody::KernelBoundLaunch::bind(
            bound_config,
            self.driver.kind(),
            &lifecycle,
        )?;
        let bound_config = kernel_binding.config();
        let bound_cmdline = if bound_config.runtime_release_proof.is_some()
            || bound_config.unsigned_runtime_development
        {
            cmdline::runner_cmdline(
                bound_config,
                &vm_state_dir(&bound_config.name),
                |has_disk| self.driver.workload_base_bootargs(has_disk),
            )
        } else {
            inputs.cmdline.clone()
        };
        let inputs = &WorkloadLaunchInputs {
            config: bound_config,
            tenant: inputs.tenant,
            secrets: inputs.secrets,
            redaction: inputs.redaction,
            network_policy: inputs.network_policy,
            cmdline: bound_cmdline,
        };
        let result = (|| {
            #[cfg(unix)]
            if let Some(workspace) = startup_workspace {
                workspace.complete()?;
            }
            self.boot_bound_workload_guarded(inputs, Some(&kernel_binding), writable_images)
        })();
        #[cfg(unix)]
        if let Some(slot) = installed {
            slot.retain_launch(lifecycle, kernel_binding)?;
            return match result {
                Ok(vm) => Ok(vm),
                Err(error) => {
                    let message = format!("installed native startup retained: {error:#}");
                    slot.retain_failure(error)?;
                    anyhow::bail!(message)
                }
            };
        }
        result.map_err(|error| {
            cold_hvf_channel::retain_boot_error(error, (lifecycle, kernel_binding))
        })
    }

    /// Maps an already-bound configuration into a backend boot. Production
    /// callers must hold the lifecycle lease and pass the verifier's paths.
    #[cfg(test)]
    fn boot_bound_workload(&self, inputs: &WorkloadLaunchInputs<'_>) -> Result<Box<dyn RunningVm>> {
        self.boot_bound_workload_guarded(inputs, None, Vec::new())
    }

    fn require_caller_registration_shape(&self, config: &VmStartConfig) -> Result<()> {
        if config.caller_registration.is_some() {
            anyhow::ensure!(
                self.driver.kind() == mvm_core::vm_backend::BackendKind::Hvf,
                "caller registration requires a cold HVF workload"
            );
            let plan = config
                .plan_json
                .as_deref()
                .context("caller registration requires a signed plan")?;
            serde_json::from_str::<mvm_core::plan::SignedExecutionPlan>(plan)
                .context("caller registration requires a signed plan")?;
        }
        Ok(())
    }

    /// Prepare the same policy, endpoint and device mapping for both ordinary
    /// boots and the concrete owned cold channel.
    fn prepare_workload_boot(
        &self,
        inputs: &WorkloadLaunchInputs<'_>,
    ) -> Result<PreparedWorkloadBoot> {
        // A caller times this call from outside and cannot see past it, yet the
        // VMM boot and every post-boot registration happen in here. Off unless
        // a measurement asked for it.
        let mut trace =
            mvm_core::launch_trace::LaunchTraceRecorder::new(self.driver.kind().as_str());
        let installed_anchor = cmdline::uses_installed_payload_anchor(inputs.config);
        if installed_anchor {
            anyhow::ensure!(
                mvm_agentd::vsock::host_signer_pub_token(&inputs.cmdline).is_none(),
                "installed workload cmdline contains an unbound host signer anchor"
            );
        }

        #[cfg(unix)]
        let installed = if let Some(owner) = &inputs.config.host_lifetime {
            let slot = self
                .installed
                .find(&VmId(inputs.config.name.clone()))?
                .context("original installed slot missing")?;
            anyhow::ensure!(slot.matches(owner), "installed launch owner differs");
            self.installed_agent
                .get()
                .context("original installed host agent missing")?
                .check_current_for_tenant(inputs.tenant)?;
            Some(slot)
        } else {
            None
        };

        let state_dir = prepare_state_directory(inputs.config)?;
        crate::base::runtime_meta::record_from_start_config(
            &inputs.config.name,
            StartMode::Detached,
            inputs.config,
        )?;
        let network_limits = admitted_network_limits(inputs.config.plan_json.as_deref())?;
        let ingress = admitted_ingress(inputs.config.plan_json.as_deref())?;
        let tools = admitted_tool_rules(inputs.config.plan_json.as_deref())?;

        // Required telemetry peer/signing authority must already be registered
        // when its endpoint is provisioned. Retain the exact signed guard in
        // the original slot before any endpoint or backend effect can fail.
        #[cfg(unix)]
        if let Some(slot) = &installed {
            let socks = standing_sockets(&state_dir, inputs.config);
            let (broker, services) = self.register_workload_broker(inputs.config, &socks)?;
            trace.degrade_unless("host_services", broker.services_healthy(&services));
            slot.retain_broker(broker)?;
            trace.mark("broker_register");
        }

        // Spawn the per-child substitution endpoint through the shared
        // `ClaimGuards`, so a warm claim stands up the identical guarded endpoint
        // a cold boot does, keyed on this VM's own id. A deny-all, secret-free
        // workload receives no egress channel and therefore needs no process.
        let guards = ClaimGuards::new(&self.spawner);
        let endpoint_inputs = EndpointSpawnInputs {
            state_dir: &state_dir,
            admitted_plan_json: inputs.config.plan_json.as_deref(),
            tenant: inputs.tenant,
            secrets: inputs.secrets,
            redaction: inputs.redaction,
            tools: &tools,
            network_policy: inputs.network_policy,
            network_limits,
            ingress: &ingress,
            // A cold boot mints this guest's identity and hands it a drive.
            identity: FlowMuxIdentitySource::Mint,
        };
        #[cfg(unix)]
        let endpoint = if inputs.config.host_lifetime.is_some() {
            let slot = installed
                .as_ref()
                .context("original installed slot missing")?;
            // Clone only the observation while holding the short custody lock;
            // all freshness/filesystem/endpoint I/O runs after that lock drops.
            let registration = slot.broker_registration()?;
            let registrar = self
                .installed_agent
                .get()
                .context("original installed host agent missing")?;
            let socks = standing_sockets(&state_dir, inputs.config);
            let (services, capability_bindings) =
                admitted_broker_bindings(inputs.config.plan_json.as_deref())?;
            let original = mvm_vmm::host::network_endpoint_spawn::InstalledHostServices::new(
                registrar,
                &registration,
                mvm_vmm::host::host_agent_spawn::HostAgentServicesParams {
                    workload_id: &inputs.config.name,
                    tenant_id: inputs.config.tenant_id.as_deref(),
                    vm_name: &inputs.config.name,
                    state_dir: &state_dir,
                    broker_listen_socket: socks
                        .broker
                        .as_deref()
                        .context("installed broker socket missing")?,
                    services: &services,
                    capability_bindings: &capability_bindings,
                    service_proxies: &inputs.config.service_proxies,
                },
            )?;
            guards.spawn_endpoint_installed(
                &VmId(inputs.config.name.clone()),
                &endpoint_inputs,
                inputs.config,
                &original,
            )?
        } else {
            guards.spawn_endpoint(&VmId(inputs.config.name.clone()), &endpoint_inputs)?
        };
        #[cfg(not(unix))]
        let endpoint =
            guards.spawn_endpoint(&VmId(inputs.config.name.clone()), &endpoint_inputs)?;
        #[cfg(unix)]
        let (endpoint, installed_paths) = if let Some(slot) = &installed {
            let paths = (
                endpoint.egress_uds().map(Path::to_owned),
                endpoint.identity_drive().map(Path::to_owned),
                endpoint.host_anchor,
            );
            let telemetry = endpoint.owned_telemetry_provisioned();
            slot.retain_endpoint(endpoint)?;
            if telemetry {
                mvm_vmm::host::telemetry_provisioning::record_installed_boot_provisioning(
                    &state_dir,
                )
                .context("publish original installed telemetry boot marker")?;
            }
            (None, Some(paths))
        } else {
            (Some(endpoint), None)
        };
        #[cfg(not(unix))]
        let (endpoint, installed_paths) = (
            Some(endpoint),
            None::<(Option<PathBuf>, Option<PathBuf>, Option<[u8; 32]>)>,
        );
        trace.mark("endpoint_spawn");

        let mut boot_cmdline = inputs.cmdline.clone();
        if installed_anchor {
            let anchor = installed_paths
                .as_ref()
                .and_then(|(_, _, anchor)| anchor.as_ref())
                .context("original installed endpoint host anchor missing")?;
            append_cmdline_token(
                &mut boot_cmdline,
                &mvm_vmm::host::egress_bridge::host_signer_pub_cmdline_token_for_key(anchor),
            );
        }
        if let Some(token) =
            mvm_vmm::host::egress_bridge::telemetry_cmdline_token(&inputs.config.name)
        {
            append_cmdline_token(&mut boot_cmdline, &token);
        }
        if let Some(problem) = cmdline::cmdline_overflow(&boot_cmdline) {
            anyhow::bail!("refusing to start VM {}: {problem}", inputs.config.name);
        }

        // A GPU launch gets its host endpoint before the spec is assembled:
        // the channel the guest dials must already have a listener, and the
        // socket path the endpoint bound is by construction the one
        // `standing_sockets` resolves for the spec.
        if inputs.config.gpu {
            let gpu_transport = Self::gpu_endpoint_transport(self.driver.kind(), &state_dir);
            mvm_vmm::host::gpu_endpoint_spawn::spawn_gpu_endpoint(
                &inputs.config.name,
                &state_dir,
                gpu_transport,
                inputs.config.gpu_device,
            )
            .context("spawning the GPU endpoint")?;
        }
        let socks = standing_sockets(&state_dir, inputs.config);
        let (egress_uds, identity_drive) = if let Some((egress, identity, _)) = &installed_paths {
            (egress.as_deref(), identity.as_deref())
        } else {
            let endpoint = endpoint.as_ref().context("prepared endpoint missing")?;
            (endpoint.egress_uds(), endpoint.identity_drive())
        };
        let spec = workload_spec(&WorkloadSpecInputs {
            config: inputs.config,
            identity_drive,
            sockets: socks.with_egress(egress_uds),
            cmdline: boot_cmdline,
            console_log: socks.console_log.clone(),
        });

        trace.mark("spec_assembly");

        Ok(PreparedWorkloadBoot {
            spec,
            socks,
            endpoint,
            trace: Some(trace),
        })
    }

    /// Maps an already-bound configuration into a backend boot. Production
    /// callers must hold the lifecycle lease and pass the verifier's paths.
    fn boot_bound_workload_guarded(
        &self,
        inputs: &WorkloadLaunchInputs<'_>,
        kernel: Option<&crate::kernel_custody::KernelBoundLaunch>,
        writable_images: mvm_vmm::driver::prepared_disks::WritableVolumeImages,
    ) -> Result<Box<dyn RunningVm>> {
        anyhow::ensure!(
            (inputs.config.canonical_kernel.is_none()
                && inputs.config.kernel_read_sha256.is_none())
                || kernel.is_some(),
            "canonical kernel launch has no actual final-config custody guard"
        );
        if let Some(kernel) = kernel {
            anyhow::ensure!(
                std::ptr::eq(inputs.config, kernel.config()),
                "launch substituted the final config object"
            );
        }
        let PreparedWorkloadBoot {
            spec,
            socks,
            mut endpoint,
            trace,
        } = self.prepare_workload_boot(inputs)?;
        #[cfg(unix)]
        let installed = if inputs.config.host_lifetime.is_some() {
            Some(
                self.installed
                    .find(&VmId(inputs.config.name.clone()))?
                    .context("original installed slot missing")?,
            )
        } else {
            None
        };
        let mut trace = trace.context("prepared workload launch trace missing")?;
        let state_dir = vm_state_dir(&inputs.config.name);
        // Unconditional and best-effort. The follower can wait for a console
        // file that does not exist yet, so install it alongside VMM boot rather
        // than serializing its process setup after guest readiness.
        let capture = ConsoleCapture {
            vm_name: &inputs.config.name,
            supervisor_owned: supervisor_owns_console(self.driver.kind()),
            console_log: &socks.console_log,
            display_socket: socks.display.as_deref(),
            redaction: inputs.redaction,
            retention: plan_stream_retention(inputs.config.plan_json.as_deref()),
        };
        durability::wait_for_unactivated_boot(inputs.config)?;
        if let Some(kernel) = kernel {
            kernel.before_boot(&spec)?;
        }
        let streamer = Arc::clone(&self.console_streamer);
        #[cfg(unix)]
        let disks = mvm_vmm::driver::prepared_disks::PreparedWritableDisks::bind_sources(
            &spec,
            writable_images,
        )?;
        let boot = console_boot::boot_while_starting_console(
            || {
                #[cfg(unix)]
                {
                    match kernel {
                        Some(kernel) => kernel.boot_custodied(&self.driver, &spec, disks),
                        None => {
                            disks.validate_spec(&spec)?;
                            self.driver.boot_custodied(&spec, None, disks)
                        }
                    }
                }
                #[cfg(not(unix))]
                {
                    match kernel {
                        Some(kernel) => kernel.boot(&self.driver, &spec),
                        None => self.driver.boot(&spec),
                    }
                }
            },
            || streamer.start(&capture),
            || trace.mark("driver_boot"),
        );
        let vm = match boot {
            Ok(vm) => vm,
            Err(error) => {
                return Err(cold_hvf_channel::retain_boot_error(
                    error,
                    (endpoint, Arc::clone(&self.console_streamer)),
                ));
            }
        };
        #[cfg(unix)]
        let vm = if let Some(slot) = &installed {
            slot.retain_vm(vm)?
        } else {
            vm
        };
        if let Some(kernel) = kernel {
            kernel.observe_booted(&*vm)?;
        }
        trace.mark("console_stream_start");

        // Universal initramfs path: the guest PID-1 agent waits for a signed
        // ActivateEnvironment before exposing operational RPCs. Send it now,
        // while the broker registration below still has a guard that rolls back
        // on failure. A rootfs boot whose universal initramfs could not be
        // resolved was refused at launch resolution, before the VMM started.
        if crate::microvm::booted_with_universal_initramfs(inputs.config) {
            durability::wait_for_activation(inputs.config, &*vm, &*self.console_streamer)?;
            #[cfg(unix)]
            if let Some(owner) = &inputs.config.host_lifetime {
                owner.check_parent_current(inputs.config, self.driver.kind())?;
            }
            trace.mark("admission_durable");
            crate::microvm::activate_workload(&*vm, inputs.config)
                .context("activate workload after boot")?;
        }
        trace.mark("activate_workload");

        // Register the per-VM broker for the exact admitted host-service set.
        // The guard's Drop reaps on any early return until it is defused. A
        // requested service whose broker cannot start fails the launch closed.
        #[cfg(unix)]
        if installed.is_some() {
            trace.write_to(&state_dir);
            return Ok(vm);
        }
        let (mut broker_guard, services) = self.register_workload_broker(inputs.config, &socks)?;
        trace.mark("broker_register");
        trace.degrade_unless("host_services", broker_guard.services_healthy(&services));
        endpoint
            .as_mut()
            .context("legacy endpoint missing")?
            .defuse();
        broker_guard.defuse();
        trace.write_to(&state_dir);
        Ok(vm)
    }

    fn register_workload_broker(
        &self,
        config: &VmStartConfig,
        socks: &sockets::StandingSockets,
    ) -> Result<(BrokerGuard, Vec<ServiceId>)> {
        let state_dir = vm_state_dir(&config.name);
        let (services, capability_bindings) =
            admitted_broker_bindings(config.plan_json.as_deref())?;
        let request = BrokerRegisterRequest {
            vm_name: &config.name,
            state_dir: &state_dir,
            tenant: config.tenant_id.as_deref(),
            broker_listen_socket: socks.broker.as_deref(),
            services: &services,
            capability_bindings: &capability_bindings,
            service_proxies: &config.service_proxies,
        };
        #[cfg(unix)]
        let guard = if config.host_lifetime.is_some() {
            self.register_installed_workload_broker(&request)?
        } else {
            self.broker.register(&request)?
        };
        #[cfg(not(unix))]
        let guard = self.broker.register(&request)?;
        Ok((guard, services))
    }

    #[cfg(unix)]
    fn register_installed_workload_broker(
        &self,
        request: &BrokerRegisterRequest<'_>,
    ) -> Result<BrokerGuard> {
        let original = self
            .installed_agent
            .get()
            .context("original installed host agent missing")?;
        let tenant = request.tenant.context("installed tenant missing")?;
        original.check_current_for_tenant(tenant)?;
        self.broker.register_installed(request, original)
    }

    /// Fork a clean standby parent into a fresh, admitted child, gated exactly as
    /// strictly as a cold boot — the guarded heart of the warm pool.
    ///
    /// Runs the fail-closed sequence in order, cloning or booting nothing until
    /// every gate passes: reserve the parent atomically and verify its sealed
    /// content + signed-audit lineage; bind the already-admitted plan's image
    /// digest to that verified parent (so the audit-recorded plan describes
    /// exactly what boots); mint a fresh, registry-unique identity; materialize
    /// the child's rootfs from the parent's own verified content; run the
    /// host-side overlay-contract gate, spawn the child's own 0700 substitution
    /// endpoint keyed on its fresh id, resolve its host channel set and register
    /// its host-services broker; then fork the VMM, start following its console
    /// (the only channel that would show a hang or panic inside the handshake
    /// window that follows), and require the restored guest to prove it adopted
    /// a fresh VMGenID before the claim commits, so the child's CSPRNG diverges
    /// from the parent's.
    ///
    /// The host-side plumbing is deliberately all on the near side of the fork.
    /// A cold boot has a kernel boot between wiring its channels and the guest
    /// dialing them; a restore has nothing — the guest comes back already booted
    /// and runs the moment the fork resumes it. Anything wired afterwards would
    /// be wired against a guest already dialing sockets that do not exist.
    ///
    /// Layering the runner does NOT own (enforced at their own layers, mirroring
    /// a cold boot): claim-8 admission of the child plan (CLI mint + supervisor
    /// re-verify at attach), dm-verity inherit (CLI populates the child config),
    /// per-service confinement (guest init, inherited via the post-init parent
    /// snapshot), and the `plan.launched` chain emit (the CLI audit layer, which
    /// owns the host signer). The runner receives the admitted plan and the
    /// verity-populated config in `claim` and consumes them.
    pub fn claim_standby(
        &self,
        ctx: &ClaimContext<'_>,
        handle: &StandbyHandle,
        claim: &StandbyClaim,
    ) -> std::result::Result<VmId, StandbyError> {
        if claim
            .start_config
            .as_ref()
            .is_some_and(|config| config.caller_registration.is_some())
        {
            return Err(StandbyError::ClaimFailed(
                "caller registration requires cold launch; caller-authenticated warm handoff is unavailable".into(),
            ));
        }
        use std::io::Write;

        let claim_started = Instant::now();
        let mut claim_debug = mvm_vmm::agent_debug::open();
        macro_rules! claim_phase {
            ($phase:expr) => {
                warm_claim::record_phase(claim_started, &mut claim_debug, $phase);
            };
        }
        let resident_handoff = self.driver.supports_resident_handoff();
        // (1) Reserve the parent atomically, then verify it — before any clone.
        // Resident HVF claims use the signed bundle manifest as their O(1)
        // publication witness; saved-state claims retain full content hashing.
        let parent = reserve_and_verify_parent(ctx, handle, resident_handoff)?;
        claim_phase!("parent_verified");

        // The parent is now reserved (`Claimed`) and verified healthy. Arm the
        // release-unless-committed guard: any early return past this point returns
        // the good parent to claimable (so a failed claim never strands warm
        // capacity) and removes a partial child dir. Only a booted child commits.
        let preloaded_child_name = handle.preloaded_child_vm_name.clone();
        let mut cleanup = WarmClaimLease::new(ctx.pool, handle.id.as_str(), &self.driver);
        if parent.class != mvm_core::checkpoint::CheckpointClass::VmFull {
            return Err(StandbyError::ClaimFailed(
                "warm memory restore requires a vm_full checkpoint".into(),
            ));
        }
        let runtime_verified = if let Some(name) = &preloaded_child_name {
            verify_preloaded_child_name_is_available(ctx, name)?;
            crate::checkpoint::verify_checkpoint_runtime_at(
                ctx.checkpoints,
                &parent,
                &vm_state_dir(name),
            )
        } else {
            crate::checkpoint::verify_checkpoint_runtime(ctx.checkpoints, &parent)
        };
        runtime_verified.map_err(|error| {
            StandbyError::ClaimFailed(format!("verify paused runtime: {error:#}"))
        })?;
        crate::runtime_evidence::verify_runtime_for_claim(
            parent.runtime_launch_binding.as_ref(),
            claim.start_config.as_ref(),
        )
        .map_err(|error| {
            StandbyError::ClaimFailed(format!("verify inherited runtime: {error:#}"))
        })?;

        // (2) + (4) Bind the admitted plan's image digest to the verified parent.
        // A missing plan or a digest mismatch refuses before any child side effect.
        let plan = claim_plan(claim)?;
        let parent_image_sha256 =
            materialized_blob_sha256(ctx.checkpoints, &parent, mvm_core::checkpoint::ROOTFS_BLOB)
                .map_err(|_| refuse(ClaimRefusal::ParentTampered))?;
        bind_plan_to_parent_digest(&plan.image.sha256, &parent_image_sha256).map_err(refuse)?;
        // The same comparison a vm_full fork makes, against the same
        // chain-verified parent record and through the same predicate. A warm
        // claim restores a child out of a parent's saved memory exactly as a
        // fork does, so it must not be the one restore path where a child can
        // ask for more than its parent held. Placed beside the image-digest
        // bind — both bind the admitted plan to this verified parent — and
        // before the child gets an identity, a state dir, or any bytes.
        let parent_bound = claim_parent_grant_bound(
            parent.grants.as_ref(),
            handle.vsock_egress,
            plan.grants.as_ref(),
        );
        ensure_child_grants_within_parent(plan.grants.as_ref(), parent_bound.as_ref()).map_err(
            |e| {
                refuse(ClaimRefusal::GrantsExceedParent {
                    reason: e.to_string(),
                })
            },
        )?;
        // The policy this claim installs in the child's endpoint below must be
        // the one the child's own signed plan recorded — never the parent's,
        // which booted with none, and never one supplied beside the plan.
        bind_claim_policy_to_plan(&plan.asset_identities, &claim.network_policy).map_err(refuse)?;
        // A standby parent carries no grant, so the comparison above has
        // nothing to bind a claimed child's CPU share against and would admit
        // any share at all. The host's own ceiling is what bounds it instead —
        // the same operator-configured maximum every cold boot on this host
        // clears, read from host config rather than from the plan being
        // admitted. It is a host-wide maximum and not a pool-specific grant, so
        // it bounds a claim no more tightly than it bounds anything else here;
        // it is only stronger than the unbounded claim it replaces.
        //
        // Deliberately after the parent has been matched and reserved rather
        // than part of the pool's compatibility key: keying on a grant value
        // would split one pool into a pool per distinct share and cost the warm
        // hit rate the pool exists for. The price is a claim that matches and is
        // then refused, so the refusal names the ceiling and the request.
        ensure_child_grants_within_host_ceiling(
            plan.grants.as_ref(),
            &mvm_core::user_config::load(None).grant_ceiling(),
        )
        .map_err(refuse)?;

        // (6a) Fresh, registry-unique identity for the child.
        let child = match preloaded_child_name.clone() {
            Some(name) => {
                verify_preloaded_child_name_is_available(ctx, &name)?;
                VmId(name)
            }
            None => fresh_child_id(ctx)?,
        };
        let child_dir = vm_state_dir(&child.0);
        // Track it before creating or materializing anything so even a partial
        // claim is cleaned up.
        cleanup.track_child_dir(child_dir.clone());
        if preloaded_child_name.is_some() {
            cleanup.track_preloaded_child(child.0.clone());
        }

        // (3) A resident handoff transfers the already-paused HVF machine and
        // creates only the fresh child state directory. Saved-state backends
        // still materialize the verified parent content before restoring.
        let child_rootfs_dir = if resident_handoff {
            std::fs::create_dir_all(&child_dir).map_err(|e| {
                StandbyError::ClaimFailed(format!(
                    "create resident HVF child state {}: {e:#}",
                    child_dir.display()
                ))
            })?;
            warm_claim::resident_parent_rootfs_dir(handle.id.as_str())?
        } else if preloaded_child_name.is_some() {
            child_dir.clone()
        } else {
            let materialize =
                if is_trusted_snapshot_id(parent.snapshot_id.as_deref().unwrap_or_default()) {
                    let backend = mvm_fs::trusted_snapshot::platform_backend(ctx.snapshots.root())
                        .map_err(|e| {
                            StandbyError::ClaimFailed(format!(
                                "open trusted snapshot backend: {e:#}"
                            ))
                        })?;
                    materialize_child_from_trusted_parent(
                        ctx.checkpoints,
                        backend.as_ref(),
                        ctx.parent_checkpoint,
                        ctx.anchor,
                        &child_dir,
                    )
                } else {
                    materialize_child_from_parent(
                        ctx.checkpoints,
                        ctx.snapshots,
                        ctx.parent_checkpoint,
                        ctx.anchor,
                        &child_dir,
                    )
                };
            materialize.map_err(|e| {
                StandbyError::ClaimFailed(format!("materialize child rootfs: {e:#}"))
            })?;
            claim_phase!("child_materialized");
            child_dir.clone()
        };
        if resident_handoff {
            claim_phase!("resident_handoff_ready");
        }

        // (8) The runner-side host gates a cold boot runs, before the child boots:
        // the overlay contract, then the child's own 0700 substitution endpoint
        // keyed on its fresh id (never a sibling's; the factory parent has none).
        let mut child_cfg = child_start_config(claim, &child, &child_rootfs_dir);
        if let Some(binding) = &parent.runtime_launch_binding {
            // The parent record and these retained bytes were verified above.
            // A restored child inherits the parent's generation, not cache paths.
            binding.apply_to_config(&mut child_cfg);
        }
        // Recorded before the fork, as a cold boot records before it boots, so
        // a step checkpoint of the claimed child resolves its own rootfs and
        // the device paths its restored VMM names. A resident handoff keeps the
        // parent's live machine and has no materialized copy of its own to
        // describe; its record stays with the parent's.
        if !resident_handoff {
            warm_claim::record_claimed_child_runtime_meta(&child, &child_cfg, &child_dir)?;
        }
        // The launch's read-only volumes go behind the late-volume slots the
        // parent booted, and the guest is told to mount them before the claim
        // commits. A launch with none attaches nothing.
        let late_volumes = if child_cfg.volumes.is_empty() {
            Vec::new()
        } else {
            mvm_vmm::host::late_volumes::attachments(&child_cfg, self.driver.late_volume_slots())
                .map_err(|e| StandbyError::ClaimFailed(format!("late volumes: {e:#}")))?
        };
        let late_volume_configs = crate::microvm::activation::build_volume_configs(&child_cfg)
            .map_err(|e| StandbyError::ClaimFailed(format!("late volumes: {e:#}")))?;
        let guards = ClaimGuards::new(&self.spawner);
        // Gate the image the claim was admitted for, not the clone the child
        // boots: the sidecar describes how the image was built and is not part
        // of the captured snapshot, so it exists only beside the image.
        guards
            .admit_overlay_contract(std::path::Path::new(&claim.rootfs_path))
            .map_err(|e| StandbyError::ClaimFailed(format!("overlay contract: {e:#}")))?;

        let grant_envelope = issue_child_grant(&plan, &child_cfg, ctx.grant_issuer)
            .map_err(|e| StandbyError::ClaimFailed(format!("issue child verb grant: {e:#}")))?;

        let secrets =
            mvm_core::plan::secrets_from_signed_json(&claim.plan_json).unwrap_or_default();
        let redaction =
            mvm_core::plan::redaction_from_signed_json(&claim.plan_json).unwrap_or_default();
        let network_limits = plan
            .effective_network_limits()
            .map_err(|e| StandbyError::ClaimFailed(format!("network limits: {e:#}")))?;
        let ingress = plan.ingress.clone();
        if let Some(file) = claim_debug.as_mut() {
            let _ = writeln!(
                file,
                "[warm-claim] inputs allows_egress={} secrets={}",
                claim.network_policy.allows_egress(),
                secrets.len()
            );
        }
        let parent_state_dir = vm_state_dir(handle.id.as_str());
        let mut endpoint = guards
            .spawn_endpoint(
                &child,
                &EndpointSpawnInputs {
                    state_dir: &child_dir,
                    admitted_plan_json: Some(claim.plan_json.as_str()),
                    tenant: claim.tenant_id.as_str(),
                    secrets: &secrets,
                    redaction: &redaction,
                    tools: &plan.tools,
                    network_policy: &claim.network_policy,
                    network_limits,
                    ingress: &ingress,
                    // A restored child already holds its parent's signing key
                    // in the memory image it woke from, and there is no way to
                    // put a different one there. Its endpoint pins what the
                    // guest actually has.
                    identity: FlowMuxIdentitySource::InheritFrom(&parent_state_dir),
                },
            )
            .map_err(|e| StandbyError::ClaimFailed(format!("spawn child endpoint: {e:#}")))?;
        claim_phase!("endpoint_ready");

        // The child's host channel set, resolved under its own state dir and
        // mapped through the one mapper a cold boot's set comes from. The fork
        // wires these before it resumes the child; a restored guest is already
        // booted, so it dials the instant its vCPUs run.
        let socks = standing_sockets(&child_dir, &child_cfg);
        let channels = workload_vsock_ports(&socks.with_egress(endpoint.egress_uds()));

        // Register the child's exact admitted host-service set before the fork,
        // because the restored guest can dial `BROKER_PORT` immediately. Any
        // registration failure refuses the claim; the guard reaps until commit.
        let child_capabilities: Vec<_> = plan
            .extensions
            .iter()
            .flat_map(|extension| extension.capabilities.iter().cloned())
            .collect();
        let mut broker_guard = self
            .broker
            .register(&BrokerRegisterRequest {
                vm_name: &child.0,
                state_dir: &child_dir,
                tenant: child_cfg.tenant_id.as_deref(),
                broker_listen_socket: socks.broker.as_deref(),
                services: &plan.services,
                capability_bindings: &child_capabilities,
                service_proxies: &child_cfg.service_proxies,
            })
            .map_err(|e| StandbyError::ClaimFailed(format!("register child broker: {e:#}")))?;
        claim_phase!("broker_registered");

        // (6b) Mint a fresh VMGenID bound to the child's content-address and fork
        // the VMM. A fork restores a running guest out of the parent's saved
        // memory, so the child comes back holding the parent's CSPRNG state and
        // the parent's wall clock — nothing is scrubbed yet at this point.
        let content_hash =
            materialized_blob_sha256(ctx.checkpoints, &parent, mvm_core::checkpoint::ROOTFS_BLOB)
                .map_err(|_| refuse(ClaimRefusal::ParentTampered))?;
        let genid = fresh_generation_token(content_hash);
        let token = genid.token;
        let runtime_digest = crate::checkpoint::metadata_blob_sha256(
            ctx.checkpoints,
            &parent,
            "runtime-artifacts.json",
        )
        .map_err(|_| refuse(ClaimRefusal::ParentTampered))?;
        let anchors_digest = crate::checkpoint::metadata_blob_sha256(
            ctx.checkpoints,
            &parent,
            "device-anchors.json",
        )
        .map_err(|_| refuse(ClaimRefusal::ParentTampered))?;
        let fork_request = ChildForkRequest {
            child_vm_name: &child.0,
            child_dir: &child_dir,
            runtime_artifacts_sha256: Some(&runtime_digest),
            device_anchors_sha256: Some(&anchors_digest),
            // A resident HVF claim addresses the paused parent by its stable
            // pool identity. Saved-state drivers receive no parent name and
            // restore from the materialized child directory instead.
            parent_vm_name: resident_handoff.then_some(handle.id.as_str()),
            genid,
            channels: &channels,
            // Straight off the admitted plan — the value the subset comparison
            // above cleared. Taking it from `child_cfg` instead would take it
            // from a start config the claim supplied, which is not what was
            // checked.
            cpu_grant: plan.grants.as_ref().and_then(|grants| grants.cpu),
            // The same admitted plan `claim_plan` decoded the bindings above
            // from, so the bounds the child's owner arms are the ones checked.
            admitted_plan: Some(&claim.plan_json),
            late_volumes: &late_volumes,
        };
        let forked = if preloaded_child_name.is_some() {
            self.driver.resume_preloaded_child(&fork_request)
        } else {
            self.driver.fork_standby_child(&fork_request)
        };
        if let Err(StandbyError::Unrestorable(reason)) = &forked {
            tracing::warn!(
                parent = %handle.id,
                %reason,
                "dropping a standby parent this host cannot restore"
            );
            cleanup.quarantine();
        }
        forked?;
        claim_phase!("child_forked");

        // Unconditional and best-effort, mirroring `start_workload`: started
        // the moment the restored guest is live, before the fallible
        // post-restore handshake below. A cold boot has a kernel boot to
        // blame a silent hang on; a fork has none — the guest is already
        // running the instant the fork resumes it — so the handshake window
        // this call precedes is the one place a restore can wedge or panic
        // with nothing else to show why.
        self.console_streamer.start(&ConsoleCapture {
            vm_name: &child.0,
            supervisor_owned: supervisor_owns_console(self.driver.kind()),
            console_log: &socks.console_log,
            display_socket: socks.display.as_deref(),
            redaction: &redaction,
            retention: plan_stream_retention(child_cfg.plan_json.as_deref()),
        });

        // (7) Close that window before the claim commits: deliver the token to
        // the now-reachable guest and make it prove, on its own report, that it
        // rotated its generation identity and took the host's clock. Two children
        // of one parent that skipped this would draw identical randomness, which
        // is the whole reason a warm child needs a fresh identity — so a child
        // that cannot prove it is never admitted.
        //
        // The same answer admits the child's seccomp tier. The parent booted
        // with no plan and so holds none; the tier comes from the plan this
        // claim was admitted under, and the guest must report holding exactly
        // that tier before the claim commits and any workload process starts.
        let identity = ChildIdentity {
            token,
            grant_envelope,
            seccomp_tier: Some(admitted_seccomp_tier(&plan)),
            volumes: late_volume_configs,
        };
        if let Err(refusal) = self.take_fresh_child_identity(&child.0, identity) {
            // The child is live and still carrying its parent's random state.
            // Unwinding alone would leave running exactly the VM this refusal
            // exists to prevent, so stop it before returning. `force_stop`
            // only tears down the VMM, not the console follower this claim
            // started above and `VmBackend::stop` never runs for a name that
            // is refused here and never becomes live state, so this is the
            // one place responsible for reaping it — after the teardown, so
            // whatever the refused child prints as it dies is in the record
            // of why it was refused.
            self.force_stop(&child.0, "refused forked standby child");
            self.console_streamer.stop(&child.0);
            return Err(refusal);
        }
        claim_phase!("identity_verified");

        // The child booted and proved a fresh identity: disarm the endpoint and
        // broker reapers (the stop path owns them now) and commit — the parent
        // stays reserved and the child dir is real state.
        endpoint.defuse();
        broker_guard.defuse();
        cleanup.commit();
        if resident_handoff {
            schedule_resident_checkpoint_reclaim(ctx, &parent);
        }
        Ok(child)
    }

    /// Deliver `token` to the forked child's guest agent and judge what it
    /// reports. The driver owns the transport; the verdict is the claim's.
    fn take_fresh_child_identity(
        &self,
        child_vm_name: &str,
        identity: ChildIdentity,
    ) -> std::result::Result<(), StandbyError> {
        let requested_tier = identity.seccomp_tier;
        let requested_volumes = identity.volumes.len();
        let outcome = self
            .driver
            .deliver_child_identity(child_vm_name, identity)
            .map_err(|e| {
                StandbyError::ClaimFailed(format!(
                    "forked child '{child_vm_name}' never answered the post-restore identity \
                     handshake: {e:#}; a guest agent too old to take the claim's seccomp tier \
                     refuses this handshake, and the claim is refused rather than run \
                     unfiltered — `mvmctl bootstrap` refreshes the guest runtime"
                ))
            })?;
        require_fresh_child_identity(child_vm_name, &outcome)?;
        require_admitted_seccomp_tier(child_vm_name, requested_tier, &outcome)?;
        require_late_volumes_mounted(child_vm_name, requested_volumes, &outcome)
    }

    /// Boot a standby parent, capture its whole live state, and release it.
    ///
    /// The parent's boot inputs are derived here, from the launch it will
    /// serve, through the same mappers `start_workload` uses — a factory parent
    /// boots the device model and boot-shape cmdline a workload boots, minus
    /// the claim-time hostname and host channels a workload is entitled to and
    /// it is not. That is not a
    /// nicety: a child is restored out of the parent's saved memory and
    /// inherits both, so a parent assembled by a second recipe hands every
    /// child whatever that recipe got wrong.
    ///
    /// The driver boots those inputs and supplies the backend-specific control;
    /// capturing a live VM's memory is backend-agnostic, so it lives here rather
    /// than in any one driver. The captured checkpoint is what a later claim
    /// verifies content and lineage against.
    ///
    /// A factory parent gets no substitution endpoint and no broker: those are
    /// workload-only steps (`ClaimGuards::spawn_endpoint`, `BrokerRegistrar`,
    /// both reached from `start_workload` and neither reachable from here), and
    /// [`factory_parent_config`] drops every field that could carry workload
    /// authority into the parent's launch config in the first place.
    pub fn spawn_standby_captured(
        &self,
        ctx: &SpawnContext<'_>,
        spec: &StandbySpec,
    ) -> std::result::Result<StandbyHandle, StandbyError>
    where
        D: 'static,
    {
        let launch = ctx.launch.ok_or_else(|| {
            StandbyError::SpawnFailed(format!(
                "standby '{}' has no launch config to mirror: a warm parent boots the same \
                 device model and boot-shape kernel cmdline a workload does, so it cannot be assembled \
                 without the launch it will serve",
                spec.id
            ))
        })?;
        let started = Instant::now();
        let parent_config = factory_parent_config(launch, spec)?;
        let lifecycle = crate::runtime_evidence::RuntimeLifecycleLease::acquire(&spec.id)
            .map_err(|e| StandbyError::SpawnFailed(format!("lock runtime lifecycle: {e:#}")))?;
        warm_claim::record_standby_phase(started, "lease", "acquired");
        let parent_config = lifecycle.bind(&parent_config).map_err(|e| {
            StandbyError::SpawnFailed(format!("bind standby runtime artifacts: {e:#}"))
        })?;
        warm_claim::record_standby_phase(started, "lease", "bound");
        let result = match (&self.driver as &dyn std::any::Any)
            .downcast_ref::<mvm_backends::driver::hvf::HvfDriver>()
        {
            Some(driver) => {
                self.spawn_bound_standby_captured_using(ctx, spec, &parent_config, |request| {
                    driver.spawn_standby_parent_owned(request)
                })
            }
            None => self
                .spawn_bound_standby_captured(ctx, spec, &parent_config)
                .map_err(anyhow::Error::new),
        };
        result.map_err(|error| {
            cold_hvf_channel::standby_compatibility_error(cold_hvf_channel::retain_boot_error(
                error,
                (lifecycle, parent_config),
            ))
        })
    }

    /// Maps an already-bound parent while its caller holds the lifecycle lease.
    fn spawn_bound_standby_captured(
        &self,
        ctx: &SpawnContext<'_>,
        spec: &StandbySpec,
        parent_config: &VmStartConfig,
    ) -> std::result::Result<StandbyHandle, StandbyError> {
        self.spawn_bound_standby_captured_using(ctx, spec, parent_config, |request| {
            self.driver
                .spawn_standby_parent(request)
                .map_err(anyhow::Error::new)
        })
        .map_err(cold_hvf_channel::standby_compatibility_error)
    }

    fn spawn_bound_standby_captured_using(
        &self,
        ctx: &SpawnContext<'_>,
        spec: &StandbySpec,
        parent_config: &VmStartConfig,
        launch: impl FnOnce(&StandbyParentSpawn<'_>) -> Result<StandbyHandle>,
    ) -> Result<StandbyHandle> {
        let started = Instant::now();
        let state_dir = PathBuf::from(&spec.vm_state_dir);

        // Written before boot, exactly as `start` does for a workload, so a
        // capture against this parent resolves its rootfs and boot contract the
        // same way every runner-launched VM's does.
        crate::base::runtime_meta::record_from_start_config(
            &spec.id,
            StartMode::Detached,
            parent_config,
        )
        .map_err(|e| {
            StandbyError::SpawnFailed(format!(
                "recording standby parent '{}' runtime metadata: {e:#}",
                spec.id
            ))
        })?;

        let slots = self.driver.late_volume_slots();
        mvm_vmm::host::late_volumes::ensure_placeholders(&state_dir, slots).map_err(|e| {
            StandbyError::SpawnFailed(format!(
                "creating standby '{}' late-volume placeholders: {e:#}",
                spec.id
            ))
        })?;
        let mut boot = slotted_factory_parent_spec(
            parent_config,
            &state_dir,
            |has_disk| self.driver.workload_base_bootargs(has_disk),
            slots,
        );
        let identity = spawner::prepare_standby_identity(&self.spawner, spec)?;
        spawner::assert_standby_telemetry(&state_dir, &mut boot.cmdline);
        // The same truncation refusal a workload boot gets, for the same reason
        // and then some: a child inherits its parent's cmdline out of restored
        // memory rather than deriving its own, so a parent whose trailing tokens
        // the kernel silently dropped hands that loss to every child it produces.
        if let Some(problem) = cmdline::cmdline_overflow(&boot.cmdline) {
            return Err(StandbyError::SpawnFailed(format!(
                "refusing to boot standby parent '{}': {problem}",
                spec.id
            ))
            .into());
        }
        let boot = mvm_vmm::host::spec_map::with_identity_drive(boot, identity.as_deref());
        warm_claim::record_standby_phase(started, "boot", "spec_ready");
        let mut handle = launch(&StandbyParentSpawn { spec, boot: &boot })?;
        warm_claim::record_standby_phase(started, "boot", "parent_booted");

        // The universal initramfs waits in a fail-closed pre-activation state.
        // Capturing it there would make every restored child refuse PostRestore
        // and fall back to a cold boot. The parent shares only its rootfs device
        // and verity environment; factory_parent_config has already removed all
        // workload identity, secrets, plan, and grant authority.
        if crate::microvm::booted_with_universal_initramfs(parent_config) {
            let parent = self.driver.attach(&VmId(spec.id.clone())).map_err(|e| {
                StandbyError::SpawnFailed(format!(
                    "attach standby parent '{}' for activation: {e:#}",
                    spec.id
                ))
            })?;
            crate::microvm::activate_workload(parent.as_ref(), parent_config).map_err(|e| {
                StandbyError::SpawnFailed(format!(
                    "activate standby parent '{}' before capture: {e:#}",
                    spec.id
                ))
            })?;
        }
        warm_claim::record_standby_phase(started, "boot", "parent_activated");

        let control = self.driver.vm_full_control(&spec.id).ok_or_else(|| {
            StandbyError::SpawnFailed(format!(
                "backend cannot capture a warm parent's memory for standby '{}'",
                spec.id
            ))
        })?;
        let retain_parent = control.retain_paused_after_capture();
        let snapshots = FsSnapshotStore::new(mvm_core::config::snapshots_dir())
            .map_err(|e| StandbyError::SpawnFailed(format!("open snapshot store: {e:#}")))?;

        let capture_params = CaptureVmFullParams {
            id: CheckpointId::new(format!("standby-{}", spec.id)),
            vm_name: spec.id.clone(),
            supervisor_config_digest: String::new(),
            runtime_overlay_version: None,
            runtime_launch_binding: crate::base::runtime_meta::read(&spec.id)
                .map_err(|e| {
                    StandbyError::SpawnFailed(format!("read bound standby runtime metadata: {e:#}"))
                })?
                .and_then(|meta| meta.runtime_launch_binding),
            // Firecracker keeps no supervisor-config blob; its presence is
            // what marks a checkpoint as originating from a backend that does.
            supervisor_config_src: control.supervisor_config_path().map_err(|e| {
                StandbyError::SpawnFailed(format!("resolve standby supervisor config: {e:#}"))
            })?,
            tag: None,
            created_unix: mvm_core::time::now_unix_secs(),
            retain_paused: true,
            // A decision, not an omission. A factory parent holds no plan and
            // no tenant by construction — `factory_parent_config` drops
            // `plan_json` and `cpu_grant` precisely so a parent cannot carry a
            // grant admitted for some other workload, and one parent serves
            // every later claim against this pool. Sealing the mirrored
            // launch's grant here would bind all of them to whichever workload
            // happened to provision the pool.
            //
            // Sealing nothing is not the same as checking nothing: the claim
            // path still compares, and an absent parent grant is deny-all
            // egress, so a claimed child asking to reach anywhere is refused.
            // It leaves CPU and wall clock unbounded by the *parent*; those are
            // bounded for a warm child by the host ceiling its own plan was
            // admitted against, never by this record.
            grants: None,
            // A factory parent has no workspace: it is booted before any
            // workload, with no user volume attached.
            parent: None,
            session: None,
            workspace_volumes: Vec::new(),
            key_domain: mvm_core::checkpoint::CheckpointKeyDomain::host(),
        };
        let trusted_backend = if cfg!(all(feature = "trusted-apfs", target_os = "macos"))
            && trusted_snapshot_opted_in(
                std::env::var("MVM_HVF_ENABLE_TRUSTED_SNAPSHOT")
                    .ok()
                    .as_deref(),
            ) {
            Some(
                mvm_fs::trusted_snapshot::platform_backend(snapshots.root()).map_err(|e| {
                    StandbyError::SpawnFailed(format!("open trusted snapshot backend: {e:#}"))
                })?,
            )
        } else {
            None
        };
        let captured = if let Some(backend) = trusted_backend.as_deref() {
            capture_vm_full_to_trusted_snapshot_backend(
                ctx.checkpoints,
                capture_params,
                control.as_ref(),
                backend,
            )
        } else {
            capture_vm_full_into_snapshot_store(
                ctx.checkpoints,
                capture_params,
                control.as_ref(),
                &snapshots,
            )
        };

        warm_claim::record_standby_phase(started, "capture", "captured");

        // Saved-state backends release the source after capture because the
        // checkpoint is their claim resource. The HVF live-handoff backend
        // deliberately retains its paused supervisor: the checkpoint is an
        // integrity witness, while the resident parent remains the sole owner
        // of the HVF machine and its interrupt-controller state. A failed
        // capture never leaves that source resident.
        if captured.is_err() || !retain_parent {
            self.force_stop(&spec.id, "captured standby parent");
        }

        warm_claim::record_standby_phase(started, "capture", "source_released");
        let meta = captured
            .map_err(|e| StandbyError::SpawnFailed(format!("capture standby parent: {e:#}")))?;

        // Saved-state backends have no live process after capture and use pid=0
        // as their persisted sentinel. A retained HVF parent keeps its real pid
        // so claims can verify and address the resident supervisor.
        if !retain_parent {
            handle.pid = 0;
        }
        handle.parent_checkpoint = Some(meta.id.as_str().to_string());
        Ok(handle)
    }

    /// Force-stop a VM the warm-pool path is done with, naming its `role` for the
    /// log. Failure is logged, never propagated: the callers are already on their
    /// way out (a captured parent, a refused child) and have nothing better to do
    /// about it, but a VM that outlives its owner must stay visible.
    fn force_stop(&self, vm_name: &str, role: &str) {
        let id = VmId(vm_name.to_string());
        match self.driver.attach(&id).and_then(|vm| vm.kill()) {
            Ok(()) => {}
            Err(e) => tracing::warn!(
                vm = vm_name,
                role,
                error = %e,
                "stopping a warm-pool VM failed; it may still be running"
            ),
        }
    }
}

/// The admitted plan from the claim.
/// The runner does not re-verify the signature — the host admitted the plan and
/// the supervisor re-verifies at attach. The runner reads the image binding and
/// child-grant fields it must enforce. A claim carrying no parseable plan fails
/// closed.
fn claim_plan(claim: &StandbyClaim) -> std::result::Result<ExecutionPlan, StandbyError> {
    mvm_core::plan::plan_from_admitted_json(&claim.plan_json)
        .map_err(|_| refuse(ClaimRefusal::PlanMissing))
}

fn admitted_broker_bindings(
    plan_json: Option<&str>,
) -> Result<(
    Vec<ServiceId>,
    Vec<mvm_contract::protocol::agent_capability::CapabilityBinding>,
)> {
    plan_json
        .map(mvm_core::plan::plan_from_admitted_json)
        .transpose()
        .context("parse admitted plan host services")
        .map(|plan| {
            plan.map_or_else(
                || (Vec::new(), Vec::new()),
                |plan| {
                    let capabilities = plan
                        .extensions
                        .iter()
                        .flat_map(|extension| extension.capabilities.iter().cloned())
                        .collect();
                    (plan.services, capabilities)
                },
            )
        })
}

/// How many times to redraw a fresh child name before giving up. A collision is
/// astronomically unlikely (random suffix), so a small bound is a fail-closed
/// backstop, never a hot loop.
const MAX_CHILD_NAME_ATTEMPTS: usize = 8;

/// Mint a fresh child [`VmId`] that collides with no existing VM registration.
/// The name is a fresh random id (never the parent's), which — with the fresh
/// VMGenID and per-child endpoint — is the identity scrub that stops a fork from
/// inheriting the parent's identity. Uniqueness comes from the random suffix
/// checked against the registry, not from mutual exclusion: the registry lock
/// only serializes the read (nothing is persisted under it here — the boot path
/// registers the name), so two truly-concurrent claims rely on the ~2^64 suffix
/// space to not collide, which is what makes a re-check-and-redraw a backstop
/// rather than a race.
fn fresh_child_id(ctx: &ClaimContext<'_>) -> std::result::Result<VmId, StandbyError> {
    let _lock = acquire_registry_lock(ctx.registry_path)
        .map_err(|e| StandbyError::ClaimFailed(format!("acquire registry lock: {e:#}")))?;
    let registry = VmNameRegistry::load(ctx.registry_path)
        .map_err(|e| StandbyError::ClaimFailed(format!("load vm registry: {e:#}")))?;
    for _ in 0..MAX_CHILD_NAME_ATTEMPTS {
        let name = generate_vm_name();
        if registry.lookup(&name).is_none() {
            return Ok(VmId(name));
        }
    }
    Err(StandbyError::ClaimFailed(
        "could not mint a registry-unique child name".into(),
    ))
}

/// Recheck a preloaded child's registry identity immediately before claim-side
/// authority is created. The preload name was collision-checked when the pool
/// record was written, but another VM may have registered the same random name
/// before a later process claimed the persisted record.
fn verify_preloaded_child_name_is_available(
    ctx: &ClaimContext<'_>,
    child_name: &str,
) -> std::result::Result<(), StandbyError> {
    let _lock = acquire_registry_lock(ctx.registry_path)
        .map_err(|e| StandbyError::ClaimFailed(format!("acquire registry lock: {e:#}")))?;
    let registry = VmNameRegistry::load(ctx.registry_path)
        .map_err(|e| StandbyError::ClaimFailed(format!("load vm registry: {e:#}")))?;
    if registry.lookup(child_name).is_some() {
        return Err(StandbyError::ClaimFailed(format!(
            "preloaded child name '{child_name}' is already registered"
        )));
    }
    Ok(())
}
/// The child's launch config: the CLI-populated claim config (carrying the
/// verity fields the CLI already resolved on the cloned rootfs) rekeyed onto the
/// fresh child identity and its materialized rootfs. The runner consumes verity;
/// it never derives it.
fn child_start_config(claim: &StandbyClaim, child: &VmId, rootfs_dir: &Path) -> VmStartConfig {
    let mut cfg = claim.start_config.clone().unwrap_or_default();
    cfg.name = child.0.clone();
    cfg.rootfs_path = rootfs_dir
        .join("rootfs.ext4")
        .to_string_lossy()
        .into_owned();
    cfg.tenant_id = Some(claim.tenant_id.clone());
    cfg.network_policy = claim.network_policy.clone();
    cfg.plan_json = Some(claim.plan_json.clone());
    cfg.bundle_json = claim.bundle_json.clone();
    cfg
}

/// Whether the backend's own supervisor holds the console capture for the
/// VM's whole life, so the launcher must not start a competing writer.
///
/// Only the HVF supervisor owns capture today. Every other backend leaves it
/// to the launcher's follower.
fn supervisor_owns_console(kind: mvm_core::vm_backend::BackendKind) -> bool {
    kind == mvm_core::vm_backend::BackendKind::Hvf
}

#[cfg(test)]
mod tests {
    #[test]
    fn trusted_snapshot_requires_the_exact_opt_in_value() {
        assert!(trusted_snapshot_opted_in(Some("1")));
        assert!(!trusted_snapshot_opted_in(Some("0")));
        assert!(!trusted_snapshot_opted_in(Some("")));
        assert!(!trusted_snapshot_opted_in(None));
    }

    use super::parent_verify::{
        reclaim_consumed_resident_checkpoint_at, verify_resident_snapshot_manifest,
    };
    use super::*;
    use std::collections::HashMap;
    use std::sync::Mutex;

    use mvm_agentd::vsock::{BROKER_PORT, EGRESS_PORT, GUEST_AGENT_PORT};
    use mvm_core::checkpoint::CheckpointMeta;
    use mvm_core::plan::{Nonce, SecretBinding, SecretSource, VerbGrant, VerbId};
    use mvm_core::policy::network_policy::HostPort;
    use mvm_core::protocol::vm_backend::VerbGrantEnvelope;
    use mvm_core::util::test_env::TestEnv;
    use mvm_fs::snapshot_store::SnapshotStore;

    use crate::backends::hvf::HvfDriver;
    use crate::driver::MockDriver;
    use crate::workload_runner::standby_boot::factory_parent_spec;

    fn without_per_boot_tokens(cmdline: &str) -> String {
        cmdline
            .split_whitespace()
            .filter(|token| {
                !token.starts_with("mvm.hostname=") && !token.starts_with("mvm.hostepoch=")
            })
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// An `NetworkEndpointSpawner` test double: records the request it was handed and
    /// returns a canned UDS without spawning any process. `Mutex` (not `RefCell`)
    /// so it satisfies the `Send + Sync` a `VmBackend` spawner must be.
    struct RecordingSpawner {
        uds: PathBuf,
        seen: Mutex<Option<Recorded>>,
    }

    struct Recorded {
        mints_identity: bool,
        tenant: String,
        secrets_len: usize,
        policy: NetworkPolicy,
        network_limits: mvm_core::plan::NetworkLimits,
    }

    impl RecordingSpawner {
        fn new(uds: &str) -> Self {
            Self {
                uds: PathBuf::from(uds),
                seen: Mutex::new(None),
            }
        }
    }

    impl NetworkEndpointSpawner for RecordingSpawner {
        fn prepare_identity(
            &self,
            req: &NetworkEndpointSpawnRequest<'_>,
        ) -> Result<Option<PathBuf>> {
            // The real spawner clears any stale provisioning marker here, so a
            // re-used state dir never asserts a previous boot's telemetry.
            let _ = mvm_vmm::host::telemetry_provisioning::record_boot_provisioning(
                req.state_dir,
                false,
            );
            if !matches!(req.identity, FlowMuxIdentitySource::Mint) {
                return Ok(None);
            }
            std::fs::create_dir_all(req.state_dir)?;
            let path = req
                .state_dir
                .join(mvm_vmm::host::flowmux_identity::IDENTITY_DRIVE_FILE);
            std::fs::write(&path, b"mock-identity-drive")?;
            Ok(Some(path))
        }

        fn start_telemetry_without_endpoint(
            &self,
            req: &NetworkEndpointSpawnRequest<'_>,
        ) -> TelemetryStart {
            // Recorded now because the guest's cmdline is built from the
            // marker; the double itself starts no collector process.
            let provisioned = spawner::telemetry_for_boot(
                mvm_vmm::host::telemetry_provisioning::telemetry_collection_enabled(),
                req.identity,
            );
            if provisioned {
                let _ = mvm_vmm::host::telemetry_provisioning::record_boot_provisioning(
                    req.state_dir,
                    true,
                );
            }
            TelemetryStart::default()
        }

        fn spawn(&self, req: &NetworkEndpointSpawnRequest<'_>) -> Result<SpawnedEndpoint> {
            *self.seen.lock().unwrap() = Some(Recorded {
                mints_identity: matches!(req.identity, FlowMuxIdentitySource::Mint),
                tenant: req.tenant.to_string(),
                secrets_len: req.secrets.len(),
                policy: req.network_policy.clone(),
                network_limits: req.network_limits,
            });
            let identity_drive = self.prepare_identity(req)?;
            // The same record the real endpoint spawn writes, so the cmdline
            // token gate observes this boot's provisioning decision.
            let _ = mvm_vmm::host::telemetry_provisioning::record_boot_provisioning(
                req.state_dir,
                spawner::telemetry_for_boot(
                    mvm_vmm::host::telemetry_provisioning::telemetry_collection_enabled(),
                    req.identity,
                ),
            );
            Ok(SpawnedEndpoint {
                egress_uds: self.uds.clone(),
                identity_drive,
            })
        }
    }

    /// A `BrokerRegistrar` test double: records the request it saw and returns a
    /// defused no-op guard (spawns no broker subprocess). `Mutex` for the
    /// `Send + Sync` bound a `VmBackend`'s registrar must satisfy.
    struct RecordingBrokerRegistrar {
        seen: Mutex<Option<RecordedBroker>>,
    }

    struct RecordedBroker {
        vm_name: String,
        tenant: Option<String>,
        broker_listen_socket: Option<PathBuf>,
        services: Vec<ServiceId>,
    }

    impl RecordingBrokerRegistrar {
        fn new() -> Self {
            Self {
                seen: Mutex::new(None),
            }
        }
    }

    impl BrokerRegistrar for RecordingBrokerRegistrar {
        fn register(&self, req: &BrokerRegisterRequest<'_>) -> Result<BrokerGuard> {
            *self.seen.lock().unwrap() = Some(RecordedBroker {
                vm_name: req.vm_name.to_string(),
                tenant: req.tenant.map(str::to_string),
                broker_listen_socket: req.broker_listen_socket.map(Path::to_path_buf),
                services: req.services.to_vec(),
            });
            Ok(BrokerGuard::defused())
        }
    }

    fn service(id: &str) -> ServiceId {
        ServiceId::parse(id.to_string()).unwrap()
    }

    /// A guard that did register — the only inner variant a test can build
    /// without a live daemon, and its Drop is a no-op.
    fn registered_guard() -> BrokerGuard {
        BrokerGuard::from_services_guard(mvm_vmm::host::host_agent_spawn::ServicesGuard::Agent(
            mvm_vmm::host::host_agent_spawn::HostAgentServicesGuard::defused(),
        ))
    }

    #[test]
    fn a_workload_that_bound_no_host_service_is_not_degraded() {
        assert!(BrokerGuard::defused().services_healthy(&[]));
    }

    #[test]
    fn a_bound_host_service_that_never_registered_is_degraded() {
        assert!(!BrokerGuard::defused().services_healthy(&[service("host.audit.v1")]));
    }

    #[test]
    fn a_bound_host_service_that_registered_is_not_degraded() {
        assert!(registered_guard().services_healthy(&[service("host.audit.v1")]));
    }

    /// A `ConsoleStreamer` double proving the *wiring*, not re-proving the
    /// follower's own polling correctness (that lives, and is tested, in
    /// `mvm-hostd::stream::console_source` — the crate this one cannot
    /// depend on, which is why the hook exists). Records every `start`/`stop`
    /// call, and on `stop` snapshots whatever the console-log path holds at
    /// that moment: a real follower's `stop` synchronously drains before
    /// returning, so a wired `stop` that runs before the file is read back
    /// would show up here as a snapshot missing bytes that were already on
    /// disk.
    #[derive(Default)]
    struct RecordingConsoleStreamer {
        started: Mutex<Vec<(String, PathBuf)>>,
        /// `ConsoleCapture::supervisor_owned` of each `start`, in call order.
        supervisor_owned: Mutex<Vec<bool>>,
        stopped: Mutex<Vec<String>>,
        captured_at_stop: Mutex<HashMap<String, Vec<u8>>>,
    }

    impl ConsoleStreamer for RecordingConsoleStreamer {
        fn start(&self, capture: &ConsoleCapture<'_>) {
            self.supervisor_owned
                .lock()
                .unwrap()
                .push(capture.supervisor_owned);
            self.started.lock().unwrap().push((
                capture.vm_name.to_string(),
                capture.console_log.to_path_buf(),
            ));
        }

        fn stop(&self, vm_name: &str) {
            self.stopped.lock().unwrap().push(vm_name.to_string());
            let path = self
                .started
                .lock()
                .unwrap()
                .iter()
                .find(|(name, _)| name == vm_name)
                .map(|(_, path)| path.clone());
            if let Some(path) = path {
                let bytes = std::fs::read(&path).unwrap_or_default();
                self.captured_at_stop
                    .lock()
                    .unwrap()
                    .insert(vm_name.to_string(), bytes);
            }
        }
    }

    #[test]
    fn only_the_hvf_supervisor_owns_console_capture() {
        use mvm_core::vm_backend::BackendKind;
        assert!(supervisor_owns_console(BackendKind::Hvf));
        for kind in [
            BackendKind::Firecracker,
            BackendKind::Libkrun,
            BackendKind::Qemu,
            BackendKind::Mock,
        ] {
            assert!(!supervisor_owns_console(kind), "{kind:?}");
        }
    }

    #[test]
    fn boot_and_console_start_run_concurrently() {
        let (started_tx, started_rx) = std::sync::mpsc::sync_channel(0);
        let booted = console_boot::boot_while_starting_console(
            || {
                started_rx
                    .recv_timeout(Duration::from_secs(1))
                    .map_err(|error| {
                        anyhow::anyhow!("console start did not overlap boot: {error}")
                    })?;
                Ok(7_u8)
            },
            || {
                let _ = started_tx.send(());
            },
            || {},
        )
        .expect("the console-start task runs while the driver boot is in progress");

        assert_eq!(booted, 7);
    }

    fn isolated_runtime_home() -> (TestEnv, tempfile::TempDir) {
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.isolate_mvm_home(home.path());
        (env, home)
    }

    fn config(name: &str) -> VmStartConfig {
        VmStartConfig {
            name: name.into(),
            rootfs_path: "/img/rootfs.ext4".into(),
            ..Default::default()
        }
    }

    // These adapters exercise post-admission mapping with synthetic artifacts,
    // not launch authorization. Public entrypoint tests below separately
    // exercise refusal and checked-source verification.
    fn mapping_start<D: VmmDriver, S: NetworkEndpointSpawner, B: BrokerRegistrar>(
        runner: &WorkloadRunner<D, S, B>,
        config: &VmStartConfig,
    ) -> Result<VmId> {
        let state_dir = vm_state_dir(&config.name);
        std::fs::create_dir_all(&state_dir)?;
        let default_redaction = RedactionPolicy::default();
        let decoded = decode_plan_secrets_from_state(&state_dir)?;
        let (secrets, redaction, tenant): (&[SecretBinding], &RedactionPolicy, &str) =
            match &decoded {
                Some((secrets, redaction, tenant)) => {
                    (secrets.as_slice(), redaction, tenant.as_str())
                }
                None => (
                    &[],
                    &default_redaction,
                    config.tenant_id.as_deref().unwrap_or("local"),
                ),
            };
        let cmdline = cmdline::runner_cmdline(config, &state_dir, |has_disk| {
            runner.driver.workload_base_bootargs(has_disk)
        });
        runner
            .boot_bound_workload(&WorkloadLaunchInputs {
                config,
                tenant,
                secrets,
                redaction,
                network_policy: &config.network_policy,
                cmdline,
            })
            .map(|vm| vm.id().clone())
    }

    fn mapping_standby<D: VmmDriver, S: NetworkEndpointSpawner, B: BrokerRegistrar>(
        runner: &WorkloadRunner<D, S, B>,
        ctx: &SpawnContext<'_>,
        spec: &StandbySpec,
    ) -> std::result::Result<StandbyHandle, StandbyError> {
        let config =
            factory_parent_config(ctx.launch.expect("mapping fixture has a launch"), spec)?;
        runner.spawn_bound_standby_captured(ctx, spec, &config)
    }

    fn checked_source_config(name: &str, rootfs_path: String) -> VmStartConfig {
        let cache = PathBuf::from(mvm_core::config::mvm_cache_dir());
        let workspace = mvm_build::image_source::guest_runtime_source_checkout()
            .expect("source-channel test checkout");
        let version = env!("CARGO_PKG_VERSION");
        let arch = mvm_core::arch::GuestArch::host();
        let runtime = mvm_build::guest_runtime::test_support::write_source_cache_fixture(
            &cache, &workspace, version, arch,
        )
        .unwrap();
        let overlay = mvm_build::runtime_overlay::build_runtime_overlay_from_guest_runtime(
            &cache, version, arch, &runtime,
        )
        .unwrap();
        let initramfs = mvm_build::initramfs::build_initramfs_from_guest_runtime(
            &cache, version, arch, &runtime,
        )
        .unwrap();
        VmStartConfig {
            name: name.into(),
            rootfs_path,
            kernel_path: Some("/img/kernel".into()),
            initrd_path: Some(initramfs.image_path.display().to_string()),
            runtime_overlay_path: Some(overlay.overlay_ext4.display().to_string()),
            runtime_overlay_verity_path: Some(overlay.sidecar.display().to_string()),
            runtime_overlay_roothash: Some(overlay.roothash),
            runtime_overlay_version: Some(version.into()),
            unsigned_runtime_development: true,
            cpus: 1,
            memory_mib: 64,
            ..Default::default()
        }
    }

    #[test]
    fn checked_source_cold_and_standby_boot_private_bytes_and_keep_them_after_stop() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let (_image, rootfs) = overlay_aware_rootfs("checked-source");
        let config = checked_source_config("checked-source", rootfs.clone());
        let checked = crate::runtime_evidence::verify_runtime_for_launch(
            &config,
            crate::runtime_evidence::MIN_GUEST_RPC_PROTOCOL_VERSION,
        )
        .unwrap()
        .unwrap();
        assert!(
            !checked.is_release(),
            "synthetic source bytes are not signed release evidence"
        );
        let driver = MockDriver::default().with_vm_full_rootfs(Path::new(&rootfs));
        let guest = spawn_activation_guest(driver.clone(), "checked-source");
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        runner.start(&config).unwrap();
        guest.join().unwrap();
        let parent_guest = spawn_activation_guest(runner.driver.clone(), "checked-parent");
        let store = CheckpointStore::at(home.path().join("checkpoints"));
        let spec = standby_spec_for("checked-parent", &vm_state_dir("checked-parent"), &config);
        runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: Some(&config),
                },
                &spec,
            )
            .unwrap();
        parent_guest.join().unwrap();
        let boots = runner.driver.booted_specs();
        assert_eq!(boots.len(), 2);
        let mut retained = Vec::new();
        for (boot, name) in boots.iter().zip(["checked-source", "checked-parent"]) {
            let binding = crate::base::runtime_meta::read(name)
                .unwrap()
                .unwrap()
                .runtime_launch_binding
                .unwrap();
            crate::runtime_evidence::verify_runtime_binding(&binding).unwrap();
            let mvm_core::protocol::runtime_release::RuntimeLaunchBinding::CliAssembly(binding) =
                binding
            else {
                panic!("source assembly fixture");
            };
            assert!(binding.release_proof().is_none());
            assert_eq!(
                Some(binding.overlay_roothash.as_str()),
                config.runtime_overlay_roothash.as_deref()
            );
            assert_eq!(boot.initramfs.as_ref(), Some(&binding.initramfs_path));
            assert!(
                boot.blocks
                    .iter()
                    .any(|disk| disk.source == binding.overlay_path)
            );
            assert!(
                boot.blocks
                    .iter()
                    .any(|disk| disk.source == binding.overlay_verity_path)
            );
            assert_ne!(
                binding.overlay_path,
                PathBuf::from(config.runtime_overlay_path.as_ref().unwrap())
            );
            retained.push(binding);
        }
        assert_ne!(retained[0].overlay_path, retained[1].overlay_path);
        runner.stop(&VmId("checked-source".into())).unwrap();
        runner.stop(&VmId("checked-parent".into())).unwrap();
        std::fs::write(
            config.runtime_overlay_path.as_ref().unwrap(),
            b"changed cache output",
        )
        .unwrap();
        let before = runner.driver.booted_specs().len();
        assert!(
            runner.start(&config).is_err(),
            "changed selection must fail before spawn"
        );
        assert_eq!(runner.driver.booted_specs().len(), before);
        for binding in retained {
            crate::runtime_evidence::verify_runtime_binding(
                &mvm_core::protocol::runtime_release::RuntimeLaunchBinding::CliAssembly(binding),
            )
            .unwrap();
        }
    }

    fn egress_allowing_policy() -> NetworkPolicy {
        NetworkPolicy::allow_list(vec![HostPort::new("example.com", 443)])
    }

    /// Seed an overlay-aware `mvm-meta.json` sidecar next to a rootfs file in a
    /// fresh tempdir and return `(dir, rootfs_path)`. `VmBackend::start`'s
    /// admission gate refuses a rootfs whose parent dir carries no overlay-aware
    /// sidecar, so every test that drives the full trait method provides one.
    /// The returned `TempDir` must stay in scope for the rootfs to exist.
    fn overlay_aware_rootfs(name: &str) -> (tempfile::TempDir, String) {
        let dir = tempfile::tempdir().unwrap();
        let rootfs = dir.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"rootfs").unwrap();
        // sealed=false (accessible dev image), runtime_lean=true so the sidecar
        // clears the gate under every runtime-source policy, not just the default.
        mvm_build::builder_vm::GuestSidecar::for_oci_run(name, false, true)
            .write_to_dir(dir.path())
            .unwrap();
        (dir, rootfs.display().to_string())
    }

    fn keystore_secret() -> SecretBinding {
        SecretBinding {
            name: "API_KEY".into(),
            source: SecretSource::Keystore {
                address: "test-key".into(),
            },
            destinations: Vec::new(),
            approval_required: false,
        }
    }

    fn egress_host_uds(spec: &crate::driver::VmmSpec) -> &Path {
        spec.vsock
            .iter()
            .find(|p| p.service.port() == EGRESS_PORT)
            .map(|p| p.host_uds.as_path())
            .expect("spec carries an EGRESS_PORT vsock channel")
    }

    #[test]
    fn gpu_endpoint_transport_binds_vsock_only_for_qemu() {
        use mvm_core::vm_backend::BackendKind;
        use mvm_vmm::host::network_endpoint_spawn::EndpointTransport;

        let state = tempfile::tempdir().unwrap();
        assert_eq!(
            gpu_endpoint_transport(BackendKind::Qemu, state.path()),
            EndpointTransport::Vsock {
                port: mvm_agentd::vsock::GPU_PORT,
            },
            "QEMU's vhost-vsock binds the GPU port directly"
        );
        for other in [
            BackendKind::Firecracker,
            BackendKind::Libkrun,
            BackendKind::Hvf,
            BackendKind::Wasm,
        ] {
            assert_eq!(
                gpu_endpoint_transport(other, state.path()),
                EndpointTransport::Uds {
                    path: mvm_core::config::vm_vsock_port_socket_at(
                        state.path(),
                        mvm_agentd::vsock::GPU_PORT,
                    ),
                },
                "every non-QEMU tier proxies the guest GPU dial to a per-VM UDS"
            );
        }
    }

    #[test]
    fn append_cmdline_token_separates_only_a_non_empty_cmdline() {
        let mut empty = String::new();
        append_cmdline_token(&mut empty, "mvm.telemetry=1");
        assert_eq!(
            empty, "mvm.telemetry=1",
            "no leading space on an empty cmdline"
        );

        let mut non_empty = "root=/dev/vda".to_string();
        append_cmdline_token(&mut non_empty, "mvm.telemetry=1");
        assert_eq!(
            non_empty, "root=/dev/vda mvm.telemetry=1",
            "a non-empty cmdline gets exactly one space separator"
        );
    }

    #[test]
    fn universal_activation_keeps_substitution_values_off_the_boot_cmdline() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let rootfs_dir = tempfile::tempdir().unwrap();
        let rootfs = rootfs_dir.path().join("rootfs.ext4");
        let verity = rootfs_dir.path().join("rootfs.verity");
        let initrd = rootfs_dir.path().join("rootfs.initrd");
        std::fs::write(&rootfs, b"rootfs").unwrap();
        std::fs::write(&verity, b"verity").unwrap();
        std::fs::write(&initrd, b"initrd").unwrap();
        mvm_build::builder_vm::GuestSidecar::for_oci_run(
            "runner-secret-env-cmdline-spacing",
            false,
            true,
        )
        .write_to_dir(rootfs_dir.path())
        .unwrap();

        let vm_name = "runner-secret-env-cmdline-spacing";
        seed_grant_sidecar_and_key(vm_name);
        // Substitution values belong to the host's per-entrypoint environment
        // synthesis, never the globally readable kernel command line.
        let state_dir = mvm_core::config::vm_state_dir(vm_name);
        std::fs::create_dir_all(&state_dir).unwrap();
        std::fs::write(
            state_dir.join("substitution-env.json"),
            br#"[["API_KEY","mvm-secret-test"]]"#,
        )
        .unwrap();

        let cfg = VmStartConfig {
            name: vm_name.into(),
            rootfs_path: rootfs.display().to_string(),
            initrd_path: Some(mvm_vmm::host::cmdline::seed_universal_initramfs(
                home.path(),
            )),
            verity_path: Some(verity.display().to_string()),
            roothash: Some("a".repeat(64)),
            network_policy: NetworkPolicy::preset(mvm_core::network_policy::NetworkPreset::Dev),
            ..Default::default()
        };

        let driver = MockDriver::default();
        let guest = spawn_activation_guest(driver.clone(), vm_name);
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        mapping_start(&runner, &cfg).expect("start succeeds");
        guest.join().expect("guest thread");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let cmdline = &specs[0].cmdline;
        assert!(!cmdline.contains("mvm.secret_env="), "{cmdline}");
        assert!(!cmdline.contains("mvm-secret-test"), "{cmdline}");
        assert!(!cmdline.contains(&hex::encode("API_KEY=")), "{cmdline}");
    }

    /// A blanket refusal in front of the HVF driver turns `machine run` into an
    /// error on the default macOS backend before anything is checked. Both
    /// entrypoints must reach the real launch checks, which refuse this
    /// synthetic config for their own reasons (no rootfs, no kernel).
    #[test]
    fn an_hvf_runner_reaches_the_launch_checks_instead_of_a_blanket_refusal() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let runner = WorkloadRunner::new(
            mvm_backends::driver::hvf::HvfDriver::new(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = config("hvf-not-blanket-refused");
        let redaction = RedactionPolicy::default();

        let started = VmBackend::start(&runner, &cfg).expect_err("no rootfs to boot");
        let launched = runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &cfg.network_policy,
                cmdline: String::new(),
            })
            .map(|_| ())
            .expect_err("no rootfs to boot");

        for error in [format!("{started:#}"), format!("{launched:#}")] {
            assert!(
                !error.contains("native HVF"),
                "HVF was refused outright instead of reaching the launch checks: {error}"
            );
        }
    }

    /// A named HVF machine writes its supervisor pid file but no console log.
    /// Listing only console-logged directories made `machine ls` report such a
    /// running machine as stopped.
    #[test]
    fn list_includes_a_vm_that_has_a_pid_file_but_no_console_log() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let vms = mvm_core::config::vms_dir();
        for (name, marker) in [
            ("pid-only", Some("hvf.pid")),
            ("console-only", Some("console.log")),
            ("neither", None),
        ] {
            let dir = vms.join(name);
            std::fs::create_dir_all(&dir).unwrap();
            if let Some(marker) = marker {
                std::fs::write(dir.join(marker), "1").unwrap();
            }
        }
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let mut names: Vec<String> = VmBackend::list(&runner)
            .unwrap()
            .into_iter()
            .map(|vm| vm.name)
            .collect();
        names.sort();

        assert_eq!(names, ["console-only", "pid-only"]);
    }

    #[test]
    fn stops_and_dropped_handles_never_reap_unproven_runtime_generations() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = config("retained-generations");
        let redaction = RedactionPolicy::default();
        let vm = runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &cfg.network_policy,
                cmdline: String::new(),
            })
            .unwrap();
        // Synthetic retained bytes test lifecycle deletion only, not signature
        // verification. Both an older launch and a newer launch must survive.
        let root = mvm_core::config::runtime_evidence_root().join(&cfg.name);
        let generations = ["runtime-old", "runtime-new"].map(|name| {
            let directory = root.join(name);
            std::fs::create_dir(&directory).unwrap();
            let artifact = directory.join("overlay.ext4");
            std::fs::write(&artifact, name).unwrap();
            artifact
        });
        drop(vm);
        for artifact in &generations {
            assert!(artifact.exists());
        }
        let id = VmId(cfg.name.clone());
        runner.stop(&id).expect("mock stop succeeds");
        for artifact in &generations {
            assert!(
                artifact.exists(),
                "PID-only success cannot authorize deletion"
            );
        }
        // A subsequent/stale stop may fail attachment, but is equally unable
        // to delete either generation.
        let _ = runner.stop(&id);
        let mut missing_proof = cfg;
        missing_proof.runtime_overlay_path = Some("/untrusted/overlay".into());
        assert!(
            runner
                .start_workload(&WorkloadLaunchInputs {
                    config: &missing_proof,
                    tenant: "local",
                    secrets: &[],
                    redaction: &redaction,
                    network_policy: &missing_proof.network_policy,
                    cmdline: String::new(),
                })
                .is_err()
        );
        for artifact in &generations {
            assert!(
                artifact.exists(),
                "failed replacement cannot delete retained bytes"
            );
        }
    }

    #[test]
    fn runtime_proof_rejection_precedes_every_backend_spawn() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let mut cfg = config("proof-refused");
        cfg.runtime_overlay_path = Some("/runtime/overlay".into());
        let redaction = RedactionPolicy::default();
        for forged_development_flag in [false, true] {
            cfg.unsigned_runtime_development = forged_development_flag;
            let outcome = runner.start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &cfg.network_policy,
                cmdline: "mvm.runtime_roothash=untrusted".into(),
            });
            assert!(outcome.is_err());
            assert!(runner.driver.booted_specs().is_empty());
            assert!(runner.spawner.seen.lock().unwrap().is_none());
        }
    }

    #[test]
    #[cfg(unix)]
    fn retention_diagnostics_do_not_block_stop_but_invalid_leases_do() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let id = VmId("broken-retention".into());
        let lease = crate::runtime_evidence::RuntimeLifecycleLease::acquire(&id.0).unwrap();
        let root = mvm_core::config::runtime_evidence_root();
        let unreadable = root.join(&id.0).join("runtime-unreadable");
        std::fs::create_dir(&unreadable).unwrap();
        mvm_core::private_fs::set_mode(&unreadable, 0).unwrap();
        // Root bypasses directory DAC. Non-root host runs exercise the actual
        // diagnostic failure; both must still exercise driver termination.
        // SAFETY: geteuid has no arguments or memory preconditions.
        if unsafe { libc::geteuid() } != 0 {
            assert!(lease.report_retained().is_err());
        }
        drop(lease);
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let result = runner.stop(&id);
        mvm_core::private_fs::set_mode(&unreadable, 0o700).unwrap();
        result.expect("diagnostic failure must not block stop");
        assert_eq!(runner.driver.killed_vms(), vec![id.0.clone()]);

        let original = root.with_extension("retained");
        std::fs::rename(&root, &original).unwrap();
        std::os::unix::fs::symlink(&original, &root).unwrap();
        assert!(runner.abort_start(&id).is_err());
        assert_eq!(runner.driver.killed_vms().len(), 1);
        for invalid in ["../bad", "x/y", ""] {
            assert!(runner.stop(&VmId(invalid.into())).is_err());
        }
        assert_eq!(runner.driver.killed_vms().len(), 1);
        std::fs::remove_file(&root).unwrap();
        std::fs::rename(&original, &root).unwrap();
        let refusing = WorkloadRunner::new(
            MockDriver::default().refusing_attach(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let expected_error = refusing.driver.attach(&id).err().unwrap().to_string();
        let error = refusing.stop(&id).unwrap_err();
        assert_eq!(error.to_string(), expected_error);
    }

    #[test]
    fn start_workload_threads_endpoint_uds_into_egress_port() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let cfg = config("w-egress");
        let vm = runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: "root=/dev/vda".into(),
            })
            .expect("start_workload succeeds against the mock driver");

        assert_eq!(vm.id().0, "w-egress");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let spec = &specs[0];

        // The endpoint UDS the spawner returned is wired to EGRESS_PORT.
        assert_eq!(egress_host_uds(spec), Path::new("/run/ep.sock"));
        // The sealed rootfs lands at /dev/vda.
        assert_eq!(spec.blocks[0].device_node(), "/dev/vda");
        assert_eq!(spec.blocks[0].source, PathBuf::from("/img/rootfs.ext4"));
        // The write-only console capture path is set under the state dir.
        assert!(spec.console.log_path.ends_with("console.log"));
    }

    #[test]
    fn start_workload_puts_no_secret_environment_on_the_kernel_cmdline() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let cfg = config("w-secret-env");
        let env_path = mvm_core::config::vm_substitution_env_path(&cfg.name);
        std::fs::create_dir_all(env_path.parent().unwrap()).unwrap();
        std::fs::write(
            &env_path,
            serde_json::to_vec(&vec![(
                "API_KEY".to_string(),
                "mvm-secret://opaque-placeholder".to_string(),
            )])
            .unwrap(),
        )
        .unwrap();
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let secrets = vec![keystore_secret()];
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &secrets,
                redaction: &redaction,
                network_policy: &policy,
                cmdline: "root=/dev/vda".into(),
            })
            .expect("secret-bearing workload boots");

        // The placeholders reach the workload with each `RunEntrypoint`, from
        // the host's environment synthesis. Any guest process can read
        // `/proc/cmdline`, so nothing of them rides the kernel cmdline.
        let specs = runner.driver.booted_specs();
        let cmdline = &specs[0].cmdline;
        assert!(!cmdline.contains("mvm.secret_env"), "{cmdline}");
        assert!(!cmdline.contains("4150495f4b45593d"), "{cmdline}");
        assert!(!cmdline.contains("opaque-placeholder"), "{cmdline}");
    }

    #[test]
    fn start_workload_starts_console_streaming_and_stop_tears_it_down_without_losing_bytes() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let streamer = Arc::new(RecordingConsoleStreamer::default());
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        )
        .with_console_streamer(streamer.clone() as Arc<dyn ConsoleStreamer>);

        let cfg = config("w-console");
        let vm = runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: "root=/dev/vda".into(),
            })
            .expect("start_workload succeeds against the mock driver");

        // Started exactly once, unconditionally (no admission gating: the
        // hook must not inherit `BrokerRegistrar`'s tenant-gated posture),
        // and pointed at the same console-log path the boot spec carries.
        let expected_console_log = vm_state_dir(&cfg.name).join("console.log");
        {
            let started = streamer.started.lock().unwrap();
            assert_eq!(
                started.as_slice(),
                [("w-console".to_string(), expected_console_log.clone())]
            );
        }
        // The mock backend has no supervisor that owns capture, so the
        // launcher's follower is the writer and must be told so.
        assert_eq!(
            streamer.supervisor_owned.lock().unwrap().as_slice(),
            [false]
        );
        assert!(
            streamer.stopped.lock().unwrap().is_empty(),
            "must not stop before the workload ends"
        );

        // The boot-failure case this feature exists for: output that lands
        // on the console between start and stop, with no agent involved.
        std::fs::write(&expected_console_log, b"kernel panic\n")
            .expect("write to the console-log path the hook was started with");

        runner
            .stop(vm.id())
            .expect("stop succeeds against the mock driver");

        // Stopped exactly once, by name, and the snapshot taken at that stop
        // call sees the bytes written above -- proving `stop` is wired to run
        // (and, for a real follower, drain) before the caller can observe the
        // workload as torn down, not merely that the method was called.
        assert_eq!(streamer.stopped.lock().unwrap().as_slice(), ["w-console"]);
        assert_eq!(
            streamer
                .captured_at_stop
                .lock()
                .unwrap()
                .get("w-console")
                .expect("stop captured this vm's console"),
            b"kernel panic\n"
        );
    }

    #[test]
    fn the_console_capture_outlives_the_kill_so_a_dying_guests_output_is_recorded() {
        // A guest prints its last words *during* teardown. Releasing the
        // capture before the kill leaves those bytes in the write-only
        // console file and out of the chain — which is exactly the output an
        // operator opens the transcript to find.
        let mut env = mvm_core::util::test_env::TestEnv::new();
        let tmp = tempfile::tempdir().expect("tempdir");
        env.isolate_mvm_home(tmp.path());

        let policy = NetworkPolicy::deny_all();
        let redaction = RedactionPolicy::default();
        let streamer = Arc::new(RecordingConsoleStreamer::default());
        let runner = WorkloadRunner::new(
            MockDriver::default().printing_on_kill(b"panic on the way down\n"),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        )
        .with_console_streamer(streamer.clone() as Arc<dyn ConsoleStreamer>);

        let cfg = config("w-dying");
        let vm = runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: "root=/dev/vda".into(),
            })
            .expect("start_workload succeeds against the mock driver");
        std::fs::write(
            vm_state_dir(&cfg.name).join("console.log"),
            b"while it lived\n",
        )
        .expect("write the console capture");

        runner.stop(vm.id()).expect("stop");

        // The snapshot the hook takes at `stop` is what a real follower's
        // final drain would see. It must hold the kill-time bytes.
        let captured = streamer.captured_at_stop.lock().unwrap();
        let seen = captured.get("w-dying").expect("stop captured this vm");
        assert_eq!(seen.as_slice(), b"while it lived\npanic on the way down\n");
    }

    #[test]
    fn a_kill_that_fails_still_releases_the_console_capture() {
        let (_env, _home) = isolated_runtime_home();
        // The property the old ordering bought and this one must not lose: a
        // VM that will not die cannot strand its follower, or leave its
        // transcript unsealed.
        let streamer = Arc::new(RecordingConsoleStreamer::default());
        let runner = WorkloadRunner::new(
            MockDriver::default().refusing_attach(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        )
        .with_console_streamer(streamer.clone() as Arc<dyn ConsoleStreamer>);

        let err = runner
            .stop(&VmId("w-undead".to_string()))
            .expect_err("the driver refuses to attach");
        assert!(format!("{err:#}").contains("no such vm"), "{err:#}");
        assert_eq!(streamer.stopped.lock().unwrap().as_slice(), ["w-undead"]);
    }

    #[test]
    fn every_cold_boot_mints_an_identity_whether_or_not_it_carries_secrets() {
        let (_env, _home) = isolated_runtime_home();
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();

        // There is one transport, so carrying secrets changes what
        // the endpoint does with a flow -- not which protocol the guest speaks.
        let raw_runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = config("w-raw");
        raw_runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .unwrap();
        assert!(
            raw_runner
                .spawner
                .seen
                .lock()
                .unwrap()
                .as_ref()
                .unwrap()
                .mints_identity
        );

        // A secret-bearing workload mints exactly the same way.
        let wire_runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = config("w-wire");
        let secrets = [keystore_secret()];
        wire_runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &secrets,
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .unwrap();
        let recorded = wire_runner.spawner.seen.lock().unwrap();
        let recorded = recorded.as_ref().unwrap();
        assert!(
            recorded.mints_identity,
            "a secret-bearing cold boot mints an identity too -- the protocol \
             does not fork on whether secrets are present"
        );
        assert_eq!(recorded.secrets_len, 1);
        assert_eq!(
            recorded.network_limits,
            mvm_core::plan::NetworkLimits::default()
        );
    }

    #[test]
    fn start_workload_passes_the_network_policy_and_tenant_to_the_spawner() {
        let (_env, _home) = isolated_runtime_home();
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let cfg = config("w-policy");
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "acme",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .unwrap();

        let recorded = runner.spawner.seen.lock().unwrap();
        let recorded = recorded.as_ref().unwrap();
        assert_eq!(recorded.tenant, "acme");
        assert_eq!(recorded.policy, egress_allowing_policy());
    }

    fn admitted_config(name: &str) -> VmStartConfig {
        VmStartConfig {
            name: name.into(),
            rootfs_path: "/img/rootfs.ext4".into(),
            tenant_id: Some("tenant-x".into()),
            ..Default::default()
        }
    }

    #[test]
    fn start_workload_registers_the_broker_and_wires_it_into_the_spec_when_admitted() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let policy = NetworkPolicy::deny_all();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let cfg = admitted_config("w-broker-admitted");
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "tenant-x",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("start_workload succeeds");

        // register saw the tenant + the resolved BROKER_PORT bind socket.
        let expected_socket =
            mvm_core::config::vm_vsock_port_socket("w-broker-admitted", BROKER_PORT);
        let recorded = runner.broker.seen.lock().unwrap();
        let recorded = recorded.as_ref().expect("register was called");
        assert_eq!(recorded.vm_name, "w-broker-admitted");
        assert_eq!(recorded.tenant.as_deref(), Some("tenant-x"));
        assert_eq!(
            recorded.broker_listen_socket.as_deref(),
            Some(expected_socket.as_path())
        );

        // The spec carries the same socket as a GuestDials BROKER_PORT channel, so
        // the supervisor relay target and the daemon's bind path are identical.
        let specs = runner.driver.booted_specs();
        let broker = specs[0]
            .vsock
            .iter()
            .find(|p| p.service.port() == BROKER_PORT)
            .expect("admitted spec carries a BROKER_PORT channel");
        assert_eq!(broker.direction, crate::driver::VsockDirection::GuestDials);
        assert_eq!(broker.host_uds, expected_socket);
    }

    #[test]
    fn start_workload_broker_is_a_defused_no_op_when_unadmitted() {
        let (_env, _home) = isolated_runtime_home();
        let policy = NetworkPolicy::deny_all();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        // config() sets no tenant_id ⇒ unadmitted.
        let cfg = config("w-broker-unadmitted");
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("start_workload succeeds");

        // register is still called, but with no tenant + no broker socket.
        let recorded = runner.broker.seen.lock().unwrap();
        let recorded = recorded.as_ref().expect("register is still called");
        assert_eq!(recorded.tenant, None);
        assert_eq!(recorded.broker_listen_socket, None);

        // The spec carries NO BROKER_PORT channel, so a stray guest dial to
        // BROKER_PORT stays ECONNREFUSED (fail-closed).
        let specs = runner.driver.booted_specs();
        assert!(
            specs[0]
                .vsock
                .iter()
                .all(|p| p.service.port() != BROKER_PORT),
            "unadmitted VM must carry no broker port"
        );
    }

    #[test]
    fn stop_reaps_the_host_agent_tenant_ref_marker() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let vm_name = "runner-stop-reaps-broker";
        let state_dir = mvm_core::config::vm_state_dir(vm_name);
        std::fs::create_dir_all(&state_dir).unwrap();
        // Plant the daemon-path tenant-ref marker `register` writes; the stop reap
        // must remove it, proving `reap_host_agent_services_from_state` ran.
        std::fs::write(state_dir.join("host-agent.tenant"), "tenant-x").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        runner.stop(&VmId(vm_name.into())).expect("stop succeeds");

        assert!(
            !state_dir.join("host-agent.tenant").exists(),
            "stop must reap the host-agent registration marker"
        );
    }

    #[test]
    fn vmbackend_start_then_status_wait_stop_via_the_driver() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let exit = VmExitStatus {
            code: Some(0),
            success: true,
        };
        let runner = WorkloadRunner::new(
            MockDriver::with_exit(exit),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("w");
        let cfg = VmStartConfig {
            name: "w".into(),
            rootfs_path: rootfs,
            ..Default::default()
        };
        let id = mapping_start(&runner, &cfg).expect("start succeeds");
        assert_eq!(id.0, "w");

        // attach hands back a MockRunningVm, so the lifecycle works with no real VM.
        assert_eq!(runner.status(&id).unwrap(), VmStatus::Running);
        assert_eq!(runner.wait(&id).unwrap(), exit);
        // stop reaps a nonexistent endpoint (no-op) then kills the attached handle.
        assert!(runner.stop(&VmId("w".into())).is_ok());
    }

    /// Write a `verb-grant.json` sidecar plus the host-signer public key
    /// under `vm_name`'s state dir, the shape the grant cmdline tokens read.
    fn seed_grant_sidecar_and_key(vm_name: &str) {
        let state_dir = mvm_core::config::vm_state_dir(vm_name);
        std::fs::create_dir_all(&state_dir).unwrap();
        let nonce = Nonce::from_bytes([9u8; 16]);
        let not_after = mvm_core::time::parse_iso8601("2099-01-01T00:00:00Z").unwrap();
        let envelope = VerbGrantEnvelope {
            pubkey_hex: "cc".repeat(32),
            plan_nonce_hex: nonce.as_hex().to_string(),
            predecessor_session_id: None,
            predecessor_plan_nonce_hex: None,
            grant: VerbGrant {
                session_id: vm_name.to_string(),
                plan_nonce: nonce,
                not_after,
                verbs: vec![VerbId::new("run-entrypoint").unwrap()],
                drive: None,
                tool_mediation: None,
                application_terminal: None,
                owner_access: None,
                sig: vec![0u8; 64],
            },
        };
        std::fs::write(
            state_dir.join("verb-grant.json"),
            serde_json::to_vec(&envelope).unwrap(),
        )
        .unwrap();
        let keys_dir = mvm_core::config::mvm_keys_dir();
        std::fs::create_dir_all(&keys_dir).unwrap();
        std::fs::write(keys_dir.join("host-signer.pub"), [0xEEu8; 32]).unwrap();
    }

    /// Seed only the host key — no verb-grant sidecar. Models the transient
    /// `machine run` path, which mints no grant.
    fn seed_host_key_only() {
        let keys_dir = mvm_core::config::mvm_keys_dir();
        std::fs::create_dir_all(&keys_dir).unwrap();
        std::fs::write(keys_dir.join("host-signer.pub"), [0xEEu8; 32]).unwrap();
    }

    /// A launch that mints no verb grant must still carry the host-signer
    /// anchor, or its guest agent has no pinned key to authenticate the control
    /// channel against, rejects every connection, and the run dies at its first
    /// RPC.
    ///
    /// The sibling test below covers the grant-*bearing* launch, and that was
    /// exactly the gap: the anchor used to be gated on the grant sidecar, so the
    /// grant-less shape shipped no anchor and nothing at this level noticed.
    /// Asserting the token builder alone did not catch it either — the
    /// regression only surfaced in an assembled cmdline.
    #[test]
    fn start_carries_the_host_anchor_without_a_grant_but_grants_no_authority() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let rootfs_dir = tempfile::tempdir().unwrap();
        let rootfs = rootfs_dir.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"rootfs").unwrap();
        let vm_name = "runner-grantless-anchor";
        mvm_build::builder_vm::GuestSidecar::for_oci_run(vm_name, false, true)
            .write_to_dir(rootfs_dir.path())
            .unwrap();

        seed_host_key_only();

        let cfg = VmStartConfig {
            name: vm_name.into(),
            rootfs_path: rootfs.display().to_string(),
            network_policy: NetworkPolicy::preset(mvm_core::network_policy::NetworkPreset::Dev),
            ..Default::default()
        };

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        mapping_start(&runner, &cfg).expect("start succeeds");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let cmdline = &specs[0].cmdline;

        assert!(
            cmdline.contains("mvm.host_signer_pub="),
            "a grant-less launch must still pin the host anchor, or the agent \
             rejects every control connection: {cmdline}"
        );
        // Reachable, but no more privileged: authority stays sidecar-gated.
        assert!(
            !cmdline.contains("mvm.verb_grant="),
            "no grant was minted, so no grant token may appear: {cmdline}"
        );
        assert!(
            !cmdline.contains("mvm.require_grant="),
            "no grant was minted, so enforcement must not be demanded: {cmdline}"
        );
    }

    /// `WorkloadRunner::start` (the `VmBackend::start` production path) must
    /// assemble the same security-bearing kernel cmdline the raw HVF backend
    /// does — dm-verity, the plan-bound grant triple, vsock egress, and the
    /// runtime-source-policy token — instead of booting with an empty
    /// cmdline. Drives the whole trait method through a `MockDriver` and
    /// inspects the booted `VmmSpec` it recorded.
    #[test]
    fn start_assembles_the_security_cmdline_tokens_via_the_shared_assembler() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let rootfs_dir = tempfile::tempdir().unwrap();
        let rootfs = rootfs_dir.path().join("rootfs.ext4");
        let verity = rootfs_dir.path().join("rootfs.verity");
        let initrd = rootfs_dir.path().join("rootfs.initrd");
        std::fs::write(&rootfs, b"rootfs").unwrap();
        std::fs::write(&verity, b"verity").unwrap();
        std::fs::write(&initrd, b"initrd").unwrap();
        // Overlay-aware sidecar next to the rootfs so `start`'s admission gate
        // (refuses a rootfs with no `/mvm/runtime` mount point) admits this boot.
        mvm_build::builder_vm::GuestSidecar::for_oci_run(
            "runner-security-cmdline-tokens",
            false,
            true,
        )
        .write_to_dir(rootfs_dir.path())
        .unwrap();

        let vm_name = "runner-security-cmdline-tokens";
        seed_grant_sidecar_and_key(vm_name);

        let cfg = VmStartConfig {
            name: vm_name.into(),
            rootfs_path: rootfs.display().to_string(),
            initrd_path: Some(mvm_vmm::host::cmdline::seed_universal_initramfs(
                home.path(),
            )),
            verity_path: Some(verity.display().to_string()),
            roothash: Some("a".repeat(64)),
            network_policy: NetworkPolicy::preset(mvm_core::network_policy::NetworkPreset::Dev),
            ..Default::default()
        };

        let driver = MockDriver::default();
        let guest = spawn_activation_guest(driver.clone(), vm_name);
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        mapping_start(&runner, &cfg).expect("start succeeds");
        guest.join().expect("guest thread");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let cmdline = &specs[0].cmdline;

        let require_grant = mvm_vmm::host::egress_bridge::require_grant_cmdline_token(vm_name)
            .expect("sidecar present ⇒ enforcement token");
        // Roothash and block-device tokens travel over vsock via
        // ActivateEnvironment, so the kernel cmdline only carries egress and
        // grant tokens.
        for needle in [
            "mvm.verb_grant=",
            require_grant.as_str(),
            "mvm.host_signer_pub=",
            "mvm.vsock_egress=1",
        ] {
            assert!(
                cmdline.contains(needle),
                "booted cmdline missing {needle:?}: {cmdline}"
            );
        }
    }

    /// The base console/earlycon/root bootargs the runner boots with must come
    /// from the driver (`VmmDriver::workload_base_bootargs`), not a hardcoded
    /// HVF default — proven by driving `start` through a `MockDriver` whose
    /// base uses `hvc0` rather than HVF's `ttyAMA0` and asserting the booted
    /// spec's cmdline carries that base.
    #[test]
    fn start_uses_the_drivers_base_bootargs_not_a_hardcoded_hvf_default() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let driver = MockDriver::default();
        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("runner-driver-base-bootargs");
        let cfg = VmStartConfig {
            name: "runner-driver-base-bootargs".into(),
            rootfs_path: rootfs,
            network_policy: NetworkPolicy::preset(mvm_core::network_policy::NetworkPreset::Dev),
            ..Default::default()
        };

        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        mapping_start(&runner, &cfg).expect("start succeeds");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let cmdline = &specs[0].cmdline;

        let expected_base = driver.workload_base_bootargs(true);
        assert!(
            cmdline.starts_with(&expected_base),
            "cmdline did not start with the driver's base bootargs {expected_base:?}: {cmdline}"
        );
        assert!(
            !cmdline.contains("ttyAMA0"),
            "cmdline carried the hardcoded HVF console rather than the driver's: {cmdline}"
        );
    }

    fn spawn_activation_guest(driver: MockDriver, vm_name: &str) -> std::thread::JoinHandle<()> {
        use ed25519_dalek::SigningKey;
        use mvm_agentd::vsock::{AuthenticatedSession, GuestRequest, GuestResponse};

        let host_signer = [7u8; 32];
        let keys_dir = mvm_core::config::mvm_keys_dir();
        std::fs::create_dir_all(&keys_dir).unwrap();
        std::fs::write(keys_dir.join("host-signer.ed25519"), host_signer).unwrap();
        let vm_id = VmId(vm_name.to_string());

        std::thread::spawn(move || {
            let mut stream = {
                let mut found = None;
                for _ in 0..200 {
                    if let Some(end) = driver.take_guest_end(&vm_id, GUEST_AGENT_PORT) {
                        found = Some(end);
                        break;
                    }
                    std::thread::sleep(std::time::Duration::from_millis(10));
                }
                found.expect("the runner connected to the guest agent port")
            };
            let host_key = SigningKey::from_bytes(&host_signer).verifying_key();
            let mut session = AuthenticatedSession::guest(
                &mut stream,
                SigningKey::from_bytes(&[9u8; 32]),
                &host_key,
            )
            .expect("guest handshake");
            let req: GuestRequest = session.read(&mut stream).expect("read request");
            assert!(
                matches!(req, GuestRequest::ActivateEnvironment(_)),
                "the first post-boot verb must be ActivateEnvironment, got: {req:?}"
            );
            session
                .write(&mut stream, &GuestResponse::ActivateEnvironmentAck)
                .expect("write ack");
        })
    }

    /// A boot that attached the universal initramfs must be sent
    /// `ActivateEnvironment` over the agent vsock port before the launch
    /// returns — proven by driving `start_workload` through the `MockDriver`
    /// loopback and answering as the guest: the host's request must BE the
    /// activation verb (not an operational RPC), and the launch must succeed
    /// on the ACK. This is the contract every runner driver (Firecracker,
    /// libkrun, HVF, QEMU) inherits: the driver's only part is a working
    /// `vsock_connect(GUEST_AGENT_PORT)`.
    #[test]
    fn start_workload_sends_activate_environment_for_a_universal_initramfs_boot() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        // An initramfs artifact under the shared cache is the discriminant
        // for the universal-initramfs boot path.
        let initrd = std::path::PathBuf::from(mvm_core::config::mvm_cache_dir())
            .join("initramfs")
            .join("test-version")
            .join("initramfs.cpio.gz");
        std::fs::create_dir_all(initrd.parent().expect("initramfs cache parent")).unwrap();
        std::fs::write(&initrd, b"initramfs").unwrap();

        let driver = MockDriver::default();
        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = VmStartConfig {
            name: "runner-activation".into(),
            initrd_path: Some(initrd.to_string_lossy().into_owned()),
            ..config("runner-activation")
        };
        let policy = NetworkPolicy::deny_all();
        let redaction = RedactionPolicy::default();

        // The guest side of the loopback authenticates, verifies that the first
        // request is the activation verb, and acknowledges it.
        let guest = spawn_activation_guest(driver, "runner-activation");

        runner
            .boot_bound_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("start_workload succeeds once activation is ACKed");
        guest.join().expect("guest thread");
    }

    /// A legacy per-rootfs initramfs boot (an initrd NOT under the shared
    /// cache) is never sent `ActivateEnvironment` — the guest keeps its own
    /// PID 1 and the launch proceeds without the handshake.
    #[test]
    fn start_workload_skips_activation_for_a_legacy_initramfs_boot() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let legacy = home.path().join("rootfs.initrd");
        std::fs::write(&legacy, b"initrd").unwrap();

        let driver = MockDriver::default();
        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = VmStartConfig {
            name: "runner-legacy-initrd".into(),
            initrd_path: Some(legacy.to_string_lossy().into_owned()),
            ..config("runner-legacy-initrd")
        };
        let policy = NetworkPolicy::deny_all();
        let redaction = RedactionPolicy::default();
        runner
            .boot_bound_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("a legacy initramfs boot needs no activation handshake");
        // No vsock connect was ever made for activation: the loopback guest
        // end registry is empty.
        assert!(
            driver
                .take_guest_end(&VmId("runner-legacy-initrd".into()), GUEST_AGENT_PORT)
                .is_none(),
            "a legacy initramfs boot must not connect for activation"
        );
    }

    /// An initramfs under the shared cache: the universal-initramfs boot whose
    /// guest waits for `ActivateEnvironment`.
    fn checked_source_launch_config(
        vm: &str,
        admission_durability: Option<mvm_core::admission_durability::AdmissionDurability>,
    ) -> VmStartConfig {
        // These tests prove activation/sync ordering, not runtime
        // authentication, but the launch gate authenticates any runtime the
        // config names — so the fixture supplies a checked one rather than
        // naming an unverifiable initramfs.
        let (fixture_cfg, _binding) = crate::runtime_evidence::checked_source_runtime_fixture(
            vm,
            std::path::Path::new("/img/rootfs.ext4"),
        )
        .expect("checked-source runtime fixture");
        VmStartConfig {
            admission_durability,
            ..fixture_cfg
        }
    }

    fn launch(runner_cfg: &VmStartConfig) -> WorkloadLaunchInputs<'_> {
        static POLICY: std::sync::OnceLock<NetworkPolicy> = std::sync::OnceLock::new();
        static REDACTION: std::sync::OnceLock<RedactionPolicy> = std::sync::OnceLock::new();
        WorkloadLaunchInputs {
            config: runner_cfg,
            tenant: "local",
            secrets: &[],
            redaction: REDACTION.get_or_init(RedactionPolicy::default),
            network_policy: POLICY.get_or_init(NetworkPolicy::deny_all),
            cmdline: String::new(),
        }
    }

    /// The VMM may boot while the admission's audit sync is still running, but
    /// the guest is not activated until it has finished: the sync is held well
    /// past the moment the boot returns, and the guest checks it had completed
    /// once `ActivateEnvironment` has been answered.
    #[test]
    fn activation_waits_for_the_admission_sync() {
        use std::sync::atomic::{AtomicBool, Ordering};

        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let synced = Arc::new(AtomicBool::new(false));
        let (release, held) = std::sync::mpsc::channel::<()>();
        let durability = mvm_core::admission_durability::AdmissionDurability::spawn({
            let synced = Arc::clone(&synced);
            move || {
                held.recv().expect("released");
                synced.store(true, Ordering::SeqCst);
                Ok(())
            }
        })
        .expect("spawn the sync");
        let releaser = std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(200));
            release.send(()).expect("release the sync");
        });

        let driver = MockDriver::default();
        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = checked_source_launch_config("runner-durable-activation", Some(durability));

        let guest = {
            let synced = Arc::clone(&synced);
            let activation = spawn_activation_guest(driver.clone(), "runner-durable-activation");
            std::thread::spawn(move || {
                activation.join().expect("activation guest");
                synced.load(Ordering::SeqCst)
            })
        };
        // The guest thread reads the flag as soon as it has acknowledged
        // activation. A runner that did not wait would be acknowledged within
        // milliseconds, long before the sync is released.
        runner
            .start_workload(&launch(&cfg))
            .expect("the launch activates once the sync succeeds");
        assert!(
            guest.join().expect("guest thread"),
            "ActivateEnvironment was sent before the admission sync finished"
        );
        releaser.join().expect("releaser");
        assert_eq!(driver.booted_specs().len(), 1);
    }

    /// A sync that fails means the admission cannot be shown afterwards. The
    /// booted guest is never sent `ActivateEnvironment` — the runner never
    /// even connects to its agent — and the VMM is killed, not left running.
    #[test]
    fn a_failed_admission_sync_tears_the_guest_down_unactivated() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let driver = MockDriver::default();
        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let vm = "runner-undurable-admission";
        let cfg = checked_source_launch_config(
            vm,
            Some(
                mvm_core::admission_durability::AdmissionDurability::spawn(|| {
                    anyhow::bail!("fdatasync audit/local.jsonl: input/output error")
                })
                .expect("spawn the sync"),
            ),
        );

        let error = match runner.start_workload(&launch(&cfg)) {
            Ok(_) => panic!("a launch whose admission did not reach the log must fail"),
            Err(error) => error,
        };
        assert!(
            format!("{error:#}").contains("input/output error"),
            "the sync failure is what the launch reports: {error:#}"
        );
        assert_eq!(
            driver.booted_specs().len(),
            1,
            "the VMM booted beside the sync"
        );
        assert!(
            driver
                .take_guest_end(&VmId(vm.into()), GUEST_AGENT_PORT)
                .is_none(),
            "the runner must not connect to the agent of a guest it will not activate"
        );
        assert_eq!(
            driver.killed_vms(),
            vec![vm.to_string()],
            "the unactivated guest is killed"
        );
    }

    /// A guest that is not activated over vsock runs its workload on its own
    /// as soon as it boots, so it waits for the admission's sync before the
    /// VMM starts, and a failed sync boots nothing.
    #[test]
    fn a_boot_without_activation_waits_for_the_admission_sync_before_booting() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let legacy = home.path().join("rootfs.initrd");
        std::fs::write(&legacy, b"initrd").unwrap();
        let driver = MockDriver::default();
        let runner = WorkloadRunner::new(
            driver.clone(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let cfg = VmStartConfig {
            name: "runner-legacy-undurable".into(),
            initrd_path: Some(legacy.to_string_lossy().into_owned()),
            admission_durability: Some(
                mvm_core::admission_durability::AdmissionDurability::settled(Err(anyhow::anyhow!(
                    "fdatasync failed"
                ))),
            ),
            ..config("runner-legacy-undurable")
        };

        assert!(runner.start_workload(&launch(&cfg)).is_err());
        assert!(
            driver.booted_specs().is_empty(),
            "nothing boots on an admission that is not durable"
        );
    }

    fn disk_volume(host: &str, guest: &str, read_only: bool) -> mvm_core::vm_backend::VmVolume {
        mvm_core::vm_backend::VmVolume {
            materialized_image: None,
            volume_label: None,
            host: host.into(),
            guest: guest.into(),
            size: String::new(),
            read_only,
            kind: mvm_core::vm_backend::VmVolumeKind::Disk,
            encrypted: false,
        }
    }

    /// A `--volume` disk (claim 11's sealed app-dep disk, or any other
    /// `Disk`-kind volume) must reach a runner-booted guest both as an
    /// attached `BlockDev` and as an `mvm.uvols=` cmdline entry naming it —
    /// otherwise the guest has the bytes on `/dev/vdb` but no manifest saying
    /// what they are for.
    #[test]
    fn start_carries_a_disk_volume_into_both_blocks_and_the_uvols_token() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("w-uvol");
        let cfg = VmStartConfig {
            name: "w-uvol".into(),
            rootfs_path: rootfs,
            volumes: vec![disk_volume("/vol/data.img", "/data", true)],
            ..Default::default()
        };
        mapping_start(&runner, &cfg).expect("start succeeds");

        let specs = runner.driver.booted_specs();
        assert_eq!(specs.len(), 1);
        let spec = &specs[0];

        // The volume follows the rootfs; the private identity drive comes last.
        assert_eq!(
            spec.blocks
                .iter()
                .map(|b| b.device_node())
                .collect::<Vec<_>>(),
            vec!["/dev/vda", "/dev/vdb", "/dev/vdc"]
        );
        assert_eq!(spec.blocks[1].source, PathBuf::from("/vol/data.img"));
        assert!(spec.blocks[1].read_only);
        assert_eq!(
            spec.blocks[2].source,
            vm_state_dir("w-uvol").join(mvm_vmm::host::flowmux_identity::IDENTITY_DRIVE_FILE)
        );
        assert!(spec.blocks[2].read_only);

        assert!(
            spec.cmdline.contains("mvm.uvols=uvol0:"),
            "booted cmdline missing the uvols token: {}",
            spec.cmdline
        );
    }

    #[test]
    fn start_emits_no_uvols_token_when_there_are_no_volumes() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("w-no-uvol");
        let cfg = VmStartConfig {
            name: "w-no-uvol".into(),
            rootfs_path: rootfs,
            ..Default::default()
        };
        mapping_start(&runner, &cfg).expect("start succeeds");

        let specs = runner.driver.booted_specs();
        assert!(
            !specs[0].cmdline.contains("mvm.uvols="),
            "cmdline must carry no uvols token with no volumes: {}",
            specs[0].cmdline
        );
    }

    /// The lifted admission gate: `VmBackend::start` refuses a rootfs whose
    /// parent dir carries no overlay-aware sidecar (no `/mvm/runtime` mount
    /// point) before any endpoint spawn or boot, and on an admitted boot it
    /// records the per-VM runtime metadata the console accessible/sealed gate
    /// reads. Drives the whole trait method through a `MockDriver`.
    #[test]
    fn start_refuses_a_rootfs_without_the_overlay_sidecar_and_records_runtime_meta() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        // A rootfs whose parent dir carries no sidecar is refused before boot.
        let bare = tempfile::tempdir().unwrap();
        let bare_rootfs = bare.path().join("rootfs.ext4");
        std::fs::write(&bare_rootfs, b"rootfs").unwrap();
        let refused = VmStartConfig {
            name: "runner-gate-refused".into(),
            rootfs_path: bare_rootfs.display().to_string(),
            ..Default::default()
        };
        let err = runner
            .start(&refused)
            .expect_err("a rootfs with no overlay-aware sidecar must be refused");
        assert!(
            err.to_string().contains("mvm-meta.json"),
            "refusal must name the missing sidecar: {err}"
        );
        assert!(
            runner.driver.booted_specs().is_empty(),
            "the gate must fire before any boot"
        );

        // An overlay-aware rootfs is admitted, and start records runtime_meta so
        // the console accessible/sealed gate has a per-VM record to read.
        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("runner-gate-admitted");
        let admitted = VmStartConfig {
            name: "runner-gate-admitted".into(),
            rootfs_path: rootfs,
            ..Default::default()
        };
        ClaimGuards::new(&runner.spawner)
            .admit_overlay_contract(Path::new(&admitted.rootfs_path))
            .expect("an overlay-aware rootfs is admitted");
        mapping_start(&runner, &admitted).expect("admitted shape maps to a boot");
        let meta = crate::base::runtime_meta::read("runner-gate-admitted")
            .expect("runtime_meta read")
            .expect("start records runtime_meta");
        assert_eq!(
            meta.rootfs_path.as_deref(),
            Some(admitted.rootfs_path.as_str())
        );
    }

    /// [`overlay_aware_rootfs`] with a real ext4 filesystem behind it, so an
    /// offline checker or a journal replay run against the image would have
    /// something to rewrite. `needs_recovery` sets the superblock flag a dirty
    /// journal leaves behind.
    fn overlay_aware_ext4_rootfs(name: &str, needs_recovery: bool) -> (tempfile::TempDir, String) {
        let (dir, rootfs) = overlay_aware_rootfs(name);
        let mut image = std::fs::File::create(&rootfs).unwrap();
        let size = 8 * 1024 * 1024;
        image.set_len(size).unwrap();
        mvm_fs::ext4::mkfs::format_empty_ext4(&mut image, size).unwrap();
        drop(image);
        if needs_recovery {
            let mut bytes = std::fs::read(&rootfs).unwrap();
            // s_feature_incompat, EXT4_FEATURE_INCOMPAT_RECOVER.
            bytes[1024 + 0x60] |= 0x4;
            std::fs::write(&rootfs, bytes).unwrap();
        }
        (dir, rootfs)
    }

    /// The image a launch admitted is the image the VMM boots. Admission hashes
    /// the rootfs before `start`, and the cached default image is shared by
    /// every later launch, so `start` must not rewrite it — not even the
    /// superblock timestamps an offline filesystem check stamps on a clean
    /// image.
    #[test]
    fn start_boots_the_admitted_rootfs_without_rewriting_it() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let (_dir, rootfs) = overlay_aware_ext4_rootfs("runner-rootfs-unchanged", false);
        let admitted = mvm_core::crypto::image_verify::sha256_file(Path::new(&rootfs)).unwrap();
        let cfg = VmStartConfig {
            name: "runner-rootfs-unchanged".into(),
            rootfs_path: rootfs.clone(),
            ..Default::default()
        };

        mapping_start(&runner, &cfg).expect("a clean rootfs boots");

        assert_eq!(
            mvm_core::crypto::image_verify::sha256_file(Path::new(&rootfs)).unwrap(),
            admitted,
            "start rewrote the rootfs after it was admitted"
        );
        let specs = runner.driver.booted_specs();
        assert_eq!(specs[0].blocks[0].source, PathBuf::from(&rootfs));
        assert!(
            specs[0].blocks[0].read_only,
            "the guest must not be able to write the shared image either"
        );
    }

    #[test]
    fn start_refuses_a_rootfs_whose_journal_needs_replay_before_boot() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let (_dir, rootfs) = overlay_aware_ext4_rootfs("runner-rootfs-dirty", true);
        let before = std::fs::read(&rootfs).unwrap();
        let cfg = VmStartConfig {
            name: "runner-rootfs-dirty".into(),
            rootfs_path: rootfs.clone(),
            ..Default::default()
        };

        let err = runner
            .start(&cfg)
            .expect_err("a read-only guest cannot mount a journal that needs replay");

        assert!(err.to_string().contains(&rootfs), "names the image: {err}");
        assert!(
            runner.driver.booted_specs().is_empty(),
            "the refusal must come before any boot"
        );
        assert_eq!(
            std::fs::read(&rootfs).unwrap(),
            before,
            "the refused image must be left exactly as it was"
        );
    }

    #[test]
    fn vmbackend_name_and_capabilities_delegate_to_the_driver() {
        let driver = MockDriver::default();
        let want_name = driver.name().to_string();
        let want_caps = driver.capabilities();
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        assert_eq!(runner.name(), want_name);
        assert_eq!(runner.capabilities().vsock, want_caps.vsock);
        assert!(runner.is_available().unwrap());
    }

    #[test]
    fn vmbackend_kind_snapshot_security_and_channel_delegate_to_the_hvf_driver() {
        // Proves the runner reads these from the driver rather than the old
        // `BackendKind::Hvf` hardcode / the VmBackend trait's fail-closed
        // defaults — a runner wrapping a *different* driver would report that
        // driver's own values instead.
        let driver = HvfDriver::new();
        let want_kind = driver.kind();
        let want_snapshot = driver.snapshot_capability();
        let want_security_tier = driver.security_profile().tier;
        let id = VmId("kind-delegation-test-vm".into());
        let want_channel_err = driver.guest_channel_info(&id).is_err();
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        assert_eq!(runner.kind(), want_kind);
        assert_eq!(runner.kind(), BackendKind::Hvf);
        assert_eq!(runner.snapshot_capability(), want_snapshot);
        assert_eq!(runner.security_profile().tier, want_security_tier);
        assert_eq!(runner.guest_channel_info(&id).is_err(), want_channel_err);
    }

    #[test]
    fn start_workload_with_dev_console_threads_128_console_ports_into_spec() {
        use mvm_agentd::vsock::CONSOLE_PORT_BASE;
        let (_env, _home) = isolated_runtime_home();
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let cfg = VmStartConfig {
            dev_console: true,
            ..config("w-dev-console")
        };
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "t",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("start_workload with dev_console succeeds");

        let specs = runner.driver.booted_specs();
        let spec = &specs[0];

        // Four standing channels plus 128 console data channels.
        assert_eq!(spec.vsock.len(), 132);

        // Every console port is in range and routed as HostDials.
        let console: Vec<_> = spec
            .vsock
            .iter()
            .filter(|p| p.service.port() > CONSOLE_PORT_BASE)
            .collect();
        assert_eq!(console.len(), 128);
        assert!(
            console
                .iter()
                .all(|p| p.direction == crate::driver::VsockDirection::HostDials),
            "console ports must be HostDials"
        );

        // Paths live under <state_dir>/vsock/ — the shared HVF vsock convention.
        let first = &console[0];
        assert!(
            first.host_uds.to_string_lossy().contains("/vsock/vsock-"),
            "path must be under vsock/ subdir: {}",
            first.host_uds.display()
        );
    }

    #[test]
    fn start_workload_without_dev_console_carries_only_four_vsock_entries() {
        let (_env, _home) = isolated_runtime_home();
        let policy = egress_allowing_policy();
        let redaction = RedactionPolicy::default();
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        let cfg = VmStartConfig {
            dev_console: false,
            ..config("w-sealed")
        };
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &cfg,
                tenant: "t",
                secrets: &[],
                redaction: &redaction,
                network_policy: &policy,
                cmdline: String::new(),
            })
            .expect("start_workload without dev_console succeeds");

        let specs = runner.driver.booted_specs();
        let spec = &specs[0];
        assert_eq!(
            spec.vsock.len(),
            4,
            "sealed prod boot must carry no console listeners"
        );
    }

    /// A spawned parent is claimable only once captured: the handle must carry
    /// the checkpoint a later claim verifies content and lineage against, and
    /// that checkpoint must carry saved memory — a rootfs-only capture would
    /// make every claim a cold boot.
    #[test]
    fn spawn_standby_captured_stamps_a_memory_carrying_checkpoint() {
        use mvm_core::checkpoint::CheckpointClass;

        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let launch = checked_source_config("workload-a", rootfs.display().to_string());
        let spec = standby_spec_for("parent-a", tmp.path(), &launch);
        let guest = spawn_activation_guest(runner.driver.clone(), &spec.id);
        let handle = runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: Some(&launch),
                },
                &spec,
            )
            .unwrap();
        guest.join().unwrap();

        let id = handle
            .parent_checkpoint
            .expect("a captured parent must carry its checkpoint id");
        let meta = store.read_meta(&CheckpointId::new(id)).unwrap();
        assert_eq!(meta.class, CheckpointClass::VmFull);
        assert!(
            meta.content.iter().any(|b| b.name == "memory.bin"),
            "the capture must carry saved memory, got: {:?}",
            meta.content.iter().map(|b| &b.name).collect::<Vec<_>>()
        );
        // The parent is released once captured — a pool slot costs disk, not a
        // resident VM — and the handle says so.
        assert_eq!(handle.pid, 0, "a captured parent backs no live process");
        assert!(
            runner.driver.killed_vms().contains(&spec.id),
            "the captured parent must be stopped, got: {:?}",
            runner.driver.killed_vms()
        );
    }

    /// A backend that keeps the paused source resident after capture hands the
    /// claim a handle that still names the live process, and does not stop it.
    #[test]
    fn spawn_standby_captured_keeps_a_retained_parent_resident() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default()
                .with_vm_full_rootfs(&rootfs)
                .with_retained_paused_source(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let launch = checked_source_config("workload-a", rootfs.display().to_string());
        let spec = standby_spec_for("parent-retained", tmp.path(), &launch);
        let guest = spawn_activation_guest(runner.driver.clone(), &spec.id);
        let handle = runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: Some(&launch),
                },
                &spec,
            )
            .unwrap();
        guest.join().unwrap();
        assert_eq!(handle.pid, std::process::id());
        assert!(!runner.driver.killed_vms().contains(&spec.id));
    }

    /// The trusted-snapshot backend is opened only on a macOS build that has the
    /// feature; setting its switch elsewhere must not change how a parent is
    /// captured.
    #[test]
    fn the_trusted_snapshot_switch_does_not_reroute_a_capture_on_a_build_without_the_backend() {
        if cfg!(all(feature = "trusted-apfs", target_os = "macos")) {
            return;
        }
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        env.set("MVM_HVF_ENABLE_TRUSTED_SNAPSHOT", "1");

        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();
        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let launch = checked_source_config("workload-a", rootfs.display().to_string());
        let spec = standby_spec_for("parent-switch", tmp.path(), &launch);
        let guest = spawn_activation_guest(runner.driver.clone(), &spec.id);
        runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: Some(&launch),
                },
                &spec,
            )
            .expect("the switch is inert without the backend");
        guest.join().unwrap();
    }

    #[test]
    fn a_runner_reports_the_standby_capabilities_of_its_driver() {
        let plain = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        assert!(!plain.supports_preloaded_standby());
        assert_eq!(plain.late_volume_slots(), 0);
        let slotted = WorkloadRunner::new(
            MockDriver::default()
                .with_preloaded_standby()
                .with_late_volume_slots(4),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        assert!(slotted.supports_preloaded_standby());
        assert_eq!(slotted.late_volume_slots(), 4);
    }

    /// An unsigned source-built runtime is booted on the cmdline the runner
    /// derives from the bound launch, never on the one the caller supplied.
    #[test]
    fn a_checked_source_launch_boots_the_derived_cmdline_not_the_supplied_one() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let (_image, rootfs) = overlay_aware_rootfs("checked-cmdline");
        let config = checked_source_config("checked-cmdline", rootfs.clone());
        let driver = MockDriver::default().with_vm_full_rootfs(Path::new(&rootfs));
        let guest = spawn_activation_guest(driver.clone(), "checked-cmdline");
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let redaction = RedactionPolicy::default();
        runner
            .start_workload(&WorkloadLaunchInputs {
                config: &config,
                tenant: "local",
                secrets: &[],
                redaction: &redaction,
                network_policy: &config.network_policy,
                cmdline: "mvm.supplied_sentinel=1".into(),
            })
            .unwrap();
        guest.join().unwrap();
        let specs = runner.driver.booted_specs();
        assert!(
            !specs[0].cmdline.contains("mvm.supplied_sentinel"),
            "{}",
            specs[0].cmdline
        );
    }

    /// The launch a warm parent is spawned for: a plain sealed boot whose rootfs
    /// is the one the parent will attach.
    fn standby_launch_config(rootfs: &Path) -> VmStartConfig {
        VmStartConfig {
            name: "workload-a".into(),
            rootfs_path: rootfs.display().to_string(),
            kernel_path: Some("/img/kernel".into()),
            cpus: 2,
            memory_mib: 512,
            // Every launch carries the overlay triple — it is the only source
            // of the guest agent, so a parent warmed without one cannot reach
            // an agent to be captured.
            runtime_overlay_path: Some("/img/runtime.ext4".into()),
            runtime_overlay_verity_path: Some("/img/runtime.verity".into()),
            runtime_overlay_roothash: Some("b".repeat(64)),
            ..Default::default()
        }
    }

    /// A pool record for a parent of `rootfs`, booting no guest egress client.
    /// Tests that warm a parent *for a launch* go through [`standby_spec_for`]
    /// instead, so the record they match on is the one a real spawn would write.
    fn sample_standby_spec(
        id: &str,
        vm_state_dir: &Path,
        rootfs: &Path,
    ) -> mvm_core::vm_backend::StandbySpec {
        mvm_core::vm_backend::StandbySpec {
            id: id.to_string(),
            template_id: None,
            kernel_path: "/img/kernel".into(),
            kernel_sha256: "a".repeat(64),
            vcpus: 2,
            mem_mib: 512,
            signing_key_path: "/keys/host-signer.ed25519".into(),
            signer_id: "host:test".into(),
            binding_nonce: "b".repeat(64),
            control_socket: vm_state_dir.join("control.sock").display().to_string(),
            vm_state_dir: vm_state_dir.display().to_string(),
            image_path: Some(rootfs.display().to_string()),
            image_sha256: Some("c".repeat(64)),
            root_strategy: Default::default(),
            vsock_egress: false,
        }
    }

    /// The pool record a spawn for `launch` would write: the base fixture plus
    /// the egress enablement the compat-key builder derives from that launch, so
    /// the parent boots the value a claim for the same launch would match on.
    fn standby_spec_for(
        id: &str,
        vm_state_dir: &Path,
        launch: &VmStartConfig,
    ) -> mvm_core::vm_backend::StandbySpec {
        mvm_core::vm_backend::StandbySpec {
            vsock_egress: mvm_vmm::host::egress_shared::effective_vsock_egress(launch),
            ..sample_standby_spec(id, vm_state_dir, Path::new(&launch.rootfs_path))
        }
    }

    /// A spawn-and-capture records a clean, pre-workload parent: the pool
    /// round-trip the CLI runs afterwards sees an idle standby, and — the
    /// invariant this test actually exercises — no substitution endpoint and no
    /// broker are ever stood up for it, unlike every real workload boot on this
    /// runner. Those two are the host-side authority a parent must never hold.
    #[test]
    fn spawn_standby_captured_records_a_parent_with_no_endpoint_and_no_broker() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let launch = checked_source_config("workload-a", rootfs.display().to_string());
        let spec = standby_spec_for("standby-test", &tmp.path().join("vm"), &launch);
        let guest = spawn_activation_guest(runner.driver.clone(), &spec.id);
        let handle = runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: Some(&launch),
                },
                &spec,
            )
            .expect("spawn_standby_captured succeeds through the mock driver");
        guest.join().unwrap();

        let pool = crate::standby_pool::SupervisorStandbyPool::at(tmp.path().join("pool"));
        pool.record(&handle).unwrap();
        let recorded = pool.list().unwrap();
        assert_eq!(recorded.len(), 1);
        assert!(matches!(
            recorded[0].state,
            mvm_core::vm_backend::StandbyState::Idle
        ));

        // The parent boots with no vsock channel at all: no egress relay, no
        // broker port, no exit report — so a stray guest dial to any of them
        // stays ECONNREFUSED. Only a claimed child gets those three; parents and
        // workloads live in disjoint namespaces and this is where that holds.
        let booted = runner.driver.booted_specs();
        assert_eq!(booted.len(), 1);
        let identity = booted[0].blocks.last().unwrap();
        assert_eq!(
            identity.source,
            Path::new(&spec.vm_state_dir)
                .join(mvm_vmm::host::flowmux_identity::IDENTITY_DRIVE_FILE)
        );
        assert!(identity.read_only);
        assert!(
            booted[0].vsock.is_empty(),
            "parent boot must carry no vsock channel (no egress, broker or exit channel), got: {:?}",
            booted[0]
                .vsock
                .iter()
                .map(|p| p.service.port())
                .collect::<Vec<_>>()
        );

        // No substitution endpoint and no broker were stood up for the parent:
        // neither double was ever invoked, unlike every real `start_workload`.
        assert!(
            runner.spawner.seen.lock().unwrap().is_none(),
            "a standby parent must never get a substitution endpoint"
        );
        assert!(
            runner.broker.seen.lock().unwrap().is_none(),
            "a standby parent must never get a host-services broker"
        );
    }

    #[test]
    fn standby_parent_refuses_missing_identity_before_boot() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let rootfs = home.path().join("rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs").unwrap();
        let launch = standby_launch_config(&rootfs);
        let spec = standby_spec_for("no-identity", &home.path().join("parent"), &launch);
        let store = CheckpointStore::at(home.path().join("checkpoints"));
        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RealNetworkEndpointSpawner,
            RecordingBrokerRegistrar::new(),
        );
        let error = mapping_standby(
            &runner,
            &SpawnContext {
                checkpoints: &store,
                launch: Some(&launch),
            },
            &spec,
        )
        .unwrap_err();
        assert!(
            error
                .to_string()
                .contains("provision standby guest identity"),
            "{error}"
        );
        assert!(runner.driver.booted_specs().is_empty());
        assert!(runner.broker.seen.lock().unwrap().is_none());
    }

    /// A parent's cmdline gets the same truncation refusal a workload's does,
    /// and needs it more: a child inherits the parent's cmdline out of restored
    /// memory rather than deriving its own, so a parent booted with its trailing
    /// tokens silently dropped by the kernel hands that loss to every child.
    #[test]
    fn spawn_standby_captured_refuses_a_parent_cmdline_the_kernel_would_truncate() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let mut launch = standby_launch_config(&rootfs);
        // A sealed boot; the universal initramfs moves the roothash off the
        // cmdline, so force an overflow with an oversized verb grant instead.
        launch.verity_path = Some(tmp.path().join("rootfs.verity").display().to_string());
        launch.roothash = Some("a".repeat(4096));
        launch.initrd_path = Some(mvm_vmm::host::cmdline::seed_universal_initramfs(
            home.path(),
        ));
        let state_dir = mvm_core::config::vm_state_dir("parent-oversized");
        std::fs::create_dir_all(&state_dir).unwrap();
        let nonce = mvm_core::plan::Nonce::from_bytes([3u8; 16]);
        let not_after = mvm_core::time::parse_iso8601("2099-01-01T00:00:00Z").unwrap();
        let envelope = mvm_core::protocol::vm_backend::VerbGrantEnvelope {
            pubkey_hex: "cc".repeat(32),
            plan_nonce_hex: nonce.as_hex().to_string(),
            predecessor_session_id: None,
            predecessor_plan_nonce_hex: None,
            grant: mvm_core::plan::VerbGrant {
                session_id: "parent-oversized".into(),
                plan_nonce: nonce,
                not_after,
                verbs: vec![mvm_core::plan::VerbId::new(&"a".repeat(4000)).unwrap()],
                drive: None,
                tool_mediation: None,
                application_terminal: None,
                owner_access: None,
                sig: vec![0u8; 64],
            },
        };
        std::fs::write(
            state_dir.join("verb-grant.json"),
            serde_json::to_vec(&envelope).unwrap(),
        )
        .unwrap();
        // Derive the spec from this launch: the compat key now carries the
        // launch's egress enablement, so a spec built from the rootfs alone
        // could refuse for a mismatched key rather than the oversized cmdline
        // this test is about.
        let spec = standby_spec_for("parent-oversized", tmp.path(), &launch);

        let err = mapping_standby(
            &runner,
            &SpawnContext {
                checkpoints: &store,
                launch: Some(&launch),
            },
            &spec,
        )
        .expect_err("an oversized parent cmdline must be refused before the boot");

        assert!(
            matches!(err, StandbyError::SpawnFailed(ref m) if m.contains("command line")),
            "expected a SpawnFailed naming the kernel command line, got: {err:?}"
        );
        assert!(
            runner.driver.booted_specs().is_empty(),
            "nothing may boot before the refusal"
        );
    }

    /// A spawn with no launch to mirror is refused outright. The alternative —
    /// inventing a default boot shape — is what produced a parent that booted a
    /// bare rootfs while every workload booted a verity-sealed stack plus the
    /// runtime overlay carrying the guest agent.
    #[test]
    fn spawn_standby_captured_refuses_without_the_launch_it_must_mirror() {
        let tmp = tempfile::tempdir().unwrap();
        let store = CheckpointStore::at(tmp.path().join("checkpoints"));
        let rootfs = tmp.path().join("parent-rootfs.ext4");
        std::fs::write(&rootfs, b"parent rootfs bytes").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default().with_vm_full_rootfs(&rootfs),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let spec = sample_standby_spec("parent-a", tmp.path(), &rootfs);

        let err = runner
            .spawn_standby_captured(
                &SpawnContext {
                    checkpoints: &store,
                    launch: None,
                },
                &spec,
            )
            .expect_err("a parent cannot be assembled without the launch it serves");

        assert!(
            matches!(err, StandbyError::SpawnFailed(ref m) if m.contains("launch config")),
            "expected a SpawnFailed naming the missing launch, got: {err:?}"
        );
        assert!(
            runner.driver.booted_specs().is_empty(),
            "nothing may boot before the refusal"
        );
    }

    /// The same guard as `standby_boot`'s, but through the runner's real
    /// wiring: the shipped defect was not that the mappers disagreed, it was
    /// that the spawn path never called them. Boot a sealed, overlay-carrying
    /// launch as a workload and then warm a parent for it, and the two specs
    /// the driver was handed must describe the same guest.
    #[test]
    fn the_parent_and_the_workload_boot_the_same_shape_through_the_runner() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let (dir, rootfs) = overlay_aware_rootfs("shape-parity");
        std::fs::write(dir.path().join("rootfs.verity"), b"verity").unwrap();
        let source = checked_source_config("shape-parity", rootfs.clone());
        let lease =
            crate::runtime_evidence::RuntimeLifecycleLease::acquire("shape-parity").unwrap();
        let bound = lease.bind(&source).unwrap();
        let launch = VmStartConfig {
            verity_path: Some(dir.path().join("rootfs.verity").display().to_string()),
            roothash: Some("a".repeat(64)),
            cpus: 2,
            memory_mib: 512,
            ..bound
        };

        let store = CheckpointStore::at(home.path().join("checkpoints"));
        let driver = MockDriver::default().with_vm_full_rootfs(Path::new(&rootfs));
        let guest = spawn_activation_guest(driver.clone(), "shape-parity");
        let parent_guest = spawn_activation_guest(driver.clone(), "standby-parity");
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        mapping_start(&runner, &launch).expect("workload boots");
        guest.join().expect("guest thread");
        let spec = standby_spec_for(
            "standby-parity",
            &home.path().join("standby-parity"),
            &launch,
        );
        mapping_standby(
            &runner,
            &SpawnContext {
                checkpoints: &store,
                launch: Some(&launch),
            },
            &spec,
        )
        .expect("warm parent spawns for that launch");
        parent_guest.join().expect("parent guest thread");

        let booted = runner.driver.booted_specs();
        assert_eq!(booted.len(), 2, "one workload boot, then one parent boot");
        let (workload, parent) = (&booted[0], &booted[1]);
        // Non-vacuity: the fixture must actually exercise the full sealed stack,
        // or "the two match" would say nothing.
        assert_eq!(
            workload.blocks.len(),
            5,
            "fixture must boot rootfs + verity + overlay + overlay verity + identity"
        );
        assert_boot_disks_and_private_identity(parent, workload, Path::new(&spec.vm_state_dir));
        assert_eq!(
            without_per_boot_tokens(&parent.cmdline),
            without_per_boot_tokens(&workload.cmdline)
        );
        assert!(!parent.cmdline.contains("mvm.hostname="));
        assert_eq!(parent.kernel, workload.kernel);
        assert_eq!(parent.initramfs, workload.initramfs);
    }

    /// The same parity, for the launch shape the pool used to refuse: one whose
    /// policy allows egress.
    ///
    /// A restored child inherits its cmdline from the parent's saved memory, so
    /// the only way a warm child ends up with the guest egress client a cold boot
    /// would have started is for the parent to have started it. This drives both
    /// paths through the real runner wiring and requires the two specs to be
    /// equal — and it names the token, so a failure says which side lost it. The
    /// parent still gets no substitution endpoint and no broker: what it boots is
    /// the enablement, not the authority.
    #[test]
    fn a_parent_warmed_for_an_egress_allowing_launch_boots_that_launchs_shape() {
        use mvm_core::network_policy::HostPort;

        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        // `_dir` holds the rootfs's temp dir alive for the whole test.
        let (_dir, rootfs) = overlay_aware_rootfs("egress-parity");
        let source = checked_source_config("egress-parity", rootfs.clone());
        let lease =
            crate::runtime_evidence::RuntimeLifecycleLease::acquire("egress-parity").unwrap();
        let bound = lease.bind(&source).unwrap();
        let launch = VmStartConfig {
            network_policy: NetworkPolicy::allow_list(vec![HostPort::new("api.example.com", 443)]),
            cpus: 2,
            memory_mib: 512,
            ..bound
        };

        let store = CheckpointStore::at(home.path().join("checkpoints"));
        let driver = MockDriver::default().with_vm_full_rootfs(Path::new(&rootfs));
        let guest = spawn_activation_guest(driver.clone(), "egress-parity");
        let parent_guest = spawn_activation_guest(driver.clone(), "standby-egress-parity");
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        mapping_start(&runner, &launch).expect("workload boots");
        guest.join().unwrap();
        let spec = standby_spec_for(
            "standby-egress-parity",
            &home.path().join("standby-egress-parity"),
            &launch,
        );
        assert!(
            spec.vsock_egress,
            "the compat key for this launch must ask for an egress-enabled parent"
        );
        mapping_standby(
            &runner,
            &SpawnContext {
                checkpoints: &store,
                launch: Some(&launch),
            },
            &spec,
        )
        .expect("warm parent spawns for an egress-allowing launch");
        parent_guest.join().unwrap();

        let booted = runner.driver.booted_specs();
        assert_eq!(booted.len(), 2, "one workload boot, then one parent boot");
        let (workload, parent) = (&booted[0], &booted[1]);
        assert!(
            workload.cmdline.contains("mvm.vsock_egress=1"),
            "fixture must boot the guest egress client: {}",
            workload.cmdline
        );
        assert!(
            parent.cmdline.contains("mvm.vsock_egress=1"),
            "the parent must boot it too, or every child restored from it has no network: {}",
            parent.cmdline
        );
        assert_eq!(
            without_per_boot_tokens(&parent.cmdline),
            without_per_boot_tokens(&workload.cmdline)
        );
        assert!(!parent.cmdline.contains("mvm.hostname="));
        assert_boot_disks_and_private_identity(parent, workload, Path::new(&spec.vm_state_dir));
        assert!(
            !parent.cmdline.contains("api.example.com"),
            "the parent's cmdline must name no destination: {}",
            parent.cmdline
        );
        assert!(
            parent.vsock.is_empty(),
            "an egress-enabled parent still wires no egress channel to dial"
        );
        assert!(!parent.trusted_builder);
    }

    fn assert_boot_disks_and_private_identity(
        parent: &mvm_vmm::driver::spec::VmmSpec,
        workload: &mvm_vmm::driver::spec::VmmSpec,
        parent_state: &Path,
    ) {
        let (parent_identity, parent_disks) = parent.blocks.split_last().unwrap();
        let (workload_identity, workload_disks) = workload.blocks.split_last().unwrap();
        assert_eq!(
            parent_disks, workload_disks,
            "parent retains the workload's disk stack"
        );
        for (identity, state) in [
            (parent_identity, parent_state.to_path_buf()),
            (workload_identity, vm_state_dir(&workload.name)),
        ] {
            assert_eq!(
                identity.source,
                state.join(mvm_vmm::host::flowmux_identity::IDENTITY_DRIVE_FILE)
            );
            assert!(identity.read_only);
            assert!(!identity.ephemeral);
        }
        assert_ne!(parent_identity.source, workload_identity.source);
        assert_eq!(
            parent_identity.device_node(),
            workload_identity.device_node()
        );
    }

    // ── Warm claim: the guarded fork of a clean parent into a fresh child ──────

    use mvm_core::checkpoint::CheckpointDigest;
    use mvm_core::crypto::vmgenid::GENID_BYTES;
    use mvm_core::vm_backend::StandbyState;

    use crate::checkpoint::capture_vm_full;

    /// A `CheckpointChainAnchor` double: reports the parent as audited (echoing
    /// its own recomputed creation digest) so the lineage gate passes, and every
    /// other checkpoint as un-audited.
    struct ClaimTestAnchor {
        verdicts: std::collections::HashMap<String, CheckpointDigest>,
    }

    impl ClaimTestAnchor {
        fn audited(meta: &CheckpointMeta) -> Self {
            let mut verdicts = std::collections::HashMap::new();
            verdicts.insert(meta.id.to_string(), meta.compute_meta_digest());
            Self { verdicts }
        }

        /// No signed creation entry for any checkpoint → the lineage gate refuses
        /// the parent as un-audited.
        fn unaudited() -> Self {
            Self {
                verdicts: std::collections::HashMap::new(),
            }
        }
    }

    impl CheckpointChainAnchor for ClaimTestAnchor {
        fn recorded_creation_tenant(&self, _meta: &CheckpointMeta) -> Result<Option<String>> {
            Ok(None)
        }

        fn recorded_creation_digest(
            &self,
            meta: &CheckpointMeta,
        ) -> Result<Option<CheckpointDigest>> {
            Ok(self.verdicts.get(&meta.id.to_string()).cloned())
        }
    }

    /// An `NetworkEndpointSpawner` double that keys its returned socket on the vm name it
    /// is handed — mirroring `RealNetworkEndpointSpawner` — and records that name, so a
    /// test can prove the child endpoint is keyed on the child's own id and the
    /// parent got none, with no real endpoint process.
    #[derive(Default)]
    struct KeyingSpawner {
        seen_vm: Mutex<Option<String>>,
    }

    impl NetworkEndpointSpawner for KeyingSpawner {
        fn prepare_identity(
            &self,
            req: &NetworkEndpointSpawnRequest<'_>,
        ) -> Result<Option<PathBuf>> {
            Ok(
                matches!(req.identity, FlowMuxIdentitySource::Mint).then(|| {
                    req.state_dir
                        .join(mvm_vmm::host::flowmux_identity::IDENTITY_DRIVE_FILE)
                }),
            )
        }

        fn spawn(&self, req: &NetworkEndpointSpawnRequest<'_>) -> Result<SpawnedEndpoint> {
            *self.seen_vm.lock().unwrap() = Some(req.vm_name.to_string());
            Ok(SpawnedEndpoint {
                egress_uds: vm_network_endpoint_socket(req.vm_name),
                identity_drive: None,
            })
        }
    }

    /// Seed a clean, audited, pre-workload parent checkpoint and return
    /// `(store, snapshots, parent_id, parent_meta)`. With `with_overlay_sidecar`
    /// the source rootfs carries an overlay-aware sidecar so its clone clears the
    /// same host gate a cold boot runs; without it, the child's overlay-contract
    /// gate refuses — the wiring witness. The `TempDir`s must outlive the stores.
    fn seed_audited_parent(
        store_root: &Path,
        src_root: &Path,
        with_overlay_sidecar: bool,
    ) -> (
        CheckpointStore,
        FsSnapshotStore,
        CheckpointId,
        CheckpointMeta,
    ) {
        seed_audited_parent_with_grants(store_root, src_root, with_overlay_sidecar, None)
    }

    /// Seed a warm parent whose sealed record carries `grants`, so a claim has a
    /// real permission set to be bounded against.
    fn seed_audited_parent_with_grants(
        store_root: &Path,
        src_root: &Path,
        with_overlay_sidecar: bool,
        grants: Option<mvm_contract::grants::Grants>,
    ) -> (
        CheckpointStore,
        FsSnapshotStore,
        CheckpointId,
        CheckpointMeta,
    ) {
        seed_audited_parent_in(
            CheckpointStore::at(store_root.join("checkpoints")),
            store_root,
            src_root,
            with_overlay_sidecar,
            grants,
        )
    }

    /// Seed a warm parent into `checkpoints`, which decides whether the
    /// capture is sealed.
    fn seed_audited_parent_in(
        checkpoints: CheckpointStore,
        store_root: &Path,
        src_root: &Path,
        with_overlay_sidecar: bool,
        grants: Option<mvm_contract::grants::Grants>,
    ) -> (
        CheckpointStore,
        FsSnapshotStore,
        CheckpointId,
        CheckpointMeta,
    ) {
        let snapshots = FsSnapshotStore::new(store_root.join("snapshots")).unwrap();

        let rootfs = src_root.join("rootfs.ext4");
        std::fs::write(&rootfs, b"clean-parent-rootfs").unwrap();
        if with_overlay_sidecar {
            // runtime_lean=true so the overlay sidecar clears the gate under every
            // runtime-source policy, exactly like the cold-boot admission tests.
            mvm_build::builder_vm::GuestSidecar::for_oci_run("warm-parent", false, true)
                .write_to_dir(src_root)
                .unwrap();
        }

        // The synthetic parent carries checked-source evidence. Only execution
        // and the audit anchor are mocked; runtime verification is not.
        let runtime_config = checked_source_config("warm-parent", rootfs.display().to_string());
        let lease = crate::runtime_evidence::RuntimeLifecycleLease::acquire("warm-parent").unwrap();
        let bound = lease.bind(&runtime_config).unwrap();
        crate::base::runtime_meta::record_from_start_config(
            "warm-parent",
            StartMode::Detached,
            &bound,
        )
        .unwrap();
        let runtime_binding = crate::base::runtime_meta::read("warm-parent")
            .unwrap()
            .unwrap()
            .runtime_launch_binding;
        drop(lease);
        let parent_id = CheckpointId::new("warm-parent-cp");
        let driver = MockDriver::default().with_vm_full_rootfs(&rootfs);
        let boot = factory_parent_spec(&bound, &vm_state_dir("warm-parent"), |has_disk| {
            driver.workload_base_bootargs(has_disk)
        });
        driver.boot(&boot).unwrap();
        let control = driver.vm_full_control("warm-parent").unwrap();
        let parent_meta = capture_vm_full(
            &checkpoints,
            CaptureVmFullParams {
                id: parent_id.clone(),
                vm_name: "warm-parent".into(),
                supervisor_config_digest: "d".into(),
                runtime_overlay_version: bound.runtime_overlay_version,
                runtime_launch_binding: runtime_binding,
                supervisor_config_src: None,
                tag: None,
                created_unix: 1,
                retain_paused: false,
                grants,
                parent: None,
                session: None,
                workspace_volumes: Vec::new(),
                key_domain: mvm_core::checkpoint::CheckpointKeyDomain::host(),
            },
            control.as_ref(),
        )
        .unwrap();
        let snapshot_id = format!(
            "checkpoint-{parent_id}-content-{}",
            mvm_core::checkpoint::content_manifest_digest(&parent_meta.content)
        );
        snapshots
            .create(
                &mvm_fs::snapshot_store::SnapshotId::with_digest(
                    snapshot_id.clone(),
                    mvm_core::checkpoint::content_manifest_digest(&parent_meta.content).to_string(),
                ),
                &checkpoints.content_dir(&parent_id),
            )
            .unwrap();
        let parent_meta = parent_meta.with_snapshot_id(snapshot_id);
        checkpoints.write_meta(&parent_meta).unwrap();
        (checkpoints, snapshots, parent_id, parent_meta)
    }

    fn materialized_parent_rootfs_digest(
        checkpoints: &CheckpointStore,
        parent: &CheckpointMeta,
    ) -> String {
        materialized_blob_sha256(checkpoints, parent, mvm_core::checkpoint::ROOTFS_BLOB).unwrap()
    }

    /// A warm parent captured under the host key, as production captures it,
    /// with a child preloaded from it by the runner's own pool-refill path.
    struct ProtectedPreloadedParent {
        _env: TestEnv,
        _home: tempfile::TempDir,
        store_root: tempfile::TempDir,
        src: tempfile::TempDir,
        checkpoints: CheckpointStore,
        snapshots: FsSnapshotStore,
        parent_id: CheckpointId,
        parent_meta: CheckpointMeta,
        pool: SupervisorStandbyPool,
        handle: StandbyHandle,
    }

    impl ProtectedPreloadedParent {
        fn seed(
            runner: &WorkloadRunner<MockDriver, KeyingSpawner, RecordingBrokerRegistrar>,
        ) -> Self {
            let home = tempfile::tempdir().unwrap();
            let mut env = TestEnv::new();
            env.set("MVM_HOME", home.path());
            env.set(
                crate::vm::snapshot_key::SNAPSHOT_TENANT_KEY_ENV,
                "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff",
            );
            let store_root = tempfile::tempdir().unwrap();
            let src = tempfile::tempdir().unwrap();
            let sealed_store = CheckpointStore::at(store_root.path().join("checkpoints"))
                .with_key_custody(std::sync::Arc::new(crate::checkpoint::HostKeyCustody));
            let (checkpoints, snapshots, parent_id, parent_meta) =
                seed_audited_parent_in(sealed_store, store_root.path(), src.path(), true, None);
            assert!(parent_meta.protection.is_sealed());

            let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
            let mut handle =
                idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
            handle.parent_checkpoint = Some(parent_id.to_string());
            let anchor = ClaimTestAnchor::audited(&parent_meta);
            let opened_before = crate::checkpoint::chunk_opens::under(store_root.path());
            runner
                .preload_standby_child(
                    &PreloadContext {
                        checkpoints: &checkpoints,
                        snapshots: &snapshots,
                        anchor: &anchor,
                        registry_path: &store_root.path().join("vm-names.json"),
                    },
                    &mut handle,
                )
                .expect("preload a child from the protected parent");
            assert!(
                crate::checkpoint::chunk_opens::under(store_root.path()) > opened_before,
                "preparing the standby is where the parent's content is opened"
            );
            pool.record(&handle).unwrap();
            Self {
                _env: env,
                _home: home,
                store_root,
                src,
                checkpoints,
                snapshots,
                parent_id,
                parent_meta,
                pool,
                handle,
            }
        }

        fn claim(
            &self,
            runner: &WorkloadRunner<MockDriver, KeyingSpawner, RecordingBrokerRegistrar>,
        ) -> std::result::Result<VmId, StandbyError> {
            let parent_digest =
                materialized_parent_rootfs_digest(&self.checkpoints, &self.parent_meta);
            let registry_path = self.store_root.path().join("vm-names.json");
            let anchor = ClaimTestAnchor::audited(&self.parent_meta);
            let claim = admitted_child_claim(
                &self.src.path().join("rootfs.ext4"),
                signed_child_plan_json(&parent_digest),
            );
            let ctx = ClaimContext {
                pool: &self.pool,
                checkpoints: &self.checkpoints,
                snapshots: &self.snapshots,
                anchor: &anchor,
                parent_checkpoint: &self.parent_id,
                registry_path: &registry_path,
                grant_issuer: None,
            };
            runner.claim_standby(&ctx, &self.handle, &claim)
        }

        fn chunk_objects(&self) -> Vec<PathBuf> {
            // Everything in a sealed content dir that is not a blob's sealed
            // index is a chunk object.
            let mut objects = Vec::new();
            let mut stack = vec![self.checkpoints.content_dir(&self.parent_id)];
            while let Some(dir) = stack.pop() {
                for entry in std::fs::read_dir(&dir).unwrap() {
                    let path = entry.unwrap().path();
                    if path.is_dir() {
                        stack.push(path);
                    } else if path.extension().is_none_or(|ext| ext != "sealed") {
                        objects.push(path);
                    }
                }
            }
            objects
        }
    }

    fn claim_runner() -> WorkloadRunner<MockDriver, KeyingSpawner, RecordingBrokerRegistrar> {
        WorkloadRunner::new(
            MockDriver::default().with_preloaded_standby(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        )
    }

    /// Pool refill opened the parent's sealed content into the preloaded child,
    /// so a claim decrypts none of it again: it authenticates the sealed
    /// objects where they lie and wakes the child that already holds them.
    #[test]
    fn a_warm_claim_on_a_protected_preloaded_parent_decrypts_no_chunk() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let runner = claim_runner();
        let parent = ProtectedPreloadedParent::seed(&runner);
        assert!(
            !parent.chunk_objects().is_empty(),
            "the parent must hold sealed chunks for this to mean anything"
        );
        let before = crate::checkpoint::chunk_opens::under(parent.store_root.path());

        let child = parent.claim(&runner).expect("claim a protected parent");

        assert_eq!(
            Some(child.0.as_str()),
            parent.handle.preloaded_child_vm_name.as_deref(),
            "the claim wakes the child prepared at refill"
        );
        assert_eq!(
            crate::checkpoint::chunk_opens::under(parent.store_root.path()),
            before,
            "a warm claim must not decrypt the parent's content again"
        );
        assert_eq!(runner.driver.forked_children().len(), 1);
    }

    #[test]
    fn a_warm_claim_refuses_changed_materialized_runtime_evidence_without_decrypting() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let runner = claim_runner();
        let parent = ProtectedPreloadedParent::seed(&runner);
        let child = parent.handle.preloaded_child_vm_name.as_ref().unwrap();
        std::fs::write(vm_state_dir(child).join("runtime-artifacts.json"), b"{}").unwrap();
        let before = crate::checkpoint::chunk_opens::under(parent.store_root.path());

        let error = parent.claim(&runner).expect_err("changed child evidence");
        assert!(
            error.to_string().contains("evidence digest mismatch"),
            "{error}"
        );
        assert_eq!(
            crate::checkpoint::chunk_opens::under(parent.store_root.path()),
            before
        );
        assert!(runner.driver.forked_children().is_empty());
    }

    /// Not decrypting is not trusting: a sealed object changed after the
    /// standby was prepared still refuses the claim and quarantines the parent.
    #[test]
    fn a_warm_claim_refuses_a_protected_parent_whose_sealed_object_changed() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let runner = claim_runner();
        let parent = ProtectedPreloadedParent::seed(&runner);
        let object = parent.chunk_objects().pop().expect("a sealed chunk object");
        let mut bytes = std::fs::read(&object).unwrap();
        let last = bytes.len() - 1;
        bytes[last] ^= 0x01;
        // A fresh inode, as an editor or an attacker replacing the file would
        // leave; the pool's other links keep the original bytes.
        std::fs::remove_file(&object).unwrap();
        std::fs::write(&object, &bytes).unwrap();

        let error = parent
            .claim(&runner)
            .expect_err("a tampered sealed object must refuse the claim");

        assert_eq!(
            error.to_string(),
            refuse(ClaimRefusal::ParentTampered).to_string()
        );
        assert!(
            parent.pool.load("warm-parent").is_err(),
            "a tampered parent is quarantined, never returned to the pool"
        );
        assert!(runner.driver.forked_children().is_empty());
    }

    #[test]
    fn public_claim_requires_authenticated_vm_full_runtime_observation_before_child_effects() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|error| error.into_inner());
        for failure in [
            "filesystem-only",
            "missing-observation",
            "wrong-initramfs",
            "reordered-disks",
            "reforged-metadata",
        ] {
            let home = tempfile::tempdir().unwrap();
            let mut env = TestEnv::new();
            env.set("MVM_HOME", home.path());
            let source = tempfile::tempdir().unwrap();
            let (checkpoints, snapshots, parent_id, mut parent) =
                seed_audited_parent(home.path(), source.path(), true);
            let rootfs_digest = materialized_parent_rootfs_digest(&checkpoints, &parent);
            let original_anchor = ClaimTestAnchor::audited(&parent);
            match failure {
                "filesystem-only" => parent.class = mvm_core::checkpoint::CheckpointClass::FsQuick,
                "missing-observation" => {
                    parent
                        .content
                        .retain(|blob| blob.name != "runtime-artifacts.json");
                }
                "wrong-initramfs" | "reordered-disks" => {
                    let path = checkpoints
                        .content_dir(&parent_id)
                        .join("runtime-artifacts.json");
                    let mut observed: mvm_vmm::runtime_artifacts::RuntimeArtifacts =
                        serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
                    if failure == "wrong-initramfs" {
                        observed.initramfs.as_mut().unwrap().path =
                            source.path().join("other-initramfs");
                    } else {
                        observed.disks.reverse();
                    }
                    std::fs::write(&path, serde_json::to_vec(&observed).unwrap()).unwrap();
                    parent
                        .content
                        .iter_mut()
                        .find(|blob| blob.name == "runtime-artifacts.json")
                        .unwrap()
                        .sha256 = mvm_core::crypto::image_verify::sha256_file(&path).unwrap();
                }
                "reforged-metadata" => {
                    let mvm_core::protocol::runtime_release::RuntimeLaunchBinding::CliAssembly(
                        binding,
                    ) = parent.runtime_launch_binding.as_mut().unwrap()
                    else {
                        panic!("source assembly fixture");
                    };
                    binding.overlay_path = source.path().join("unauthenticated-overlay");
                }
                _ => unreachable!(),
            }
            parent.meta_digest = parent.compute_meta_digest();
            checkpoints.write_meta(&parent).unwrap();
            // The first four cases are honestly recorded invalid captures. The
            // last re-seals changed metadata without changing its audit witness.
            let anchor = if failure == "reforged-metadata" {
                original_anchor
            } else {
                ClaimTestAnchor::audited(&parent)
            };
            let pool = SupervisorStandbyPool::at(home.path().join("pool"));
            let handle = idle_parent_handle("warm-parent", &home.path().join("control.sock"));
            pool.record(&handle).unwrap();
            let registry_path = home.path().join("vm-names.json");
            let claim = admitted_child_claim(
                &source.path().join("rootfs.ext4"),
                signed_child_plan_json(&rootfs_digest),
            );
            let runner = WorkloadRunner::new(
                MockDriver::default(),
                KeyingSpawner::default(),
                RecordingBrokerRegistrar::new(),
            );
            let error = runner
                .claim_standby(
                    &ClaimContext {
                        pool: &pool,
                        checkpoints: &checkpoints,
                        snapshots: &snapshots,
                        anchor: &anchor,
                        parent_checkpoint: &parent_id,
                        registry_path: &registry_path,
                        grant_issuer: None,
                    },
                    &handle,
                    &claim,
                )
                .expect_err(failure);
            if failure == "reforged-metadata" {
                assert!(pool.load("warm-parent").is_err(), "{failure}: {error}");
            } else {
                let message = error.to_string();
                assert!(
                    message.contains(if failure == "filesystem-only" {
                        "requires a vm_full"
                    } else {
                        "verify paused runtime"
                    }),
                    "{failure}: {message}"
                );
                assert!(pool.load("warm-parent").unwrap().state.is_claimable());
            }
            assert!(runner.driver.forked_children().is_empty(), "{failure}");
            assert!(
                runner.spawner.seen_vm.lock().unwrap().is_none(),
                "{failure}"
            );
            assert!(runner.broker.seen.lock().unwrap().is_none(), "{failure}");
            assert_eq!(orphan_child_dirs(), 0, "{failure}");
        }
    }

    #[test]
    fn resident_claim_accepts_a_valid_signed_bundle_manifest_without_hashing_blobs() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let manifest_digest =
            mvm_core::checkpoint::content_manifest_digest(&parent_meta.content).to_string();
        let snapshot_id = parent_meta.snapshot_id.as_deref().unwrap();
        let identity = mvm_core::crypto::snapshot_sign::host_snapshot_identity().unwrap();
        mvm_core::crypto::snapshot_sign::sign_manifest(
            &snapshots.root().join(snapshot_id),
            &manifest_digest,
            &identity.signing,
        )
        .unwrap();
        let parent = parent_meta.clone();

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent);
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        verify_resident_snapshot_manifest(&ctx, &parent)
            .expect("a host-signed resident bundle manifest must verify");

        std::fs::write(
            snapshots
                .root()
                .join(snapshot_id)
                .join(mvm_core::crypto::snapshot_sign::MANIFEST_SIGNATURE_FILENAME),
            b"tampered",
        )
        .unwrap();
        assert!(
            verify_resident_snapshot_manifest(&ctx, &parent).is_err(),
            "a tampered signed manifest must fail closed"
        );
        drop(env);
    }

    #[test]
    fn resident_claim_creates_no_child_restore_bundle() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);
        let snapshot_id = parent_meta.snapshot_id.as_deref().unwrap();
        let manifest_digest =
            mvm_core::checkpoint::content_manifest_digest(&parent_meta.content).to_string();
        let identity = mvm_core::crypto::snapshot_sign::host_snapshot_identity().unwrap();
        mvm_core::crypto::snapshot_sign::sign_manifest(
            &snapshots.root().join(snapshot_id),
            &manifest_digest,
            &identity.signing,
        )
        .unwrap();

        crate::base::runtime_meta::record_from_start_config(
            "warm-parent",
            StartMode::Detached,
            &VmStartConfig {
                name: "warm-parent".into(),
                rootfs_path: src.path().join("rootfs.ext4").display().to_string(),
                ..Default::default()
            },
        )
        .unwrap();

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::unaudited();
        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );
        let runner = WorkloadRunner::new(
            MockDriver::default().with_resident_handoff(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let child = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect("resident claim");
        let child_dir = vm_state_dir(&child.0);
        assert!(child_dir.is_dir());
        assert!(
            !child_dir.join("rootfs.ext4").exists(),
            "resident claims must not materialize a child restore bundle"
        );
        assert_eq!(runner.driver.forked_children().len(), 1);
        reclaim_consumed_resident_checkpoint_at(
            checkpoints.root(),
            snapshots.root(),
            &parent_meta.id,
            parent_meta.snapshot_id.as_deref(),
        )
        .expect("resident checkpoint cleanup is idempotent");
        assert!(
            !checkpoints.dir_for(&parent_id).exists(),
            "committed resident claims must reclaim the consumed checkpoint payload"
        );
        assert!(
            !snapshots.root().join(snapshot_id).exists(),
            "committed resident claims must reclaim the consumed snapshot payload"
        );
        drop(env);
    }

    /// Build a signed, admitted child plan whose bound image digest is the
    /// parent's own verified rootfs content-address (claim-8 authority), the way
    /// the CLI mints it before handing the runner the claim.
    fn signed_child_plan_json(image_sha256: &str) -> String {
        signed_child_plan_json_with_verbs(image_sha256, None)
    }

    /// Record `policy` the way admission records a resolved network policy:
    /// as a policy asset identity carrying its content digest.
    fn record_policy_identity(plan: &mut ExecutionPlan, policy: &NetworkPolicy) {
        plan.asset_identities.push(
            mvm_core::plan::AssetIdentity::new(
                mvm_core::plan::AssetKind::Policy,
                "tenant-x:child",
                mvm_core::policy::network_policy::content_sha256(policy),
            )
            .unwrap(),
        );
    }

    /// A child plan admitted under `policy`, signed.
    fn signed_child_plan_json_for_policy(
        image_sha256: &str,
        grants: Option<mvm_contract::grants::Grants>,
        policy: &NetworkPolicy,
    ) -> String {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new()
            .tenant("tenant-x")
            .grants(grants)
            .build();
        plan.image.sha256 = image_sha256.to_string();
        record_policy_identity(&mut plan, policy);
        let key = ed25519_dalek::SigningKey::from_bytes(&[7u8; 32]);
        serde_json::to_string(&mvm_core::plan::sign_plan(&plan, &key, "host:test")).unwrap()
    }

    fn signed_child_plan_json_with_grants(
        image_sha256: &str,
        grants: Option<mvm_contract::grants::Grants>,
    ) -> String {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new()
            .tenant("tenant-x")
            .grants(grants)
            .build();
        plan.image.sha256 = image_sha256.to_string();
        record_policy_identity(&mut plan, &egress_allowing_policy());
        let key = ed25519_dalek::SigningKey::from_bytes(&[7u8; 32]);
        serde_json::to_string(&mvm_core::plan::sign_plan(&plan, &key, "host:test")).unwrap()
    }

    fn signed_child_plan_json_with_verbs(
        image_sha256: &str,
        agent_verbs: Option<Vec<VerbId>>,
    ) -> String {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new()
            .tenant("tenant-x")
            .build();
        plan.image.sha256 = image_sha256.to_string();
        plan.agent_verbs = agent_verbs;
        record_policy_identity(&mut plan, &egress_allowing_policy());
        let key = ed25519_dalek::SigningKey::from_bytes(&[7u8; 32]);
        serde_json::to_string(&mvm_core::plan::sign_plan(&plan, &key, "host:test")).unwrap()
    }

    #[test]
    fn admitted_network_limits_are_extracted_without_defaulting() {
        let expected = mvm_core::plan::NetworkLimits::builder()
            .max_tcp_flows(7)
            .max_udp_associations(5)
            .max_dns_bindings(3)
            .max_ingress_listeners(2)
            .build()
            .unwrap();
        let mut plan = mvm_core::plan::test_support::PlanFixture::new().build();
        plan.network_limits = expected;
        let key = ed25519_dalek::SigningKey::from_bytes(&[7u8; 32]);
        let json =
            serde_json::to_string(&mvm_core::plan::sign_plan(&plan, &key, "host:test")).unwrap();

        assert_eq!(admitted_network_limits(Some(&json)).unwrap(), expected);
        assert_eq!(
            admitted_network_limits(None).unwrap(),
            mvm_core::plan::NetworkLimits::default()
        );
    }

    #[test]
    fn admitted_tool_rules_are_projected_from_the_signed_plan() {
        let mut plan = mvm_core::plan::test_support::PlanFixture::new().build();
        plan.tools.allow.push("shell".into());
        let expected = plan.tools.clone();
        let key = ed25519_dalek::SigningKey::from_bytes(&[7u8; 32]);
        let json =
            serde_json::to_string(&mvm_core::plan::sign_plan(&plan, &key, "host:test")).unwrap();

        assert_eq!(admitted_tool_rules(Some(&json)).unwrap(), expected);
        assert!(admitted_tool_rules(None).unwrap().is_empty());
        assert!(admitted_tool_rules(Some("not json")).is_err());
    }

    #[derive(Default)]
    struct TestChildGrantIssuer {
        seen_child: Mutex<Option<String>>,
    }

    impl ChildGrantIssuer for TestChildGrantIssuer {
        fn issue(&self, config: &VmStartConfig) -> Result<Option<VerbGrantEnvelope>> {
            let plan_json = config.plan_json.as_deref().context("child plan missing")?;
            let plan = mvm_core::plan::plan_from_admitted_json(plan_json)?;
            let verbs = plan.agent_verbs.unwrap_or_default();
            let drive = plan.grants.and_then(|grants| grants.drive);
            if verbs.is_empty() && drive.is_none() {
                return Ok(None);
            }
            *self.seen_child.lock().unwrap() = Some(config.name.clone());
            Ok(Some(VerbGrantEnvelope {
                pubkey_hex: "ab".repeat(32),
                plan_nonce_hex: plan.nonce.as_hex().to_string(),
                predecessor_session_id: None,
                predecessor_plan_nonce_hex: None,
                grant: mvm_core::plan::VerbGrant {
                    session_id: config.name.clone(),
                    plan_nonce: plan.nonce,
                    not_after: plan.valid_until,
                    verbs,
                    drive,
                    tool_mediation: None,
                    application_terminal: None,
                    owner_access: None,
                    sig: vec![3u8; 64],
                },
            }))
        }
    }

    fn idle_parent_handle(id: &str, control_socket: &Path) -> StandbyHandle {
        StandbyHandle {
            id: id.to_string(),
            template_id: None,
            control_socket: control_socket.display().to_string(),
            pid: 0,
            kernel_sha256: "k".repeat(64),
            vcpus: 2,
            mem_mib: 512,
            binding_nonce: "b".repeat(64),
            spawned_unix_secs: 1,
            state: StandbyState::Idle,
            image_sha256: None,
            root_strategy: Default::default(),
            parent_checkpoint: None,
            preloaded_child_vm_name: None,
            vsock_egress: false,
        }
    }

    fn admitted_child_claim(rootfs: &Path, plan_json: String) -> StandbyClaim {
        StandbyClaim {
            start_config: Some(VmStartConfig {
                name: "unused-cold".into(),
                rootfs_path: rootfs.display().to_string(),
                tenant_id: Some("tenant-x".into()),
                ..checked_source_config("unused-cold", rootfs.display().to_string())
            }),
            rootfs_path: rootfs.display().to_string(),
            tenant_id: "tenant-x".into(),
            audit_dir: rootfs.with_file_name("audit"),
            gateway_audit_socket: rootfs.with_file_name("gw-audit.sock"),
            gateway_events_socket: None,
            plan_json,
            bundle_json: None,
            network_policy: egress_allowing_policy(),
        }
    }

    /// The positive path: `claim_standby` forks a clean, audited parent into a
    /// fresh, admitted child that carries a fresh identity on every axis the fork
    /// controls, its own isolated endpoint, the overlay gate a cold boot runs, and
    /// a fresh VMGenID delivered with the boot.
    /// Seed an audited parent and claim it with `driver`, the claim's start
    /// config carrying `volumes`.
    fn claim_with_volumes(
        driver: MockDriver,
        volumes: Vec<mvm_core::vm_backend::VmVolume>,
    ) -> (
        std::result::Result<VmId, StandbyError>,
        Vec<mvm_backends::mock::MockChildFork>,
        Vec<mvm_backends::mock::DeliveredChildIdentity>,
    ) {
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);
        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);
        let mut claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );
        if let Some(start) = claim.start_config.as_mut() {
            start.volumes = volumes;
        }
        let runner = WorkloadRunner::new(
            driver,
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };
        let result = runner.claim_standby(&ctx, &handle, &claim);
        (
            result,
            runner.driver.forked_children(),
            runner.driver.delivered_child_identities(),
        )
    }

    fn read_only_mount(image: &str, guest: &str) -> mvm_core::vm_backend::VmVolume {
        mvm_core::vm_backend::VmVolume {
            host: "/host/project".into(),
            guest: guest.into(),
            materialized_image: Some(image.into()),
            volume_label: Some("mvmmnt0".into()),
            read_only: true,
            ..Default::default()
        }
    }

    /// A claim's read-only mount reaches the child through the slot its parent
    /// booted: the driver points that slot at the launch's own image before the
    /// child resumes, and the guest is told to mount it — read-only, by label —
    /// before the claim commits.
    #[test]
    fn a_claim_attaches_its_read_only_mount_to_the_parents_slot_before_resume() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let (result, forks, delivered) = claim_with_volumes(
            MockDriver::default().with_late_volume_slots(4),
            vec![read_only_mount("/cache/project.ext4", "/data")],
        );
        result.expect("a slotted parent serves a read-only mount");
        assert_eq!(forks.len(), 1);
        assert_eq!(
            forks[0].late_volumes,
            vec![crate::driver::LateVolumeAttach {
                // Rootfs first, then the authenticated runtime overlay and its
                // verity sidecar the claim inherits from the parent's binding,
                // so the parent's first late-volume slot is 3.
                slot: 3,
                source: PathBuf::from("/cache/project.ext4"),
            }]
        );
        assert_eq!(delivered.len(), 1);
        let mounted = &delivered[0].volumes;
        assert_eq!(mounted.len(), 1);
        assert_eq!(mounted[0].mountpoint, "/data");
        assert!(mounted[0].read_only);
        assert_eq!(mounted[0].label.as_deref(), Some("mvmmnt0"));
        assert_eq!(mounted[0].device.as_deref(), Some("/dev/vdd"));
    }

    /// A backend whose parents boot no slots cannot attach a volume, so the
    /// claim is refused before any child is forked.
    #[test]
    fn a_parent_without_slots_refuses_a_volume_claim_before_forking() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let (result, forks, _) = claim_with_volumes(
            MockDriver::default(),
            vec![read_only_mount("/cache/project.ext4", "/data")],
        );
        let err = result.expect_err("no slot can serve the volume");
        assert!(err.to_string().contains("late-volume slots"), "{err}");
        assert!(
            forks.is_empty(),
            "nothing may be forked for a refused claim"
        );
    }

    /// A guest that does not report mounting every attached volume is refused
    /// rather than committed: its workload would start without its data.
    #[test]
    fn a_child_that_did_not_mount_its_volumes_is_refused() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let mut outcome = PostRestoreOutcome {
            acknowledged: true,
            detail: None,
            reseeded: true,
            clock_resynced: true,
            reseed_shortfall: None,
            seccomp_tier: None,
            volumes_mounted: None,
        };
        let admitted_tier =
            mvm_core::plan::plan_from_admitted_json(&signed_child_plan_json(&"0".repeat(64)))
                .unwrap()
                .admission_profile
                .seccomp_tier;
        outcome.seccomp_tier = Some(admitted_tier.into());
        let (result, _, _) = claim_with_volumes(
            MockDriver::default()
                .with_late_volume_slots(4)
                .with_child_identity(outcome),
            vec![read_only_mount("/cache/project.ext4", "/data")],
        );
        let err = result.expect_err("an unmounted volume must refuse the claim");
        assert!(err.to_string().contains("mounted none of the 1"), "{err}");
    }

    #[test]
    fn claim_produces_fresh_identity_and_isolated_endpoint() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_verbs(
                &parent_digest,
                Some(vec![VerbId::new("run-entrypoint").unwrap()]),
            ),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let grant_issuer = TestChildGrantIssuer::default();
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: Some(&grant_issuer),
        };

        let mut opted_in = claim.clone();
        let config = opted_in.start_config.as_mut().unwrap();
        let plan = mvm_core::plan::plan_from_admitted_json(&claim.plan_json).unwrap();
        let installation =
            serde_json::from_str("\"bdf189ab-9a9a-440b-a266-e95b19e58a5e\"").unwrap();
        let identity =
            mvm_core::crypto::entrypoint_delegation::test_support::identity([3; 32], installation);
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_secs();
        let expected =
            mvm_core::vm_backend::caller_registration::CallerRegistration::challenge_for_plan(
                &config.name,
                &plan,
                identity,
                now,
            )
            .unwrap();
        let proof =
            mvm_core::crypto::entrypoint_delegation::test_support::proof([3; 32], &expected, now)
                .unwrap();
        config.caller_registration = Some(
            mvm_core::vm_backend::caller_registration::CallerRegistration {
                vm: config.name.clone(),
                expected,
                proof,
            },
        );
        assert!(runner.claim_standby(&ctx, &handle, &opted_in).is_err());
        assert_eq!(pool.load("warm-parent").unwrap().state, StandbyState::Idle);
        assert!(
            !registry_path.exists(),
            "refusal must precede child identity allocation"
        );
        assert!(runner.driver.forked_children().is_empty());
        assert!(runner.spawner.seen_vm.lock().unwrap().is_none());

        let child = runner.claim_standby(&ctx, &handle, &claim).expect("claim");

        // The child records the runtime metadata a cold boot records, naming
        // its own materialized rootfs, so a step checkpoint of it resolves.
        let meta = crate::base::runtime_meta::read(&child.0)
            .expect("read child runtime metadata")
            .expect("a claimed child records its runtime metadata");
        assert_eq!(
            meta.rootfs_path.map(PathBuf::from),
            Some(vm_state_dir(&child.0).join("rootfs.ext4"))
        );

        // Fresh identity: the child differs from the parent and gets a fresh name.
        assert_ne!(child.0, handle.id, "child VmId must differ from the parent");
        assert!(
            child.0.starts_with("vm-"),
            "child gets a fresh registry name: {}",
            child.0
        );

        // Surface 5: the child's endpoint is keyed on its own fresh id, and the
        // factory parent never got one.
        let seen = runner.spawner.seen_vm.lock().unwrap().clone();
        assert_eq!(
            seen.as_deref(),
            Some(child.0.as_str()),
            "the endpoint is keyed on the child's own id"
        );
        assert_ne!(
            seen.as_deref(),
            Some(handle.id.as_str()),
            "the parent, a factory, gets no substitution endpoint"
        );

        // Surface 3: the fork delivered a fresh VMGenID bound to the child's
        // content-address, at the boot call — before any guest randomness consumer
        // runs — so the child's CSPRNG cannot share the parent's state.
        let forks = runner.driver.forked_children();
        assert_eq!(forks.len(), 1, "exactly one child fork");
        assert_eq!(forks[0].child_vm_name, child.0);
        assert_ne!(
            forks[0].genid.token, [0u8; GENID_BYTES],
            "a clean parent's baseline token is zero; the child gets a fresh non-zero one"
        );
        assert_eq!(
            forks[0].genid.content_hash, parent_digest,
            "the fresh token is bound to the child's content-address"
        );

        // The fork alone only resumes the child on the parent's saved memory, so
        // the claim also handed that same token to the child's guest agent and
        // committed only once the guest reported it had rotated onto it.
        let delivered = runner.driver.delivered_child_identities();
        assert_eq!(delivered.len(), 1);
        assert_eq!(delivered[0].child_vm_name, child.0);
        assert_eq!(delivered[0].token, forks[0].genid.token);
        // The parent booted with no plan and so holds no seccomp tier; the
        // child's comes from the plan this claim was admitted under, on the
        // same handshake, before the claim commits.
        let plan = mvm_core::plan::plan_from_admitted_json(&claim.plan_json).unwrap();
        assert_eq!(
            delivered[0].seccomp_tier,
            Some(plan.admission_profile.seccomp_tier.into()),
            "the claimed child is handed its own plan's seccomp tier"
        );
        let delivered_grant = delivered[0]
            .grant_envelope
            .as_ref()
            .expect("the child grant rides the post-restore handshake");
        assert_eq!(delivered_grant.grant.session_id, child.0);
        assert_eq!(
            delivered_grant.grant.verbs,
            vec![VerbId::new("run-entrypoint").unwrap()]
        );
        assert_eq!(
            grant_issuer.seen_child.lock().unwrap().as_deref(),
            Some(child.0.as_str())
        );

        // The runner-side overlay-contract gate ran on the materialized child:
        // its dir carries the overlay sidecar the clone rode plus the rootfs.
        let child_dir = mvm_core::config::vm_state_dir(&child.0);
        assert!(
            child_dir
                .join(mvm_build::builder_vm::SIDECAR_FILENAME)
                .exists(),
            "the overlay sidecar rode the clone into the child dir"
        );
        assert!(
            child_dir.join("rootfs.ext4").exists(),
            "the child rootfs was materialized from the parent's content"
        );

        // The parent was reserved (marked Claimed) atomically, never left idle for
        // a second claim to grab.
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Claimed,
            "the parent is reserved so a concurrent claim cannot double-claim it"
        );
    }

    /// Where a claimed child's egress *destinations* come from: its own launch
    /// policy, threaded into its own endpoint at claim time.
    ///
    /// This is what makes keying the pool on the enablement boolean sound. The
    /// parent boots only whether a guest egress client starts; every host:port a
    /// workload may reach is resolved here, per child, from that child's policy —
    /// so a shared parent has no launch's allow-list to hand to the next claim.
    #[test]
    fn a_claimed_childs_endpoint_gets_its_own_launchs_allow_list() {
        use mvm_core::network_policy::HostPort;

        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let mut handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        // The parent was warmed for an egress-enabled launch, so it is claimable
        // by one.
        handle.vsock_egress = true;
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let policy = NetworkPolicy::allow_list(vec![
            HostPort::new("api.example.com", 443),
            HostPort::new("logs.example.com", 443),
        ]);
        let mut claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_for_policy(&parent_digest, None, &policy),
        );
        claim.network_policy = policy.clone();

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        runner
            .claim_standby(&ctx, &handle, &claim)
            .expect("claim an egress-enabled parent");

        let seen = runner.spawner.seen.lock().unwrap();
        let recorded = seen.as_ref().expect("the child got its own endpoint");
        assert_eq!(
            recorded.policy, policy,
            "the child's endpoint must enforce the launch's own allow-list, not the parent's"
        );
    }

    /// Seed an audited egress-capable parent and return what a claim needs.
    struct EgressClaimFixture {
        _home: tempfile::TempDir,
        _env: TestEnv,
        store_root: tempfile::TempDir,
        src: tempfile::TempDir,
        checkpoints: CheckpointStore,
        snapshots: FsSnapshotStore,
        parent_id: CheckpointId,
        parent_digest: String,
        anchor: ClaimTestAnchor,
    }

    impl EgressClaimFixture {
        fn new() -> Self {
            let home = tempfile::tempdir().unwrap();
            let mut env = TestEnv::new();
            env.set("MVM_HOME", home.path());
            let store_root = tempfile::tempdir().unwrap();
            let src = tempfile::tempdir().unwrap();
            let (checkpoints, snapshots, parent_id, parent_meta) =
                seed_audited_parent(store_root.path(), src.path(), true);
            let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);
            let anchor = ClaimTestAnchor::audited(&parent_meta);
            Self {
                _home: home,
                _env: env,
                store_root,
                src,
                checkpoints,
                snapshots,
                parent_id,
                parent_digest,
                anchor,
            }
        }

        /// Claim an idle parent recorded with `parent_boots_egress_client`.
        fn claim(
            &self,
            parent_boots_egress_client: bool,
            claim: &StandbyClaim,
        ) -> (
            std::result::Result<VmId, StandbyError>,
            Option<NetworkPolicy>,
        ) {
            let pool = SupervisorStandbyPool::at(self.store_root.path().join("pool"));
            let mut handle =
                idle_parent_handle("warm-parent", &self.store_root.path().join("control.sock"));
            handle.vsock_egress = parent_boots_egress_client;
            pool.record(&handle).unwrap();
            let registry_path = self.store_root.path().join("vm-names.json");
            let runner = WorkloadRunner::new(
                MockDriver::default(),
                RecordingSpawner::new("/run/ep.sock"),
                RecordingBrokerRegistrar::new(),
            );
            let ctx = ClaimContext {
                pool: &pool,
                checkpoints: &self.checkpoints,
                snapshots: &self.snapshots,
                anchor: &self.anchor,
                parent_checkpoint: &self.parent_id,
                registry_path: &registry_path,
                grant_issuer: None,
            };
            let result = runner.claim_standby(&ctx, &handle, claim);
            let seen = runner
                .spawner
                .seen
                .lock()
                .unwrap()
                .as_ref()
                .map(|recorded| recorded.policy.clone());
            (result, seen)
        }

        fn rootfs(&self) -> PathBuf {
            self.src.path().join("rootfs.ext4")
        }
    }

    fn api_allow_list() -> NetworkPolicy {
        use mvm_core::network_policy::HostPort;
        NetworkPolicy::allow_list(vec![HostPort::new("api.example.com", 443)])
    }

    fn api_egress_grant() -> mvm_contract::grants::Grants {
        use mvm_core::network_policy::HostPort;
        mvm_contract::grants::Grants {
            egress: Some(mvm_contract::grants::EgressGrant {
                allow: vec![HostPort::new("api.example.com", 443)],
            }),
            ..Default::default()
        }
    }

    /// The policy the claim installs must be the one the claiming plan
    /// recorded. A different policy beside a valid plan is refused before the
    /// child's endpoint is spawned, so no endpoint ever enforces it.
    #[test]
    fn a_claim_carrying_a_policy_its_plan_did_not_record_is_refused_before_any_endpoint() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let fixture = EgressClaimFixture::new();
        let mut claim = admitted_child_claim(
            &fixture.rootfs(),
            signed_child_plan_json_for_policy(&fixture.parent_digest, None, &api_allow_list()),
        );
        claim.network_policy = NetworkPolicy::unrestricted();

        let (result, endpoint_policy) = fixture.claim(true, &claim);

        let err = result.expect_err("a policy the plan did not record must refuse the claim");
        assert!(
            err.to_string()
                .contains("is not the policy its admitted plan recorded"),
            "{err}"
        );
        assert_eq!(
            endpoint_policy, None,
            "no endpoint may run a refused policy"
        );
    }

    /// A parent booted with the egress client carries no destinations of its
    /// own, so the claiming plan's admitted allow-list is what bounds the child
    /// — and that same plan's policy is what its endpoint enforces.
    #[test]
    fn an_egress_parent_serves_a_child_under_its_own_admitted_allow_list() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let fixture = EgressClaimFixture::new();
        let policy = api_allow_list();
        let mut claim = admitted_child_claim(
            &fixture.rootfs(),
            signed_child_plan_json_for_policy(
                &fixture.parent_digest,
                Some(api_egress_grant()),
                &policy,
            ),
        );
        claim.network_policy = policy.clone();

        let (result, endpoint_policy) = fixture.claim(true, &claim);

        result.expect("an egress parent serves an egress-granted child");
        assert_eq!(endpoint_policy, Some(policy));
    }

    /// A parent booted without the egress client is still sealed deny-all, so
    /// an egress-granted child is refused rather than restored into a guest
    /// that has no client to carry its flows.
    #[test]
    fn a_parent_without_the_egress_client_refuses_an_egress_granted_child() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let fixture = EgressClaimFixture::new();
        let policy = api_allow_list();
        let mut claim = admitted_child_claim(
            &fixture.rootfs(),
            signed_child_plan_json_for_policy(
                &fixture.parent_digest,
                Some(api_egress_grant()),
                &policy,
            ),
        );
        claim.network_policy = policy;

        let (result, endpoint_policy) = fixture.claim(false, &claim);

        let err = result.expect_err("a deny-all parent bounds the child to no egress");
        assert!(err.to_string().contains("api.example.com"), "{err}");
        assert_eq!(endpoint_policy, None);
    }

    /// A channel set described independently of which VM owns it: each port's
    /// number, direction, and where its host socket sits *relative to that VM's
    /// own* socket and state dirs. Two VMs' descriptions compare equal exactly
    /// when they carry the same channels wired to the same per-VM locations —
    /// and the relativization keeps that true even when one VM's name is long
    /// enough to push its sockets into the short hashed namespace.
    fn channel_shape(
        channels: &[crate::driver::VsockPort],
        vm: &str,
    ) -> Vec<(u32, crate::driver::VsockDirection, String)> {
        // Both roots collapse to one label on purpose. A VM's socket root is its
        // state dir until the path grows long enough to overflow the Unix-socket
        // limit, at which point it becomes a short hashed namespace instead —
        // which of the two a given VM landed on is that fallback's business, not
        // a difference in the channel set. Labelling them apart would report two
        // VMs as carrying different channels whenever only one crossed the limit.
        // Longest root first so an equal-or-nested root cannot mask a deeper one.
        let mut roots = [mvm_core::config::vm_socket_dir(vm), vm_state_dir(vm)];
        roots.sort_by_key(|r| std::cmp::Reverse(r.as_os_str().len()));
        channels
            .iter()
            .map(|p| {
                let where_ = roots
                    .iter()
                    .find_map(|root| {
                        p.host_uds
                            .strip_prefix(root)
                            .ok()
                            .map(|rest| format!("<vm>/{}", rest.display()))
                    })
                    .unwrap_or_else(|| p.host_uds.display().to_string());
                (p.service.port(), p.direction, where_)
            })
            .collect()
    }

    /// One cold boot and one warm claim on the same runner, so the two host
    /// channel sets the driver was handed can be compared directly.
    struct ColdAndWarm {
        driver: MockDriver,
        broker: Option<RecordedBroker>,
        cold_vm: String,
        child: VmId,
        /// The signed plan the claim admitted the child under.
        claim_plan_json: String,
        /// Held so the assertions resolve the same `MVM_HOME` the run did.
        /// Declaration order is drop order: the home dir goes, then the env is
        /// restored, then the lock is released.
        _home: tempfile::TempDir,
        _env: TestEnv,
        _lock: std::sync::MutexGuard<'static, ()>,
    }

    /// Boot an admitted workload cold, then claim a child off a clean audited
    /// parent seeded from the same rootfs — both through one runner, with the
    /// endpoint spawner that keys its socket on the VM name (as the real one
    /// does), so the two channel sets differ only where the VM identity does.
    ///
    /// The isolated `MVM_HOME` is handed back alive, so the caller's assertions
    /// resolve the same per-VM paths the run wrote.
    fn cold_boot_then_claim() -> ColdAndWarm {
        let lock = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);
        let rootfs = src.path().join("rootfs.ext4");

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );

        // The cold boot: an admitted launch (tenant set), so it carries the
        // broker channel a claimed child must also get.
        let cold_vm = "cold-admitted-workload".to_string();
        mapping_start(
            &runner,
            &VmStartConfig {
                name: cold_vm.clone(),
                rootfs_path: rootfs.display().to_string(),
                kernel_path: Some("/img/kernel".into()),
                tenant_id: Some("tenant-x".into()),
                network_policy: egress_allowing_policy(),
                cpus: 2,
                memory_mib: 512,
                ..Default::default()
            },
        )
        .expect("the cold admitted workload boots");

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);
        let claim = admitted_child_claim(&rootfs, signed_child_plan_json(&parent_digest));

        let child = runner
            .claim_standby(
                &ClaimContext {
                    pool: &pool,
                    checkpoints: &checkpoints,
                    snapshots: &snapshots,
                    anchor: &anchor,
                    parent_checkpoint: &parent_id,
                    registry_path: &registry_path,
                    grant_issuer: None,
                },
                &handle,
                &claim,
            )
            .expect("claim");

        ColdAndWarm {
            driver: runner.driver.clone(),
            broker: runner.broker.seen.lock().unwrap().take(),
            cold_vm,
            child,
            claim_plan_json: claim.plan_json.clone(),
            _home: home,
            _env: env,
            _lock: lock,
        }
    }

    /// The fork carries the plan the claim admitted, so a driver whose child
    /// is owned by a supervisor can hand it the bounds to enforce. A resident
    /// parent booted with none of its own.
    #[test]
    fn claim_hands_the_fork_the_plan_the_child_was_admitted_under() {
        let run = cold_boot_then_claim();
        let forks = run.driver.forked_children();
        assert_eq!(forks.len(), 1, "exactly one child fork");
        assert_eq!(
            forks[0].admitted_plan.as_deref(),
            Some(run.claim_plan_json.as_str())
        );
    }

    /// A claimed child must reach the same host-side channels a cold-booted
    /// workload does. Asserted as an equality against the cold boot's own set
    /// rather than as a list of ports: a channel added to the workload's set and
    /// not to the claim's would leave a claimed child silently less capable than
    /// a cold-booted one, and only an equality catches that.
    #[test]
    fn claim_hands_the_child_the_same_host_channels_a_cold_boot_gets() {
        use mvm_agentd::vsock::{GUEST_AGENT_PORT, WORKLOAD_EXIT_PORT};

        let run = cold_boot_then_claim();

        let booted = run.driver.booted_specs();
        assert_eq!(booted.len(), 1, "one cold workload boot");
        let cold = &booted[0].vsock;

        // Non-vacuity: the fixture must actually exercise all four standing
        // channels, or "the two match" would say nothing. These are the three
        // the fork used to drop, plus the agent RPC.
        let ports: Vec<u32> = cold.iter().map(|p| p.service.port()).collect();
        for (port, what) in [
            (EGRESS_PORT, "the gated egress endpoint"),
            (BROKER_PORT, "the admitted host-services broker"),
            (WORKLOAD_EXIT_PORT, "the guest's exit-code report"),
            (GUEST_AGENT_PORT, "the agent RPC"),
        ] {
            assert!(
                ports.contains(&port),
                "fixture must exercise {what} (port {port}), got {ports:?}"
            );
        }

        let forks = run.driver.forked_children();
        assert_eq!(forks.len(), 1, "exactly one child fork");
        assert_eq!(
            channel_shape(&forks[0].channels, &run.child.0),
            channel_shape(cold, &run.cold_vm),
            "a claimed child must be handed exactly the channel set a cold boot wires"
        );
    }

    /// The child's broker is registered on the very socket its `BROKER_PORT`
    /// channel relays to, and under the claim's tenant — otherwise the guest
    /// dials a path nothing is bound to and admitted host services are silently
    /// unavailable, a real degradation versus a cold boot.
    #[test]
    fn claim_registers_the_childs_broker_on_the_socket_it_wired() {
        let run = cold_boot_then_claim();

        let broker = run
            .broker
            .as_ref()
            .expect("a claimed child registers a host-services broker");
        assert_eq!(
            broker.vm_name, run.child.0,
            "the broker is registered for the child's own id, never the parent's"
        );
        assert_eq!(broker.tenant.as_deref(), Some("tenant-x"));
        assert!(broker.services.is_empty());

        let wired = run.driver.forked_children()[0]
            .channels
            .iter()
            .find(|p| p.service.port() == BROKER_PORT)
            .map(|p| p.host_uds.clone())
            .expect("the child carries a broker channel");
        assert_eq!(
            broker.broker_listen_socket.as_ref(),
            Some(&wired),
            "the broker must bind the same path the child's BROKER_PORT relays to"
        );
        assert_eq!(
            wired,
            mvm_core::config::vm_vsock_port_socket_at(&vm_state_dir(&run.child.0), BROKER_PORT),
            "the broker socket lives under the child's own state dir"
        );
    }

    /// Count child (`vm-*`) dirs left under the VM state root — a failed claim
    /// must leave none.
    fn orphan_child_dirs() -> usize {
        match std::fs::read_dir(vms_dir()) {
            Ok(rd) => rd
                .flatten()
                .filter(|e| e.path().is_dir() && e.file_name().to_string_lossy().starts_with("vm-"))
                .count(),
            Err(_) => 0,
        }
    }

    /// What a claim driven against a scripted post-restore answer left behind.
    struct HandshakeClaimOutcome {
        result: std::result::Result<VmId, StandbyError>,
        /// The driver the claim ran on — an `Arc`-shared clone, so the fork,
        /// delivery, and kill records survive the runner it was moved into.
        driver: MockDriver,
        /// `None` once the claim dropped the parent from the pool.
        parent_state: Option<StandbyState>,
        orphan_child_dirs: usize,
        /// Records every `ConsoleStreamer::start`/`stop` the claim made, so a
        /// test can prove the console follower was wired into `claim_standby`
        /// itself, not only the cold-boot path — every existing caller of this
        /// helper ignores the field, so threading it through costs them nothing.
        console_streamer: Arc<RecordingConsoleStreamer>,
    }

    /// Drive one full claim over a clean audited parent against `driver`, whose
    /// `deliver_child_identity` answer the caller has scripted. Everything the
    /// claim touches (MVM_HOME, stores, pool, registry) is fresh per call, so the
    /// handshake outcomes are independent of each other.
    fn claim_with_scripted_handshake(driver: MockDriver) -> HandshakeClaimOutcome {
        claim_with_scripted_handshake_and_grant(driver, None, None)
    }

    fn claim_with_scripted_handshake_and_grant(
        driver: MockDriver,
        agent_verbs: Option<Vec<VerbId>>,
        grant_issuer: Option<&dyn ChildGrantIssuer>,
    ) -> HandshakeClaimOutcome {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);
        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_verbs(&parent_digest, agent_verbs),
        );

        let probe = driver.clone();
        let streamer = Arc::new(RecordingConsoleStreamer::default());
        let runner = WorkloadRunner::new(
            driver,
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        )
        .with_console_streamer(streamer.clone() as Arc<dyn ConsoleStreamer>);
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer,
        };

        let result = runner.claim_standby(&ctx, &handle, &claim);
        HandshakeClaimOutcome {
            result,
            driver: probe,
            parent_state: pool.load("warm-parent").ok().map(|h| h.state),
            orphan_child_dirs: orphan_child_dirs(),
            console_streamer: streamer,
        }
    }

    #[test]
    fn a_parent_this_host_cannot_restore_is_dropped_not_returned_to_rotation() {
        // A standby another VMM version captured: every claim would fail the
        // same way, so returning it to claimable would cost each later launch a
        // failed fork until its TTL.
        let out = claim_with_scripted_handshake(
            MockDriver::default().refusing_fork_as_unrestorable("snapshot format v8.0.0"),
        );

        let err = out
            .result
            .expect_err("an unrestorable parent cannot be claimed");
        assert!(matches!(err, StandbyError::Unrestorable(_)), "{err}");
        assert_eq!(
            out.parent_state, None,
            "the parent must be dropped from the pool, not released"
        );
        assert_eq!(
            out.orphan_child_dirs, 0,
            "the child dir is still cleaned up"
        );
    }

    #[test]
    fn claim_refuses_a_grant_bearing_plan_before_fork_when_no_issuer_is_configured() {
        let out = claim_with_scripted_handshake_and_grant(
            MockDriver::default(),
            Some(vec![VerbId::new("run-entrypoint").unwrap()]),
            None,
        );

        let err = out.result.expect_err("the missing issuer must fail closed");
        assert!(err.to_string().contains("no child grant issuer"));
        assert!(
            out.driver.forked_children().is_empty(),
            "grant issuance is checked before a child is resumed"
        );
        assert_eq!(out.parent_state, Some(StandbyState::Idle));
        assert_eq!(out.orphan_child_dirs, 0);
    }

    /// A forked child comes back resumed on its parent's saved memory, so until
    /// it answers the identity handshake it is still drawing on the parent's
    /// CSPRNG and reading the parent's frozen clock, and holds no seccomp tier.
    /// Every way that proof can fail — the guest never answers, answers without
    /// acknowledging, without rotating, without resynchronizing its clock, or
    /// without holding exactly the plan's seccomp tier — must refuse the claim,
    /// stop the live child, return the healthy parent to claimable, and leave no
    /// child dir. Admitting on any of them would hand out a VM whose "random"
    /// values match every sibling forked from the same parent.
    #[test]
    fn claim_refuses_a_child_that_cannot_prove_a_fresh_identity() {
        let unproven = |acknowledged: bool, reseeded: bool, clock_resynced: bool| {
            MockDriver::default().with_child_identity(PostRestoreOutcome {
                acknowledged,
                detail: None,
                reseeded,
                clock_resynced,
                reseed_shortfall: None,
                seccomp_tier: None,
                volumes_mounted: None,
            })
        };
        let cases = [
            (
                "guest never answered",
                MockDriver::default().with_unreachable_child_agent(),
            ),
            ("guest did not acknowledge", unproven(false, true, true)),
            ("guest did not reseed", unproven(true, false, true)),
            (
                "guest did not resync its clock",
                unproven(true, true, false),
            ),
            // A guest that proved a fresh identity but took no seccomp tier
            // would run the workload unfiltered; one holding a different tier
            // would run it under a filter the plan did not admit.
            ("guest holds no seccomp tier", unproven(true, true, true)),
            (
                "guest holds another seccomp tier",
                MockDriver::default().with_child_identity(PostRestoreOutcome {
                    acknowledged: true,
                    detail: None,
                    reseeded: true,
                    clock_resynced: true,
                    reseed_shortfall: None,
                    seccomp_tier: Some(mvm_core::crypto::seccomp::SeccompTier::Unrestricted),
                    volumes_mounted: None,
                }),
            ),
        ];

        for (label, driver) in cases {
            let out = claim_with_scripted_handshake(driver);
            let err = out
                .result
                .expect_err(&format!("{label}: the claim must fail closed"));
            assert!(
                matches!(err, StandbyError::ClaimFailed(_)),
                "{label}: refusal must be a ClaimFailed: {err}"
            );

            // The refusal lands AFTER the fork — the child really was live — and
            // the child was stopped rather than left running unproven.
            let forks = out.driver.forked_children();
            assert_eq!(forks.len(), 1, "{label}: the child was forked first");
            assert!(
                out.driver.killed_vms().contains(&forks[0].child_vm_name),
                "{label}: the refused child must be stopped, not left resumed: killed {:?}",
                out.driver.killed_vms()
            );
            assert_eq!(
                out.parent_state,
                Some(StandbyState::Idle),
                "{label}: a child-side failure must return the healthy parent to claimable"
            );
            assert_eq!(
                out.orphan_child_dirs, 0,
                "{label}: a refused claim must leave no orphan child dir"
            );
        }
    }

    /// The delivered token reaches the child's agent even on the refusal path —
    /// the claim refuses on what the guest reported, not by skipping the ask.
    #[test]
    fn claim_delivers_the_token_before_judging_the_child() {
        let out = claim_with_scripted_handshake(MockDriver::default().with_child_identity(
            PostRestoreOutcome {
                acknowledged: true,
                detail: None,
                reseeded: false,
                clock_resynced: true,
                reseed_shortfall: None,
                seccomp_tier: None,
                volumes_mounted: None,
            },
        ));
        assert!(out.result.is_err());
        let delivered = out.driver.delivered_child_identities();
        let forks = out.driver.forked_children();
        assert_eq!(delivered.len(), 1, "the token is delivered exactly once");
        assert_eq!(delivered[0].child_vm_name, forks[0].child_vm_name);
        assert_eq!(
            delivered[0].token, forks[0].genid.token,
            "the delivered token is the one the fork minted"
        );
    }

    /// The standby-fork analogue of
    /// `start_workload_starts_console_streaming_and_stop_tears_it_down_without_losing_bytes`:
    /// a claim that commits must have started console streaming for the
    /// child's own fresh name, at the same console-log path a cold boot would
    /// use.
    #[test]
    fn claim_standby_starts_console_streaming_for_the_committed_child() {
        let out = claim_with_scripted_handshake(MockDriver::default());
        let child = out.result.expect("a clean handshake commits the claim");

        // Not compared against a freshly-recomputed `vm_state_dir(&child.0)`:
        // that helper's `MVM_HOME` override is already unwound by the time this
        // assertion runs, so a second computation here would silently drift to
        // the real (un-isolated) home instead of proving anything. The path's
        // *shape* -- console.log directly under a dir named for the child --
        // is what `standing_sockets` actually guarantees, isolation or not.
        let started = out.console_streamer.started.lock().unwrap();
        assert_eq!(
            started.len(),
            1,
            "console streaming must start exactly once"
        );
        assert_eq!(started[0].0, child.0);
        assert_eq!(
            started[0].1.file_name(),
            Some(std::ffi::OsStr::new("console.log"))
        );
        assert_eq!(
            started[0].1.parent().and_then(|p| p.file_name()),
            Some(std::ffi::OsStr::new(child.0.as_str())),
            "the console log must live under the child's own state dir, not the parent's"
        );
        drop(started);
        assert_eq!(
            out.console_streamer
                .supervisor_owned
                .lock()
                .unwrap()
                .as_slice(),
            [false],
            "a restored child's capture ownership follows its backend, as a cold boot's does"
        );
        assert!(
            out.console_streamer.stopped.lock().unwrap().is_empty(),
            "a committed claim leaves the console streamer running for the \
             ordinary VmBackend::stop path to tear down later, exactly like a \
             cold boot"
        );
    }

    /// A restored child that never proves a fresh identity fails inside a real
    /// window: the post-restore handshake, where the guest is already live but
    /// not yet admitted. Without a console follower running through that
    /// window, a hang or panic there leaves an operator with nothing but an
    /// opaque `ClaimFailed` string. Also proves the follower is torn down on
    /// refusal rather than leaked -- `force_stop` only kills the VMM, so
    /// `claim_standby` itself must reap the streamer it started.
    #[test]
    fn claim_standby_stops_console_streaming_when_the_post_restore_handshake_is_refused() {
        let out =
            claim_with_scripted_handshake(MockDriver::default().with_unreachable_child_agent());
        let err = out
            .result
            .expect_err("an unanswered handshake must refuse the claim");
        assert!(matches!(err, StandbyError::ClaimFailed(_)));

        let forks = out.driver.forked_children();
        assert_eq!(
            forks.len(),
            1,
            "the child was forked and resumed before the handshake ran"
        );
        let child_name = forks[0].child_vm_name.clone();

        // Started while the child was live -- the only way an operator would
        // see a hang or panic inside the handshake window this refusal covers.
        let started = out.console_streamer.started.lock().unwrap();
        assert_eq!(
            started.len(),
            1,
            "console streaming must have started for the forked child"
        );
        assert_eq!(started[0].0, child_name);
        assert_eq!(
            started[0].1.parent().and_then(|p| p.file_name()),
            Some(std::ffi::OsStr::new(child_name.as_str())),
            "the console log must live under the child's own state dir"
        );
        drop(started);
        // ...and stopped once the claim gave up on it, so the follower thread
        // does not outlive a child that was never admitted.
        assert_eq!(
            out.console_streamer.stopped.lock().unwrap().as_slice(),
            [child_name]
        );
    }

    /// A post-materialize failure (here: the overlay-contract gate refusing a
    /// child whose clone carries no overlay sidecar) must return the healthy
    /// reserved parent to claimable and remove the orphaned child dir — no leaked
    /// warm capacity, no orphaned state. This ALSO proves the overlay gate is
    /// wired into `claim_standby`: with the gate deleted, this claim would
    /// succeed.
    #[test]
    fn claim_releases_reserved_parent_and_removes_child_dir_on_overlay_refusal() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        // No overlay sidecar → the child clone fails the overlay-contract gate,
        // which runs AFTER materialize (so a child dir already exists).
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), false);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("the overlay-contract gate must refuse a sidecar-less child");
        assert!(
            err.to_string().contains("overlay contract")
                || err.to_string().contains("mvm-meta.json"),
            "refusal must name the overlay gate: {err}"
        );

        // The healthy parent is returned to claimable (not stranded `Claimed`).
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Idle,
            "a non-parent-fault failure must return the parent to claimable"
        );
        // No child dir orphaned.
        assert_eq!(
            orphan_child_dirs(),
            0,
            "a failed claim must leave no orphan child dir"
        );
        // The fork never ran.
        assert!(runner.driver.forked_children().is_empty());
    }

    /// A failed claim destroys the preloaded child, so the record must stop
    /// naming it — otherwise the standby stays `Idle` advertising a paused VMM
    /// that no longer exists, and every later claim refuses on a missing control
    /// socket while `idle_count_compatible` still counts it as capacity. That
    /// made a standby single-use against even a retryable failure.
    ///
    /// The parent and its checkpoint are healthy, so it demotes to saved-state
    /// (the `pid == 0` sentinel) rather than being removed: warm capacity
    /// survives and the next claim materializes a fresh child from the
    /// checkpoint.
    #[test]
    fn a_failed_claim_demotes_a_preloaded_standby_instead_of_stranding_it() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        // No overlay sidecar → the claim fails the overlay-contract gate, which
        // is a non-parent-fault failure reached after the child is tracked.
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), false);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let mut handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        // A preloaded standby: the pool owns a paused child VMM instead of being
        // saved-only, so it carries the child's name and a live pid.
        let child_name = "preloaded-child".to_string();
        handle.preloaded_child_vm_name = Some(child_name.clone());
        handle.pid = std::process::id();
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);
        materialize_child_from_parent(
            &checkpoints,
            &snapshots,
            &parent_id,
            &anchor,
            &vm_state_dir(&child_name),
        )
        .unwrap();

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );
        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("the overlay-contract gate must refuse this claim");

        let after = pool.load("warm-parent").unwrap();
        assert_eq!(
            after.state,
            StandbyState::Idle,
            "a non-parent-fault failure must return the parent to claimable"
        );
        assert!(
            after.preloaded_child_vm_name.is_none(),
            "the record must stop naming a child the cleanup destroyed"
        );
        assert!(
            after.is_saved_state(),
            "a standby with no preloaded child is saved-only (pid == 0), so the next \
             claim materializes a fresh child from the checkpoint"
        );
        assert!(
            SupervisorStandbyPool::is_live_or_saved(&after),
            "the demoted parent must remain usable capacity, not read as dead"
        );
        assert!(
            runner.driver.killed_vms().contains(&child_name),
            "the destroyed child's VMM must be stopped, not orphaned: killed {:?}",
            runner.driver.killed_vms()
        );
    }

    /// An un-audited parent (no signed creation entry) is quarantined by removal,
    /// NOT returned to claimable — a parent that cannot be verified must never be
    /// reused. The failure is caught before any child identity/dir is minted.
    #[test]
    fn claim_quarantines_unaudited_parent_without_releasing_it() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        // The chain carries no signed creation entry for this parent.
        let anchor = ClaimTestAnchor::unaudited();

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("an un-audited parent must be refused");
        assert!(
            err.to_string().contains("no signed audit entry"),
            "refusal must be the un-audited reason: {err}"
        );

        // Quarantined by removal — NOT returned to claimable.
        assert!(
            pool.load("warm-parent").is_err(),
            "an un-audited parent must be quarantined (removed), never released"
        );
        // Nothing was minted or booted.
        assert_eq!(
            orphan_child_dirs(),
            0,
            "no child dir on a quarantine refusal"
        );
        assert!(runner.driver.forked_children().is_empty());
    }

    /// A plan whose bound image digest does not match the parent's own verified
    /// rootfs is refused before any child side effect: the bind gate runs right
    /// after reserve, so this is a non-parent-fault failure (the parent itself
    /// verified fine) and must return it to claimable, unlike an unverifiable
    /// parent which is quarantined instead.
    #[test]
    fn claim_refuses_plan_parent_image_mismatch() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        // The plan's bound image digest is unrelated to the parent's own
        // rootfs content-address.
        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&"f".repeat(64)),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("a plan bound to a different image than the parent must be refused");
        assert!(
            err.to_string()
                .contains("does not match parent rootfs digest"),
            "refusal must name the plan/parent mismatch: {err}"
        );

        // Non-parent-fault: the healthy, verified parent goes back to claimable.
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Idle,
            "a plan/parent digest mismatch must return the parent to claimable"
        );
        // The refusal runs before any child identity is minted.
        assert_eq!(
            orphan_child_dirs(),
            0,
            "no child dir on a plan/parent mismatch"
        );
        assert!(runner.driver.forked_children().is_empty());
    }

    /// A warm claim restores a child out of a parent's saved state exactly as a
    /// vm_full fork does, so it must run the same subset check. A parent sealed
    /// under a tight CPU share cannot hand a claimed child a wider one.
    #[test]
    fn claim_refuses_a_child_whose_grants_exceed_the_parents() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) = seed_audited_parent_with_grants(
            store_root.path(),
            src.path(),
            true,
            Some(mvm_contract::grants::Grants {
                cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 1000 }),
                ..Default::default()
            }),
        );
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        // Bound to the parent's own rootfs, so the image-digest bind passes and
        // the grants comparison is what refuses.
        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_grants(
                &parent_digest,
                Some(mvm_contract::grants::Grants {
                    cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 4000 }),
                    ..Default::default()
                }),
            ),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("a claimed child may not widen its parent's grants");
        assert!(
            err.to_string().contains("exceeds the parent's 1000"),
            "refusal must name the widening: {err}"
        );

        // Not the parent's fault, so warm capacity is returned rather than
        // quarantined, and nothing was minted for the refused child.
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Idle,
            "a child-side grant widening must return the parent to claimable"
        );
        assert_eq!(orphan_child_dirs(), 0, "no child dir on a grant widening");
        assert!(runner.driver.forked_children().is_empty());
    }

    /// The other side of the same check: a claimed child that narrows, or that
    /// matches, is admitted. Without this the refusal test above would pass just
    /// as well against a check that refused every claim.
    #[test]
    fn claim_admits_a_child_that_narrows_the_parents_grants() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) = seed_audited_parent_with_grants(
            store_root.path(),
            src.path(),
            true,
            Some(mvm_contract::grants::Grants {
                cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 4000 }),
                ..Default::default()
            }),
        );
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_grants(
                &parent_digest,
                Some(mvm_contract::grants::Grants {
                    cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 1000 }),
                    ..Default::default()
                }),
            ),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        runner
            .claim_standby(&ctx, &handle, &claim)
            .expect("a narrowing child must still be claimable");
    }

    /// Persist a host config whose CPU ceiling is `millicores`, so a claim in
    /// this test's isolated `MVM_HOME` is bounded by a known number rather than
    /// by whatever the default config happens to carry.
    fn host_ceiling_of(millicores: u32) {
        let cfg = mvm_core::user_config::MvmConfig {
            max_cpu_millicores: Some(millicores),
            ..Default::default()
        };
        mvm_core::user_config::save(&cfg, None).expect("write host config");
    }

    /// A parent-less bound: the standby parent deliberately carries no grant,
    /// so the parent-subset comparison clears any share at all and the host's
    /// own ceiling is what refuses. Without the ceiling check this claim boots
    /// a child holding four cores on a host configured to allow two.
    #[test]
    fn a_claimed_child_over_the_host_ceiling_is_refused() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        host_ceiling_of(2000);

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        // A grant-less parent, which is what a factory parent actually is.
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent_with_grants(store_root.path(), src.path(), true, None);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_grants(
                &parent_digest,
                Some(mvm_contract::grants::Grants {
                    cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 4000 }),
                    ..Default::default()
                }),
            ),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("a claim over the host ceiling must be refused");
        assert!(
            err.to_string().contains("grant ceiling"),
            "refusal must read as a bound: {err}"
        );

        // The host, not the parent, refused: warm capacity goes back and
        // nothing was minted for the child.
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Idle,
            "a ceiling refusal must return the parent to claimable"
        );
        assert_eq!(orphan_child_dirs(), 0, "no child dir on a ceiling refusal");
        assert!(runner.driver.forked_children().is_empty());
    }

    /// The other side: a claim at or under the ceiling still gets its warm
    /// start. Without this the refusal witness above would pass equally well
    /// against a check that refused every claim.
    #[test]
    fn a_claimed_child_within_the_ceiling_is_admitted() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        host_ceiling_of(2000);

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent_with_grants(store_root.path(), src.path(), true, None);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json_with_grants(
                &parent_digest,
                Some(mvm_contract::grants::Grants {
                    cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 1500 }),
                    ..Default::default()
                }),
            ),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        runner
            .claim_standby(&ctx, &handle, &claim)
            .expect("a claim within the host ceiling must still be claimable");
    }

    /// Because the bound is checked after the pool has already matched, a
    /// refused claim looks superficially like a pool bug: the parent was found,
    /// reserved, and then the claim died. The message is the only thing that
    /// distinguishes the two, so it has to carry both numbers — what the host
    /// allows and what the plan asked for.
    #[test]
    fn the_refusal_names_the_ceiling_and_the_request() {
        let refusal = ensure_child_grants_within_host_ceiling(
            Some(&mvm_contract::grants::Grants {
                cpu: Some(mvm_contract::grants::CpuGrant::Share { millicores: 4000 }),
                ..Default::default()
            }),
            &mvm_contract::grants::ceiling::GrantCeiling {
                max_cpu_millicores: Some(2000),
                ..Default::default()
            },
        )
        .expect_err("4000 millicores exceeds a 2000-millicore ceiling");

        let text = refusal.to_string();
        assert!(
            text.contains("2000"),
            "refusal must name the ceiling: {text}"
        );
        assert!(
            text.contains("4000"),
            "refusal must name the request: {text}"
        );
        assert!(
            text.contains("cpu.share_millicores"),
            "refusal must name the bounded dimension: {text}"
        );
        assert!(
            text.contains("ceiling"),
            "refusal must read as a bound being enforced, not a failure: {text}"
        );
    }

    /// The bound is checked after matching, never folded into the pool's
    /// compatibility key: keying on a grant would split one pool into a pool
    /// per distinct share and cost the warm hit rate the pool exists for.
    ///
    /// Two halves, both needed. The exhaustive destructure fails to compile the
    /// day a grant dimension is added to the key — which is the move this test
    /// exists to prevent — and the selection half proves the live consequence:
    /// one warm parent serves claims asking for different shares.
    #[test]
    fn pool_matching_is_unchanged_by_the_bound() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());
        host_ceiling_of(2000);

        let store_root = tempfile::tempdir().unwrap();
        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();

        let mvm_core::vm_backend::StandbyCompat {
            template_id: _,
            kernel_sha256: _,
            vcpus: _,
            mem_mib: _,
            image_sha256: _,
            root_strategy: _,
            vsock_egress: _,
        } = handle.compat();

        // The key is derived from the parent's boot shape and takes no grant as
        // input, so every claim on this boot shape resolves the one warm parent
        // whatever share its plan asks for — including one the ceiling will go
        // on to refuse. Matching and bounding stay separate decisions.
        let want = handle.compat();
        let picked = pool
            .select_idle_compatible(&want)
            .unwrap()
            .expect("a claim on this boot shape must match the warm parent");
        assert_eq!(picked.id, "warm-parent");
        assert_eq!(
            picked.compat(),
            want,
            "the matched parent's key must be the one that was asked for"
        );
    }

    /// A parent whose sealed `meta.json` is edited after capture — without
    /// recomputing its content-address — drifts from its own stored digest.
    /// This is distinct from the un-audited-parent case: here the chain DOES
    /// carry a signed entry, but the on-disk record no longer matches what was
    /// signed, so the recompute-vs-stored check must catch it before the chain
    /// lookup ever runs. Quarantined by removal, the same fail-closed posture
    /// as the un-audited case, since a record that cannot be verified must
    /// never be reused.
    #[test]
    fn claim_refuses_drift_tampered_parent() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");
        // Anchored to the digest the ORIGINAL sealed record carried — the chain
        // attests to what was signed, not to whatever is on disk now.
        let anchor = ClaimTestAnchor::audited(&parent_meta);

        // Tamper the on-disk record after sealing: mutate a load-bearing field
        // without touching `meta_digest`, so the stored digest goes stale.
        let mut tampered = checkpoints.read_meta(&parent_id).unwrap();
        tampered.vm_name = "attacker-renamed".into();
        checkpoints.write_meta(&tampered).unwrap();
        assert_ne!(
            tampered.compute_meta_digest(),
            tampered.meta_digest,
            "the tamper must actually drift the digest, or this test proves nothing"
        );

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );
        let ctx = ClaimContext {
            pool: &pool,
            checkpoints: &checkpoints,
            snapshots: &snapshots,
            anchor: &anchor,
            parent_checkpoint: &parent_id,
            registry_path: &registry_path,
            grant_issuer: None,
        };

        let err = runner
            .claim_standby(&ctx, &handle, &claim)
            .expect_err("a drift-tampered parent must be refused");
        assert!(
            err.to_string().contains("drift"),
            "refusal must name the drift reason: {err}"
        );

        // Quarantined by removal — NOT returned to claimable, mirroring the
        // un-audited case: an unverifiable record must never be reused.
        assert!(
            pool.load("warm-parent").is_err(),
            "a drift-tampered parent must be quarantined (removed), never released"
        );
        assert_eq!(
            orphan_child_dirs(),
            0,
            "no child dir on a quarantine refusal"
        );
        assert!(runner.driver.forked_children().is_empty());
    }

    /// Two concurrent claims against the same idle parent: the reserve step
    /// (load + claimable check + `mark_claimed`) runs under the registry file
    /// lock, so exactly one claim can observe the parent as claimable. Real
    /// threads racing the same runner + context prove the exclusion is actually
    /// enforced, not just serialized by test structure.
    #[test]
    fn concurrent_claims_do_not_double_claim_one_parent() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let src = tempfile::tempdir().unwrap();
        let (checkpoints, snapshots, parent_id, parent_meta) =
            seed_audited_parent(store_root.path(), src.path(), true);
        let parent_digest = materialized_parent_rootfs_digest(&checkpoints, &parent_meta);

        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let registry_path = store_root.path().join("vm-names.json");

        let claim = admitted_child_claim(
            &src.path().join("rootfs.ext4"),
            signed_child_plan_json(&parent_digest),
        );

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            KeyingSpawner::default(),
            RecordingBrokerRegistrar::new(),
        );

        // `dyn CheckpointChainAnchor` carries no `Sync` bound (real anchors are
        // the CLI's host-signer-backed audit-chain reader, never shared across
        // threads in production), so each thread gets its own owned anchor
        // instance and builds its own `ClaimContext` locally rather than
        // sharing one `&dyn CheckpointChainAnchor` across the thread boundary.
        let anchor1 = ClaimTestAnchor::audited(&parent_meta);
        let anchor2 = ClaimTestAnchor::audited(&parent_meta);

        let results: Vec<std::result::Result<VmId, StandbyError>> = std::thread::scope(|s| {
            let t1 = s.spawn(|| {
                let ctx = ClaimContext {
                    pool: &pool,
                    checkpoints: &checkpoints,
                    snapshots: &snapshots,
                    anchor: &anchor1,
                    parent_checkpoint: &parent_id,
                    registry_path: &registry_path,
                    grant_issuer: None,
                };
                runner.claim_standby(&ctx, &handle, &claim)
            });
            let t2 = s.spawn(|| {
                let ctx = ClaimContext {
                    pool: &pool,
                    checkpoints: &checkpoints,
                    snapshots: &snapshots,
                    anchor: &anchor2,
                    parent_checkpoint: &parent_id,
                    registry_path: &registry_path,
                    grant_issuer: None,
                };
                runner.claim_standby(&ctx, &handle, &claim)
            });
            vec![t1.join().unwrap(), t2.join().unwrap()]
        });

        let successes = results.iter().filter(|r| r.is_ok()).count();
        assert_eq!(
            successes, 1,
            "exactly one concurrent claim on the same parent must succeed"
        );
        let loser = results
            .iter()
            .find(|r| r.is_err())
            .unwrap()
            .as_ref()
            .unwrap_err();
        assert!(
            loser.to_string().contains("not in a claimable state"),
            "the losing claim must be refused by the reserve check, not some other error: {loser}"
        );

        // Exactly one fork happened and exactly one child dir landed — never
        // two, which is what a broken exclusion would produce.
        assert_eq!(
            runner.driver.forked_children().len(),
            1,
            "the reserve race must not let both claims through to the fork"
        );
        assert_eq!(
            orphan_child_dirs(),
            1,
            "exactly one child dir must exist after the race"
        );
        assert_eq!(
            pool.load("warm-parent").unwrap().state,
            StandbyState::Claimed,
            "the winner's parent stays reserved, never returned mid-race"
        );
    }

    /// There is no code path on this runner that takes an existing standby
    /// parent's identity and runs a workload directly on it — the guarantee is
    /// structural, not a runtime check. `claim_standby` is the only method that
    /// consumes a `StandbyHandle`, and it always mints a fresh child id distinct
    /// from the parent's own (see `claim_produces_fresh_identity_and_isolated_endpoint`).
    /// The only OTHER way this runner produces a running `VmId` is a cold
    /// `start`, which carries no reference to the standby pool at all: a parent
    /// lives under the pool root, a workload under the VM state root, so naming
    /// a cold boot after a live parent cannot promote it — it lands in a
    /// disjoint directory and leaves the parent's own record untouched.
    #[test]
    fn promoting_a_parent_to_a_workload_is_refused() {
        let _guard = crate::base::runtime_meta::HOME_TEST_LOCK
            .lock()
            .unwrap_or_else(|e| e.into_inner());
        let home = tempfile::tempdir().unwrap();
        let mut env = TestEnv::new();
        env.set("MVM_HOME", home.path());

        let store_root = tempfile::tempdir().unwrap();
        let pool = SupervisorStandbyPool::at(store_root.path().join("pool"));
        let handle = idle_parent_handle("warm-parent", &store_root.path().join("control.sock"));
        pool.record(&handle).unwrap();
        let before = pool.load("warm-parent").unwrap();

        let runner = WorkloadRunner::new(
            MockDriver::default(),
            RecordingSpawner::new("/run/ep.sock"),
            RecordingBrokerRegistrar::new(),
        );

        // The closest thing to "run a workload on this VmId": a cold start
        // under the parent's own name.
        let (_rootfs_dir, rootfs) = overlay_aware_rootfs("warm-parent");
        let cfg = VmStartConfig {
            name: "warm-parent".into(),
            rootfs_path: rootfs,
            ..Default::default()
        };
        let started =
            mapping_start(&runner, &cfg).expect("start is an ordinary cold boot, not a claim");
        assert_eq!(started.0, "warm-parent");

        // `start` never reads or mutates the standby pool — the parent's
        // record is byte-for-byte unchanged.
        assert_eq!(
            pool.load("warm-parent").unwrap(),
            before,
            "a cold-started workload sharing the parent's name must not touch its pool record"
        );

        // Disjoint directory roots: the parent lives under the pool root, the
        // workload under the VM state root. There is no shared resource here
        // to promote.
        let workload_dir = vm_state_dir("warm-parent");
        let parent_dir = pool.root().join("warm-parent");
        assert_ne!(
            workload_dir, parent_dir,
            "the started workload and the registered parent must not share a directory"
        );
        assert_eq!(before.state, StandbyState::Idle);
    }
}
