import pathlib,hashlib,json,subprocess,os,time
r=pathlib.Path('/var/tmp/spiralcore-retained-catalog-20261104');source=r/'source';out=r/'validation/retained-v2-b2-final-protected';prior=r/'validation/retained-v2-b2-closed-successor'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((prior/'source-after.json').read_text());assert all(sha(source/k)==v for k,v in before.items());(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
binary=prior/'protected-test';binsha=sha(binary);(out/'binary-before.sha256').write_text(binsha+'\n')
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/var/tmp/spiralcore-resident-parent-20261103/publication-target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1',SPIRALCORE_OLD_RETAINED_BIN=str(r/'validation/recovery-old-fixture-baseline/protected-test'),SPIRALCORE_OLD_RETAINED_STATE=str(r/'validation/recovery-old-fixture-baseline/old-process-state'))
for key in ['SPIRALCORE_B2_HOME','SPIRALCORE_B2_CRASH','SPIRALCORE_OLD_RETAINED_FIXTURE']:env.pop(key,None)
commands=[('full',[str(binary),'--test-threads=1']),('stage-a',[str(binary),'--ignored','installed_owner::retained_telemetry::recovery::tests::acquisition_','--test-threads=1']),('marker',[str(binary),'--ignored','--exact','installed_owner::retained_telemetry::recovery::tests::malformed_marker_retains_the_original_state_pin_in_blocked_custody','--test-threads=1']),('phase-two',[str(binary),'--ignored','--exact','installed_supervisor::retained_tests::closed_recovery_charges_old_phase_two_debt_without_reopening_admission','--test-threads=1'])]
for name,argv in commands:
 (out/(name+'-command.json')).write_text(json.dumps(argv)+'\n')
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  proc=subprocess.Popen(argv,cwd=source,env=env,stdout=stdout,stderr=stderr);(out/(name+'.pid')).write_text(str(proc.pid)+'\n');code=proc.wait()
 (out/(name+'.exit')).write_text(str(code)+'\n');print(name,code,flush=True)
 if code:break
after={k:sha(source/k) for k in before};assert before==after;(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert sha(binary)==binsha;(out/'binary-after.sha256').write_text(sha(binary)+'\n');(out/'batch.exit').write_text(str(code)+'\n')
