import pathlib,hashlib,json,tarfile,subprocess,os,shutil,time
r=pathlib.Path('/var/tmp/spiralcore-retained-catalog-20261104'); source=r/'source'; out=r/'validation/retained-v2-b2-api-red'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((out/'source.sha256.json').read_text())
baseline=json.loads((r/'validation/retained-v2-b2-publisher-green/source-after.json').read_text())
pre={p:sha(source/p) for p in baseline}
(out/'pre-overlay-source.json').write_text(json.dumps(pre,indent=2)+'\n')
bad=[p for p in baseline if p not in expected and pre[p]!=baseline[p]]
assert not bad,('unowned preimage differences',bad)
preimage=out/'preimages';preimage.mkdir(exist_ok=False)
with tarfile.open(out/'source-overlay.tar.gz') as t:
 assert set(t.getnames())==set(expected)
 for m in t.getmembers():
  assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
  path=source/m.name
  if path.exists():
   saved=preimage/m.name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,saved)
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(t.extractfile(m).read())
  assert sha(path)==expected[m.name]
keys=sorted(set(baseline)|set(expected)); before={p:sha(source/p) for p in keys};(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
lock=source/'crates/spiralcore-mvm-live/Cargo.lock';assert before[str(lock.relative_to(source))]==baseline[str(lock.relative_to(source))]
argv=['/home/callard/.cargo/bin/cargo','+1.97.1','test','--release','--offline','--locked','--manifest-path',str(source/'crates/spiralcore-mvm-live/Cargo.toml'),'--features','linux-host,canonical-host','--lib','--no-run','--message-format=json']
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/var/tmp/spiralcore-resident-parent-20261103/publication-target',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='1')
(out/'command.json').write_text(json.dumps({'argv':argv,'started_unix':time.time(),'env':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS']}},indent=2)+'\n')
with (out/'build.jsonl').open('w') as stdout,(out/'build.stderr').open('w') as stderr:
 proc=subprocess.Popen(argv,env=env,cwd=source,stdout=stdout,stderr=stderr);(out/'build.pid').write_text(str(proc.pid)+'\n');code=proc.wait()
(out/'build.exit').write_text(str(code)+'\n')
after={p:sha(source/p) for p in keys};(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
(out/'batch.exit').write_text(str(code)+'\n');print('BATCH_TERMINAL',code,flush=True)
