//! Actual closed debt transfer. This module exports NO native issuer or grant.
use super::super::transfer::{TransferIntent, TransferKind};
use super::*;

pub(super) struct CompiledRetainedMigration {
    target_profile: [u8; 32],
}
impl CompiledRetainedMigration {
    pub(super) fn current() -> RecoveryResult<Self> {
        Ok(Self {
            target_profile: RetainedRecoveryCompatibility::current()?.profile,
        })
    }
}
struct Transaction {
    recovery: Option<RetainedRecovery>,
    intent: Option<TransferIntent>,
    target_bytes: Vec<u8>,
    pending_storage: Option<Arc<Storage>>,
    old_state: Option<File>,
    intent_staging: Option<File>,
    catalog_staging: Option<File>,
    state_intent: Option<File>,
    state_staging: Option<File>,
}
pub(super) struct PreparedRetainedRestart {
    held: Option<Box<Transaction>>,
}
impl Drop for PreparedRetainedRestart {
    fn drop(&mut self) {
        if let Some(held) = self.held.take() {
            std::mem::forget(held);
        }
    }
}
pub(super) struct RetainedRestartFailure {
    _error: SupervisorError,
    _original: PreparedRetainedRestart,
}
impl fmt::Debug for RetainedRestartFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("retained transaction refused; same original closed custody retained")
    }
}
pub(super) struct CommittedRetainedRestart {
    closed: ClosedRetainedDebt,
}
impl CommittedRetainedRestart {
    pub(super) fn snapshot(&self) -> RecoveryResult<RetainedDebtSnapshot> {
        self.closed.snapshot()
    }
    pub(super) fn binding(&self) -> RecoveryResult<InstallationBinding> {
        let held = self
            .closed
            .recovery
            .held
            .as_ref()
            .ok_or(SupervisorError::State)?;
        held.funding()?
            .authority()
            .with_disk_owner(|owner, epoch| owner.active_binding(epoch))
    }
}
impl ClosedRetainedDebt {
    pub(super) fn prepare_restart(
        self,
        migration: &CompiledRetainedMigration,
    ) -> std::result::Result<PreparedRetainedRestart, RetainedRestartFailure> {
        let mut prepared = PreparedRetainedRestart {
            held: Some(Box::new(Transaction {
                recovery: Some(self.recovery),
                intent: None,
                target_bytes: Vec::new(),
                pending_storage: None,
                old_state: None,
                intent_staging: None,
                catalog_staging: None,
                state_intent: None,
                state_staging: None,
            })),
        };
        let result = prepared
            .held
            .as_mut()
            .expect("armed transaction")
            .prepare(migration);
        match result {
            Ok(()) => Ok(prepared),
            Err(error) => Err(RetainedRestartFailure {
                _error: error,
                _original: prepared,
            }),
        }
    }
}
impl PreparedRetainedRestart {
    pub(super) fn commit_closed(
        mut self,
    ) -> std::result::Result<CommittedRetainedRestart, RetainedRestartFailure> {
        let result = self.held.as_mut().expect("armed transaction").commit();
        match result {
            Err(error) => Err(RetainedRestartFailure {
                _error: error,
                _original: self,
            }),
            Ok(()) => {
                let mut done = self.held.take().expect("committed transaction");
                let recovery = done.recovery.take().expect("actual committed custody");
                Ok(CommittedRetainedRestart {
                    closed: ClosedRetainedDebt { recovery },
                })
            }
        }
    }
}
fn create_observed(slot: &mut Option<File>, directory: &File, name: &str) -> Result<()> {
    if slot.is_some() {
        return Err(OwnerError::Fenced);
    }
    let name = CString::new(name).map_err(|_| OwnerError::InvalidStorage)?;
    // SAFETY: original directory and fixed NUL-terminated name; exclusive
    // creation, explicit0600 mode, immediately owned before fallible checks.
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            name.as_ptr(),
            libc::O_RDWR
                | libc::O_CREAT
                | libc::O_EXCL
                | libc::O_NOFOLLOW
                | libc::O_CLOEXEC
                | libc::O_NONBLOCK,
            0o600,
        )
    };
    if fd < 0 {
        return Err(storage_open_error(io::Error::last_os_error()));
    }
    // SAFETY: fresh successful openat descriptor, installed into empty custody.
    *slot = Some(unsafe { File::from_raw_fd(fd) });
    require_private_retained_file(slot.as_ref().ok_or(OwnerError::Fenced)?)
}
fn named_is(directory: &File, name: &str, actual: &File) -> Result<()> {
    let named = open_at(directory, name, libc::O_RDONLY)?;
    if object_id(&named)? != object_id(actual)? {
        return Err(OwnerError::Fenced);
    }
    Ok(())
}
fn rename_exact(directory: &File, from: &str, to: &str, actual: &File) -> Result<()> {
    named_is(directory, from, actual)?;
    let from = CString::new(from).map_err(|_| OwnerError::InvalidStorage)?;
    let to = CString::new(to).map_err(|_| OwnerError::InvalidStorage)?;
    // SAFETY: fixed names under same original held directory.
    if unsafe {
        libc::renameat(
            directory.as_raw_fd(),
            from.as_ptr(),
            directory.as_raw_fd(),
            to.as_ptr(),
        )
    } != 0
    {
        return Err(io::Error::last_os_error().into());
    }
    Ok(())
}
fn unlink_exact(directory: &File, name: &str, actual: &File) -> Result<()> {
    named_is(directory, name, actual)?;
    let name = CString::new(name).map_err(|_| OwnerError::InvalidStorage)?;
    // SAFETY: fixed private metadata name after exact held-inode comparison.
    if unsafe { libc::unlinkat(directory.as_raw_fd(), name.as_ptr(), 0) } != 0 {
        return Err(io::Error::last_os_error().into());
    }
    directory.sync_all()?;
    Ok(())
}
impl Transaction {
    fn prepare(&mut self, migration: &CompiledRetainedMigration) -> RecoveryResult<()> {
        let held = self
            .recovery
            .as_mut()
            .and_then(|value| value.held.as_mut())
            .ok_or(SupervisorError::State)?;
        held.revalidate()?;
        if held
            .entries
            .iter()
            .flatten()
            .any(|entry| entry.record.phase != 4)
        {
            return Err(SupervisorError::State);
        }
        held.funding()?.can_rebind(held.epoch)?;
        let old_epoch = held.epoch;
        let target_epoch = Epoch {
            key: InstallationKey {
                installation: old_epoch.key.installation,
                profile: migration.target_profile,
            },
            generation: old_epoch
                .generation
                .checked_add(1)
                .ok_or(OwnerError::EpochExhausted)?,
        };
        if !supported_profile(old_epoch.key.profile)
            || target_epoch.key.profile != RetainedRecoveryCompatibility::current()?.profile
        {
            return Err(SupervisorError::Profile);
        }
        let source = decode_catalog(&held.catalog_bytes, old_epoch)?;
        let source_mode = source.mode;
        let target = CatalogV2 {
            epoch: target_epoch,
            mode: CatalogMode::Active,
            entries: source.entries,
        };
        self.target_bytes = target.encode()?;
        let authority = held.funding()?.authority();
        let (pending, intent) = authority.with_disk_owner(|owner, epoch| {
            owner.active_binding(epoch)?;
            owner.storage.absent_names(&[
                TRANSFER_INTENT,
                TRANSFER_NEXT,
                CATALOG_INTENT,
                CATALOG_NEXT,
                ".endpoint-disks.bin",
                ".endpoint-disks.intent",
                ".endpoint-disks.next",
            ])?;
            super::super::super::endpoint_disks::no_namespaces(&owner.storage.directory)?;
            observe_at(
                &mut self.old_state,
                &owner.storage.directory,
                STATE,
                libc::O_RDONLY,
            )?;
            if bounded_bytes(
                self.old_state.as_ref().ok_or(OwnerError::Fenced)?,
                RECORD_BYTES,
            )? != owner.record.encode()
            {
                return Err(OwnerError::Fenced);
            }
            let mut next = owner.record;
            next.key = target_epoch.key;
            next.generation = target_epoch.generation;
            let pending = Arc::new(Storage {
                root: owner.storage.root.clone(),
                directory: owner.storage.directory.try_clone()?,
                key: next.key,
                ids: owner.storage.ids,
            });
            pending.check()?;
            let ids = owner.storage.ids;
            let intent = TransferIntent {
                source_version: if held.catalog_bytes.starts_with(b"SCRETN01") {
                    1
                } else {
                    2
                },
                kind: TransferKind::Restart,
                old_epoch,
                target_epoch,
                objects: ids.map(|id| (id.device, id.inode)),
                old_catalog_sha256: Sha256::digest(&held.catalog_bytes).into(),
                target_catalog_sha256: Sha256::digest(&self.target_bytes).into(),
                beacon_sha256: Sha256::digest(bounded_bytes(&owner._owner, 112)?).into(),
                old_record: owner.record.encode(),
                target_record: next.encode(),
                old_catalog_len: held.catalog_bytes.len() as u64,
                target_catalog_len: self.target_bytes.len() as u64,
                entries: target.entries.len() as u16,
                source_mode,
                target_mode: CatalogMode::Active,
            };
            intent.verify_reverse(&self.target_bytes)?;
            Ok((pending, intent))
        })?;
        self.pending_storage = Some(pending);
        self.intent = Some(intent);
        Ok(())
    }
    fn commit(&mut self) -> RecoveryResult<()> {
        let held = self
            .recovery
            .as_mut()
            .and_then(|value| value.held.as_mut())
            .ok_or(SupervisorError::State)?;
        held.revalidate()?;
        held.funding()?.can_rebind(held.epoch)?;
        let intent = self.intent.as_ref().ok_or(SupervisorError::State)?;
        intent.verify_reverse(&self.target_bytes)?;
        let pending = self
            .pending_storage
            .as_ref()
            .ok_or(SupervisorError::State)?;
        let directory = &pending.directory;
        pending.check()?;
        create_observed(&mut self.intent_staging, directory, TRANSFER_NEXT)?;
        let intent_file = self.intent_staging.as_mut().ok_or(SupervisorError::State)?;
        intent_file.write_all(&intent.encode()?)?;
        intent_file.sync_all()?;
        rename_exact(directory, TRANSFER_NEXT, TRANSFER_INTENT, intent_file)?;
        directory.sync_all()?;
        // Immutable intent is durable BEFORE either catalog or state changes.
        named_is(
            directory,
            CATALOG,
            held.catalog.as_ref().ok_or(SupervisorError::State)?,
        )?;
        create_observed(&mut self.catalog_staging, directory, CATALOG_NEXT)?;
        let catalog_file = self
            .catalog_staging
            .as_mut()
            .ok_or(SupervisorError::State)?;
        catalog_file.write_all(&self.target_bytes)?;
        catalog_file.sync_all()?;
        rename_exact(directory, CATALOG_NEXT, CATALOG, catalog_file)?;
        directory.sync_all()?;
        // Preserve the canonical owner's existing state-intent encoding.
        create_observed(&mut self.state_intent, directory, INTENT)?;
        let state_intent = self.state_intent.as_mut().ok_or(SupervisorError::State)?;
        state_intent.write_all(b"SCINT001")?;
        state_intent.write_all(&intent.target_epoch.generation.to_be_bytes())?;
        state_intent.write_all(&intent.target_record[BODY_BYTES..])?;
        state_intent.sync_all()?;
        directory.sync_all()?;
        create_observed(&mut self.state_staging, directory, NEXT)?;
        let state = self.state_staging.as_mut().ok_or(SupervisorError::State)?;
        state.write_all(&intent.target_record)?;
        state.sync_all()?;
        named_is(
            directory,
            STATE,
            self.old_state.as_ref().ok_or(SupervisorError::State)?,
        )?;
        rename_exact(directory, NEXT, STATE, state)?;
        directory.sync_all()?;
        unlink_exact(directory, INTENT, state_intent)?;
        if bounded_bytes(state, RECORD_BYTES)? != intent.target_record
            || bounded_bytes(catalog_file, MAX_BYTES)? != self.target_bytes
        {
            return Err(SupervisorError::State);
        }
        // Install the paired Storage.key and Record only after known barriers.
        held.funding()?.authority().with_disk_owner(|owner, _| {
            if Sha256::digest(bounded_bytes(&owner._owner, 112)?).as_slice() != intent.beacon_sha256
            {
                return Err(OwnerError::Fenced);
            }
            owner.storage = pending.clone();
            owner.record = Record::decode(&intent.target_record)?;
            Ok(())
        })?;
        let original = held.funding.take().ok_or(SupervisorError::State)?;
        match original.rebind_closed(intent.target_epoch) {
            Ok(rebound) => held.funding = Some(rebound),
            Err(original) => {
                held.rebind_failure = Some(original);
                return Err(SupervisorError::State);
            }
        }
        held.epoch = intent.target_epoch;
        held.catalog = self.catalog_staging.take();
        held.catalog_bytes = std::mem::take(&mut self.target_bytes);
        held.revalidate()?;
        unlink_exact(directory, TRANSFER_INTENT, intent_file)?;
        pending.check()?;
        Ok(())
    }
}
