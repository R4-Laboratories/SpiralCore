// Compile the exact actual implementation files, without copying their bodies.
mod jailer {
    pub use mvm_hostd::jailer::{ConfinementSpec, JailerError};
    #[path = "/var/tmp/spiralcore-canonical-lifetime-20261103/source/crates/mvm-hostd/src/jailer/refusal_report.rs"]
    pub mod refusal_report;
    #[path = "/var/tmp/spiralcore-canonical-lifetime-20261103/source/crates/mvm-hostd/src/jailer/seccomp.rs"]
    pub mod seccomp;
}
