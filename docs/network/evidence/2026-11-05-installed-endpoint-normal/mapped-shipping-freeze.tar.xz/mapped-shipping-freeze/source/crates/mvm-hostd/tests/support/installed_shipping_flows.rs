//! Process-only peers for the actual shipping controller. No VM/quota grant.
use anyhow::{Result, ensure};
use ed25519_dalek::SigningKey;
use mvm_contract::{
    peer::{PeerBinding, PeerName},
    policy::network_policy::{
        CooperatingPayloadPolicy, CooperatingTcpPeer, NetworkPolicy, PayloadMappingProfile,
    },
    protocol::network_flow::{Opcode, hello::Handshake},
};
use mvm_core::net::session::Session;
use mvm_vmm::host::network_endpoint_spawn::AdmittedNetworkPlan;
use std::{net::TcpListener, os::unix::net::UnixStream, path::Path, thread::JoinHandle};

use super::installed_factory::{self as factory, TARGET, receive, send};

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum FlowCase {
    Mapped,
    Unmapped,
}
const UNMAPPED: &str = "plain.mvm.peer";

pub(crate) struct OriginalPeer {
    case: FlowCase,
    listener: Option<TcpListener>,
    identity: spiralcore_mvm_flowmux::tls::PinnedIdentity,
    worker: Option<JoinHandle<()>>,
}
impl OriginalPeer {
    pub(crate) fn new(case: FlowCase) -> Result<Self> {
        let listener = TcpListener::bind("127.0.0.1:0")?;
        listener.set_nonblocking(true)?;
        Ok(Self {
            case,
            listener: Some(listener),
            identity: factory::identity(&SigningKey::from_bytes(&[8; 32])),
            worker: None,
        })
    }
    pub(crate) fn policy(&self) -> Result<NetworkPolicy> {
        let address = self.listener.as_ref().unwrap().local_addr()?;
        let mut peers = vec![PeerBinding {
            name: PeerName::parse(TARGET)?,
            port: 443,
            host_addr: address.ip().to_string(),
            host_port: address.port(),
        }];
        if self.case == FlowCase::Unmapped {
            peers.push(PeerBinding {
                name: PeerName::parse(UNMAPPED)?,
                port: 443,
                host_addr: address.ip().to_string(),
                host_port: address.port(),
            });
        }
        Ok(NetworkPolicy::deny_all()
            .with_peers(peers)
            .with_payload_mapping(Some(CooperatingPayloadPolicy::new(vec![
                CooperatingTcpPeer {
                    host: TARGET.into(),
                    port: 443,
                    server_name: TARGET.into(),
                    spki_sha256: self.identity.spki_sha256(),
                    profile: PayloadMappingProfile::SpiralCoreObjectStreamSmallV1,
                },
            ])?)))
    }
    pub(crate) fn start(&mut self, plan: &AdmittedNetworkPlan, state: &Path) -> Result<()> {
        if self.case == FlowCase::Mapped {
            let listener = self.listener.take().unwrap();
            let address = listener.local_addr()?;
            let identity = factory::identity(&SigningKey::from_bytes(&[8; 32]));
            let config = serde_json::json!({
                "admitted_network_plan": plan,
                "flowmux_identity": {"session_id": hex::encode([3; 32])},
            });
            let state = state.to_owned();
            self.worker = Some(std::thread::spawn(move || {
                factory::peer(
                    listener,
                    address,
                    identity,
                    config,
                    factory::Case::Duplex,
                    state,
                );
            }));
        }
        Ok(())
    }
    pub(crate) fn exchange(
        &mut self,
        guest: &mut UnixStream,
        session: &mut Session,
    ) -> Result<bool> {
        send(
            guest,
            session,
            Opcode::Hello,
            0,
            &Handshake::local("shipping-payload-fixture").encode(),
        );
        ensure!(receive(guest, session).0 == Opcode::HelloAck);
        let target = if self.case == FlowCase::Mapped {
            TARGET
        } else {
            UNMAPPED
        };
        send(
            guest,
            session,
            Opcode::OpenTcp,
            1,
            format!("{target}:443").as_bytes(),
        );
        let (opcode, id, body) = receive(guest, session);
        if self.case == FlowCase::Unmapped {
            // Check only after the response: old Opened implies connect already
            // happened; no timeout/sleep can hide a late connection here.
            let zero_dial = match self.listener.as_ref().unwrap().accept() {
                Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => true,
                Ok((socket, _)) => {
                    drop(socket);
                    false
                }
                Err(error) => return Err(error.into()),
            };
            eprintln!("unmapped original response={opcode:?} zero_dial={zero_dial}");
            return Ok(opcode == Opcode::Refused && id == 1 && zero_dial);
        }
        ensure!(
            opcode == Opcode::Opened && id == 1,
            "mapped open refused: {}",
            String::from_utf8_lossy(&body)
        );
        let expected = factory::payload();
        send(guest, session, Opcode::Data, 1, &expected);
        send(guest, session, Opcode::HalfClose, 1, &[]);
        let mut received = Vec::with_capacity(expected.len());
        loop {
            let (opcode, id, body) = receive(guest, session);
            ensure!(id == 1);
            match opcode {
                Opcode::WindowUpdate => {}
                Opcode::Data => {
                    ensure!(
                        received.len() + body.len() <= expected.len(),
                        "excess application bytes"
                    );
                    received.extend_from_slice(&body);
                }
                Opcode::HalfClose => break,
                other => anyhow::bail!("unexpected mapped frame {other:?}"),
            }
        }
        ensure!(received == expected, "exact original guest response bytes");
        self.worker
            .take()
            .unwrap()
            .join()
            .map_err(|_| anyhow::anyhow!("original cooperating peer failed"))?;
        eprintln!(
            "actual mapped application readbacks {} bytes each direction; canonical artifacts verified at original peer",
            expected.len()
        );
        Ok(true)
    }
}
impl Drop for OriginalPeer {
    fn drop(&mut self) {
        // The canonical peer has its original bounded I/O deadline. Never
        // discard its original handle on a fixture refusal/error path.
        if let Some(worker) = self.worker.take() {
            let _ = worker.join();
        }
    }
}
