//! Foreground original-child lifecycle. Legacy endpoint startup is separate.

use super::{Component, InstalledEndpointProgram, InstalledEndpointResources};
use anyhow::{Context, Result, ensure};
use mvm_vmm::host::network_endpoint_spawn::InstalledEndpointChild;
use std::time::{Duration, Instant};

mod network;
pub use network::{OwnedNetworkRuntimeRequirements, owned_network_runtime_requirements};

/// Requested controller storage; bootstrap, collector, relays and readers have
/// separate same-partition charges. This is not process RSS/native heap proof.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct OwnedEndpointRuntimeRequirements {
    pub main_stack_envelope_bytes: u64,
    pub controller_metadata_bytes: u64,
    pub additional_threads: u8,
}

pub fn owned_endpoint_runtime_requirements() -> Result<OwnedEndpointRuntimeRequirements> {
    const MAIN_STACK: u64 = 8 * 1024 * 1024;
    let mut limit = std::mem::MaybeUninit::<libc::rlimit>::uninit();
    // SAFETY: one writable native rlimit value, queried without changing limits.
    ensure!(
        unsafe { libc::getrlimit(libc::RLIMIT_STACK, limit.as_mut_ptr()) } == 0,
        "installed main stack query refused"
    );
    // SAFETY: successful getrlimit initialized this value.
    let limit = unsafe { limit.assume_init() };
    ensure!(
        limit.rlim_cur != libc::RLIM_INFINITY
            && limit.rlim_cur > 0
            && limit.rlim_cur <= MAIN_STACK as libc::rlim_t,
        "installed main stack envelope unsupported"
    );
    let supplement = mvm_core::host_lifetime::native_thread_stack_terms(MAIN_STACK)?;
    Ok(OwnedEndpointRuntimeRequirements {
        // Conservatively retain the full declared main envelope and the same
        // Rust signal-stack mapping term, independent of observed resident pages.
        main_stack_envelope_bytes: supplement.known_rust_bytes,
        // Fixed poll descriptors, original control/owner references and terminal
        // bookkeeping. Raw/typed config is charged by the bootstrap query.
        controller_metadata_bytes: 65_536,
        additional_threads: 0,
    })
}

/// Called by the canonical binary BEFORE orphan watchers or runtime threads.
/// The original private-stdio handshake alone creates its child/resource owners.
pub fn run_installed_endpoint() -> Result<()> {
    let mut child = InstalledEndpointChild::from_stdio()?;
    let resources = InstalledEndpointResources::from_child(&mut child)?;
    if matches!(&resources.program, InstalledEndpointProgram::Network(_)) {
        return network::run(child, resources);
    }
    let requirements = owned_endpoint_runtime_requirements()?;
    let _controller = resources.claim_component(
        Component::Controller,
        requirements.main_stack_envelope_bytes,
        requirements.controller_metadata_bytes,
    )?;
    #[cfg(target_os = "linux")]
    {
        let InstalledEndpointProgram::TelemetryOnly(config) = &resources.program else {
            unreachable!("validated original collector program")
        };
        let telemetry = &config.telemetry;
        let mut spec = crate::jailer::ConfinementSpec::telemetry_collector(
            &telemetry.state_dir,
            telemetry.telemetry_sock.parent(),
            std::path::PathBuf::new(),
        );
        // Only the public verification anchor, never the private key directory.
        spec.readable_paths.clear();
        spec.readable_paths.push(telemetry.host_anchor_path.clone());
        if let Some(parent) = telemetry.signer_sock.parent()
            && parent != telemetry.state_dir
        {
            spec.read_write_paths.push(parent.to_path_buf());
        }
        resources.confine(&spec)?;
    }
    let mut collector = resources
        .start_owned_collector(child.startup_deadline())?
        .context("installed collector was not selected")?;
    child.send_ready(Default::default(), child.startup_deadline())?;
    while !child.parent_closed()? {
        if let Err(error) = child.check_parent() {
            // Closing the original control pipe can race this fresh check.
            // That same EOF still owns the graceful cleanup transition.
            if child.parent_closed()? {
                break;
            }
            return Err(error);
        }
        let mut control = libc::pollfd {
            fd: child.control_fd(),
            events: libc::POLLIN,
            revents: 0,
        };
        // SAFETY: the sole original controller retains the borrowed control FD.
        let outcome = unsafe { libc::poll(&mut control, 1, 100) };
        if outcome < 0 {
            let error = std::io::Error::last_os_error();
            if error.kind() != std::io::ErrorKind::Interrupted {
                return Err(error).context("installed controller poll failed");
            }
        }
    }
    // One original cleanup cap spans every original join and terminal record.
    // The parent additionally requires successful collection of this Child.
    let cleanup = Instant::now() + Duration::from_secs(2);
    collector.close_and_join(cleanup)?;
    child.send_drained(cleanup)
}
