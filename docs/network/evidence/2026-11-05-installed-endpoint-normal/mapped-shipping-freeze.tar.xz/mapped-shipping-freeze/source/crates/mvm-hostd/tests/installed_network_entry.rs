//! Test wrapper for the SAME production library entry. No controller copy.
//! Normal canonical-bin/all-target release qualification remains separate.
fn main() -> anyhow::Result<()> {
    mvm_vmm::host::helper_contract::exit_with_probe_answer_if_requested("mvm-network-endpoint");
    match std::env::args().nth(1).as_deref() {
        Some("--installed-partition") => mvm_hostd::installed_endpoint::run_installed_endpoint(),
        // Cargo's direct helper entry is not an actual handoff/process witness.
        None => Ok(()),
        _ => anyhow::bail!("unexpected installed controller fixture argument"),
    }
}
