//! Actual kernel-filter controls only; no admission/resource authority is minted.
use super::*;
use std::{
    os::fd::AsRawFd,
    process::{Command, Stdio},
    time::{Duration, Instant},
};
const CHILD: &str = "jailer::seccomp::owned_tests::filter_child";

#[test]
fn filter_child() {
    let Ok(mode) = std::env::var("MVM_OWNED_FILTER_TEST") else {
        return;
    };
    let core = libc::rlimit {
        rlim_cur: 0,
        rlim_max: 0,
    };
    // SAFETY: valid fixed limits; avoid disposable core dumps for intentional
    // SIGSYS children. This affects this test process only.
    assert_eq!(unsafe { libc::setrlimit(libc::RLIMIT_CORE, &core) }, 0);
    let root = std::path::PathBuf::from(
        std::env::var_os("MVM_OWNED_FILTER_ROOT").expect("original fixture namespace"),
    );
    let file = std::fs::File::create(root.join("record")).unwrap();
    let directory = root.join("disposable");
    std::fs::create_dir(&directory).unwrap();
    if mode == "store-cleanup" {
        std::fs::write(directory.join("original-file"), b"owned").unwrap();
    }
    let directory_path = directory.clone();
    let directory = std::ffi::CString::new(directory.as_os_str().as_encoded_bytes()).unwrap();
    let root_name = std::ffi::CString::new(root.as_os_str().as_encoded_bytes()).unwrap();
    let spec = ConfinementSpec::telemetry_collector(&root, None, Default::default());
    if mode.starts_with("legacy") {
        apply(&spec).unwrap();
    } else if mode.starts_with("store-") {
        apply_with_owned_files(&spec, true, false).unwrap();
    } else {
        apply_with_owned_files(&spec, false, true).unwrap();
    }
    if mode == "store-cleanup" {
        // Same real standard-library operation as original codec-store cleanup.
        // It must remove its test-owned file and directory before exit.
        std::fs::remove_dir_all(&directory_path).unwrap();
        assert!(!directory_path.exists());
    } else if mode == "store-wide-unlink" {
        // SAFETY: exact native syscall ABI and original test directory. A
        // Dword-only filter would ignore upper bits and permit removal.
        unsafe {
            libc::syscall(
                libc::SYS_unlinkat,
                libc::AT_FDCWD,
                directory.as_ptr(),
                (1u64 << 32) | libc::AT_REMOVEDIR as u64,
            );
        }
    } else if mode.ends_with("delete-at") || mode == "store-bad-unlink" {
        let flags = if mode == "store-bad-unlink" {
            libc::AT_SYMLINK_NOFOLLOW
        } else {
            libc::AT_REMOVEDIR
        };
        // SAFETY: test-owned empty directory and fixed native flags. Deny
        // controls must trap rather than merely receiving kernel EINVAL.
        unsafe {
            libc::unlinkat(libc::AT_FDCWD, directory.as_ptr(), flags);
        }
    } else if mode == "legacy-fs" || mode == "path-fs" || mode == "store-fs" {
        let mut facts = std::mem::MaybeUninit::<libc::statfs>::uninit();
        if mode == "legacy-fs" || mode == "store-fs" {
            // SAFETY: original held file and correctly sized writable output.
            unsafe {
                libc::fstatfs(file.as_raw_fd(), facts.as_mut_ptr());
            }
        } else {
            // SAFETY: original parent-owned namespace C string; expected trap.
            unsafe {
                libc::statfs(root_name.as_ptr(), facts.as_mut_ptr());
            }
        }
    } else if mode == "write" {
        // SAFETY: test-owned file and valid bounded static input; expected trap.
        unsafe {
            libc::fsetxattr(
                file.as_raw_fd(),
                c"user.owned_filter".as_ptr(),
                b"x".as_ptr().cast(),
                1,
                0,
            );
        }
    } else if mode == "delete" {
        #[cfg(target_arch = "x86_64")]
        // SAFETY: valid test-owned empty directory C string; expected filter trap.
        unsafe {
            libc::rmdir(directory.as_ptr());
        }
        #[cfg(target_arch = "aarch64")]
        // SAFETY: same original private fixture namespace, never product cleanup.
        unsafe {
            libc::unlinkat(libc::AT_FDCWD, directory.as_ptr(), libc::AT_REMOVEDIR);
        }
    } else {
        let mut body = [0u8; 8];
        let (buffer, size) = if mode == "body" {
            (body.as_mut_ptr().cast(), body.len())
        } else {
            (std::ptr::null_mut(), 0)
        };
        // SAFETY: held original file, static NUL-terminated attribute, valid
        // output storage for the deliberately forbidden body-read control.
        let result = unsafe {
            libc::fgetxattr(
                file.as_raw_fd(),
                c"system.posix_acl_access".as_ptr(),
                buffer,
                size,
            )
        };
        if mode == "presence" {
            assert!(
                result >= 0
                    || matches!(
                        std::io::Error::last_os_error().raw_os_error(),
                        Some(libc::ENODATA) | Some(libc::ENOTSUP)
                    )
            );
            let mut facts = std::mem::MaybeUninit::<libc::statfs>::uninit();
            // SAFETY: original held descriptor and one native statfs output.
            assert_eq!(
                unsafe { libc::fstatfs(file.as_raw_fd(), facts.as_mut_ptr()) },
                0
            );
        }
    }
    // Exit directly: this child qualifies filter shape, not tempfile cleanup.
    // Parent owns and removes the uniquely named test namespace separately.
    std::process::exit(0);
}

fn run(mode: &str, expected: i32) {
    let root = tempfile::tempdir().unwrap();
    let mut child = Command::new(std::env::current_exe().unwrap())
        .args(["--exact", CHILD, "--nocapture", "--test-threads=1"])
        .env("MVM_OWNED_FILTER_TEST", mode)
        .env("MVM_OWNED_FILTER_ROOT", root.path())
        .stdout(Stdio::null())
        .stderr(Stdio::piped())
        .spawn()
        .unwrap();
    let deadline = Instant::now() + Duration::from_secs(3);
    loop {
        if child.try_wait().unwrap().is_some() {
            break;
        }
        if Instant::now() >= deadline {
            let _ = child.kill();
            let _ = child.wait();
            panic!("original filter child did not complete");
        }
        std::thread::yield_now();
    }
    let output = child.wait_with_output().unwrap();
    if expected == 159 {
        use std::os::unix::process::ExitStatusExt as _;
        assert!(
            output.status.signal() == Some(libc::SIGSYS) || output.status.code() == Some(159),
            "filter control {mode}: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        let number = match mode {
            "legacy-fs" | "store-fs" => libc::SYS_fstatfs,
            "path-fs" => libc::SYS_statfs,
            "legacy-delete-at" | "delete-at" | "store-bad-unlink" | "store-wide-unlink" => {
                libc::SYS_unlinkat
            }
            "write" => libc::SYS_fsetxattr,
            #[cfg(target_arch = "x86_64")]
            "delete" => libc::SYS_rmdir,
            #[cfg(target_arch = "aarch64")]
            "delete" => libc::SYS_unlinkat,
            _ => libc::SYS_fgetxattr,
        };
        assert!(
            String::from_utf8_lossy(&output.stderr).contains(&format!("syscall {number};")),
            "wrong syscall trap for {mode}"
        );
        assert!(
            output
                .stderr
                .windows(b"seccomp refused".len())
                .any(|part| part == b"seccomp refused")
        );
    } else {
        assert_eq!(
            output.status.code(),
            Some(expected),
            "positive filter query failed"
        );
    }
    if mode == "delete"
        || mode.ends_with("delete-at")
        || mode == "store-bad-unlink"
        || mode == "store-wide-unlink"
    {
        assert!(
            root.path().join("disposable").is_dir(),
            "denied deletion changed original fixture directory"
        );
    }
}
#[test]
fn legacy_has_no_owned_xattr_allowance() {
    run("legacy", 159);
}
#[test]
fn legacy_has_no_owned_filesystem_allowance() {
    run("legacy-fs", 159);
}
#[test]
fn store_only_has_no_unneeded_filesystem_allowance() {
    run("store-fs", 159);
}
#[test]
fn records_only_denies_path_filesystem_probe() {
    run("path-fs", 159);
}
#[test]
fn records_only_denies_xattr_write() {
    run("write", 159);
}
#[test]
fn records_only_allows_presence_query() {
    run("presence", 0);
}
#[test]
fn records_only_denies_xattr_body_read() {
    run("body", 159);
}
#[test]
fn records_only_denies_directory_deletion() {
    run("delete", 159);
}

#[test]
fn original_store_standard_library_cleanup_is_allowed() {
    run("store-cleanup", 0);
}
#[test]
fn records_only_denies_unlinkat_directory_deletion() {
    run("delete-at", 159);
}
#[test]
#[cfg(target_arch = "x86_64")]
fn legacy_keeps_unlinkat_directory_deletion_denied() {
    run("legacy-delete-at", 159);
}
#[test]
#[cfg(target_arch = "x86_64")]
fn store_only_denies_noncanonical_unlinkat_flags() {
    run("store-bad-unlink", 159);
}

#[test]
#[cfg(target_arch = "x86_64")]
fn store_only_denies_upper_unlinkat_argument_bits() {
    run("store-wide-unlink", 159);
}
