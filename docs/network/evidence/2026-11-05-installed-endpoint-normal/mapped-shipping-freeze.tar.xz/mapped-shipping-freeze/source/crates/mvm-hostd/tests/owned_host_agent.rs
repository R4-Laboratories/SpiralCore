#![cfg(unix)]

use anyhow::{Result, ensure};
use mvm_core::protocol::broker::{CorrelationId, ServiceCall, ServiceId, ServiceResponse};
use mvm_core::{
    config,
    host_lifetime::{HostLeaseExpectation, PreparedHostLifetimeLease},
    util::test_env::TestEnv,
};
use mvm_vmm::host::host_agent_spawn::{
    HostAgentParentPermit, HostAgentServicesParams, OwnedHostAgent, OwnedHostAgentInputs,
    OwnedHostAgentRegistrar, OwnedVmRegistration,
};
use sha2::{Digest, Sha256};
use std::{
    fs::File,
    io::Write,
    os::unix::fs::{OpenOptionsExt, PermissionsExt},
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
};

struct Parent {
    current: AtomicBool,
}
impl HostAgentParentPermit for Parent {
    fn check_current(&self, tenant: &str) -> Result<()> {
        ensure!(
            tenant == "local" && self.current.load(Ordering::Acquire),
            "fixture parent refused"
        );
        Ok(())
    }
    fn check_registration(&self, params: &HostAgentServicesParams<'_>) -> Result<()> {
        self.check_current(params.tenant_id.unwrap_or_default())?;
        ensure!(
            ["vm-1", "vm-2"].contains(&params.vm_name),
            "fixture VM not admitted"
        );
        Ok(())
    }
}
pub(crate) struct Fixture {
    _env: TestEnv,
    _home: tempfile::TempDir,
    lease: tempfile::TempDir,
    parent: Arc<Parent>,
    verifying: ed25519_dalek::VerifyingKey,
}
impl Fixture {
    pub(crate) fn new() -> Self {
        let mut env = TestEnv::new();
        let home = tempfile::Builder::new()
            .permissions(std::fs::Permissions::from_mode(0o700))
            .tempdir()
            .unwrap();
        env.set("MVM_HOME", home.path());
        env.set(
            "MVM_HOST_AGENT_PATH",
            std::env::var_os("OWNED_AGENT_TEST_BIN")
                .or_else(|| {
                    option_env!("CARGO_BIN_EXE_mvm-host-agent").map(std::ffi::OsString::from)
                })
                .expect("actual canonical host-agent test binary required"),
        );
        env.set(
            "MVM_SIGNER_HELPER_PATH",
            std::env::var_os("OWNED_SIGNER_TEST_BIN")
                .or_else(|| {
                    option_env!("CARGO_BIN_EXE_mvm-signer-helper").map(std::ffi::OsString::from)
                })
                .expect("actual canonical signer-helper test binary required"),
        );
        env.set("MVM_HOST_AGENT_DAEMON", "1");
        let verifying = mvm_hostd::audit::host_keypair::load_or_init_at(&config::mvm_keys_dir())
            .unwrap()
            .verifying;
        let lease = tempfile::Builder::new()
            .permissions(std::fs::Permissions::from_mode(0o700))
            .tempdir()
            .unwrap();
        let mut state = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(lease.path().join("state"))
            .unwrap();
        state.write_all(b"original fixture state").unwrap();
        std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .mode(0o600)
            .open(lease.path().join("holders"))
            .unwrap();
        Self {
            _env: env,
            _home: home,
            lease,
            parent: Arc::new(Parent {
                current: AtomicBool::new(true),
            }),
            verifying,
        }
    }
    pub(crate) fn inputs(&self) -> OwnedHostAgentInputs {
        OwnedHostAgentInputs {
            tenant: "local".into(),
            parent: self.parent.clone(),
            holder: PreparedHostLifetimeLease::bind(
                File::open(self.lease.path()).unwrap(),
                File::open(self.lease.path().join("holders")).unwrap(),
                HostLeaseExpectation {
                    state_name: "state".into(),
                    state_bytes: 22,
                    state_sha256: Sha256::digest(b"original fixture state").into(),
                    absent_names: ["intent".into(), "dirty".into()],
                },
            )
            .unwrap(),
        }
    }
    pub(crate) fn vm(&self, name: &str) -> (PathBuf, PathBuf) {
        let state = config::vm_state_dir(name);
        config::create_private_dir(&state).unwrap();
        let socket = config::vm_socket_dir_at(&state).join("owned-broker.sock");
        (state, socket)
    }
}
pub(crate) fn register(
    registrar: &OwnedHostAgentRegistrar,
    vm: &str,
    state: &Path,
    socket: &Path,
) -> Result<OwnedVmRegistration> {
    registrar.register(HostAgentServicesParams {
        workload_id: vm,
        tenant_id: Some("local"),
        vm_name: vm,
        state_dir: state,
        broker_listen_socket: socket,
        services: &[ServiceId::parse("host.audit.v1").unwrap()],
        capability_bindings: &[],
        service_proxies: &[],
    })
}
fn emit(socket: &Path, event: &str) {
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    runtime.block_on(async {
        let mut stream = tokio::net::UnixStream::connect(socket).await.unwrap();
        mvm_hostd::broker::server::write_frame(&mut stream, &ServiceCall {
            service: ServiceId::parse("host.audit.v1").unwrap(), verb: "emit".into(), correlation_id: CorrelationId::new("guest-ignored"),
            payload: serde_json::json!({ "ts":"2026-11-03T00:00:00Z", "fields": { "event":event } }), capability: None,
        }).await.unwrap();
        let response: ServiceResponse = mvm_hostd::broker::server::read_frame(&mut stream, 65536).await.unwrap();
        assert!(matches!(response, ServiceResponse::Ok { .. }), "{response:?}");
    });
}

#[cfg(target_os = "linux")]
fn actual_stack_and_holder(pid: u32, holder: &Path) {
    use std::os::unix::fs::MetadataExt;
    let limits = std::fs::read_to_string(format!("/proc/{pid}/limits")).unwrap();
    let stack: Vec<_> = limits
        .lines()
        .find(|line| line.starts_with("Max stack size"))
        .unwrap()
        .split_whitespace()
        .collect();
    assert_eq!(&stack[3..5], &["8388608", "8388608"]);
    assert!(
        std::fs::read_dir(format!("/proc/{pid}/task"))
            .unwrap()
            .count()
            <= 5
    );
    let expected = holder.metadata().unwrap();
    let mut found = false;
    for entry in std::fs::read_dir(format!("/proc/{pid}/fd"))
        .unwrap()
        .take(128)
    {
        let entry = entry.unwrap();
        if let Ok(meta) = entry.path().metadata()
            && (meta.dev(), meta.ino()) == (expected.dev(), expected.ino())
        {
            let info = std::fs::read_to_string(format!(
                "/proc/{pid}/fdinfo/{}",
                entry.file_name().to_string_lossy()
            ))
            .unwrap();
            found |= info.contains("FLOCK") && info.contains("READ");
        }
    }
    assert!(
        found,
        "actual original shared holder is present in child {pid}"
    );
}

#[test]
fn owned_host_agent_has_distinct_sendable_owner_registrar_and_registration() {
    fn send<T: Send>() {}
    send::<OwnedHostAgent>();
    send::<OwnedHostAgentRegistrar>();
    send::<OwnedVmRegistration>();
    let _: fn(OwnedHostAgentInputs) -> anyhow::Result<OwnedHostAgent> = OwnedHostAgent::spawn;
}

#[test]
fn two_signed_registrations_share_original_child_and_stop_independently() {
    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let original = agent.child_id().unwrap();
    let registrar = agent.registrar();
    let sibling = registrar.clone();
    let (a, sa) = fixture.vm("vm-1");
    let (b, sb) = fixture.vm("vm-2");
    let mut first = register(&registrar, "vm-1", &a, &sa).unwrap();
    let mut second = register(&sibling, "vm-2", &b, &sb).unwrap();
    let audit = [ServiceId::parse("host.audit.v1").unwrap()];
    let time = [ServiceId::parse("host.time.v1").unwrap()];
    let mut original_params = HostAgentServicesParams {
        workload_id: "vm-1",
        tenant_id: Some("local"),
        vm_name: "vm-1",
        state_dir: &a,
        broker_listen_socket: &sa,
        services: &audit,
        capability_bindings: &[],
        service_proxies: &[],
    };
    first.check_current_for(&sibling, &original_params).unwrap();
    original_params.workload_id = "changed";
    assert!(
        first
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    original_params.workload_id = "vm-1";
    original_params.broker_listen_socket = &sb;
    assert!(
        first
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    original_params.broker_listen_socket = &sa;
    original_params.state_dir = &b;
    assert!(
        first
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    original_params.state_dir = &a;
    original_params.services = &time;
    assert!(
        first
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    original_params.services = &audit;
    first
        .check_current_for(&registrar, &original_params)
        .unwrap();
    {
        let target = first.audit_target(&sibling, &original_params).unwrap();
        assert_eq!(target.tenant_id(), "local");
        assert_eq!(target.vm_name(), "vm-1");
        assert_eq!(
            target.socket(),
            config::host_agent_signer_helper_socket("local")
        );
        assert!(target.signer_pid() > 1 && target.signer_pid() != original);
    }
    assert_eq!(agent.child_id().unwrap(), original);
    #[cfg(target_os = "linux")]
    {
        actual_stack_and_holder(original, &fixture.lease.path().join("holders"));
        let children =
            std::fs::read_to_string(format!("/proc/{original}/task/{original}/children")).unwrap();
        let children: Vec<u32> = children
            .split_whitespace()
            .map(|pid| pid.parse().unwrap())
            .collect();
        assert_eq!(
            children.len(),
            1,
            "one actual signer, no worker wrapper or per-VM fork"
        );
        assert_eq!(
            first
                .audit_target(&registrar, &original_params)
                .unwrap()
                .signer_pid(),
            children[0],
            "nonce-bound metadata comes from the actual original signer Child"
        );
        actual_stack_and_holder(children[0], &fixture.lease.path().join("holders"));
    }
    emit(&sa, "first");
    emit(&sb, "second");
    let prepared = first
        .prepare_endpoint_audit(&registrar, &original_params)
        .unwrap();
    prepared.check_current().unwrap();
    assert!(
        first
            .prepare_endpoint_audit(&registrar, &original_params)
            .is_err(),
        "the original audit capability is claimed once"
    );
    assert!(
        first.shutdown().is_err(),
        "the original registration cannot retire under a live endpoint audit token"
    );
    prepared.check_current().unwrap();
    drop(prepared);
    first.shutdown().unwrap();
    assert!(!sa.exists());
    emit(&sb, "second-after-first-stop");
    let mut replacement = register(&registrar, "vm-1", &a, &sa).unwrap();
    assert!(
        first
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    assert!(first.audit_target(&registrar, &original_params).is_err());
    replacement
        .check_current_for(&registrar, &original_params)
        .unwrap();
    first.shutdown().unwrap();
    drop(first);
    emit(&sa, "replacement-survives-retired-guard");
    fixture.parent.current.store(false, Ordering::Release);
    assert!(
        replacement
            .check_current_for(&registrar, &original_params)
            .is_err()
    );
    assert!(
        replacement
            .audit_target(&registrar, &original_params)
            .is_err()
    );
    replacement.shutdown().unwrap();
    second.shutdown().unwrap();
    agent.shutdown().unwrap();
    agent.shutdown().unwrap();
    for vm in ["vm-1", "vm-2"] {
        assert_eq!(
            mvm_hostd::audit_signer::verify::verify_workload_chain(
                &config::workload_audit_path("local", vm),
                &fixture.verifying
            )
            .unwrap(),
            2
        );
    }
    assert!(!config::host_agent_control_socket("local").exists());
    assert!(!config::host_agent_signer_helper_socket("local").exists());
    assert!(
        !config::host_agent_dir("local")
            .join("registrations.json")
            .exists()
    );
    assert!(register(&registrar, "vm-1", &a, &sa).is_err());
}

#[test]
fn busy_final_stop_closes_shared_admission_but_allows_owned_cleanup() {
    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let registrar = agent.registrar();
    let (a, sa) = fixture.vm("vm-1");
    let (b, sb) = fixture.vm("vm-2");
    let mut first = register(&registrar, "vm-1", &a, &sa).unwrap();
    assert!(agent.shutdown().is_err());
    assert!(register(&registrar.clone(), "vm-2", &b, &sb).is_err());
    assert!(!sb.exists());
    emit(&sa, "survives-busy-stop");
    fixture.parent.current.store(false, Ordering::Release);
    first.shutdown().unwrap();
    agent.shutdown().unwrap();
}

#[test]
fn original_registrar_query_checks_tenant_holder_parent_and_closed_admission() {
    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let registrar = agent.registrar();
    let original = agent.child_id().unwrap();
    registrar.check_current_for_tenant("local").unwrap();
    assert!(registrar.check_current_for_tenant("foreign").is_err());
    std::fs::write(
        fixture.lease.path().join("state"),
        b"changed original state",
    )
    .unwrap();
    assert!(registrar.check_current_for_tenant("local").is_err());
    std::fs::write(
        fixture.lease.path().join("state"),
        b"original fixture state",
    )
    .unwrap();
    registrar.check_current_for_tenant("local").unwrap();
    assert_eq!(agent.child_id().unwrap(), original);
    fixture.parent.current.store(false, Ordering::Release);
    assert!(registrar.check_current_for_tenant("local").is_err());
    // Cleanup has its original owner and must remain possible after revocation.
    agent.shutdown().unwrap();
    assert!(registrar.check_current_for_tenant("local").is_err());
    assert!(!config::host_agent_control_socket("local").exists());
    assert!(!config::host_agent_signer_helper_socket("local").exists());
}

#[test]
fn preexisting_unowned_evidence_and_parent_refusal_have_no_spawn_effects() {
    let fixture = Fixture::new();
    fixture.parent.current.store(false, Ordering::Release);
    assert!(OwnedHostAgent::spawn(fixture.inputs()).is_err());
    assert!(!config::host_agent_dir("local").exists());
    fixture.parent.current.store(true, Ordering::Release);
    mvm_core::private_fs::create_owned_private_dir(config::host_agent_root()).unwrap();
    mvm_core::private_fs::create_owned_private_dir(config::host_agent_dir("local")).unwrap();
    let marker = config::host_agent_dir("local").join("daemon.pid");
    std::fs::write(&marker, b"unowned-evidence").unwrap();
    assert!(OwnedHostAgent::spawn(fixture.inputs()).is_err());
    assert_eq!(std::fs::read(marker).unwrap(), b"unowned-evidence");
    assert!(!config::host_agent_control_socket("local").exists());
    assert!(!config::host_agent_signer_helper_socket("local").exists());
}

#[test]
fn owned_journal_replacement_keeps_cleanup_uncertain_until_original_is_restored() {
    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let registrar = agent.registrar();
    let (state, socket) = fixture.vm("vm-1");
    let mut registration = register(&registrar, "vm-1", &state, &socket).unwrap();
    let journal = config::host_agent_dir("local").join("registrations.json");
    let original = journal.with_file_name("retained-original-journal");
    let foreign = journal.with_file_name("retained-foreign-evidence");
    std::fs::rename(&journal, &original).unwrap();
    std::fs::write(&journal, b"foreign replacement evidence").unwrap();
    assert!(registration.shutdown().is_err());
    assert_eq!(
        std::fs::read(&journal).unwrap(),
        b"foreign replacement evidence"
    );
    assert!(agent.shutdown().is_err());
    let holder = File::open(fixture.lease.path().join("holders")).unwrap();
    assert!(
        rustix::fs::flock(
            &holder,
            rustix::fs::FlockOperation::NonBlockingLockExclusive
        )
        .is_err()
    );
    std::fs::rename(&journal, &foreign).unwrap();
    std::fs::rename(&original, &journal).unwrap();
    registration.shutdown().unwrap();
    agent.shutdown().unwrap();
    assert_eq!(
        std::fs::read(&foreign).unwrap(),
        b"foreign replacement evidence"
    );
    drop(registration);
    drop(registrar);
    drop(agent);
    rustix::fs::flock(
        &holder,
        rustix::fs::FlockOperation::NonBlockingLockExclusive,
    )
    .unwrap();
}

#[test]
fn owned_telemetry_uses_actual_canonical_handshake_and_original_host_key() {
    use mvm_core::net::telemetry::{TelemetryReceiver, TelemetrySender};
    use std::os::unix::net::UnixStream;
    use std::time::Duration;

    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let host_key = fixture.verifying;
    let guest_key = ed25519_dalek::SigningKey::from_bytes(&[17; 32]);
    let guest_public = guest_key.verifying_key();
    let (mut host_io, mut guest_io) = UnixStream::pair().unwrap();
    for stream in [&host_io, &guest_io] {
        stream
            .set_read_timeout(Some(Duration::from_secs(5)))
            .unwrap();
        stream
            .set_write_timeout(Some(Duration::from_secs(5)))
            .unwrap();
    }
    let guest = std::thread::spawn(move || {
        TelemetrySender::connect(&mut guest_io, guest_key, &host_key).unwrap()
    });
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    let client = mvm_hostd::audit_signer::helper_client::SignerHelperClient::new(
        config::host_agent_signer_helper_socket("local"),
    );
    let receiver = TelemetryReceiver::connect_authenticated(
        &mut host_io,
        &host_key,
        &guest_public,
        |hello, ack| {
            runtime
                .block_on(client.sign_telemetry_handshake(
                    hello,
                    ack,
                    &host_key,
                    Duration::from_secs(5),
                ))
                .map_err(|_| {
                    mvm_core::net::session::SessionError::InvalidHandshake(
                        "owned telemetry signer refused".into(),
                    )
                })
        },
    );
    let sender = guest.join().unwrap();
    assert!(
        receiver.is_ok(),
        "owned required telemetry handshake must remain authenticated"
    );
    drop((sender, receiver));
    agent.shutdown().unwrap();
}

#[cfg(target_os = "linux")]
#[test]
#[ignore = "requires the protected original-helper pair from before SCM_RIGHTS sideband"]
fn register_ok_without_capability_retains_original_uncertain_cleanup() {
    let fixture = Fixture::new();
    // The qualification command selects the separately protected pre-sideband
    // pair through the SAME canonical helper-path controls used by Fixture.
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let registrar = agent.registrar();
    let (state, socket) = fixture.vm("vm-1");
    let failure = match register(&registrar, "vm-1", &state, &socket) {
        Err(failure) => failure,
        Ok(mut unexpected) => {
            unexpected.shutdown().unwrap();
            agent.shutdown().unwrap();
            panic!("acknowledged Register without its original capability must refuse");
        }
    };
    let mut retained = failure
        .downcast::<mvm_vmm::host::host_agent_spawn::OwnedRegistrationError>()
        .expect("acknowledged Register without its capability retains the original serial");
    assert!(register(&registrar, "vm-1", &state, &socket).is_err());
    assert!(
        agent.shutdown().is_err(),
        "uncertain registration remains charged"
    );
    retained.registration_mut().shutdown().unwrap();
    // Cleanup is the unchanged signed Deregister, which has no sideband. The
    // missing capability cannot be treated as proof that Register had no effect.
    agent.shutdown().unwrap();
}

#[cfg(target_os = "linux")]
#[test]
fn unexpected_original_signer_exit_fences_the_original_daemon() {
    use mvm_vmm::host::process_exit::{ProcessExitObserver, ProcessExitWait};
    use rustix::process::{Pid, PidfdFlags, Signal, pidfd_open, pidfd_send_signal};
    use std::os::unix::fs::MetadataExt;
    use std::time::{Duration, Instant};

    struct OriginalSignals {
        daemon: std::os::fd::OwnedFd,
        signer: std::os::fd::OwnedFd,
        daemon_exit: ProcessExitObserver,
        signer_exit: ProcessExitObserver,
    }
    impl Drop for OriginalSignals {
        fn drop(&mut self) {
            // Test-only cleanup of the two original, already-bound pidfds.
            // No PID fallback, discovery after signalling or unknown process.
            let _ = pidfd_send_signal(&self.signer, Signal::CONT);
            let _ = pidfd_send_signal(&self.signer, Signal::KILL);
            let _ = pidfd_send_signal(&self.daemon, Signal::KILL);
            let until = Instant::now() + Duration::from_secs(2);
            let _ = self.signer_exit.wait_event(until);
            let _ = self.daemon_exit.wait_event(until);
        }
    }
    let fixture = Fixture::new();
    let mut agent = OwnedHostAgent::spawn(fixture.inputs()).unwrap();
    let registrar = agent.registrar();
    let daemon = agent.child_id().unwrap();
    let (state, socket) = fixture.vm("vm-1");
    let mut registration = register(&registrar, "vm-1", &state, &socket).unwrap();
    let children =
        std::fs::read_to_string(format!("/proc/{daemon}/task/{daemon}/children")).unwrap();
    let children: Vec<u32> = children
        .split_whitespace()
        .map(|child| child.parse().unwrap())
        .collect();
    assert_eq!(children.len(), 1, "one original signer Child");
    let signer = children[0];
    let stat = std::fs::read_to_string(format!("/proc/{signer}/stat")).unwrap();
    let fields: Vec<_> = stat
        .rsplit_once(") ")
        .unwrap()
        .1
        .split_whitespace()
        .collect();
    assert_eq!(fields[1].parse::<u32>().unwrap(), daemon);
    let birth = fields[19].to_owned();
    let signer_fd = pidfd_open(
        Pid::from_raw(signer.try_into().unwrap()).unwrap(),
        PidfdFlags::empty(),
    )
    .unwrap();
    let daemon_fd = pidfd_open(
        Pid::from_raw(daemon.try_into().unwrap()).unwrap(),
        PidfdFlags::empty(),
    )
    .unwrap();
    let daemon_exit = ProcessExitObserver::arm(daemon.try_into().unwrap()).unwrap();
    let signer_exit = ProcessExitObserver::arm(signer.try_into().unwrap()).unwrap();
    // Corroborate the original child relation, UID, executable and shared
    // holder before any signal, then retain the SAME kernel descriptors.
    let expected = std::fs::metadata(
        std::env::var_os("OWNED_SIGNER_TEST_BIN")
            .or_else(|| {
                option_env!("CARGO_BIN_EXE_mvm-signer-helper").map(std::ffi::OsString::from)
            })
            .expect("actual canonical signer-helper test binary required"),
    )
    .unwrap();
    let actual = std::fs::metadata(format!("/proc/{signer}/exe")).unwrap();
    assert_eq!(
        (actual.dev(), actual.ino()),
        (expected.dev(), expected.ino())
    );
    assert_eq!(actual.uid(), rustix::process::geteuid().as_raw());
    actual_stack_and_holder(signer, &fixture.lease.path().join("holders"));
    let after = std::fs::read_to_string(format!("/proc/{signer}/stat")).unwrap();
    let after: Vec<_> = after
        .rsplit_once(") ")
        .unwrap()
        .1
        .split_whitespace()
        .collect();
    assert_eq!(after[1].parse::<u32>().unwrap(), daemon);
    assert_eq!(after[19], birth);
    registrar.check_current_for_tenant("local").unwrap();
    let original = OriginalSignals {
        daemon: daemon_fd,
        signer: signer_fd,
        daemon_exit,
        signer_exit,
    };
    assert_eq!(
        original.signer_exit.wait_event(Instant::now()).unwrap(),
        ProcessExitWait::TimedOut
    );
    pidfd_send_signal(&original.signer, Signal::KILL).unwrap();
    assert_eq!(
        original
            .daemon_exit
            .wait_event(Instant::now() + Duration::from_secs(2))
            .unwrap(),
        ProcessExitWait::Exited,
        "unexpected signer exit must fence and end the original daemon"
    );
    assert!(registrar.check_current_for_tenant("local").is_err());
    assert!(registration.shutdown().is_err());
    assert!(
        agent.shutdown().is_err(),
        "unexpected exit is not clean shutdown"
    );
}
