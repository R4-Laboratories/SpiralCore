//! Actual owned helper/registration -> official endpoint producer -> child
//! Resources/Recorder/FlowMux fixture. This is not native VM admission or a
//! complete shipping controller/resource qualification.
#![cfg(unix)]

#[path = "owned_host_agent.rs"]
mod helper_fixture;
#[path = "support/installed_factory.rs"]
mod installed_factory;
#[path = "common/installed_resource_fixture.rs"]
mod installed_resource_fixture;
#[path = "support/installed_shipping_flows.rs"]
mod installed_shipping_flows;
use installed_shipping_flows::{FlowCase, OriginalPeer};

use anyhow::{Result, ensure};
use base64::{Engine as _, engine::general_purpose::STANDARD};
use ed25519_dalek::SigningKey;
use mvm_core::{
    config,
    host_lifetime::{
        CoreCurrentParentPermit, EndpointPartitionGuard, EndpointPartitionLimits,
        EndpointPartitionProjection, EndpointStoreLocator, HostLaunchBinding, HostLifetimeInputs,
        PreparedEndpointHandoff, PreparedEndpointPartition, PreparedHostLifetime,
        PreparedHostLifetimeLease,
    },
    plan::{PlanId, compute_plan_id, sign_plan, test_support::PlanFixture},
    policy::network_policy::{HostPort, NetworkPolicy},
    protocol::broker::ServiceId,
    vm_backend::{BackendKind, VmStartConfig},
};
use mvm_hostd::{
    installed_endpoint::{InstalledEndpointProgram, InstalledEndpointResources},
    supervisor::{
        audit_recorder::EventCategory,
        flowmux::{
            FlowMuxAccept, FlowMuxError, FlowMuxSession, OwnedTcpRelays, PayloadMappingConfig,
            SpiralCorePayloadFactory, registry::RegistryLimits,
        },
    },
};
use mvm_vmm::host::{
    host_agent_spawn::{HostAgentServicesParams, OwnedHostAgent},
    network_endpoint_spawn::{
        AdmittedNetworkPlan, EgressProxySpawnConfig, EndpointLifetime, EndpointTransport,
        FlowMuxIdentitySpawnConfig, InstalledEndpointChild, InstalledHostServices,
        SubstitutionSpawnParams, spawn_network_endpoint_installed,
    },
};
use std::{
    fs::File,
    io::Read,
    os::{
        fd::AsFd,
        unix::{fs::MetadataExt, net::UnixStream},
    },
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

fn main() -> Result<()> {
    mvm_vmm::host::helper_contract::exit_with_probe_answer_if_requested("mvm-network-endpoint");
    match std::env::args().nth(1).as_deref() {
        Some("--installed-partition") => child(),
        None => parent(false, false, None, None),
        Some("--retained-producer") => parent(true, false, None, None),
        Some("--shipping-controller") => parent(true, true, None, None),
        Some("--shipping-protocol-failure") => {
            parent(true, true, Some(Violation::InitialHello), None)
        }
        Some("--shipping-validator-failure") => {
            parent(true, true, Some(Violation::RepeatedHello), None)
        }
        Some("--shipping-mapped-payload") => parent(true, true, None, Some(FlowCase::Mapped)),
        Some("--shipping-unmapped-target") => parent(true, true, None, Some(FlowCase::Unmapped)),
        _ => anyhow::bail!("unexpected fixture argument"),
    }
}

#[derive(Clone, Copy)]
enum Violation {
    InitialHello,
    RepeatedHello,
}

struct Guard {
    projection: EndpointPartitionProjection,
    retained: Option<Mutex<FixtureRetention>>,
}
struct FixtureRetention {
    state_path: PathBuf,
    original_state: File,
    prepared: bool,
    files: Option<(File, File)>,
}
fn file_id(file: &File) -> Result<(u64, u64)> {
    let metadata = file.metadata()?;
    Ok((metadata.dev(), metadata.ino()))
}
impl EndpointPartitionGuard for Guard {
    fn check_current(&self, facts: &EndpointPartitionProjection) -> Result<()> {
        ensure!(facts == &self.projection, "foreign functional partition");
        Ok(())
    }
    fn prepare_retained_telemetry(
        &self,
        facts: &EndpointPartitionProjection,
        state_path: &Path,
        state: &File,
    ) -> Result<()> {
        self.check_current(facts)?;
        let mut retained = self
            .retained
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("unselected functional retained owner"))?
            .lock()
            .unwrap();
        ensure!(
            state_path == retained.state_path
                && file_id(state)? == file_id(&retained.original_state)?
        );
        ensure!(!retained.prepared && retained.files.is_none());
        // This test owner checks ordering/identity only. It is not a durable
        // Root catalog, quota reservation or installation permission source.
        for name in [
            mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_FILE,
            mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_KEY_FILE,
        ] {
            ensure!(
                !state_path.join(name).exists(),
                "key/writer effect preceded retained prepare"
            );
        }
        retained.prepared = true;
        Ok(())
    }
    fn bind_retained_telemetry_files(
        &self,
        facts: &EndpointPartitionProjection,
        state_path: &Path,
        state: &File,
        records: &File,
        wrapped_key: &File,
    ) -> Result<()> {
        self.check_current(facts)?;
        let mut retained = self
            .retained
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("unselected functional retained owner"))?
            .lock()
            .unwrap();
        ensure!(
            state_path == retained.state_path
                && file_id(state)? == file_id(&retained.original_state)?
        );
        ensure!(
            retained.prepared && retained.files.is_none(),
            "bind preceded prepare or repeated"
        );
        let named_records =
            state_path.join(mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_FILE);
        let named_key =
            state_path.join(mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_KEY_FILE);
        ensure!(file_id(records)? == file_id(&File::open(named_records)?)?);
        ensure!(file_id(wrapped_key)? == file_id(&File::open(named_key)?)?);
        let flags = rustix::fs::fcntl_getfl(records.as_fd())?;
        ensure!(
            flags & rustix::fs::OFlags::ACCMODE == rustix::fs::OFlags::RDWR
                && flags.contains(rustix::fs::OFlags::APPEND)
        );
        ensure!(
            rustix::fs::fcntl_getfl(wrapped_key.as_fd())? & rustix::fs::OFlags::ACCMODE
                == rustix::fs::OFlags::RDONLY
        );
        ensure!(records.metadata()?.len() == 0 && wrapped_key.metadata()?.len() <= 1024);
        retained.files = Some((records.try_clone()?, wrapped_key.try_clone()?));
        Ok(())
    }
}
struct Parent(EndpointPartitionProjection, Arc<dyn EndpointPartitionGuard>);
impl CoreCurrentParentPermit for Parent {
    fn check_current(&self, binding: &HostLaunchBinding) -> Result<()> {
        ensure!(binding == &self.0.binding, "foreign functional binding");
        Ok(())
    }
    fn prepare_endpoint_partition(
        &self,
        binding: &HostLaunchBinding,
    ) -> Result<PreparedEndpointPartition> {
        self.check_current(binding)?;
        PreparedEndpointPartition::new(self.0.clone(), self.1.clone())
    }
}

fn handoff(
    holder: &PreparedHostLifetimeLease,
    store: &Path,
    state: &Path,
    retained: bool,
) -> Result<(PreparedEndpointHandoff, PlanId, Arc<Guard>)> {
    let mut plan = PlanFixture::new().workload("vm-1").build();
    plan.plan_id = compute_plan_id(&plan);
    let metadata = store.metadata()?;
    let facts = EndpointPartitionProjection {
        version: 1,
        binding: HostLaunchBinding {
            installation: [1; 32],
            profile: [2; 32],
            generation: 1,
            grant_serial: 1,
            vm_name: "vm-1".into(),
            backend: BackendKind::Firecracker,
            cpus: 1,
            memory_mib: 128,
        },
        admitted_plan_id: plan.plan_id.0.clone(),
        session: [3; 32],
        partition_serial: 1,
        profile: 2,
        store: Some(EndpointStoreLocator {
            version: 1,
            path: store.into(),
            device: metadata.dev(),
            inode: metadata.ino(),
            reservation_serial: 1,
            tenant: [0; 32],
            session: [3; 32],
        }),
        // Explicit functional envelope. No aggregate host quota is represented
        // by these test guards. Child debits real bootstrap/Audit/relay/reader
        // claims from its ONE supplied ledger (Audit workspace alone is 8MiB).
        limits: EndpointPartitionLimits {
            host_plaintext_bytes: 1 << 20,
            host_codec_bytes: 16 << 20,
            host_carrier_bytes: 1 << 20,
            host_metadata_bytes: if retained { 128 << 20 } else { 32 << 20 },
            // Experimental controller fixture includes main8MiB + original
            // session2MiB + collector6MiB + relay2MiB + reader2MiB supplements.
            // This is not a Root production profile or capacity claim.
            host_stack_bytes: 24 << 20,
            cache_disk_bytes: (16 << 20)
                + if retained {
                    mvm_vmm::host::telemetry_provisioning::DEFAULT_RECORDS_BYTE_CAP
                        + mvm_core::runtime_state_protection::INSTALLED_TELEMETRY_SIDECAR_BYTES
                } else {
                    0
                },
            staging_disk_bytes: 16 << 20,
            workers: 1,
            max_streams: 1,
        },
    };
    let anchor = PreparedHostLifetime::bind(
        HostLifetimeInputs {
            directory: holder.directory().try_clone()?,
            holder: holder.holder().try_clone()?,
            expected: holder.expectation().clone(),
            binding: facts.binding.clone(),
        },
        (),
    )?
    .into_anchor();
    let mut config = VmStartConfig {
        name: "vm-1".into(),
        cpus: 1,
        memory_mib: 128,
        ..Default::default()
    };
    anchor.bind_to_config(&mut config)?;
    config.plan_json = Some(serde_json::to_string(&sign_plan(
        &plan,
        &SigningKey::from_bytes(&[8; 32]),
        "fixture",
    ))?);
    anchor.bind_admitted(&config, BackendKind::Firecracker, &plan)?;
    let guard = Arc::new(Guard {
        projection: facts.clone(),
        retained: retained.then(|| {
            Mutex::new(FixtureRetention {
                state_path: state.into(),
                original_state: File::open(state).unwrap(),
                prepared: false,
                files: None,
            })
        }),
    });
    anchor.bind_parent_permit(
        &config,
        BackendKind::Firecracker,
        Arc::new(Parent(facts, guard.clone())),
    )?;
    Ok((
        anchor.prepare_endpoint_handoff(&config, BackendKind::Firecracker)?,
        plan.plan_id,
        guard,
    ))
}

fn parent(
    retained: bool,
    shipping: bool,
    violation: Option<Violation>,
    flow: Option<FlowCase>,
) -> Result<()> {
    use mvm_contract::policy::network_policy::{
        CooperatingPayloadPolicy, CooperatingTcpPeer, PayloadMappingProfile,
    };
    let fixture = helper_fixture::Fixture::new();
    // Supplied by the recorded test command as the actual protected executable,
    // never a fabricated Cargo helper variable or another endpoint binary.
    let expected_program = if shipping {
        PathBuf::from(
            std::env::var_os("MVM_INSTALLED_ENDPOINT_BIN").ok_or_else(|| {
                anyhow::anyhow!("protected canonical endpoint prerequisite missing")
            })?,
        )
    } else {
        std::env::current_exe()?
    };
    ensure!(
        std::env::var_os("MVM_SUBSTITUTION_ENDPOINT_PATH")
            == Some(expected_program.into_os_string()),
        "exact fixture executable required"
    );
    let holder = fixture.inputs().holder;
    let mut agent = OwnedHostAgent::spawn(fixture.inputs())?;
    let registrar = agent.registrar();
    let (state, socket) = fixture.vm("vm-1");
    let mut registration = helper_fixture::register(&registrar, "vm-1", &state, &socket)?;
    let store = state.join("codec-functional-store");
    config::create_private_dir(&store)?;
    let (handoff, plan_id, guard) = handoff(&holder, &store, &state, retained)?;
    let services = [ServiceId::parse("host.audit.v1")?];
    let original = InstalledHostServices::new(
        &registrar,
        &registration,
        HostAgentServicesParams {
            workload_id: "vm-1",
            tenant_id: Some("local"),
            vm_name: "vm-1",
            state_dir: &state,
            broker_listen_socket: &socket,
            services: &services,
            capability_bindings: &[],
            service_proxies: &[],
        },
    )?;
    let mut peer = flow.map(OriginalPeer::new).transpose()?;
    let policy = NetworkPolicy::allow_list(vec![HostPort::new("peer.example", 443)])
        .with_payload_mapping(Some(CooperatingPayloadPolicy::new(vec![
            CooperatingTcpPeer {
                host: "peer.example".into(),
                port: 443,
                server_name: "peer.example".into(),
                spki_sha256: [5; 32],
                profile: PayloadMappingProfile::SpiralCoreObjectStreamSmallV1,
            },
        ])?));
    let policy = if let Some(peer) = &peer {
        peer.policy()?
    } else {
        policy
    };
    let admitted = AdmittedNetworkPlan {
        plan_id,
        plan_version: 1,
        plan_nonce: mvm_core::plan::Nonce::from_bytes([4; 16]),
        bundle_sha256: "11".repeat(32),
        tenant_id: "local".into(),
        instance_id: "vm-1".into(),
        policy_sha256: mvm_core::policy::network_policy::content_sha256(&policy),
    };
    let redaction = Default::default();
    let params = SubstitutionSpawnParams::builder()
        .vm_name("vm-1")
        .state_dir(&state)
        .lifetime(EndpointLifetime::Launcher)
        .tenant("local")
        .secrets(&[])
        .redaction(&redaction)
        .transport(EndpointTransport::Uds {
            path: state.join("network.sock"),
        })
        .telemetry(retained)
        // The test explicitly selects the canonical empty operator table;
        // production may not normalize absent/unresolved proxy settings here.
        .egress_proxy(EgressProxySpawnConfig::default())
        .network_policy(&policy)
        .admitted_network_plan(admitted.clone())
        .network_limits(Default::default())
        .ingress(&[])
        .flowmux_identity(FlowMuxIdentitySpawnConfig {
            session_id: hex::encode([3; 32]),
            host_signing_key_base64: STANDARD.encode([9; 32]),
            guest_verifying_key_base64: STANDARD
                .encode(SigningKey::from_bytes(&[7; 32]).verifying_key().to_bytes()),
        })
        .build()?;
    let mut endpoint = match spawn_network_endpoint_installed(params, handoff, &original) {
        Ok(endpoint) => endpoint,
        Err(error) => {
            // Dropping an actual failed-start owner collects its original
            // Child and releases only the audit pin. The retained preparation
            // remains quarantined; no store/Drained/refund success is claimed.
            let message = error.to_string();
            drop(error);
            if shipping && let Ok(log) = File::open(state.join("network-endpoint.stderr.log")) {
                let mut bytes = Vec::with_capacity(8192);
                log.take(8192).read_to_end(&mut bytes)?;
                eprintln!(
                    "canonical controller diagnostics: {}",
                    String::from_utf8_lossy(&bytes)
                );
            }
            registration.shutdown()?;
            agent.shutdown()?;
            return Err(anyhow::anyhow!(message));
        }
    };
    if let Some(peer) = &mut peer {
        peer.start(&admitted, &state)?;
    }
    let mut flow_accepted = true;
    let shipping_guest = if shipping {
        let mut guest = UnixStream::connect(state.join("network.sock"))?;
        guest.set_read_timeout(Some(Duration::from_secs(3)))?;
        guest.set_write_timeout(Some(Duration::from_secs(3)))?;
        let (mut session, _) = mvm_core::net::session::Session::guest(
            &mut guest,
            SigningKey::from_bytes(&[7; 32]),
            &SigningKey::from_bytes(&[9; 32]).verifying_key(),
        )?;
        if let Some(violation) = violation {
            use mvm_contract::protocol::network_flow::{Opcode, decode, encode};
            use mvm_core::net::session::{read_sealed_frame, write_sealed_frame};
            let invalid = match violation {
                Violation::InitialHello => encode(Opcode::Hello, 0, b"invalid canonical hello")?,
                Violation::RepeatedHello => {
                    let hello = encode(
                        Opcode::Hello,
                        0,
                        &mvm_contract::protocol::network_flow::hello::Handshake::local(
                            "installed-controller-fixture",
                        )
                        .encode(),
                    )?;
                    write_sealed_frame(&mut guest, &session.seal(&hello)?)?;
                    let response = read_sealed_frame(&mut guest, 65_536)?;
                    let response = session.open(&response)?;
                    ensure!(
                        decode(&response)?.header.opcode == Opcode::HelloAck,
                        "valid opening did not receive canonical HelloAck"
                    );
                    hello
                }
            };
            write_sealed_frame(&mut guest, &session.seal(&invalid)?)?;
            let rejected = read_sealed_frame(&mut guest, 65_536)?;
            let rejected = session.open(&rejected)?;
            ensure!(
                decode(&rejected)?.header.opcode == Opcode::GoAway,
                "actual protocol refusal was not observed before parent EOF"
            );
            if matches!(violation, Violation::InitialHello) {
                wait_original_session_exit(endpoint.id())?;
            }
        }
        if let Some(peer) = &mut peer {
            flow_accepted = peer.exchange(&mut guest, &mut session)?;
        }
        // Keep the ORIGINAL authenticated transport idle before FlowMux Hello.
        // Only the controller's pre-handshake cancellation clone can reliably
        // wake this session; no TCP relay exists to provide its own wake yet.
        Some(guest)
    } else {
        None
    };
    let stopped = endpoint.shutdown();
    if violation.is_some() {
        // Complete original fixture cleanup even in the expected old-code RED.
        // A failed actual endpoint stop does not mint a resource retirement.
        drop(shipping_guest);
        drop(endpoint);
        registration.shutdown()?;
        agent.shutdown()?;
        ensure!(
            stopped.is_err(),
            "actual protocol worker failure was erased by later parent EOF/Drained"
        );
        eprintln!(
            "actual protocol failure before parent EOF remains terminal; no Drained success: PASS"
        );
        return Ok(());
    }
    if let Err(error) = stopped {
        // Collect the actual original Child before reading its completed stderr;
        // this diagnostic is not a Drained/resource-retirement certificate.
        drop(shipping_guest);
        drop(endpoint);
        if let Ok(log) = File::open(state.join("network-endpoint.stderr.log")) {
            let mut bytes = Vec::with_capacity(8192);
            log.take(8192).read_to_end(&mut bytes)?;
            eprintln!(
                "original controller stop diagnostics: {}",
                String::from_utf8_lossy(&bytes)
            );
        }
        registration.shutdown()?;
        agent.shutdown()?;
        return Err(error);
    }
    if let Some(mut guest) = shipping_guest {
        if flow.is_some() {
            // Window-update frames may already be queued after HalfClose.
            // Exact application readback was checked before original stop.
            let mut tail = Vec::new();
            (&mut guest).take(65_537).read_to_end(&mut tail)?;
            ensure!(tail.len() < 65_537, "original transport did not reach EOF");
        } else {
            ensure!(guest.read(&mut [0; 1])? == 0, "original guest not closed");
        }
    }
    drop(endpoint);
    if let Some(retained) = &guard.retained {
        let retained = retained.lock().unwrap();
        let (records, key) = retained
            .files
            .as_ref()
            .ok_or_else(|| anyhow::anyhow!("actual file bind never completed"))?;
        ensure!(
            file_id(records)?
                == file_id(&File::open(state.join(
                    mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_FILE
                ))?)?
        );
        ensure!(
            file_id(key)?
                == file_id(&File::open(state.join(
                    mvm_vmm::host::telemetry_provisioning::TELEMETRY_RECORDS_KEY_FILE
                ))?)?
        );
        ensure!(
            mvm_vmm::host::telemetry_provisioning::load_records_key(
                &state,
                &config::mvm_keys_dir()
            )?
            .is_some()
        );
    }
    registration.shutdown()?;
    agent.shutdown()?;
    if let Some(flow) = flow {
        ensure!(
            flow_accepted,
            "unmapped selected ObjectTCP target performed Dial/Opened"
        );
        match flow {
            FlowCase::Mapped => verify_chain_for(
                "host.flow.allowed",
                std::collections::BTreeMap::from([
                    ("stream_id".into(), "1".into()),
                    ("class".into(), "tcp".into()),
                    ("route".into(), "peer".into()),
                    (
                        "target".into(),
                        format!("{}:443", installed_factory::TARGET),
                    ),
                    ("resolved_ips".into(), "127.0.0.1".into()),
                ]),
            )?,
            FlowCase::Unmapped => {
                let path = config::workload_audit_path("local", "vm-1");
                if path.exists() {
                    let key =
                        mvm_hostd::audit::host_keypair::load_or_init_at(&config::mvm_keys_dir())?
                            .verifying;
                    ensure!(
                        mvm_hostd::audit_signer::verify::verify_workload_chain_entries(
                            &path, &key
                        )?
                        .iter()
                        .all(|entry| entry.fields["event"] != "host.flow.allowed")
                    );
                }
            }
        }
        eprintln!(
            "shipping controller original mapped/refused flow and original positive joins: PASS"
        );
        return Ok(());
    }
    if shipping {
        let path = config::workload_audit_path("local", "vm-1");
        if path.exists() {
            let key =
                mvm_hostd::audit::host_keypair::load_or_init_at(&config::mvm_keys_dir())?.verifying;
            ensure!(
                mvm_hostd::audit_signer::verify::verify_workload_chain_entries(&path, &key)?
                    .is_empty(),
                "idle startup unexpectedly appended a flow outcome"
            );
        }
        eprintln!(
            "shipping Network controller original audit/factory/group + authenticated idle guest cancellation -> original session/collector joins + Drained/collected success: PASS (no mapped flow/native claim)"
        );
        return Ok(());
    }
    verify_chain()?;
    if retained {
        eprintln!(
            "actual original helper/registration -> retained prepare/strict key/original file bind -> child collector joins +canonical audit/FlowMux: PASS"
        );
    } else {
        eprintln!(
            "actual original helper/registration/child Recorder + mandatory-origin guard + authenticated FlowMux: PASS"
        );
    }
    Ok(())
}

#[cfg(target_os = "linux")]
fn wait_original_session_exit(original_child: u32) -> Result<()> {
    // Observation of our still-owned unreaped original Child only; this PID
    // supplies no product control/admission/retirement authority. GoAway above
    // proves the original session ran before this no-longer-present check.
    let deadline = Instant::now() + Duration::from_secs(3);
    loop {
        let mut active = false;
        for task in std::fs::read_dir(format!("/proc/{original_child}/task"))? {
            let path = task?.path().join("comm");
            match std::fs::read_to_string(path) {
                Ok(name) if name.trim() == "installed-sessi" => active = true,
                Ok(_) => {}
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
        }
        if !active {
            return Ok(());
        }
        ensure!(
            Instant::now() < deadline,
            "original protocol worker did not complete"
        );
        std::thread::yield_now();
    }
}
#[cfg(not(target_os = "linux"))]
fn wait_original_session_exit(_original_child: u32) -> Result<()> {
    anyhow::bail!("protocol-failure process fixture is Linux-only")
}

fn child() -> Result<()> {
    let mut child = InstalledEndpointChild::from_stdio()?;
    let resources = InstalledEndpointResources::from_child(&mut child)?;
    let mut collector = resources.start_owned_collector(child.startup_deadline())?;
    let recorder = resources.build_owned_audit_recorder()?;
    let group = OwnedTcpRelays::from_installed_resources(&resources)?;
    let factory = SpiralCorePayloadFactory::from_installed_resources(&resources)?
        .expect("mapped functional config");
    let (program, lease, pool) = resources.into_parts();
    let audit = lease.audit()?;
    let InstalledEndpointProgram::Network(config) = program else {
        anyhow::bail!("network required")
    };
    let policy = config.network_policy.unwrap();
    let mapping = Arc::new(
        PayloadMappingConfig::new(&policy, config.admitted_network_plan.unwrap())?
            .with_factory(Arc::new(factory)),
    );
    let session = config.flowmux_identity.unwrap().session_id;
    let runtime = tokio::runtime::Builder::new_current_thread().build()?;
    let entered = runtime.enter();
    // Original capability alone must not accept a missing Recorder origin.
    // Refusal occurs before authentication or binding the one guest transport.
    let (ours, mut peer) = UnixStream::pair()?;
    peer.set_read_timeout(Some(Duration::from_secs(1)))?;
    let base = || {
        FlowMuxAccept::new(
            &session,
            SigningKey::from_bytes(&[9; 32]),
            SigningKey::from_bytes(&[7; 32]).verifying_key(),
            RegistryLimits::default(),
            mvm_hostd::supervisor::network_endpoint::build_egress_gate(&policy),
        )
        .with_payload_mapping(Some(mapping.clone()))
        .with_owned_tcp_relays(Some(group.clone()))
        .with_installed_audit(audit.clone())
    };
    let result = FlowMuxSession::accept_with(ours, base());
    ensure!(
        matches!(result, Err(FlowMuxError::FrameRefused(_))),
        "missing origin accepted"
    );
    drop(result);
    ensure!(
        peer.read(&mut [0; 1])? == 0,
        "missing origin emitted authentication bytes"
    );
    drop(peer);
    append_canonical_record(&runtime, &recorder)?;
    let host = std::thread::scope(|scope| -> Result<FlowMuxSession> {
        let (ours, mut peer) = UnixStream::pair()?;
        ours.set_read_timeout(Some(Duration::from_secs(2)))?;
        ours.set_write_timeout(Some(Duration::from_secs(2)))?;
        peer.set_read_timeout(Some(Duration::from_secs(2)))?;
        peer.set_write_timeout(Some(Duration::from_secs(2)))?;
        let guest = scope.spawn(move || -> Result<()> {
            let (_, _) = mvm_core::net::session::Session::guest(
                &mut peer,
                SigningKey::from_bytes(&[7; 32]),
                &SigningKey::from_bytes(&[9; 32]).verifying_key(),
            )?;
            Ok(())
        });
        let host = FlowMuxSession::accept_with(
            ours,
            base().with_recorder(Some(Arc::new(recorder.clone()))),
        )?;
        guest.join().expect("original guest worker")?;
        Ok(host)
    })?;
    drop(entered);
    drop(runtime);
    child.send_ready(Default::default(), child.startup_deadline())?;
    let end = Instant::now() + Duration::from_secs(3);
    while !child.parent_closed()? {
        ensure!(Instant::now() < end, "parent EOF deadline");
        std::thread::yield_now();
    }
    drop(host);
    group.close_and_join(end)?;
    if let Some(collector) = &mut collector {
        collector.close_and_join(end)?;
    }
    let pool = pool.expect("one supplied pool");
    pool.close_admission()?;
    ensure!(pool.drained()?, "live payload resource");
    child.send_drained(end)?;
    Ok(())
}

fn append_canonical_record(
    runtime: &tokio::runtime::Runtime,
    recorder: &mvm_hostd::supervisor::audit_recorder::Recorder,
) -> Result<()> {
    runtime.handle().block_on(recorder.record_unbound(
        EventCategory::Host,
        "host.flow.fixture",
        [("destination".into(), "fixture.invalid:443".into())],
    ))?;
    Ok(())
}

fn verify_chain() -> Result<()> {
    verify_chain_for(
        "host.flow.fixture",
        std::collections::BTreeMap::from([("destination".into(), "fixture.invalid:443".into())]),
    )
}

fn verify_chain_for(event: &str, extras: std::collections::BTreeMap<String, String>) -> Result<()> {
    use mvm_hostd::{
        audit_signer::{chain::OnDiskEntry, verify::verify_workload_chain_entries},
        supervisor::{audit::PlanAuditEntry, audit_recorder::UNBOUND_PLAN_ID},
    };
    let key = mvm_hostd::audit::host_keypair::load_or_init_at(&config::mvm_keys_dir())?.verifying;
    let path = config::workload_audit_path("local", "vm-1");
    // The canonical verifier owns JCS/signature/algorithm/hash/order checks;
    // this fixture adds exact original entry and outer attribution readbacks.
    let authenticated = verify_workload_chain_entries(&path, &key)?;
    ensure!(
        authenticated.len() == 1,
        "exact endpoint audit record count"
    );
    let canonical = &authenticated[0];
    let original: PlanAuditEntry = serde_json::from_value(canonical.fields.clone())?;
    let expected = PlanAuditEntry {
        timestamp: original.timestamp,
        tenant: mvm_core::plan::TenantId("local".into()),
        plan_id: PlanId(UNBOUND_PLAN_ID.into()),
        plan_version: 0,
        bundle_id: None,
        bundle_version: None,
        image_name: "<unbound>".into(),
        image_sha256: "0".repeat(64),
        event: event.into(),
        caller_commitment: None,
        labels: std::collections::BTreeMap::from([
            ("category".into(), "host".into()),
            ("vm_name".into(), "vm-1".into()),
        ])
        .into_iter()
        .chain(extras)
        .collect(),
    };
    ensure!(
        canonical.fields == serde_json::to_value(expected)?,
        "exact canonical entry fields"
    );
    ensure!(
        canonical.ts == original.timestamp.to_rfc3339(),
        "outer original timestamp"
    );
    ensure!(
        canonical.category == "host"
            && canonical.tenant_id == "local"
            && canonical.workload_id == "vm-1"
    );
    ensure!(
        canonical.session_id == hex::encode([3; 32]) && canonical.correlation_id == "endpoint-0"
    );
    let text = std::fs::read_to_string(path)?;
    let records: Vec<OnDiskEntry> = text
        .lines()
        .map(serde_json::from_str)
        .collect::<std::result::Result<_, _>>()?;
    ensure!(records.len() == 1);
    let head = std::fs::read_to_string(
        config::vm_state_dir("vm-1")
            .join(mvm_vmm::host::broker_services_spawn::AUDIT_SIGNER_HEAD_FILE),
    )?;
    ensure!(head == records[0].entry_hash, "actual persisted head");
    Ok(())
}
