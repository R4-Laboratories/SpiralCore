//! seccomp-BPF filter via `seccompiler`.
//!
//! `seccompiler` 0.5 expects syscall numbers (libc::SYS_*) keyed by
//! `i64` in the rules map; it does not ship a public name-to-nr table
//! (the `sys` module exists but is private to the crate). We carry our
//! own table below — restricted to the syscalls
//! `ConfinementSpec::firecracker_bridge()` actually lists — so adding
//! a new entry to that allowlist also requires touching this lookup,
//! which is the audit point we want.

use crate::jailer::{ConfinementSpec, JailerError};
use seccompiler::{
    SeccompAction, SeccompCmpArgLen, SeccompCmpOp, SeccompCondition, SeccompFilter, SeccompRule,
    TargetArch,
};
use std::collections::BTreeMap;

#[cfg(target_arch = "x86_64")]
const TARGET_ARCH: TargetArch = TargetArch::x86_64;
#[cfg(target_arch = "aarch64")]
const TARGET_ARCH: TargetArch = TargetArch::aarch64;

/// Canonical (name, syscall-number) table for the
/// confined roles. This is the single source of
/// truth for the bridge's syscall allowlist:
/// `ConfinementSpec::firecracker_bridge()` derives its
/// `allowed_syscalls` from the names here, and `syscall_name_to_nr`
/// looks up numbers against it. Adding a syscall is a single edit;
/// review process is documented in `SECCOMP.md` §"Adding a syscall".
///
/// **Never relax this list without security review.** Names known to
/// be dangerous (`execve`, `setuid`, `setgid`, `ptrace`, `capset`) are
/// asserted-absent in `lib.rs::tests` as defense-in-depth.
///
/// Architecture divergence: `stat` / `lstat` map to `SYS_stat` /
/// `SYS_lstat` on x86_64 and are folded into `SYS_newfstatat` on aarch64
/// (aarch64 doesn't expose the path-stat syscalls separately).
/// `epoll_wait` maps to `SYS_epoll_wait` on x86_64 and is folded into
/// `SYS_epoll_pwait` on aarch64 for the same reason. The fold happens
/// here so the policy layer (`ConfinementSpec`) stays arch-agnostic.
#[cfg(target_arch = "x86_64")]
pub(crate) const CONFINED_ROLE_SYSCALLS: &[(&str, libc::c_long)] = &[
    ("read", libc::SYS_read),
    ("write", libc::SYS_write),
    // rustls/tokio-rustls drain coalesced handshake records with one vectored
    // write per flush; the first flow that reaches TLS termination (a
    // substituted secret on an attributed tool invocation) takes SIGSYS on
    // `writev` without it. Found via the live KVM witness.
    ("writev", libc::SYS_writev),
    ("fsync", libc::SYS_fsync),
    // The audit recorder locks the per-tenant log before appending, so the
    // first chain-signed event this endpoint emits calls `flock`. That event is
    // `host.flow.allowed`, written on the first egress the gate permits — so a
    // missing `flock` SIGSYS-kills the endpoint at the moment it starts
    // working, after the connect it was about to report succeeded. The
    // confinement already grants Landlock write on the audit dir; this is the
    // syscall that makes the grant usable.
    ("flock", libc::SYS_flock),
    // ...and `fdatasync` to make the append durable. The audit chain writes
    // each entry then syncs it, so both syscalls are on the same first-event
    // path; allowing only the lock moves the kill one syscall later.
    ("fdatasync", libc::SYS_fdatasync),
    ("openat", libc::SYS_openat),
    // musl's `open` issues the legacy `open` syscall on x86_64, where glibc
    // issues `openat`. Release binaries link musl statically, so every file a
    // released endpoint opened after confinement — the session marker first —
    // SIGSYS-killed it the moment a guest authenticated. glibc development
    // builds never made the call, which is why only releases broke.
    ("open", libc::SYS_open),
    ("close", libc::SYS_close),
    // glibc's resolver seeks while reading /etc/hosts (getaddrinfo); a missing
    // `lseek` SIGSYS-kills the endpoint mid-egress on a Linux host.
    ("lseek", libc::SYS_lseek),
    // Audit segment rotation renames the full active segment aside. The
    // Landlock grant on the audit dir already carries `Refer` for it; without
    // the syscall the endpoint dies the first time its log reaches the
    // rotation threshold. The embedded telemetry collector relies on the same
    // row: it replaces its status snapshot by writing a temp file and renaming
    // it over the old one, confined by Landlock to the VM state dir.
    ("rename", libc::SYS_rename),
    // arch divergence: x86_64 keeps `stat` / `lstat` as their own
    // syscalls; aarch64 folds both into `fstatat` (see aarch64 block).
    ("stat", libc::SYS_stat),
    ("lstat", libc::SYS_lstat),
    ("fstat", libc::SYS_fstat),
    ("socket", libc::SYS_socket),
    ("bind", libc::SYS_bind),
    ("connect", libc::SYS_connect),
    ("accept", libc::SYS_accept),
    ("accept4", libc::SYS_accept4),
    ("sendmsg", libc::SYS_sendmsg),
    ("recvmsg", libc::SYS_recvmsg),
    ("sendto", libc::SYS_sendto),
    ("recvfrom", libc::SYS_recvfrom),
    ("splice", libc::SYS_splice),
    ("clock_gettime", libc::SYS_clock_gettime),
    ("futex", libc::SYS_futex),
    ("exit", libc::SYS_exit),
    ("exit_group", libc::SYS_exit_group),
    ("rt_sigprocmask", libc::SYS_rt_sigprocmask),
    ("rt_sigaction", libc::SYS_rt_sigaction),
    // The Rust runtime installs an alternate signal stack (stack-overflow
    // guard) during thread setup; without this the bridge takes SIGSYS on its
    // own `sigaltstack` as soon as the packet thread spins up. Found via live
    // FC strace — the allowlist had never been exercised on the real sidecar.
    ("sigaltstack", libc::SYS_sigaltstack),
    ("mmap", libc::SYS_mmap),
    ("munmap", libc::SYS_munmap),
    ("mprotect", libc::SYS_mprotect),
    ("brk", libc::SYS_brk),
    ("getpid", libc::SYS_getpid),
    ("gettid", libc::SYS_gettid),
    ("getuid", libc::SYS_getuid),
    ("getgid", libc::SYS_getgid),
    ("getrandom", libc::SYS_getrandom),
    ("epoll_create1", libc::SYS_epoll_create1),
    ("epoll_ctl", libc::SYS_epoll_ctl),
    // arch divergence: x86_64 keeps `epoll_wait` as its own syscall;
    // aarch64 folds it into `epoll_pwait` (see aarch64 block).
    ("epoll_wait", libc::SYS_epoll_wait),
    ("epoll_pwait", libc::SYS_epoll_pwait),
    ("prctl", libc::SYS_prctl),
    ("set_tid_address", libc::SYS_set_tid_address),
    ("set_robust_list", libc::SYS_set_robust_list),
    // ── substitution-endpoint additions ────────────────────────────
    // The endpoint runs a multi-thread tokio runtime and a rustls TLS
    // forward leg (mvm-http, rustls-native-certs) that the bridge does
    // not. These cover thread creation, the glibc allocator + resolver,
    // socket-option negotiation, and cert-store directory reads. Erring
    // toward inclusion: a missing syscall SIGSYS-kills the endpoint
    // mid-egress, which is worse than a slightly wider allowlist on an
    // already-isolated per-VM process.
    ("clone", libc::SYS_clone),     // tokio worker / blocking thread spawn
    ("clone3", libc::SYS_clone3),   // modern glibc pthread_create path
    ("rseq", libc::SYS_rseq),       // glibc registers rseq on each new thread
    ("madvise", libc::SYS_madvise), // allocator MADV_DONTNEED / MADV_FREE
    ("sched_yield", libc::SYS_sched_yield), // futex spin fallback
    ("eventfd2", libc::SYS_eventfd2), // tokio reactor wakeup fd
    ("getsockname", libc::SYS_getsockname),
    ("getpeername", libc::SYS_getpeername),
    ("getsockopt", libc::SYS_getsockopt), // SO_ERROR after a timed connect, TLS
    ("setsockopt", libc::SYS_setsockopt), // TCP_NODELAY, socket tuning
    ("poll", libc::SYS_poll),             // glibc resolver / connect timeouts
    ("ppoll", libc::SYS_ppoll),
    ("pread64", libc::SYS_pread64),
    ("pwrite64", libc::SYS_pwrite64),
    ("statx", libc::SYS_statx), // newer glibc stat() for cert files
    ("socketpair", libc::SYS_socketpair),
    ("recvmmsg", libc::SYS_recvmmsg),     // glibc DNS resolver
    ("sendmmsg", libc::SYS_sendmmsg),     // glibc DNS resolver
    ("getdents64", libc::SYS_getdents64), // read /etc/ssl/certs dir
    ("readlinkat", libc::SYS_readlinkat), // cert symlink resolution
    // glibc's NSS hostname path (getaddrinfo → nscd/files fallback, then
    // `_uname` for the canonical host name) calls `uname` on the FIRST egress
    // the endpoint proxies. Without it the filter SIGSYS-kills the endpoint
    // seconds after the FlowMux handshake — the guest only notices at its next
    // use, and every reconnect then hits the stale socket. Found via live
    // Firecracker strace on a KVM host: the allowlist had never been
    // exercised on a real Linux egress CONNECT.
    ("uname", libc::SYS_uname),
    ("fcntl", libc::SYS_fcntl),       // O_NONBLOCK on accepted sockets
    ("shutdown", libc::SYS_shutdown), // graceful socket close
    ("clock_nanosleep", libc::SYS_clock_nanosleep), // tokio timer
    // The audit signer create_dir_all's the audit dir on first open;
    // Rust std emits the legacy `mkdir` on x86_64.
    ("mkdir", libc::SYS_mkdir),
    ("mkdirat", libc::SYS_mkdirat),
    // tokio's runtime queries CPU affinity when it spawns workers after
    // confinement (worker count / NUMA placement).
    ("sched_getaffinity", libc::SYS_sched_getaffinity),
    // Completed via live FC strace: the Rust/tokio runtime (thread TLS, stack
    // limits, allocator realloc) + the transcript-capture sink + the
    // gateway-audit socket make these after confinement; without them the
    // bridge takes SIGSYS and the watchdog tears down the VM.
    ("access", libc::SYS_access),
    ("arch_prctl", libc::SYS_arch_prctl),
    ("chmod", libc::SYS_chmod),
    ("ioctl", libc::SYS_ioctl),
    ("listen", libc::SYS_listen),
    ("mremap", libc::SYS_mremap),
    ("newfstatat", libc::SYS_newfstatat),
    ("prlimit64", libc::SYS_prlimit64),
    ("unlink", libc::SYS_unlink),
];

#[cfg(target_arch = "aarch64")]
pub(crate) const CONFINED_ROLE_SYSCALLS: &[(&str, libc::c_long)] = &[
    ("read", libc::SYS_read),
    ("write", libc::SYS_write),
    // rustls/tokio-rustls drain coalesced handshake records with one vectored
    // write per flush; the first flow that reaches TLS termination (a
    // substituted secret on an attributed tool invocation) takes SIGSYS on
    // `writev` without it. Found via the live KVM witness.
    ("writev", libc::SYS_writev),
    ("fsync", libc::SYS_fsync),
    // The audit recorder locks the per-tenant log before appending, so the
    // first chain-signed event this endpoint emits calls `flock`. That event is
    // `host.flow.allowed`, written on the first egress the gate permits — so a
    // missing `flock` SIGSYS-kills the endpoint at the moment it starts
    // working, after the connect it was about to report succeeded. The
    // confinement already grants Landlock write on the audit dir; this is the
    // syscall that makes the grant usable.
    ("flock", libc::SYS_flock),
    // ...and `fdatasync` to make the append durable. The audit chain writes
    // each entry then syncs it, so both syscalls are on the same first-event
    // path; allowing only the lock moves the kill one syscall later.
    ("fdatasync", libc::SYS_fdatasync),
    ("openat", libc::SYS_openat),
    // arch divergence: aarch64 has no legacy `open`; musl and glibc both
    // issue `openat` there (the policy layer keeps the name).
    ("open", libc::SYS_openat),
    ("close", libc::SYS_close),
    // glibc's resolver seeks while reading /etc/hosts (getaddrinfo); a missing
    // `lseek` SIGSYS-kills the endpoint mid-egress on a Linux host.
    ("lseek", libc::SYS_lseek),
    // Audit segment rotation (see the x86_64 block). aarch64 has no bare
    // `rename`; both C libraries issue `renameat`.
    ("rename", libc::SYS_renameat),
    // arch divergence: aarch64 does not expose `stat` / `lstat` as
    // their own syscalls — both fold into `newfstatat` (syscall 79; libc
    // exposes no bare `SYS_fstatat` on aarch64). The policy layer still
    // references the names `stat` / `lstat` for readability.
    ("stat", libc::SYS_newfstatat),
    ("lstat", libc::SYS_newfstatat),
    ("fstat", libc::SYS_fstat),
    ("socket", libc::SYS_socket),
    ("bind", libc::SYS_bind),
    ("connect", libc::SYS_connect),
    ("accept", libc::SYS_accept),
    ("accept4", libc::SYS_accept4),
    ("sendmsg", libc::SYS_sendmsg),
    ("recvmsg", libc::SYS_recvmsg),
    ("sendto", libc::SYS_sendto),
    ("recvfrom", libc::SYS_recvfrom),
    ("splice", libc::SYS_splice),
    ("clock_gettime", libc::SYS_clock_gettime),
    ("futex", libc::SYS_futex),
    ("exit", libc::SYS_exit),
    ("exit_group", libc::SYS_exit_group),
    ("rt_sigprocmask", libc::SYS_rt_sigprocmask),
    ("rt_sigaction", libc::SYS_rt_sigaction),
    // The Rust runtime installs an alternate signal stack (stack-overflow
    // guard) during thread setup; without this the bridge takes SIGSYS on its
    // own `sigaltstack` as soon as the packet thread spins up. Found via live
    // FC strace — the allowlist had never been exercised on the real sidecar.
    ("sigaltstack", libc::SYS_sigaltstack),
    ("mmap", libc::SYS_mmap),
    ("munmap", libc::SYS_munmap),
    ("mprotect", libc::SYS_mprotect),
    ("brk", libc::SYS_brk),
    ("getpid", libc::SYS_getpid),
    ("gettid", libc::SYS_gettid),
    ("getuid", libc::SYS_getuid),
    ("getgid", libc::SYS_getgid),
    ("getrandom", libc::SYS_getrandom),
    ("epoll_create1", libc::SYS_epoll_create1),
    ("epoll_ctl", libc::SYS_epoll_ctl),
    // arch divergence: aarch64 does not expose `epoll_wait` — fold
    // into `epoll_pwait` (the policy layer keeps the legacy name).
    ("epoll_wait", libc::SYS_epoll_pwait),
    ("epoll_pwait", libc::SYS_epoll_pwait),
    ("prctl", libc::SYS_prctl),
    ("set_tid_address", libc::SYS_set_tid_address),
    ("set_robust_list", libc::SYS_set_robust_list),
    // ── substitution-endpoint additions (see x86_64 block for rationale) ──
    ("clone", libc::SYS_clone),
    ("clone3", libc::SYS_clone3),
    ("rseq", libc::SYS_rseq),
    ("madvise", libc::SYS_madvise),
    ("sched_yield", libc::SYS_sched_yield),
    ("eventfd2", libc::SYS_eventfd2),
    ("getsockname", libc::SYS_getsockname),
    ("getpeername", libc::SYS_getpeername),
    ("getsockopt", libc::SYS_getsockopt),
    ("setsockopt", libc::SYS_setsockopt),
    // arch divergence: aarch64 has no bare `poll` syscall — both `poll`
    // and `ppoll` fold into `SYS_ppoll` (the policy layer keeps both names).
    ("poll", libc::SYS_ppoll),
    ("ppoll", libc::SYS_ppoll),
    ("pread64", libc::SYS_pread64),
    ("pwrite64", libc::SYS_pwrite64),
    ("statx", libc::SYS_statx),
    ("socketpair", libc::SYS_socketpair),
    ("recvmmsg", libc::SYS_recvmmsg),
    ("sendmmsg", libc::SYS_sendmmsg),
    ("getdents64", libc::SYS_getdents64),
    ("readlinkat", libc::SYS_readlinkat),
    // glibc's NSS hostname path (getaddrinfo → nscd/files fallback, then
    // `_uname` for the canonical host name) calls `uname` on the FIRST egress
    // the endpoint proxies. Without it the filter SIGSYS-kills the endpoint
    // seconds after the FlowMux handshake — the guest only notices at its next
    // use, and every reconnect then hits the stale socket. Found via live
    // Firecracker strace on a KVM host: the allowlist had never been
    // exercised on a real Linux egress CONNECT.
    ("uname", libc::SYS_uname),
    ("fcntl", libc::SYS_fcntl),
    ("shutdown", libc::SYS_shutdown),
    ("clock_nanosleep", libc::SYS_clock_nanosleep),
    // arch divergence: aarch64 has no bare `mkdir` — it folds into
    // `mkdirat` (the policy layer keeps both names).
    ("mkdir", libc::SYS_mkdirat),
    ("mkdirat", libc::SYS_mkdirat),
    // tokio's runtime queries CPU affinity when it spawns workers after
    // confinement (worker count / NUMA placement).
    ("sched_getaffinity", libc::SYS_sched_getaffinity),
    // Completed via live FC strace (x86_64). aarch64 has no arch_prctl, and
    // access/chmod/unlink fold into the *at variants glibc actually issues.
    ("faccessat", libc::SYS_faccessat),
    ("fchmodat", libc::SYS_fchmodat),
    ("ioctl", libc::SYS_ioctl),
    ("listen", libc::SYS_listen),
    ("mremap", libc::SYS_mremap),
    ("newfstatat", libc::SYS_newfstatat),
    ("prlimit64", libc::SYS_prlimit64),
    ("unlinkat", libc::SYS_unlinkat),
];

/// Resolve a syscall by name to its `libc::SYS_*` number on the current
/// architecture. Returns `None` for any name not in `CONFINED_ROLE_SYSCALLS`.
///
/// Every entry in `ConfinementSpec::firecracker_bridge()`'s
/// `allowed_syscalls` must have a row in `CONFINED_ROLE_SYSCALLS`; because
/// the spec is derived from that table, the discipline is structural
/// (you can't add a name without a number, you can't add a number
/// without a name).
fn syscall_name_to_nr(name: &str) -> Option<libc::c_long> {
    CONFINED_ROLE_SYSCALLS
        .iter()
        .find(|(n, _)| *n == name)
        .map(|(_, nr)| *nr)
}

/// Install the confined-role filter on every thread of the process.
///
/// The filter is installed with `SECCOMP_FILTER_FLAG_TSYNC`, so the kernel
/// applies it to all existing threads in one step, and threads created later
/// inherit it. Without the flag the filter binds only the calling thread, and
/// a sibling that already existed — an async runtime worker — would make any
/// system call it liked. The install fails, applying nothing, if some thread
/// cannot be synchronised.
///
/// First installs the refusal reporter, so a call the filter refuses is named
/// on stderr before the process dies of it rather than silently.
pub fn apply(spec: &ConfinementSpec) -> Result<(), JailerError> {
    apply_inner(spec, false, false)
}

pub(crate) fn apply_with_owned_files(
    spec: &ConfinementSpec,
    store: bool,
    records: bool,
) -> Result<(), JailerError> {
    apply_inner(spec, store, records)
}

fn apply_inner(
    spec: &ConfinementSpec,
    owned_store: bool,
    owned_records: bool,
) -> Result<(), JailerError> {
    crate::jailer::refusal_report::install(process_label())?;
    let mut rules: BTreeMap<i64, Vec<SeccompRule>> = BTreeMap::new();
    for name in &spec.allowed_syscalls {
        let nr = syscall_name_to_nr(name).ok_or_else(|| {
            JailerError::SeccompInstall(format!(
                "unknown syscall name {name:?}; extend CONFINED_ROLE_SYSCALLS in mvm_hostd::jailer::seccomp"
            ))
        })?;
        rules.insert(nr, vec![]);
    }
    if owned_store || owned_records {
        // Current-owner verification reads the effective UID after confinement.
        rules.insert(libc::SYS_geteuid, vec![]);
    }
    if owned_records {
        // Records freshness reopens/checks the original state directory using
        // the canonical local-filesystem probe. Store-only freshness currently
        // needs metadata/current-owner, so it receives no extra FS query.
        rules.insert(libc::SYS_fstatfs, vec![]);
        // The canonical FD ACL check only queries presence/length. It does
        // not read xattr bytes: require the actual NULL buffer and zero size.
        // BPF cannot validate the attribute-name string; the original opaque
        // writer's namespace/identity/owner/flags/ACL checks remain mandatory.
        let conditions = [2, 3]
            .into_iter()
            .map(|argument| {
                SeccompCondition::new(argument, SeccompCmpArgLen::Qword, SeccompCmpOp::Eq, 0)
                    .map_err(|error| JailerError::SeccompInstall(error.to_string()))
            })
            .collect::<Result<Vec<_>, _>>()?;
        let presence = SeccompRule::new(conditions)
            .map_err(|error| JailerError::SeccompInstall(error.to_string()))?;
        rules.insert(libc::SYS_fgetxattr, vec![presence]);
        if !owned_store && rules.contains_key(&libc::SYS_unlinkat) {
            // AArch64's canonical file cleanup uses unlinkat. The records-only
            // role's unlinkat allowance removes status temp files, without
            // the explicit directory-removal flag. Preserve
            // the legacy rule while narrowing only this selected owned role.
            let files_only = SeccompRule::new(vec![
                SeccompCondition::new(2, SeccompCmpArgLen::Qword, SeccompCmpOp::Eq, 0)
                    .map_err(|error| JailerError::SeccompInstall(error.to_string()))?,
            ])
            .map_err(|error| JailerError::SeccompInstall(error.to_string()))?;
            rules.insert(libc::SYS_unlinkat, vec![files_only]);
        }
    }
    if owned_store {
        // Store retirement removes only directories within its Landlock grant.
        #[cfg(target_arch = "x86_64")]
        {
            rules.insert(libc::SYS_rmdir, vec![]);
            // Rust's descriptor-relative remove_dir_all uses unlinkat for
            // files and directories. Permit only those exact native flags;
            // Qword comparison also rejects unknown upper argument bits.
            let removals = [0, libc::AT_REMOVEDIR as u64]
                .into_iter()
                .map(|flags| {
                    let condition =
                        SeccompCondition::new(2, SeccompCmpArgLen::Qword, SeccompCmpOp::Eq, flags)
                            .map_err(|error| JailerError::SeccompInstall(error.to_string()))?;
                    SeccompRule::new(vec![condition])
                        .map_err(|error| JailerError::SeccompInstall(error.to_string()))
                })
                .collect::<Result<Vec<_>, _>>()?;
            rules.insert(libc::SYS_unlinkat, removals);
        }
        #[cfg(target_arch = "aarch64")]
        rules.insert(libc::SYS_unlinkat, vec![]);
    }
    // SeccompAction::Trap (vs Errno(EACCES)) is intentional: the
    // bridge sidecar is expected to be killed by SIGSYS on a forbidden
    // syscall, and the supervisor's BridgeRestartPolicy::HardFail
    // tears the VM down. Errno would let a
    // compromised bridge observe the rejection and retry or pivot,
    // which is exactly what we want to forbid. SECCOMP.md §"Refusal
    // posture" documents this trade-off.
    let filter = SeccompFilter::new(
        rules,
        SeccompAction::Trap,
        SeccompAction::Allow,
        TARGET_ARCH,
    )
    .map_err(|e| JailerError::SeccompInstall(format!("{e:?}")))?;
    let bpf: seccompiler::BpfProgram = filter
        .try_into()
        .map_err(|e| JailerError::SeccompInstall(format!("{e:?}")))?;
    seccompiler::apply_filter_all_threads(&bpf).map_err(|e| match e {
        seccompiler::Error::ThreadSync(tid) => JailerError::SeccompInstall(format!(
            "thread {tid} could not take the filter; nothing was installed"
        )),
        other => JailerError::SeccompInstall(format!("{other:?}")),
    })?;
    Ok(())
}

#[cfg(test)]
#[path = "seccomp_owned_tests.rs"]
mod owned_tests;

/// The name a refusal line is attributed to: this executable's file name.
fn process_label() -> &'static str {
    let name = std::env::args_os()
        .next()
        .map(std::path::PathBuf::from)
        .and_then(|path| path.file_name().map(|n| n.to_string_lossy().into_owned()))
        .unwrap_or_else(|| "confined process".to_string());
    // A signal handler reads it for the rest of the process's life, so it has
    // to outlive every borrow. Computed once per confinement.
    Box::leak(name.into_boxed_str())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn syscall_name_to_nr_returns_none_for_unknown_name() {
        assert!(syscall_name_to_nr("execve").is_none());
        assert!(syscall_name_to_nr("setuid").is_none());
        assert!(syscall_name_to_nr("ptrace").is_none());
        assert!(syscall_name_to_nr("definitely_not_a_real_syscall").is_none());
    }

    #[test]
    fn syscall_name_to_nr_resolves_known_names() {
        // Spot-check a representative slice rather than every entry —
        // the negative tests in lib.rs already exercise the audit
        // discipline.
        assert!(syscall_name_to_nr("read").is_some());
        assert!(syscall_name_to_nr("write").is_some());
        assert!(syscall_name_to_nr("splice").is_some());
        assert!(syscall_name_to_nr("fsync").is_some());
        // glibc resolver path — omitting it SIGSYS-killed the substitution
        // endpoint mid-egress on a live Firecracker host.
        assert!(syscall_name_to_nr("lseek").is_some());
        // The NSS hostname path (`getaddrinfo` → `uname`) — omitting it
        // SIGSYS-killed the endpoint seconds after the FlowMux handshake,
        // which reads as a guest-egress transport failure minutes later
        //. Pin it so the allowlist can never regress here again.
        assert!(syscall_name_to_nr("uname").is_some());
        // musl's `open` on x86_64 — omitting it SIGSYS-killed every released
        // endpoint when its first guest authenticated.
        assert!(syscall_name_to_nr("open").is_some());
        // Audit segment rotation, and the embedded telemetry collector's
        // status-snapshot replace after the endpoint confines itself.
        assert!(syscall_name_to_nr("rename").is_some());
    }

    #[test]
    fn bridge_syscalls_has_no_duplicate_names() {
        // Defense against a future arch-block edit accidentally
        // shipping two rows for the same name (which would silently
        // shadow the first under `find()`).
        let mut seen: Vec<&str> = CONFINED_ROLE_SYSCALLS.iter().map(|(n, _)| *n).collect();
        seen.sort_unstable();
        let original_len = seen.len();
        seen.dedup();
        assert_eq!(
            original_len,
            seen.len(),
            "CONFINED_ROLE_SYSCALLS contains duplicate name"
        );
    }
}
