//! Confinement helper for per-VM sibling processes that run alongside
//! Firecracker on Linux.
//!
//! Wraps `seccompiler` (Firecracker-maintained) + `landlock` (official
//! Rust LSM binding) behind a single `confine_self(&ConfinementSpec)`
//! entry point. Non-Linux targets compile as inert stubs (the roles that
//! call `confine_self` are Linux-only at runtime; the stub keeps
//! workspace `cargo check` green on macOS / Windows contributor hosts).
//!
//! The `dead_code` allow below is gated to non-Linux targets because
//! `ConfinementSpec`'s syscall-name + path fields are only consumed by
//! the Linux-only `seccomp` + `landlock` modules. On macOS / Windows
//! the type is built (so callers compile) but its fields aren't read
//! by anything, which would otherwise trip the compiler's dead-code
//! lint. Per-symbol `#[cfg(target_os = "linux")]` would force every
//! field + impl method to carry the gate; a file-level cfg-attr is
//! cleaner and still leaves Linux compilation unaffected.
use std::path::{Path, PathBuf};

#[derive(Debug, thiserror::Error)]
pub enum JailerError {
    #[error("seccomp filter install failed: {0}")]
    SeccompInstall(String),
    #[error("landlock ruleset apply failed: {0}")]
    LandlockApply(String),
    #[error(
        "kernel cannot enforce landlock ABI v2; enable CONFIG_SECURITY_LANDLOCK=y, include landlock in the active LSM list, and use Linux 5.19+"
    )]
    LandlockUnavailable,
    #[error("kernel does not support seccomp-bpf (need Linux 4.14+)")]
    SeccompUnavailable,
    /// Confinement was asked for while the process had more than one thread.
    ///
    /// Landlock restricts only the thread that calls `landlock_restrict_self`
    /// and the threads it creates afterwards. A thread that already exists
    /// keeps the whole filesystem, so confining a multi-threaded process would
    /// leave every sibling thread outside the ruleset. Nothing is applied when
    /// this is returned.
    #[error(
        "refusing to confine a process with {threads} threads: confinement must be applied before any other thread exists, or the threads already running stay unconfined"
    )]
    NotSingleThreaded { threads: usize },
    /// The thread count could not be read, so single-threadedness could not be
    /// established. Treated as a refusal rather than an assumption.
    #[error("cannot count this process's threads in {path}: {source}")]
    ThreadCountUnavailable {
        path: PathBuf,
        source: std::io::Error,
    },
    /// A path in the `ConfinementSpec` could not be opened to install a
    /// Landlock rule. Carries the failing path so the operator sees
    /// which directory needs to exist (the audit dir is the
    /// most common cause: `~/.mvm/audit/` must be pre-created with
    /// mode 0700 by the supervisor's bootstrap before the role spawns).
    #[error("landlock path missing: {path}: {source}")]
    PathNotFound {
        path: PathBuf,
        source: std::io::Error,
    },
}

/// Result of the read-only Landlock ABI query for the running host.
///
/// The query never installs a ruleset or changes the caller's privileges. It
/// exists so diagnostics can name an unusable kernel before a secret-holding
/// endpoint reaches its mandatory, irreversible confinement step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LandlockSupport {
    /// The kernel exposes at least the minimum ABI used by mvm.
    Available { abi: u32 },
    /// Landlock exists, but its ABI predates mvm's v2 floor.
    TooOld { abi: u32 },
    /// Landlock is compiled in but disabled for this boot.
    Disabled,
    /// The running kernel does not implement the Landlock syscall.
    Unavailable,
    /// The ABI query failed in an unexpected way.
    ProbeFailed { errno: Option<i32> },
    /// Landlock is a Linux LSM and does not apply to this host OS.
    NotApplicable,
}

#[cfg(any(target_os = "linux", test))]
const MIN_LANDLOCK_ABI: u32 = 2;

#[cfg(any(target_os = "linux", test))]
fn classify_landlock_abi_query(query: Result<u32, Option<i32>>) -> LandlockSupport {
    match query {
        Ok(abi) if abi >= MIN_LANDLOCK_ABI => LandlockSupport::Available { abi },
        Ok(abi) => LandlockSupport::TooOld { abi },
        Err(Some(libc::EOPNOTSUPP)) => LandlockSupport::Disabled,
        Err(Some(libc::ENOSYS)) => LandlockSupport::Unavailable,
        Err(errno) => LandlockSupport::ProbeFailed { errno },
    }
}

/// Query the running kernel's Landlock ABI without installing a ruleset.
#[cfg(target_os = "linux")]
#[must_use]
pub fn landlock_support() -> LandlockSupport {
    const LANDLOCK_CREATE_RULESET_VERSION: u32 = 1;
    // SAFETY: a null attribute pointer and zero size are the kernel-defined
    // read-only ABI-version query. No fd is created and no restriction is
    // installed when LANDLOCK_CREATE_RULESET_VERSION is supplied.
    let raw = unsafe {
        libc::syscall(
            libc::SYS_landlock_create_ruleset,
            std::ptr::null::<libc::c_void>(),
            0usize,
            LANDLOCK_CREATE_RULESET_VERSION,
        )
    };
    let query = if raw < 0 {
        Err(std::io::Error::last_os_error().raw_os_error())
    } else {
        u32::try_from(raw).map_err(|_| None)
    };
    classify_landlock_abi_query(query)
}

/// Landlock is a Linux-only LSM. Other hosts use their platform's existing
/// process boundary and report this diagnostic as not applicable.
#[cfg(not(target_os = "linux"))]
#[must_use]
pub fn landlock_support() -> LandlockSupport {
    LandlockSupport::NotApplicable
}

#[derive(Debug, Clone)]
pub struct ConfinementSpec {
    pub readable_paths: Vec<PathBuf>,
    pub read_write_paths: Vec<PathBuf>,
    pub allowed_syscalls: Vec<&'static str>,
}

impl ConfinementSpec {
    /// Canonical spec for `mvm-network-endpoint` — the per-VM process
    /// that holds the workload's decrypted secrets AND parses untrusted guest
    /// bytes over vsock/UDS. Confining it bounds the blast radius of a parser
    /// compromise: a hijacked endpoint can read only its own tenant's stores
    /// and the TLS/DNS files its forward leg needs, and can invoke only the
    /// network-service syscall set.
    ///
    /// `readable_paths` covers the secret + binding stores (resolved by the
    /// caller exactly as `assemble` does — config override or `~/.mvm`
    /// default) plus the TLS root + DNS resolver files the HTTP
    /// (`rustls-native-certs`) forward leg reads PER REQUEST during `serve`,
    /// so they must stay readable AFTER confinement. The audit recorder reads
    /// the signer key (`keys_dir`) and appends the chain-signed substitution log
    /// (`audit_dir`), so the key is readable and the audit dir is read-write.
    ///
    /// The syscall allowlist comes from the same canonical
    /// `seccomp::CONFINED_ROLE_SYSCALLS` table — extended with the
    /// extra syscalls the tokio multi-thread runtime + rustls TLS forward leg
    /// touch (see the table's comments). On non-Linux targets the list is
    /// empty (the stub `confine_self` errors; the bin hard-exits before
    /// reaching it). `existing_paths` filters to paths that exist on this host
    /// — `/etc/pki`, `/etc/resolv.conf`, etc. are distro-dependent, and a
    /// missing readable path makes the Landlock `open` step fail closed.
    ///
    /// `resolver_uds` threads in the M2 `ResolverBackend::Remote { uds_path,
    /// .. }` socket path: `Some(path)` when the endpoint config selects the
    /// remote fleet-secrets daemon, additionally permitting connect +
    /// read/write on that ONE socket so `RemoteResolver` can reach it after
    /// confinement. `None` (the `Local` backend, and the default) leaves the
    /// confinement identical to before this parameter existed — no socket
    /// egress at all.
    ///
    /// Deliberately **not** run through `existing_paths` like the TLS/DNS
    /// grants above: `Remote` mode is useless without the resolver reachable,
    /// so a socket path that doesn't (yet) exist should make Landlock's own
    /// `PathNotFound` refuse to serve — not silently vanish into an empty
    /// grant that "succeeds" while leaving `Remote` unable to resolve
    /// anything. That would be confinement quietly defeating the feature it
    /// was supposed to permit.
    ///
    /// No seccomp change accompanies this: `socket` / `connect` / `read` /
    /// `write` / `setsockopt` are already unconditionally in this spec's
    /// `allowed_syscalls` (the same `BRIDGE_SYSCALLS` rows the TLS forward
    /// leg's TCP egress already relies on) — seccomp here filters by syscall
    /// number only, with no per-call argument/address-family predicate, so
    /// there is nothing narrower to add for AF_UNIX specifically. The
    /// confinement narrowing for `Remote` is entirely a Landlock (path)
    /// concern.
    pub fn network_endpoint(
        secret_store_dir: PathBuf,
        binding_store_dir: PathBuf,
        audit_dir: PathBuf,
        keys_dir: PathBuf,
        resolver_uds: Option<&Path>,
    ) -> Self {
        #[cfg(target_os = "linux")]
        let allowed_syscalls: Vec<&'static str> = crate::jailer::seccomp::CONFINED_ROLE_SYSCALLS
            .iter()
            .map(|(name, _)| *name)
            .collect();
        #[cfg(not(target_os = "linux"))]
        let allowed_syscalls: Vec<&'static str> = Vec::new();

        // The forward leg uses mvm-http's rustls backend, which loads the
        // host's native root store (rustls-native-certs reads /etc/ssl/certs +
        // /etc/pki/tls). DNS goes through getaddrinfo (resolv.conf / hosts /
        // nsswitch). These are read per request during serve, so they must be
        // inside the Landlock ruleset.
        let tls_dns_paths: Vec<PathBuf> = [
            "/etc/ssl",
            "/etc/pki",
            "/etc/resolv.conf",
            "/etc/hosts",
            "/etc/nsswitch.conf",
        ]
        .into_iter()
        .map(PathBuf::from)
        .collect();

        // The chain-signed audit recorder reads the host signer key (keys_dir)
        // and appends to the per-tenant log (audit_dir). Without these grants a
        // confined endpoint with a recorder attached couldn't sign — so the
        // key is readable and the audit dir is read-write.
        //
        // The resolver re-reads the secret-store key on every secret `get`,
        // after confinement; the key sits beside the store dir, so a grant on
        // the store alone leaves every substitution EACCES on Linux.
        let store_key =
            mvm_core::crypto::secret_store::file_store_key_path_for_base(&secret_store_dir);
        let mut readable_paths = vec![secret_store_dir, binding_store_dir, keys_dir, store_key];
        readable_paths.extend(tls_dns_paths);

        let mut read_write_paths = existing_paths(vec![audit_dir]);
        if let Some(uds) = resolver_uds {
            // NOT filtered by `existing_paths` — see the doc comment above:
            // this grant must fail closed (via Landlock's `PathNotFound`) if
            // the socket isn't there, rather than silently drop out.
            read_write_paths.push(uds.to_path_buf());
        }

        Self {
            // Filter to extant paths: /etc/pki / /etc/resolv.conf are distro-
            // dependent, and Landlock's `open` on a missing path fails closed
            // (PathNotFound), which would abort an otherwise-healthy endpoint.
            readable_paths: existing_paths(readable_paths),
            read_write_paths,
            allowed_syscalls,
        }
    }

    /// Spec for the collector-only mode of `mvm-network-endpoint`: no
    /// secrets, no stores, no forward leg — it parses untrusted guest
    /// telemetry and writes the VM's sealed records file. Read-write on the
    /// VM state dir (records, status, the signer socket) and on the directory
    /// holding the per-port telemetry socket when that lives elsewhere;
    /// read-only on the keys dir for the host anchor. The syscall set is the
    /// shared confined-role table.
    pub fn telemetry_collector(
        state_dir: &Path,
        telemetry_sock_dir: Option<&Path>,
        keys_dir: PathBuf,
    ) -> Self {
        #[cfg(target_os = "linux")]
        let allowed_syscalls: Vec<&'static str> = crate::jailer::seccomp::CONFINED_ROLE_SYSCALLS
            .iter()
            .map(|(name, _)| *name)
            .collect();
        #[cfg(not(target_os = "linux"))]
        let allowed_syscalls: Vec<&'static str> = Vec::new();
        let mut read_write_paths = vec![state_dir.to_path_buf()];
        if let Some(dir) = telemetry_sock_dir
            && !dir.starts_with(state_dir)
        {
            read_write_paths.push(dir.to_path_buf());
        }
        Self {
            readable_paths: existing_paths(vec![keys_dir]),
            read_write_paths: existing_paths(read_write_paths),
            allowed_syscalls,
        }
    }

    /// Permit the endpoint to create its authenticated-session marker inside
    /// one already-existing per-VM directory. Keeping this as an explicit
    /// opt-in preserves the narrower default for endpoints that do not expose
    /// launch-readiness evidence.
    #[must_use]
    pub fn with_session_marker_parent(mut self, parent: Option<&Path>) -> Self {
        if let Some(parent) = parent {
            self.read_write_paths.push(parent.to_path_buf());
        }
        self
    }

    /// Permit the embedded telemetry collector's I/O: the VM state dir
    /// (records + status files, and the per-VM sockets bound inside it). The
    /// host anchor it reads lives in the keys dir, which `network_endpoint`
    /// already makes readable. Opt-in so an endpoint with no embedded
    /// collector keeps the narrower grant.
    #[must_use]
    pub fn with_telemetry_state(mut self, state_dir: Option<&Path>) -> Self {
        if let Some(state_dir) = state_dir {
            self.read_write_paths.push(state_dir.to_path_buf());
        }
        self
    }

    /// Permit the endpoint to connect to the operator's approval socket.
    /// The directory, not the socket: the broker binds the socket after the
    /// endpoint has confined itself, and Landlock cannot grant a path that
    /// does not exist yet. The directory is the VM's own socket directory,
    /// which the endpoint already binds its sockets in.
    #[must_use]
    pub fn with_approval_socket_parent(mut self, parent: Option<&Path>) -> Self {
        if let Some(parent) = parent
            && parent.exists()
            && !self.read_write_paths.iter().any(|p| p == parent)
        {
            self.read_write_paths.push(parent.to_path_buf());
        }
        self
    }
}

/// Drop paths that don't exist on this host. Landlock installs a rule by
/// `open`ing each path; a missing one returns `PathNotFound` and (per the
/// hard-exit contract) would abort the process. The store dirs are created by
/// the supervisor before spawn and the TLS/DNS files are present on any host
/// that can actually make an egress call, but `/etc/pki` / `/etc/resolv.conf`
/// vary by distro — filtering keeps the spec portable without weakening it
/// (a path that isn't there grants no access anyway).
fn existing_paths(paths: Vec<PathBuf>) -> Vec<PathBuf> {
    paths.into_iter().filter(|p| p.exists()).collect()
}

/// Apply Landlock filesystem confinement then seccomp-BPF syscall
/// filtering to the whole process.
///
/// **Call it while the process has exactly one thread.** Landlock binds only
/// the calling thread and the threads it creates afterwards, so a thread that
/// already exists — an async runtime's workers, a logging thread — would keep
/// unrestricted filesystem access. `confine_self` therefore counts the
/// process's threads first and refuses with `JailerError::NotSingleThreaded`,
/// before applying anything, if there is more than one. Create runtimes and
/// worker threads after it returns; they inherit both layers.
///
/// The seccomp filter is additionally installed with `SECCOMP_FILTER_FLAG_TSYNC`,
/// so it reaches every thread of the process even if one were created between
/// the count and the install.
///
/// **Partial-confinement contract:** on `Err`, the process may be in
/// any of three states: nothing applied (the Landlock step failed
/// before `restrict_self`), Landlock applied only (Landlock returned
/// `Ok` but the seccomp install failed), or both applied (the seccomp
/// install itself failed in a way that left the BPF program
/// half-loaded — vanishingly rare but possible because seccomp filter
/// installation is not transactional). The caller MUST hard-exit the
/// process on any error — there is no `disengage` API in either
/// kernel LSM, and a half-confined process running attacker-influenced
/// code is strictly worse than a confined one. The
/// `mvm-network-endpoint` honours this contract by returning the error
/// up to `main`, which logs and exits nonzero; the supervisor turns that exit
/// into a VM teardown.
///
/// The seccomp step also installs a `SIGSYS` handler that writes the refused
/// call's number to stderr before the process dies of it. Run
/// `self_test::ConfinementSelfTest` right after this returns to meet any
/// allowlist gap at startup rather than mid-session.
#[cfg(target_os = "linux")]
pub fn confine_self(spec: &ConfinementSpec) -> Result<(), JailerError> {
    crate::jailer::landlock::apply(spec)?;
    crate::jailer::seccomp::apply(spec)?;
    Ok(())
}

#[cfg(target_os = "linux")]
pub(crate) fn confine_self_with_owned_files(
    spec: &ConfinementSpec,
    state: &std::fs::File,
    store: Option<&std::fs::File>,
    records: bool,
) -> Result<(), JailerError> {
    crate::jailer::landlock::apply_with_owned_files(spec, Some(state), store)?;
    crate::jailer::seccomp::apply_with_owned_files(spec, store.is_some(), records)?;
    Ok(())
}

/// Where the kernel lists one directory per thread of the calling process.
#[cfg(any(target_os = "linux", test))]
const THREAD_LIST_DIR: &str = "/proc/self/task";

/// Refuse unless the calling process has exactly one thread.
///
/// Must run before Landlock is applied: the ruleset does not grant `/proc`, so
/// the count cannot be taken afterwards.
#[cfg(target_os = "linux")]
pub fn require_single_threaded() -> Result<(), JailerError> {
    let unavailable = |source| JailerError::ThreadCountUnavailable {
        path: PathBuf::from(THREAD_LIST_DIR),
        source,
    };
    let mut threads = 0usize;
    for entry in std::fs::read_dir(THREAD_LIST_DIR).map_err(unavailable)? {
        entry.map_err(unavailable)?;
        threads += 1;
    }
    single_threaded(threads)
}

#[cfg(any(target_os = "linux", test))]
fn single_threaded(threads: usize) -> Result<(), JailerError> {
    match threads {
        1 => Ok(()),
        // Zero entries means the listing is not this process's thread table
        // (an unmounted or foreign /proc); it proves nothing either way.
        0 => Err(JailerError::ThreadCountUnavailable {
            path: PathBuf::from(THREAD_LIST_DIR),
            source: std::io::Error::other("the thread list is empty"),
        }),
        threads => Err(JailerError::NotSingleThreaded { threads }),
    }
}

/// Non-Linux stub. Returns `JailerError::SeccompUnavailable` so a
/// caller that accidentally hits this path on macOS / Windows
/// fail-closes instead of running unconfined. The partial-confinement
/// contract on the Linux variant still applies to any production
/// caller — see that doc for the hard-exit requirement.
#[cfg(not(target_os = "linux"))]
pub fn confine_self(_spec: &ConfinementSpec) -> Result<(), JailerError> {
    Err(JailerError::SeccompUnavailable)
}

#[cfg(target_os = "linux")]
pub mod landlock;
#[cfg(target_os = "linux")]
mod refusal_report;
#[cfg(target_os = "linux")]
pub mod seccomp;
#[cfg(target_os = "linux")]
pub mod self_test;

#[cfg(test)]
mod tests {
    #[test]
    fn the_collector_only_spec_grants_its_state_dir_and_reads_only_keys() {
        let state = tempfile::tempdir().unwrap();
        let keys = tempfile::tempdir().unwrap();
        let sockets = tempfile::tempdir().unwrap();
        let spec = ConfinementSpec::telemetry_collector(
            state.path(),
            Some(sockets.path()),
            keys.path().to_path_buf(),
        );
        assert_eq!(spec.readable_paths, vec![keys.path().to_path_buf()]);
        assert_eq!(
            spec.read_write_paths,
            vec![state.path().to_path_buf(), sockets.path().to_path_buf()]
        );
        // No secret store, binding store, audit dir or TLS/DNS files.
        assert!(!spec.readable_paths.iter().any(|p| p.starts_with("/etc")));

        // A socket dir inside the state dir adds nothing.
        let nested = ConfinementSpec::telemetry_collector(
            state.path(),
            Some(&state.path().join("vsock")),
            keys.path().to_path_buf(),
        );
        assert_eq!(nested.read_write_paths, vec![state.path().to_path_buf()]);
    }

    use super::*;

    #[test]
    fn landlock_abi_query_requires_v2() {
        assert_eq!(
            classify_landlock_abi_query(Ok(2)),
            LandlockSupport::Available { abi: 2 }
        );
        assert_eq!(
            classify_landlock_abi_query(Ok(1)),
            LandlockSupport::TooOld { abi: 1 }
        );
    }

    #[test]
    fn confinement_requires_exactly_one_thread() {
        assert!(single_threaded(1).is_ok());
        assert!(matches!(
            single_threaded(3),
            Err(JailerError::NotSingleThreaded { threads: 3 })
        ));
        // An empty listing cannot vouch for single-threadedness.
        assert!(matches!(
            single_threaded(0),
            Err(JailerError::ThreadCountUnavailable { .. })
        ));
    }

    /// The test harness runs each test on its own thread, so the process is
    /// never single-threaded here, and the check must say so.
    #[cfg(target_os = "linux")]
    #[test]
    fn the_test_harness_is_refused_as_multi_threaded() {
        match require_single_threaded() {
            Err(JailerError::NotSingleThreaded { threads }) => assert!(threads >= 2),
            other => panic!("expected NotSingleThreaded, got {other:?}"),
        }
    }

    /// The runtime-thread self-test proves Landlock covers a thread by being
    /// refused the root directory, which holds only while no spec grants it.
    #[test]
    fn the_endpoint_spec_never_grants_the_root_directory() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            None,
        )
        .with_session_marker_parent(Some(&dir))
        .with_approval_socket_parent(Some(&dir));
        let root = Path::new("/");
        assert!(!spec.readable_paths.iter().any(|p| p == root));
        assert!(!spec.read_write_paths.iter().any(|p| p == root));
    }

    #[test]
    fn landlock_abi_query_distinguishes_missing_from_disabled() {
        assert_eq!(
            classify_landlock_abi_query(Err(Some(libc::ENOSYS))),
            LandlockSupport::Unavailable
        );
        assert_eq!(
            classify_landlock_abi_query(Err(Some(libc::EOPNOTSUPP))),
            LandlockSupport::Disabled
        );
        assert_eq!(
            classify_landlock_abi_query(Err(Some(libc::EPERM))),
            LandlockSupport::ProbeFailed {
                errno: Some(libc::EPERM)
            }
        );
    }

    /// Distinct dirs per role, so a read-only grant is distinguishable from a
    /// writable one.
    ///
    /// The sibling tests pass one directory for all four arguments, which
    /// cannot tell those apart: the signer key landing in `read_write_paths`
    /// would let a compromised endpoint replace the key it signs with, and
    /// every existing assertion would still pass.
    #[test]
    fn network_endpoint_spec_keeps_the_signer_key_read_only() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let secrets = tmp.path().join("secrets");
        let bindings = tmp.path().join("bindings");
        let audit = tmp.path().join("audit");
        let keys = tmp.path().join("keys");
        for d in [&secrets, &bindings, &audit, &keys] {
            std::fs::create_dir_all(d).expect("create spec dir");
        }

        // `None` resolver backend: this test is about the key grant, and a
        // resolver socket would add an unrelated write path.
        let spec = ConfinementSpec::network_endpoint(
            secrets.clone(),
            bindings.clone(),
            audit.clone(),
            keys.clone(),
            None,
        );

        assert!(
            spec.readable_paths.iter().any(|p| p == &keys),
            "keys dir must be readable: {:?}",
            spec.readable_paths
        );
        assert!(
            !spec.read_write_paths.iter().any(|p| p == &keys),
            "keys dir must NOT be writable: {:?}",
            spec.read_write_paths
        );
        assert!(
            spec.read_write_paths.iter().any(|p| p == &audit),
            "audit dir is the only write grant: {:?}",
            spec.read_write_paths
        );

        // The resolver re-reads the store key per `get`, post-confinement: it
        // must be readable, and it must never be writable (a compromised
        // endpoint replacing it would silently re-key the store).
        let store_key = tmp.path().join(".secret-store.key");
        std::fs::write(&store_key, b"k".repeat(32)).expect("store key fixture");
        let spec = ConfinementSpec::network_endpoint(
            secrets.clone(),
            bindings.clone(),
            audit.clone(),
            keys.clone(),
            None,
        );
        assert!(
            spec.readable_paths.iter().any(|p| p == &store_key),
            "store key must be readable post-confinement: {:?}",
            spec.readable_paths
        );
        assert!(
            !spec.read_write_paths.iter().any(|p| p == &store_key),
            "store key must NOT be writable: {:?}",
            spec.read_write_paths
        );
    }

    /// On Linux the syscall allowlist is populated from the canonical
    /// `seccomp::CONFINED_ROLE_SYSCALLS` table. We assert the contents here
    /// (positive + negative) rather than in seccomp.rs because the
    /// allowlist is the security-policy surface — a future contributor
    /// editing the table touches this test, which is the audit point.
    #[cfg(target_os = "linux")]
    #[test]
    fn confined_role_allowlist_includes_required_syscalls() {
        let spec = ConfinementSpec::network_endpoint(
            "/tmp/secrets".into(),
            "/tmp/bindings".into(),
            "/tmp/audit".into(),
            "/tmp/keys".into(),
            None,
        );
        assert!(spec.allowed_syscalls.contains(&"splice"));
        assert!(spec.allowed_syscalls.contains(&"fsync"));
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn confined_role_allowlist_rejects_dangerous_syscalls() {
        let spec = ConfinementSpec::network_endpoint(
            "/tmp/secrets".into(),
            "/tmp/bindings".into(),
            "/tmp/audit".into(),
            "/tmp/keys".into(),
            None,
        );
        assert!(!spec.allowed_syscalls.contains(&"execve"));
        assert!(!spec.allowed_syscalls.contains(&"setuid"));
        assert!(!spec.allowed_syscalls.contains(&"ptrace"));
        assert!(!spec.allowed_syscalls.contains(&"setgid"));
        assert!(!spec.allowed_syscalls.contains(&"capset"));
    }

    #[test]
    fn network_endpoint_spec_grants_read_on_stores() {
        // Use real existing dirs so they survive the `existing_paths` filter;
        // the binary's own crate manifest dir is guaranteed present.
        let store = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let bindings = store.clone();
        let spec = ConfinementSpec::network_endpoint(
            store.clone(),
            bindings.clone(),
            store.clone(),
            store.clone(),
            None,
        );
        assert!(
            spec.readable_paths.iter().any(|p| p == &store),
            "secret store dir must be readable"
        );
        assert!(
            spec.readable_paths.iter().any(|p| p == &bindings),
            "binding store dir must be readable"
        );
    }

    #[test]
    fn network_endpoint_spec_grants_audit_dir_write_and_keys_read() {
        // The audit recorder appends to the audit dir and reads the signer key,
        // so the audit dir is read-write and the keys dir readable.
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            None,
        );
        assert!(
            spec.read_write_paths.iter().any(|p| p == &dir),
            "audit dir must be read-write"
        );
    }

    #[test]
    fn network_endpoint_spec_drops_nonexistent_paths() {
        // A bogus store dir is filtered out — Landlock's `open` on a missing
        // path fails closed, which would abort an otherwise-healthy endpoint.
        let missing = PathBuf::from("/definitely/not/a/real/store/dir/xyzzy");
        let spec = ConfinementSpec::network_endpoint(
            missing.clone(),
            missing.clone(),
            missing.clone(),
            missing.clone(),
            None,
        );
        assert!(
            !spec.readable_paths.iter().any(|p| p == &missing),
            "nonexistent store dir must be filtered out"
        );
    }

    /// M3: `Local` (`None`) must leave the confinement byte-for-byte
    /// identical to before the resolver-UDS grant existed — no socket path
    /// anywhere in either grant set.
    #[test]
    fn network_endpoint_spec_local_backend_grants_no_socket() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            None,
        );
        assert_eq!(
            spec.read_write_paths,
            vec![dir],
            "Local must add nothing beyond the audit dir"
        );
    }

    /// The approval socket's directory is granted once, only when it exists,
    /// and never duplicates a directory already granted.
    #[test]
    fn network_endpoint_spec_grants_the_approval_socket_directory_once() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let socket_dir = dir.join("src");
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            None,
        )
        .with_approval_socket_parent(Some(&socket_dir))
        .with_approval_socket_parent(Some(&socket_dir));
        assert_eq!(spec.read_write_paths, vec![dir.clone(), socket_dir]);

        let missing = dir.join("no-such-socket-dir");
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            None,
        )
        .with_approval_socket_parent(Some(&missing))
        .with_approval_socket_parent(None);
        assert_eq!(spec.read_write_paths, vec![dir]);
    }

    #[test]
    fn network_endpoint_spec_grants_only_the_configured_session_marker_parent() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let marker_parent = dir.join("tests");
        let spec =
            ConfinementSpec::network_endpoint(dir.clone(), dir.clone(), dir.clone(), dir, None)
                .with_session_marker_parent(Some(&marker_parent));

        assert!(spec.read_write_paths.contains(&marker_parent));
        assert_eq!(spec.read_write_paths.len(), 2);
    }

    /// M3: `Remote { uds_path, .. }` (`Some(uds)`) additionally permits
    /// connect + read/write on that ONE socket — the exact extra grant this
    /// task adds, and nothing more.
    #[test]
    fn network_endpoint_spec_remote_backend_grants_resolver_uds() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let uds = dir.join("Cargo.toml");
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            Some(uds.as_path()),
        );
        assert!(
            spec.read_write_paths.contains(&uds),
            "resolver UDS path must be read-write granted under Remote"
        );
        assert_eq!(
            spec.read_write_paths.len(),
            2,
            "exactly audit dir + resolver uds, nothing broader"
        );
    }

    /// M3: unlike the best-effort TLS/DNS grants, the resolver UDS grant must
    /// NOT be silently dropped when the path doesn't exist (yet) — `Remote`
    /// mode is useless without it, so a missing socket should surface as
    /// Landlock's own `PathNotFound` (fail-closed) rather than a quietly
    /// empty grant that lets confinement "succeed" while leaving `Remote`
    /// unable to resolve anything.
    #[test]
    fn network_endpoint_spec_keeps_resolver_uds_even_if_missing() {
        let dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let missing = PathBuf::from("/definitely/not/a/real/resolver/socket/xyzzy.sock");
        let spec = ConfinementSpec::network_endpoint(
            dir.clone(),
            dir.clone(),
            dir.clone(),
            dir.clone(),
            Some(missing.as_path()),
        );
        assert!(
            spec.read_write_paths.contains(&missing),
            "resolver uds path must survive even when absent from disk"
        );
    }

    /// On Linux the endpoint allowlist is the shared table plus the tokio +
    /// TLS-forward additions. Assert the additions are present (the egress
    /// path needs them) and the dangerous names still absent.
    #[cfg(target_os = "linux")]
    #[test]
    fn network_endpoint_allowlist_covers_tls_and_runtime() {
        let store = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let spec = ConfinementSpec::network_endpoint(
            store.clone(),
            store.clone(),
            store.clone(),
            store.clone(),
            None,
        );
        // Thread creation for tokio workers / blocking pool.
        assert!(spec.allowed_syscalls.contains(&"clone"));
        // Socket-option negotiation.
        assert!(spec.allowed_syscalls.contains(&"getsockopt"));
        assert!(spec.allowed_syscalls.contains(&"setsockopt"));
        // Cert-store dir read for rustls-native-certs.
        assert!(spec.allowed_syscalls.contains(&"getdents64"));
        // Appending to the per-tenant audit log takes a file lock. Without
        // this the endpoint is killed by SIGSYS on the first flow it allows —
        // after the upstream connect succeeded, so the failure surfaces as a
        // guest whose proxy handshake never completes.
        assert!(spec.allowed_syscalls.contains(&"flock"));
        // Still no privilege-escalation syscalls.
        assert!(!spec.allowed_syscalls.contains(&"execve"));
        assert!(!spec.allowed_syscalls.contains(&"ptrace"));
        assert!(!spec.allowed_syscalls.contains(&"setuid"));
    }

    #[cfg(not(target_os = "linux"))]
    #[test]
    fn network_endpoint_allowlist_empty_off_linux() {
        let store = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let spec = ConfinementSpec::network_endpoint(
            store.clone(),
            store.clone(),
            store.clone(),
            store.clone(),
            None,
        );
        assert!(spec.allowed_syscalls.is_empty());
    }
}
