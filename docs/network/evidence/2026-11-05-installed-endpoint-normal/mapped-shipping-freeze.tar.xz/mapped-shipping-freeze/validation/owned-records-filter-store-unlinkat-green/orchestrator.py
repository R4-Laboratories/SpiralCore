from pathlib import Path
import subprocess,os,json,hashlib,shutil,sys,tomllib
root=Path('/var/tmp/spiralcore-canonical-lifetime-20261103'); source=root/'source';harness=root/'guard-process-harness'
record=root/'validation'/('owned-records-filter-'+sys.argv[1]);record.mkdir(parents=True,exist_ok=False)
shutil.copy2(__file__,record/'orchestrator.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(argv,name,env,timeout=None):
 (record/(name+'.argv.json')).write_text(json.dumps(argv,indent=2))
 with (record/(name+'.txt')).open('w') as out:p=subprocess.run(argv,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
 (record/(name+'.exit')).write_text(str(p.returncode)+'\n');return p.returncode
env=os.environ.copy();env['PATH']='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin';env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/var/tmp/spiralcore-installed-supervisor-20261103/component-target'
for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(k,None)
cargo='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin/cargo';common=['--offline','--config',str(root/'outcome-stop-harness/canonical-config.toml'),'--config',str(root/'audit-flow-intermediate.toml'),'--manifest-path',str(harness/'Cargo.toml')]
before=(harness/'Cargo.lock').read_bytes();(record/'Cargo.lock.before').write_bytes(before)
rc=run([cargo,'metadata',*common,'--format-version','1'],'metadata',env)
if rc:raise SystemExit(rc)
after=(harness/'Cargo.lock').read_bytes();(record/'Cargo.lock.selected').write_bytes(after)
key=lambda b:{(p['name'],p['version'],p.get('source')) for p in tomllib.loads(b.decode())['package']}
assert key(before)==key(after),'registry/package change forbidden'
run(['diff','-u',str(record/'Cargo.lock.before'),str(record/'Cargo.lock.selected')],'lock-diff',env)
m=json.loads(next(l for l in (record/'metadata.txt').read_text().splitlines() if l.startswith('{')))
for name in ['mvm-core','mvm-contract','mvm-hostd','mvm-vmm','spiralcore-transfer','spiralcore-mvm-flowmux']:
 p=[p for p in m['packages'] if p['name']==name];assert len(p)==1,(name,len(p));print(name,p[0]['version'],flush=True)
inputs=[p for b in [source,root/'dependency-handshake-1025'] for p in b.rglob('*') if p.is_file() and '.git' not in p.parts and 'target' not in p.parts]
inputs += [harness/'Cargo.toml',harness/'Cargo.lock',harness/'owned_seccomp_filter.rs',root/'outcome-stop-harness/canonical-config.toml',root/'audit-flow-intermediate.toml']
pins={str(p):sha(p) for p in inputs};(record/'source-before.json').write_text(json.dumps(pins,indent=2))
rc=run([cargo,'test',*common,'--locked','--release','--test','owned_seccomp_filter','--no-run','--message-format=json'],'build',env);print('build terminal',rc,flush=True)
assert all(sha(Path(p))==h for p,h in pins.items())
if rc:raise SystemExit(rc)
artifacts=[json.loads(l) for l in (record/'build.txt').read_text().splitlines() if l.startswith('{')]
exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']=='owned_seccomp_filter'];assert len(exes)==1
binary=record/'binary';shutil.copy2(exes[0],binary);old=sha(binary);(record/'binary-before.sha256').write_text(old+'\n')
rc=run([str(binary),'jailer::seccomp::owned_tests::','--nocapture','--test-threads=1'],'execute',env,timeout=40);print('execute terminal',rc,flush=True)
changed=[p for p,h in pins.items() if sha(Path(p))!=h];(record/'changed-after.json').write_text(json.dumps(changed));assert not changed
assert sha(binary)==old;(record/'all-readbacks.exit').write_text('0\n');raise SystemExit(rc)
