from pathlib import Path
import subprocess,os,json,hashlib,shutil,time,sys
root=Path('/var/tmp/spiralcore-canonical-lifetime-20261103')
source=root/'source'; harness=root/'guard-process-harness'
record=root/'validation'/('shipping-network-controller-'+sys.argv[1])
record.mkdir(parents=True,exist_ok=False)
shutil.copy2(source/'crates/mvm-hostd/tests/installed_flowmux_original_audit.rs',record/'fixture.rs')
shutil.copy2(Path(__file__),record/'orchestrator.py')
wrapper='wrapper' in sys.argv[2:]
(record/'entry-kind.txt').write_text('actual production library entry via test wrapper; normal canonical bin final replay pending\n' if wrapper else 'normal canonical bin\n')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(argv,name,env=None,timeout=None):
 (record/(name+'.argv.json')).write_text(json.dumps(argv,indent=2))
 with (record/(name+'.txt')).open('w') as out:
  p=subprocess.run(argv,cwd=source,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=timeout)
 (record/(name+'.exit')).write_text(str(p.returncode)+'\n'); return p.returncode
env=os.environ.copy(); env['PATH']='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin'; env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/var/tmp/spiralcore-installed-supervisor-20261103/component-target'
for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(k,None)
cargo='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin/cargo'
common=['--offline','--config',str(root/'outcome-stop-harness/canonical-config.toml'),'--config',str(root/'audit-flow-intermediate.toml'),'--manifest-path',str(harness/'Cargo.toml')]
shutil.copy2(harness/'Cargo.lock',record/'Cargo.lock.before')
rc=run([cargo,'metadata',*common,'--locked','--format-version','1'],'metadata-locked',env)
if rc:
 rc=run([cargo,'metadata',*common,'--format-version','1'],'metadata-repair',env)
 if rc:raise SystemExit(rc)
shutil.copy2(harness/'Cargo.lock',record/'Cargo.lock.selected')
before=record/'Cargo.lock.before';after=record/'Cargo.lock.selected'
run(['diff','-u',str(before),str(after)],'lock-diff')
import tomllib
old_pkgs={(p['name'],p['version'],p.get('source')) for p in tomllib.loads(before.read_text())['package']}
new_pkgs={(p['name'],p['version'],p.get('source')) for p in tomllib.loads(after.read_text())['package']}
assert old_pkgs==new_pkgs,(old_pkgs-new_pkgs,new_pkgs-old_pkgs)
m=json.loads(next(line for line in (record/('metadata-repair.txt' if (record/'metadata-repair.txt').exists() else 'metadata-locked.txt')).read_text().splitlines() if line.startswith('{')))
for name in ['mvm-core','mvm-contract','mvm-hostd','mvm-vmm','spiralcore-transfer','spiralcore-mvm-flowmux']:
 ps=[p for p in m['packages'] if p['name']==name]
 assert len(ps)==1,(name,len(ps)); print(name,ps[0]['version'],ps[0]['manifest_path'],flush=True)
old=json.loads(subprocess.check_output([cargo,'metadata',*common,'--format-version','1','--locked'],cwd=source,env=env))
# Exact source/input custody before compilation, including test includes.
inputs=[p for p in source.rglob('*') if p.is_file() and '.git' not in p.parts and 'target' not in p.parts]
inputs += [p for p in (root/'dependency-handshake-1025').rglob('*') if p.is_file()]
inputs += [harness/'Cargo.toml',harness/'Cargo.lock',root/'outcome-stop-harness/canonical-config.toml',root/'audit-flow-intermediate.toml']
selected={str(p):digest(p) for p in inputs}
(record/'source-before.json').write_text(json.dumps(selected,indent=2)); print('inputs',len(selected),flush=True)
prod_argv=[cargo,'build','--offline','--locked','--config',str(root/'audit-flow-intermediate.toml'),'--manifest-path',str(source/'Cargo.toml'),'--release','-p','mvm-hostd','--bin','mvm-network-endpoint','--message-format=json']
if wrapper:
 prod_argv=[cargo,'test',*common,'--locked','--release','--test','installed_network_entry','--no-run','--message-format=json']
rc=run(prod_argv,'canonical-build',env); print('canonical build terminal',rc,flush=True)
changed=[p for p,h in selected.items() if digest(Path(p))!=h];(record/'changed-after-canonical-build.json').write_text(json.dumps(changed));assert not changed
if rc:raise SystemExit(rc)
prod=[json.loads(line) for line in (record/'canonical-build.txt').read_text().splitlines() if line.startswith('{')]
prod_exes=[a['executable'] for a in prod if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']==('installed_network_entry' if wrapper else 'mvm-network-endpoint')];assert len(prod_exes)==1,prod_exes
canonical=record/('production-function-entry' if wrapper else 'canonical-network-endpoint');shutil.copy2(prod_exes[0],canonical)
argv=[cargo,'test',*common,'--locked','--release','--test','installed_flowmux_original_audit','--no-run','--message-format=json']
start=time.time();rc=run(argv,'build',env); print('build terminal',rc,'seconds',time.time()-start,flush=True)
changed=[p for p,h in selected.items() if digest(Path(p))!=h];(record/'changed-after-build.json').write_text(json.dumps(changed)); assert not changed
if rc:raise SystemExit(rc)
artifacts=[json.loads(line) for line in (record/'build.txt').read_text().splitlines() if line.startswith('{')]
exes=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('executable') and a['target']['name']=='installed_flowmux_original_audit']
assert len(exes)==1,exes
binary=record/'binary';shutil.copy2(exes[0],binary)
helpers=Path('/var/tmp/spiralcore-installed-factory-20261104/bin/signer-capability-green')
env['OWNED_AGENT_TEST_BIN']=str(helpers/'mvm-host-agent');env['OWNED_SIGNER_TEST_BIN']=str(helpers/'mvm-signer-helper');env['MVM_SUBSTITUTION_ENDPOINT_PATH']=str(canonical);env['MVM_INSTALLED_ENDPOINT_BIN']=str(canonical)
protected={str(p):digest(p) for p in [binary,canonical,helpers/'mvm-host-agent',helpers/'mvm-signer-helper']}
(record/'binaries-before.json').write_text(json.dumps(protected,indent=2))
rc=run([str(binary),'--shipping-controller'],'execute',env,timeout=40);print('execute terminal',rc,flush=True)
if rc==0 and 'protocol' in sys.argv[2:]:
 rc=run([str(binary),'--shipping-protocol-failure'],'protocol-failure',env,timeout=40);print('protocol-failure terminal',rc,flush=True)
if rc==0 and 'reentry' in sys.argv[2:]:
 rc=run([str(binary),'--shipping-validator-failure'],'validator-failure',env,timeout=40);print('validator-failure terminal',rc,flush=True)
if rc==0 and 'flows' in sys.argv[2:]:
 rc=run([str(binary),'--shipping-mapped-payload'],'mapped-payload',env,timeout=40);print('mapped-payload terminal',rc,flush=True)
 if rc==0:
  rc=run([str(binary),'--shipping-unmapped-target'],'unmapped-target',env,timeout=40);print('unmapped-target terminal',rc,flush=True)
changed=[p for p,h in selected.items() if digest(Path(p))!=h];(record/'changed-after-execute.json').write_text(json.dumps(changed));assert not changed
assert all(digest(Path(p))==h for p,h in protected.items())
(record/'all-readbacks.exit').write_text('0\n');raise SystemExit(rc)
