#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-baseline-footprint-fresh"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-vr.XXXXXX)
printf "%s\n" "$TMPDIR" > "$out-private-tmp.txt"
stat -c "%U %a %n" "$TMPDIR" > "$out-prerequisites.txt"
cd "$q/current-owner-port-work"
source scripts/dev-env.sh
ulimit -Sn 4096
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-verified-runtime-baseline-footprint-fresh -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
/usr/bin/time -v -o "$out-build-time.txt" cargo rustc --locked --offline -p xtask --bin xtask --message-format=json -- -C metadata=sc_baseline4031_footprint > "$out-build.jsonl" 2> "$out-build.stderr"
sha256sum "$CARGO_TARGET_DIR/debug/xtask" > "$out-executable-before.sha256"
/usr/bin/time -v -o "$out-time.txt" "$CARGO_TARGET_DIR/debug/xtask" check-rust-footprint > "$out-cargo.txt" 2>&1
