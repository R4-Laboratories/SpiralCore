#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/owned-api-policy-gates-via"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export UV_CACHE_DIR="$q/qualification-cache/uv" npm_config_cache="$q/qualification-cache/npm"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-pg.XXXXXX)
ulimit -Sn 4096
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
systemctl --user show sc-owned-api-policy-gates-via -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-before.sha256"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
for gate in check-abi-layout check-single-network-path check-closure-budget check-feature-closure-budget check-duplicate-majors; do
  cargo run --locked --offline -p xtask --bin xtask -- "$gate" > "$out-$gate.txt" 2>&1
done
cargo test --locked --offline -p xtask --bin xtask check_single_network_path -- --test-threads=1 > "$out-network-tests.txt" 2>&1
cargo test --locked --offline -p mvm-core --lib --features host-state registry_pack::application_bundle -- --test-threads=1 > "$out-core.txt" 2>&1
cargo test --locked --offline -p mvm-hostd --lib supervisor::endpoint::flowmux::open_flow::tests -- --test-threads=1 > "$out-route-tests.txt" 2>&1
cargo run --locked --offline -p xtask --bin xtask -- check-stubs > "$out-stubs.txt" 2>&1
sha256sum -c "$out-inputs-before.sha256" > "$out-inputs-after.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-after.sha256"
cmp "$out-inputs-before.sha256" "$out-inputs-after.sha256"
echo POLICY_GATES_SOURCE_VERIFIED
