#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/owned-api-structural-check"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-st.XXXXXX)
ulimit -Sn 4096
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
systemctl --user show sc-owned-api-structural-check -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-before.sha256"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
set +e
failed=0
for gate in check-file-size check-public-function-names check-rust-footprint; do
  cargo run --locked --offline -p xtask --bin xtask -- "$gate" > "$out-$gate.txt" 2>&1
  rc=$?
  printf '%s\n' "$rc" > "$out-$gate-exit.txt"
  if [ "$rc" -ne 0 ]; then failed=1; fi
done
cargo check --locked --offline --workspace --all-targets > "$out-check.txt" 2>&1
rc=$?
printf '%s\n' "$rc" > "$out-check-exit.txt"
if [ "$rc" -ne 0 ]; then failed=1; fi
sha256sum -c "$out-inputs-before.sha256" > "$out-inputs-after.txt" || failed=90
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-after.sha256"
cmp "$out-inputs-before.sha256" "$out-inputs-after.sha256" || failed=90
exit "$failed"
