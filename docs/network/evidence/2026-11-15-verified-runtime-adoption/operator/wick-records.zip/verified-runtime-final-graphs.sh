#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-final-graphs"
mkdir -m700 "$out"
for label in adapter live owner supervisor witness guest journal mvm; do
  for side in before after; do
    if [ "$side" = before ]; then
      input="$q/current-owner-sdk-core-$label-qualified-metadata.json"
      mvm=4031a54d6596cd5a12d572d12357287d97cc1042
      root="$q/current-owner-sdk-work"
    else
      input="$q/verified-runtime-sdk-$label-qualified-metadata.json"
      mvm=3d52ff7e9f4ac8a935e0fd5fa8f25d4a73b953cd
      root="$q/verified-runtime-sdk-work"
    fi
    core=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2
    if [ "$label" = mvm ]; then
      if [ "$side" = before ]; then
        root="$q/current-owner-port-work"
        input="$q/current-owner-full-core-metadata.json"
      else
        root="$q/verified-runtime-owner-work"
        input="$q/owned-api-full-metadata.json"
      fi
    fi
    jq -S --arg root "$root" --arg expected_mvm "git+https://github.com/Casey-allard/mvm?rev=$mvm#$mvm" --arg expected_core "git+https://github.com/R4-Laboratories/SpiralCore?rev=$core#$core" -f "$q/current-owner-final-graph.jq" "$input" > "$out/$label-$side.json"
  done
  cmp "$out/$label-before.json" "$out/$label-after.json"
  jq --arg label "$label" '{label:$label,normalized_equal:true,packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps[]]|length),feature_memberships:([.nodes[].features[]]|length)}' "$out/$label-after.json" > "$out/$label-summary.json"
done
jq -s '.' "$out/"*-summary.json > "$out/summary.json"
cat "$out/summary.json"
