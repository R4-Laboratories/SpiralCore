#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-port-check2"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
ulimit -Sn 4096
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-verified-runtime-port-check2 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
/usr/bin/time -v -o "$out-time.txt" cargo check --locked --offline -p mvm-runtime -p mvm-hostd -p mvm-client --all-targets > "$out-cargo.txt" 2>&1
