#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/owned-api-trust-grant"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-tg.XXXXXX)
ulimit -Sn 4096
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
systemctl --user show sc-owned-api-trust-grant -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-before.sha256"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
cargo run --locked --offline -p xtask --bin xtask -- check-require-grant-token-allowlist > "$out-grant.txt" 2>&1
cargo run --locked --offline -p xtask --bin xtask -- check-bundle-trust-sites > "$out-trust.txt" 2>&1
cargo test --locked --offline -p mvm-vmm --lib host::egress_bridge::tests -- --test-threads=1 > "$out-vmm.txt" 2>&1
cargo test --locked --offline -p mvm-runtime --lib installed_tests -- --test-threads=1 > "$out-runtime.txt" 2>&1
cargo test --locked --offline -p mvm-client --lib launch::bundle_runtime::tests -- --test-threads=1 > "$out-client.txt" 2>&1
cargo test --locked --offline -p mvm-core --lib registry_pack::application_bundle -- --test-threads=1 > "$out-core.txt" 2>&1
cargo test --locked --offline -p mvm-hostd --lib -- --test-threads=1 > "$out-hostd.txt" 2>&1
sha256sum -c "$out-inputs-before.sha256" > "$out-inputs-after.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-after.sha256"
cmp "$out-inputs-before.sha256" "$out-inputs-after.sha256"
echo TRUST_GRANT_SOURCE_VERIFIED
