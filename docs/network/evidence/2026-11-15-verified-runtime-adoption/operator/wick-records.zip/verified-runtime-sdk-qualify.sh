#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-sdk-qualified"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-sdk-state"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
umask 0022
ulimit -Sn 4096
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-verified-runtime-sdk-qualified -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-os.XXXXXX)
mkdir -m 700 -p "$MVM_HOME"
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
test "$(cat "$q/owned-api-full-exit.txt")" = 0
cd "$q/verified-runtime-owner-work"
sha256sum -c "$q/owned-api-final-inputs.sha256" > "$out-mvm-inputs-before.txt"
cd "$q/verified-runtime-sdk-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
  cmp "$out-before.sha256" "$out-after.sha256" || rc=90
  cd "$q/verified-runtime-owner-work"
  sha256sum -c "$q/owned-api-final-inputs.sha256" > "$out-mvm-inputs-after.txt" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  if [ "$rc" -eq 0 ]; then echo VERIFIED_RUNTIME_SDK_QUALIFICATION_VERIFIED; fi
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-live-check-time.txt" cargo check --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets > "$out-live-check.txt" 2>&1
/usr/bin/time -v -o "$out-live-clippy-time.txt" cargo clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings > "$out-live-clippy.txt" 2>&1
/usr/bin/time -v -o "$out-live-tests-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib -- --test-threads=1 > "$out-live-tests.txt" 2>&1
/usr/bin/time -v -o "$out-owner-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml -- --test-threads=1 > "$out-owner.txt" 2>&1
/usr/bin/time -v -o "$out-supervisor-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml -- --test-threads=1 > "$out-supervisor.txt" 2>&1
/usr/bin/time -v -o "$out-adapter-time.txt" cargo check --locked --offline --manifest-path crates/spiralcore-mvm-adapter/Cargo.toml --features live,conformance,hardware-sha256 --all-targets > "$out-adapter.txt" 2>&1
/usr/bin/time -v -o "$out-witness-time.txt" cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --all-targets > "$out-witness.txt" 2>&1
/usr/bin/time -v -o "$out-guest-time.txt" cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$out-guest.txt" 2>&1
/usr/bin/time -v -o "$out-journal-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed -- --test-threads=1 --nocapture > "$out-journal.txt" 2>&1
