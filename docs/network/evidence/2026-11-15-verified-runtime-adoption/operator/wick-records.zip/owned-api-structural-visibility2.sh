#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/owned-api-structural-visibility2"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-sv.XXXXXX)
ulimit -Sn 4096
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  sha256sum -c "$out-inputs-before.sha256" > "$out-inputs-after.txt" || rc=90
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-after.sha256"
  cmp "$out-inputs-before.sha256" "$out-inputs-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  exit "$rc"
}
trap finish EXIT
systemctl --user show sc-owned-api-structural-visibility2 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
/usr/bin/time -v -o "$out-check-time.txt" cargo check --locked --offline --workspace --all-targets > "$out-check.txt" 2>&1
echo STRUCTURAL_COMPILATION_SOURCE_VERIFIED
