#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo"
cd "$q/verified-runtime-sdk-work"
expected=$(jq -er '.mvm_source | strings | select(length > 0)' "$q/verified-runtime-platform-declaration.json")
cargo metadata --locked --offline --format-version 1 --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features linux-host --filter-platform x86_64-unknown-linux-gnu > "$q/verified-runtime-ci-linux-metadata.json"
jq -e --arg expected "$expected" '
  [.packages[] | select(.name | startswith("mvm-"))] as $m |
  ($m | length) > 0 and
  any($m[]; .name == "mvm-core") and
  any($m[]; .name == "mvm-contract") and
  all($m[]; .source == $expected)
' "$q/verified-runtime-ci-linux-metadata.json"
cargo metadata --locked --offline --no-default-features --features live --filter-platform x86_64-pc-windows-msvc --format-version 1 --manifest-path crates/spiralcore-mvm-adapter/Cargo.toml > "$q/verified-runtime-ci-windows-metadata.json"
jq -e --arg expected "$expected" '
  [.packages[] | select(.name == "mvm-core" or .name == "mvm-contract")] as $m |
  ($m | length) == 2 and all($m[]; .source == $expected)
' "$q/verified-runtime-ci-windows-metadata.json"
old=git+https://github.com/Casey-allard/mvm?rev=4031a54d6596cd5a12d572d12357287d97cc1042#4031a54d6596cd5a12d572d12357287d97cc1042
if jq -e --arg expected "$old" '[.packages[] | select(.name == "mvm-core" or .name == "mvm-contract")] as $m | ($m | length) == 2 and all($m[]; .source == $expected)' "$q/verified-runtime-ci-windows-metadata.json"; then
  echo 'stale source declaration unexpectedly accepted' >&2
  exit 1
fi
echo EXACT_SOURCE_GUARD_POSITIVE_AND_NEGATIVE_VERIFIED
