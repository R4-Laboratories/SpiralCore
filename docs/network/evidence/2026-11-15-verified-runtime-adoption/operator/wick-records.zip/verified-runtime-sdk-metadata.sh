#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-sdk-metadata"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd "$q/verified-runtime-sdk-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
trap 'printf "%s\n" "$?" > "'$out'-metadata-exit.txt"' EXIT
while IFS='|' read -r label manifest; do
  /usr/bin/time -v -o "$out-$label-metadata-time.txt" cargo metadata --locked --format-version=1 --manifest-path "$manifest" > "$out-$label-metadata.json" 2> "$out-$label-metadata.stderr"
done <<'MANIFESTS'
adapter|crates/spiralcore-mvm-adapter/Cargo.toml
live|crates/spiralcore-mvm-live/Cargo.toml
owner|crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml
supervisor|crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml
witness|tools/installed-flowmux-witness/Cargo.toml
guest|tools/installed-flowmux-witness/guest/Cargo.toml
journal|crates/spiralcore-mvm-journal-host/Cargo.toml
MANIFESTS
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
echo VERIFIED_RUNTIME_SDK_LOCKED_METADATA_VERIFIED
