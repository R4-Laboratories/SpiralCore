#!/usr/bin/env bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-workspace-checks"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 PYTHONDONTWRITEBYTECODE=1
mkdir -m700 -p "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-vr.XXXXXX)
printf "%s\n" "$TMPDIR" > "$out-private-tmp.txt"
stat -c "%U %a %n" "$TMPDIR" > "$out-prerequisites.txt"
cd "$q/verified-runtime-owner-work"
source scripts/dev-env.sh
ulimit -Sn 4096
trap 'rc=$?; printf "%s\n" "$rc" > "$out-exit.txt"; exit "$rc"' EXIT
rustc -Vv > "$out-toolchain.txt"
systemctl --user show sc-verified-runtime-workspace-checks -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
/usr/bin/time -v -o "$out-check-time.txt" cargo check --locked --offline --workspace --all-targets > "$out-check.txt" 2>&1
/usr/bin/time -v -o "$out-bdd-time.txt" cargo check --locked --offline -p mvm-conformance --all-targets --features bdd > "$out-bdd.txt" 2>&1
/usr/bin/time -v -o "$out-clippy-time.txt" cargo clippy --locked --offline --workspace -- -D warnings > "$out-clippy.txt" 2>&1
/usr/bin/time -v -o "$out-public-names-time.txt" cargo run --locked --offline -p xtask --bin xtask -- check-public-function-names > "$out-public-names.txt" 2>&1
/usr/bin/time -v -o "$out-footprint-time.txt" cargo run --locked --offline -p xtask --bin xtask -- check-rust-footprint > "$out-footprint.txt" 2>&1
