#!/usr/bin/env bash
set -euo pipefail
umask 0022
ulimit -Sn 4096
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/verified-runtime-paired-${1:-qualified}"
test "$(cat "$q/owned-api-full-exit.txt")" = 0
test "$(cat "$q/verified-runtime-sdk-qualified-exit.txt")" = 0
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/verified-runtime-paired-state"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-op.XXXXXX)
mkdir -m 700 -p "$MVM_HOME"
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
cd "$q/verified-runtime-owner-work"
sha256sum -c "$q/owned-api-final-inputs.sha256" > "$out-mvm-inputs-before.txt"
cd "$q/verified-runtime-sdk-work"
sha256sum -c "$q/verified-runtime-sdk-qualified-after.sha256" > "$out-sdk-inputs-before.txt"
cd "$q/verified-runtime-paired/after/paired-guest"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  cd "$q/verified-runtime-paired/after/paired-guest"
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-inputs-after.sha256"
  cmp "$out-inputs-before.sha256" "$out-inputs-after.sha256" || rc=90
  cd "$q/verified-runtime-sdk-work"
  sha256sum -c "$q/verified-runtime-sdk-qualified-after.sha256" > "$out-sdk-inputs-after.txt" || rc=90
  cd "$q/verified-runtime-owner-work"
  sha256sum -c "$q/owned-api-final-inputs.sha256" > "$out-mvm-inputs-after.txt" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  if [ "$rc" -eq 0 ]; then echo VERIFIED_RUNTIME_PAIRED_QUALIFICATION_VERIFIED; fi
  exit "$rc"
}
trap finish EXIT
systemctl --user show sc-verified-runtime-paired -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec > "$out-limits.txt"
rustc -Vv > "$out-toolchain.txt"
executable=$(sed -n 's/^     Running tests\/registered_direct_tcp.rs (\(.*\))$/\1/p' "$q/owned-api-full-tests.txt")
[[ "$executable" == "$CARGO_TARGET_DIR"/debug/deps/registered_direct_tcp-* ]]
test -x "$executable"
sha256sum "$executable" "$CARGO_TARGET_DIR"/debug/mvm-host-agent "$CARGO_TARGET_DIR"/debug/mvm-signer-helper "$CARGO_TARGET_DIR"/debug/mvm-network-endpoint > "$out-executables-before.sha256"
/usr/bin/time -v -o "$out-direct-time.txt" "$executable" --exact registered_prepare::registered_direct_tcp_transfers_exact_bytes_and_refunds_a_failed_peer --test-threads=1 --nocapture > "$out-direct.txt" 2>&1
sha256sum -c "$out-executables-before.sha256" > "$out-executables-after.txt"
/usr/bin/time -v -o "$out-application-time.txt" cargo test --locked --offline --features object-reader-v1,large-object-fixture,sender-ordinal-v1 --all-targets > "$out-application.txt" 2>&1
cd "$q/verified-runtime-owner-work"
/usr/bin/time -v -o "$out-reader-time.txt" cargo test --locked --offline -p mvm-agentd --bin mvm-guest-agent mailbox_reader::object_guest_tests > "$out-reader.txt" 2>&1
