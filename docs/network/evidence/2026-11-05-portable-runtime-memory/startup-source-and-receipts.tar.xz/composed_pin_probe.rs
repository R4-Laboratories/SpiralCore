use anyhow::{Result, ensure};
use mvm_core::plan::{
    PlanArtifact,
    bundle::{ArtifactRole, FsTrustStore, KeyId, PlanBundleError, verify_plan_bundle_bytes},
};
use std::{fs, path::PathBuf};

fn main() -> Result<()> {
    let root = PathBuf::from(std::env::args_os().nth(1).expect("isolated fixture root"));
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    let actual: serde_json::Value =
        serde_json::from_slice(&fs::read(root.join("run-selected-members/execute.txt"))?)?;
    let pin: PlanArtifact = serde_json::from_value(actual["signed_plan_pin"].clone())?;
    let archive = fs::read(
        root.join("mvm/bundles")
            .join(format!("{}.mvmpkg", pin.bundle_sha256)),
    )?;
    let trust = FsTrustStore::default_path()?;
    let original = verify_plan_bundle_bytes(&pin, &archive, &trust)?;
    ensure!(original.key_id == pin.key_id);
    let mut selected_capacity_slack = 0;
    for role in [
        ArtifactRole::Rootfs,
        ArtifactRole::Kernel,
        ArtifactRole::VerityHashSidecar,
    ] {
        let declaration = original
            .manifest
            .find_by_role(&role)
            .expect("actual signed role");
        let verified = original
            .artifacts
            .get(&declaration.path)
            .expect("actual verified bytes");
        selected_capacity_slack += verified.capacity() - verified.len();
        println!(
            "{role:?}: length={} capacity={}",
            verified.len(),
            verified.capacity()
        );
    }
    println!("selected_capacity_slack={selected_capacity_slack}");
    drop(original);

    let mut changed_hash = pin.clone();
    changed_hash.bundle_sha256 = "f".repeat(64);
    ensure!(changed_hash.bundle_sha256 != pin.bundle_sha256);
    ensure!(matches!(
        verify_plan_bundle_bytes(&changed_hash, &archive, &trust),
        Err(PlanBundleError::BundleSha256Mismatch { .. }),
    ));

    let mut changed_key = pin.clone();
    changed_key.key_id = KeyId("f".repeat(32));
    ensure!(changed_key.key_id != pin.key_id);
    ensure!(matches!(
        verify_plan_bundle_bytes(&changed_key, &archive, &trust),
        Err(PlanBundleError::KeyIdMismatch { .. }),
    ));

    let mut signature = pin.signature_bytes().expect("original signature shape");
    signature[0] ^= 1;
    let changed_signature = PlanArtifact::new(pin.bundle_sha256, &signature, pin.key_id);
    ensure!(matches!(
        verify_plan_bundle_bytes(&changed_signature, &archive, &trust),
        Err(PlanBundleError::SignatureMismatch),
    ));
    println!(
        "original borrowed bytes verified; archive hash, key pin, and signature pin mutations refused"
    );
    Ok(())
}
