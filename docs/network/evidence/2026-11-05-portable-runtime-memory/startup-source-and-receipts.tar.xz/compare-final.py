from pathlib import Path
import json,re,sys
receipts=Path(sys.argv[1])
measurements={}
for phase in ('baseline','successor','composed','compact-chunk'):
    data=[]
    if not (receipts/phase).is_dir():
        continue
    for attempt in range(1,4):
        sample=receipts/phase/f'measure-{attempt}.txt'
        assert sample.with_suffix('.exit').read_text().strip()=='0'
        text=sample.read_text()
        row=json.loads(next(line for line in text.splitlines() if line.startswith('{')))
        row['peak_increment_bytes']=row['rust_requested_peak']-row['rust_requested_before']
        row['held_increment_bytes']=row['rust_requested_held']-row['rust_requested_before']
        row['drop_delta_bytes']=row['rust_requested_after_drop']-row['rust_requested_before']
        row['process_max_rss_kib']=int(re.search(r'^max_rss_kib=(\d+)',text,re.M).group(1))
        assert row['drop_delta_bytes']==0
        data.append(row)
    assert len({x['peak_increment_bytes'] for x in data})==1
    assert len({x['held_increment_bytes'] for x in data})==1
    measurements[phase]={'measurements':data,'peak_increment_bytes':data[0]['peak_increment_bytes'],
        'held_increment_bytes':data[0]['held_increment_bytes'],
        'process_max_rss_kib_range':[min(x['process_max_rss_kib'] for x in data),max(x['process_max_rss_kib'] for x in data)]}
print(json.dumps(measurements,indent=2))
