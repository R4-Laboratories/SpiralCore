from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile
r=Path('/var/tmp/spiralcore-canonical-lifetime-20261103');s=r/'source'
a=Path('/var/tmp/spiralcore-native-assets-20261105');b=a/'portable-memory'
out=b/'compact-chunk';out.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((b/'composed/source-before.json').read_text())
assert json.loads((b/'composed-owner/terminal.json').read_text())['exit']==0
assert all(digest(Path(p))==h for p,h in old.items())
assets=json.loads((b/'composed/assets.json').read_text())
assert all(digest(Path(p))==h for p,h in assets.items())
for relative,before,after in (
 ('crates/mvm-core/src/plan/bundle.rs','core.composed.rs','core.compacted.rs'),
 ('crates/mvm-runtime/src/legacy_portable_runtime.rs','runtime.after.rs','runtime.chunked.rs'),
 ('crates/mvm-runtime/src/legacy_portable_runtime/memory_probe/memory_probe.rs','memory_probe.rs','memory_probe.with-controls.rs'),
):
 selected=s/relative
 assert digest(selected)==digest(b/before)
 shutil.copy2(b/after,selected)
 old[str(selected)]=digest(selected)
(out/'source-before.json').write_text(json.dumps(old,indent=2))
(out/'assets.json').write_text(json.dumps(assets,indent=2))
env=os.environ.copy()
env.update(PATH='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/var/tmp/spiralcore-installed-supervisor-20261103/component-target')
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'):env.pop(k,None)
cargo=env['PATH'].split(':')[0]+'/cargo'
test='legacy_portable_runtime::verity_asset_tests::memory_probe::measure_one_original_verification'
def run(argv,name,env,timeout=None):
 (out/(name+'.argv.json')).write_text(json.dumps(argv,indent=2))
 with (out/(name+'.txt')).open('w') as f:
  rc=subprocess.run(argv,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,umask=0o077).returncode
 (out/(name+'.exit')).write_text(str(rc)+'\n')
 print(name,rc,flush=True)
 return rc
args=[cargo,'test','--offline','--locked','--config',str(r/'audit-flow-intermediate.toml'),'--manifest-path',str(s/'Cargo.toml'),'--release','-p','mvm-runtime','--lib','legacy_portable_runtime','--no-run','--message-format=json']
rc=run(args,'build',env)
if rc==0:
 messages=[json.loads(line) for line in (out/'build.txt').read_text().splitlines() if line.startswith('{')]
 exes=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='mvm_runtime' and m['profile']['test']]
 assert len(exes)==1
 exe=out/'protected-runtime-memory';shutil.copy2(exes[0],exe)
 pin=digest(exe);(out/'protected-runtime-memory.sha256').write_text(pin+'\n')
 test_env=env|{'MVM_HOME':str(a/'mvm'),'HOME':str(a/'home'),'TMPDIR':str(a/'tmp'),'SPIRALCORE_NATIVE_ASSET_ROOT':str(a)}
 for k in ['MVM_UPDATE_DOWNLOAD_URL','MVM_ALLOW_UNSIGNED_RUNTIME','MVM_ALLOW_UNSIGNED_IMAGE_SET']:test_env.pop(k,None)
 for i in range(1,4):
  result=run(['/usr/bin/time','-f','max_rss_kib=%M user_s=%U system_s=%S process_elapsed_s=%e',str(exe),test,'--ignored','--exact','--nocapture'],f'measure-{i}',test_env,120)
  rc=rc or result
 exact='legacy_portable_runtime::verity_asset_tests::signed_workload_verity_refuses_mutations_and_snapshots_original'
 result=run([str(exe),exact,'--ignored','--exact','--nocapture'],'signed-verity',test_env,120)
 rc=rc or result
 overlay='legacy_portable_runtime::verity_asset_tests::memory_probe::selected_overlay_requires_exact_bytes_and_eof'
 result=run([str(exe),overlay,'--ignored','--exact','--nocapture'],'selected-overlay',test_env,120)
 rc=rc or result
 with tempfile.TemporaryDirectory(prefix='.spiralcore-memory-regression-',dir='/home/callard') as temporary:
  result=run([str(exe),'legacy_portable_runtime::tests::','--test-threads=1'],'existing-runtime',test_env|{'TMPDIR':temporary},120)
  rc=rc or result
 assert digest(exe)==pin
changed=[p for p,h in (old|assets).items() if digest(Path(p))!=h]
(out/'changed-after.json').write_text(json.dumps(changed))
assert not changed
raise SystemExit(rc)
