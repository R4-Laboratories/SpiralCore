# Compact verified buffers and compare selected bytes in chunks

All values are observed on the same signed asset, after subtracting the allocator's pre-verification live count. Each row represents three independent processes with one verification each.

| Source | Rust requested peak (bytes) | Held (bytes) | Process max RSS (KiB) |
|---|---:|---:|---:|
| Runtime verity baseline | 210,939,232 | 104,743,792 | 218,164–218,724 |
| Borrowed archive and owned role moves | 164,598,624 | 104,743,792 | 172,196–173,740 |
| Previous changes plus tar-entry ownership | 168,562,390 | 124,556,340 | 178,636–180,124 |
| Previous changes plus entry compaction and selected-file chunks | 124,739,244 | 104,743,792 | 146,328–146,968 |

The last phase's conservative requested realloc overlap is 134,983,895 bytes above the phase baseline. The allocator returned to the exact baseline after each verification result was dropped. The selected kernel is 19,995,452 bytes, exactly the last phase's peak minus held value. The current verifier still reads that entire selected file while it owns the verified output. The separate exact pin probe observed zero excess capacity for the three retained signed role vectors on Wick's allocator and refused all three pin mutations.

The last protected executable passed the signed verity regression, four existing portable tests, and the new selected overlay exact copy, equal-length corruption, short file and trailing-byte controls. Each path uses the same prior selection logic. The selected file is opened once and compared using fixed 64 KiB chunks against the authenticated original, with EOF checked at the end. The compacted Core entry buffers retain their verified bytes. The extra conservative realloc overlap is an observed requested-byte model, not an allocator/native RSS bound.

Helper and endpoint allowances are separately 84 MiB and 41 MiB in the current proposal. Adding those allowances to the conservative Runtime requested overlap leaves 2,379,561 bytes under 256 MiB, before token and slot charges. The observed standalone process RSS is larger than the provisional 130 MiB Runtime sizing target. This experiment establishes neither simultaneous service RSS nor an accepted startup budget, and no guest was booted.
