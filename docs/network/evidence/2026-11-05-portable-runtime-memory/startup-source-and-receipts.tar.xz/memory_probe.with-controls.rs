//! Measurement-only unit fixture. The measured process performs one verify.

mod accounting;
mod allocator;

use super::*;
use allocator::{COUNTERS, Tracked};
use mvm_core::plan::PlanArtifact;
use std::{hint::black_box, time::Instant};

#[global_allocator]
static MEASURED: Tracked = Tracked;

#[derive(serde::Deserialize)]
struct Artifact {
    path: String,
    sha256: Sha256Hex,
}

#[derive(serde::Deserialize)]
struct Selection {
    registry_root: PathBuf,
    publisher_image_set: Sha256Hex,
    selected: [Artifact; 6],
    signed_plan_pin: PlanArtifact,
}

fn read_selection(root: &Path) -> Result<VmStartConfig> {
    let selection: Selection =
        serde_json::from_slice(&fs::read(root.join("run-selected-members/execute.txt"))?)?;
    let [rootfs, kernel, initrd, overlay, overlay_verity, verity] = selection.selected;
    let overlay_dir = Path::new(&overlay.path)
        .parent()
        .context("overlay parent missing")?;
    let manifest: serde_json::Value =
        serde_json::from_slice(&fs::read(selection.registry_root.join("manifest.json"))?)?;
    let roothash = manifest["verity"]["roothash"]
        .as_str()
        .context("fixture manifest has no workload verity")?
        .to_owned();
    let archive = selection.registry_root.with_extension("mvmpkg");
    let manifest_sha256 = selection.publisher_image_set;
    Ok(VmStartConfig {
        name: "portable-memory-fixture".into(),
        rootfs_path: rootfs.path,
        kernel_path: Some(kernel.path),
        cpus: 1,
        memory_mib: 1024,
        verity_path: Some(verity.path),
        roothash: Some(roothash),
        initrd_path: Some(initrd.path),
        runtime_overlay_roothash: Some(
            fs::read_to_string(overlay_dir.join("overlay.roothash"))?
                .trim_end()
                .into(),
        ),
        runtime_overlay_version: Some(
            fs::read_to_string(overlay_dir.join("VERSION"))?
                .trim_end()
                .into(),
        ),
        runtime_overlay_path: Some(overlay.path),
        runtime_overlay_verity_path: Some(overlay_verity.path),
        legacy_portable_runtime: Some(LegacyPortableRuntimeProof {
            archive,
            pin: selection.signed_plan_pin,
            manifest_sha256: manifest_sha256.as_str().into(),
            arch: GuestArch::host(),
        }),
        bundle_boot_assets: Some(BundleBootAssetsPin {
            manifest_sha256,
            arch: GuestArch::host(),
            initrd_sha256: initrd.sha256,
        }),
        ..Default::default()
    })
}

#[test]
#[ignore = "requires the private verified Firecracker asset fixture"]
fn measure_one_original_verification() -> Result<()> {
    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT").context("isolated fixture required")?,
    );
    ensure!(root.is_absolute() && root.canonicalize()? == root);
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    let config = read_selection(&root)?;
    let started = Instant::now();
    let before = COUNTERS.begin_phase();
    let verified = verify_runtime_for_launch(black_box(&config), MIN_GUEST_RPC_PROTOCOL_VERSION)?;
    let held = COUNTERS.snapshot();
    let elapsed = started.elapsed().as_nanos();
    ensure!(
        matches!(
            &verified,
            Some(crate::runtime_evidence::VerifiedLaunchRuntime::LegacyPortable(_))
        ),
        "original portable verification was not selected"
    );
    black_box(&verified);
    drop(verified);
    let dropped = COUNTERS.snapshot();
    ensure!(
        !before.fault && !held.fault && !dropped.fault,
        "allocator tracking fault"
    );
    println!(
        "{}",
        serde_json::json!({
            "rust_requested_before": before.live,
            "rust_requested_peak": held.peak,
            "rust_requested_overlap_peak": held.realloc_overlap_peak,
            "rust_requested_held": held.live,
            "rust_requested_after_drop": dropped.live,
            "verify_elapsed_ns": elapsed,
        })
    );
    Ok(())
}

#[test]
#[ignore = "requires the private verified Firecracker asset fixture"]
fn selected_overlay_requires_exact_bytes_and_eof() -> Result<()> {
    use std::io::{Read as _, Seek as _, Write as _};

    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT").context("isolated fixture required")?,
    );
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    let mut config = read_selection(&root)?;
    let original = config
        .runtime_overlay_path
        .as_deref()
        .context("original overlay missing")?;
    let scratch = tempfile::tempdir_in(root.join("tmp"))?;
    let selected = scratch.path().join("selected.ext4");
    let size = fs::copy(original, &selected)?;
    config.runtime_overlay_path = Some(selected.display().to_string());
    ensure!(verify_runtime_for_launch(&config, MIN_GUEST_RPC_PROTOCOL_VERSION)?.is_some());
    let mut file = fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(&selected)?;
    let mut first = [0; 1];
    file.read_exact(&mut first)?;
    file.rewind()?;
    file.write_all(&[first[0] ^ 1])?;
    let refuse = |case| -> Result<()> {
        let error = verify_runtime_for_launch(&config, MIN_GUEST_RPC_PROTOCOL_VERSION)
            .expect_err("mutated selected overlay was accepted");
        ensure!(
            error.to_string().contains("selected portable bytes differ"),
            "{case}: unexpected refusal: {error:#}"
        );
        println!("{case}: refused");
        Ok(())
    };
    refuse("same-length different selected overlay")?;
    file.rewind()?;
    file.write_all(&first)?;
    file.set_len(size + 1)?;
    refuse("trailing selected overlay byte")?;
    file.set_len(size - 1)?;
    refuse("truncated selected overlay")?;
    Ok(())
}
