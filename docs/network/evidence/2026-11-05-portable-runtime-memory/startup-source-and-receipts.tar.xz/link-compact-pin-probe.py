from pathlib import Path
import hashlib,json,os,subprocess
r=Path('/var/tmp/spiralcore-native-assets-20261105')
run=r/'portable-memory'
t=Path('/var/tmp/spiralcore-installed-supervisor-20261103/component-target/release')
fp=t/'.fingerprint'
logs=run/'compact-pin-controls';logs.mkdir()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((run/'compact-chunk-owner/terminal.json').read_text())['exit']==0
messages=[json.loads(line) for line in (run/'compact-chunk/build.txt').read_text().splitlines() if line.startswith('{')]
artifacts=[m for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='mvm_core' and any(f.endswith('.rlib') for f in m['filenames'])]
assert len(artifacts)==1,artifacts
core=Path(next(f for f in artifacts[0]['filenames'] if f.endswith('.rlib')))
core_fp=fp/f'mvm-core-{core.stem.rsplit("-",1)[1]}'/'lib-mvm_core.json'
deps=json.loads(core_fp.read_text())['deps']
external={'mvm_core':core}
for _,crate,_,fingerprint in deps:
 if crate not in ('anyhow','serde_json'):continue
 key=fingerprint.to_bytes(8,'little').hex()
 variants=[p for p in fp.iterdir() if (p/f'lib-{crate}').is_file() and (p/f'lib-{crate}').read_text().strip()==key]
 assert len(variants)==1,(crate,key,variants)
 external[crate]=t/f'deps/lib{crate}-{variants[0].name.rsplit("-",1)[1]}.rlib'
assert set(external)=={'mvm_core','serde_json','anyhow'}
pins={str(p):digest(p) for p in [run/'composed_pin_probe.rs',core_fp,*external.values()]}
pins.update(json.loads((run/'compact-chunk/assets.json').read_text()))
assert all(digest(Path(p))==h for p,h in pins.items())
(logs/'inputs.json').write_text(json.dumps(pins,indent=2))
(logs/'core-artifact.json').write_text(json.dumps(artifacts[0],indent=2))
rustc='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin/rustc'
binary=logs/'protected-borrowed-pin-controls'
argv=[rustc,'--edition=2024','-C','opt-level=1','-C','debuginfo=0','-L',f'dependency={t}/deps','-o',str(binary),str(run/'composed_pin_probe.rs')]
for c,p in external.items(): argv+=['--extern',f'{c}={p}']
def invoke(args,name,env=None):
 (logs/f'{name}.argv.json').write_text(json.dumps(args,indent=2))
 with (logs/f'{name}.txt').open('w') as out:
  status=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,env=env,timeout=100).returncode
 (logs/f'{name}.exit').write_text(f'{status}\n')
 print((logs/f'{name}.txt').read_text(),end='')
 return status
rc=invoke(argv,'compile')
if rc==0:
 pin=digest(binary);(logs/'binary.sha256').write_text(pin+'\n')
 env=os.environ|{'MVM_HOME':str(r/'mvm'),'HOME':str(r/'home'),'TMPDIR':str(r/'tmp')}
 rc=invoke([str(binary),str(r)],'execute',env)
 assert digest(binary)==pin
assert all(digest(Path(p))==h for p,h in pins.items())
(logs/'readbacks.exit').write_text('0\n')
raise SystemExit(rc)
