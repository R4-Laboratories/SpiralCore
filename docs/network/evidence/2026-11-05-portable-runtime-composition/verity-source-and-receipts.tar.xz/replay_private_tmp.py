from pathlib import Path
import hashlib,json,os,stat,subprocess,tempfile
assets=Path('/var/tmp/spiralcore-native-assets-20261105')
out=assets/'verity-runtime-successor'
exe=out/'protected-runtime-tests'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((out/'source-before.json').read_text())|json.loads((out/'asset-pins.json').read_text())
pin=(out/'protected-runtime-tests.sha256').read_text().strip()
assert digest(exe)==pin
assert all(digest(Path(path))==expected for path,expected in manifest.items())
assert (out/'execute-existing.exit').read_text().strip()=='101'
argv=[str(exe),'legacy_portable_runtime::tests::','--test-threads=1']
with tempfile.TemporaryDirectory(prefix='.spiralcore-verity-runtime-',dir='/home/callard') as temporary:
 tmp=Path(temporary)
 assert tmp.stat().st_uid==os.geteuid() and stat.S_IMODE(tmp.stat().st_mode)==0o700
 ancestors=[{'path':str(p),'mode':oct(stat.S_IMODE(p.stat().st_mode)),'uid':p.stat().st_uid} for p in (tmp,*tmp.parents)]
 env=os.environ|{'MVM_HOME':str(assets/'mvm'),'HOME':str(assets/'home'),'TMPDIR':temporary,'SPIRALCORE_NATIVE_ASSET_ROOT':str(assets)}
 for k in ['MVM_UPDATE_DOWNLOAD_URL','MVM_ALLOW_UNSIGNED_RUNTIME','MVM_ALLOW_UNSIGNED_IMAGE_SET']:env.pop(k,None)
 (out/'replay-private-tmp.argv.json').write_text(json.dumps({'argv':argv,'tmp_ancestors':ancestors},indent=2))
 with (out/'replay-private-tmp.txt').open('x') as log:
  result=subprocess.run(argv,cwd='/var/tmp/spiralcore-canonical-lifetime-20261103/source',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 (out/'replay-private-tmp.exit').write_text(str(result.returncode)+'\n')
assert digest(exe)==pin
changed=[path for path,expected in manifest.items() if digest(Path(path))!=expected]
(out/'replay-private-tmp.changed.json').write_text(json.dumps(changed))
assert not changed
raise SystemExit(result.returncode)
