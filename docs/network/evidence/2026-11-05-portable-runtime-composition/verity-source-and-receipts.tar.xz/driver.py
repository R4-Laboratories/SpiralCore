from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path('/var/tmp/spiralcore-canonical-lifetime-20261103'); s=r/'source'
assets=Path('/var/tmp/spiralcore-native-assets-20261105')
out=assets/'verity-runtime-successor'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((assets/'portable-proof-red-corrected/source-before.json').read_text())
assert (assets/'portable-proof-red-corrected-owner/terminal.json').is_file()
changed=[p for p,h in old.items() if digest(Path(p))!=h]
assert not changed,changed
module=s/'crates/mvm-runtime/src/legacy_portable_runtime.rs'
leaf=module.with_suffix('')/'verity_asset_tests.rs'
assert digest(module)==digest(out/'before.rs')=='c440291bab6f392e213be64d54bff8ad347bffe3ea7cacde529d783d12a7322f'
assert not leaf.exists()
assert digest(out/'after.rs')=='11a3a58cb074ae2356e6e3291e557f5b9157df28baa9ec2b96d9731e46e1481e'
assert digest(out/'verity_asset_tests.rs')=='c75ac4fea1d0401f5a7791947454cdea8339504d9be0afc4d0cbf95fca636b21'
leaf.parent.mkdir(exist_ok=True)
shutil.copy2(out/'after.rs',module)
shutil.copy2(out/'verity_asset_tests.rs',leaf)
for source in (module,leaf): old[str(source)]=digest(source)
(out/'source-before.json').write_text(json.dumps(old,indent=2))
asset_pins=json.loads((assets/'portable-proof-red-corrected/asset-pins.json').read_text())
archive=assets/'mvm/bundles/8aeec63f28360650493212b955c39e74e8ce390ea5520db7cd02e8fa32bc0351.mvmpkg'
asset_pins[str(archive)]='8aeec63f28360650493212b955c39e74e8ce390ea5520db7cd02e8fa32bc0351'
assert all(digest(Path(p))==h for p,h in asset_pins.items())
(out/'asset-pins.json').write_text(json.dumps(asset_pins,indent=2))
env=os.environ.copy()
env.update(PATH='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_TARGET_DIR='/var/tmp/spiralcore-installed-supervisor-20261103/component-target')
for k in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS'): env.pop(k,None)
cargo=env['PATH'].split(':')[0]+'/cargo'
test='legacy_portable_runtime::verity_asset_tests::signed_workload_verity_refuses_mutations_and_snapshots_original'
def run_logged(argv,name,env,timeout=None):
 (out/(name+'.argv.json')).write_text(json.dumps(argv,indent=2))
 with (out/(name+'.txt')).open('w') as f:
  p=subprocess.run(argv,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 (out/(name+'.exit')).write_text(str(p.returncode)+'\n')
 print(name,p.returncode,flush=True)
 return p.returncode
args=[cargo,'test','--offline','--locked','--config',str(r/'audit-flow-intermediate.toml'),'--manifest-path',str(s/'Cargo.toml'),'--release','-p','mvm-runtime','--lib','legacy_portable_runtime','--no-run','--message-format=json']
rc=run_logged(args,'build',env)
if rc==0:
 messages=[json.loads(line) for line in (out/'build.txt').read_text().splitlines() if line.startswith('{')]
 exes=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='mvm_runtime' and m['profile']['test']]
 assert len(exes)==1,exes
 exe=out/'protected-runtime-tests';shutil.copy2(exes[0],exe)
 pin=digest(exe);(out/'protected-runtime-tests.sha256').write_text(pin+'\n')
 test_env=env|{'MVM_HOME':str(assets/'mvm'),'HOME':str(assets/'home'),'TMPDIR':str(assets/'tmp'),'SPIRALCORE_NATIVE_ASSET_ROOT':str(assets)}
 for k in ['MVM_UPDATE_DOWNLOAD_URL','MVM_ALLOW_UNSIGNED_RUNTIME','MVM_ALLOW_UNSIGNED_IMAGE_SET']:test_env.pop(k,None)
 rc=run_logged([str(exe),test,'--ignored','--exact','--nocapture'], 'execute-actual', test_env,120)
 existing=run_logged([str(exe),'legacy_portable_runtime::tests::','--test-threads=1'], 'execute-existing', test_env,120)
 rc=rc or existing
 assert digest(exe)==pin
changed=[path for path,expected in (old|asset_pins).items() if digest(Path(path))!=expected]
(out/'changed-after.json').write_text(json.dumps(changed))
assert not changed
raise SystemExit(rc)
