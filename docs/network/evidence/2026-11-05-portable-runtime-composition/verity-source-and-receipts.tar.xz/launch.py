import json,os,pathlib,subprocess
r=pathlib.Path('/var/tmp/spiralcore-native-assets-20261105/verity-runtime-successor')
o=r/'owner';o.mkdir()
with (o/'driver.log').open('xb') as stream:
 p=subprocess.Popen(['bash','-c','python3 "$1"; rc=$?; printf \'{"exit":%d}\\n\' "$rc" > "$2/terminal.next"; mv "$2/terminal.next" "$2/terminal.json"; exit "$rc"','verity-successor',str(r/'driver.py'),str(o)],stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
record={'pid':p.pid,'pgid':os.getpgid(p.pid),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'path':str(o)}
(o/'owner.json').write_text(json.dumps(record))
print(json.dumps(record))
