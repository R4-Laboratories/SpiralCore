use crate::runtime_evidence::{MIN_GUEST_RPC_PROTOCOL_VERSION, verify_runtime_for_launch};
use anyhow::{Context, Result, ensure};
use mvm_core::{
    arch::GuestArch,
    packs::Sha256Hex,
    plan::{
        FsTrustStore,
        bundle::{ArtifactRole, BundleRegistry, verify_bundle_file},
    },
    vm_backend::{BundleBootAssetsPin, LegacyPortableRuntimeProof, VmStartConfig},
};
use std::{
    fs,
    path::{Path, PathBuf},
};

fn checked_config(root: &Path) -> Result<VmStartConfig> {
    let archive = root.join("installed-native-witness.mvmpkg");
    let trust = FsTrustStore::default_path()?;
    let verified = verify_bundle_file(&archive, &trust)?;
    let registry = BundleRegistry::default_path()?;
    let installed = registry
        .find(&verified.bundle_sha256)?
        .context("actual installed fixture missing")?;
    ensure!(installed.manifest == verified.manifest);
    let artifact_path = |role: ArtifactRole| -> Result<String> {
        let artifact = installed
            .manifest
            .find_by_role(&role)
            .context("actual artifact role missing")?;
        Ok(installed.root.join(&artifact.path).display().to_string())
    };
    let image_set = &verified
        .boot_assets
        .as_ref()
        .context("signed boot assets missing")?
        .image_set;
    let cache = PathBuf::from(mvm_core::config::mvm_cache_dir())
        .join("image-set")
        .join(image_set.manifest_sha256.as_str());
    let initrd = cache.join("0.22.0/x86_64/initramfs.cpio.gz");
    let overlay = cache.join("runtime-overlay/0.22.0/x86_64");
    let verity = verified
        .manifest
        .verity
        .as_ref()
        .context("signed workload verity missing")?;
    Ok(VmStartConfig {
        name: "native-verity-attachment-probe".into(),
        rootfs_path: artifact_path(ArtifactRole::Rootfs)?,
        kernel_path: Some(artifact_path(ArtifactRole::Kernel)?),
        verity_path: Some(artifact_path(ArtifactRole::VerityHashSidecar)?),
        roothash: Some(verity.roothash.clone()),
        cpus: 1,
        memory_mib: 1024,
        initrd_path: Some(initrd.display().to_string()),
        runtime_overlay_path: Some(overlay.join("overlay.ext4").display().to_string()),
        runtime_overlay_verity_path: Some(overlay.join("overlay.verity").display().to_string()),
        runtime_overlay_roothash: Some(
            fs::read_to_string(overlay.join("overlay.roothash"))?
                .trim_end()
                .into(),
        ),
        runtime_overlay_version: Some(
            fs::read_to_string(overlay.join("VERSION"))?
                .trim_end()
                .into(),
        ),
        bundle_boot_assets: Some(BundleBootAssetsPin {
            manifest_sha256: image_set.manifest_sha256.clone(),
            arch: GuestArch::host(),
            initrd_sha256: Sha256Hex::new(mvm_core::crypto::image_verify::sha256_file(&initrd)?)?,
        }),
        legacy_portable_runtime: Some(LegacyPortableRuntimeProof {
            archive: registry.archive_path(&verified.bundle_sha256),
            pin: verified.plan_artifact(),
            manifest_sha256: image_set.manifest_sha256.as_str().into(),
            arch: GuestArch::host(),
        }),
        ..Default::default()
    })
}

#[test]
#[ignore = "requires the private verified Firecracker asset fixture"]
fn signed_workload_verity_refuses_mutations_and_snapshots_original() -> Result<()> {
    use std::os::unix::fs::PermissionsExt as _;

    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT").context("isolated fixture required")?,
    );
    ensure!(root.is_absolute() && root.canonicalize()? == root);
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    ensure!(std::env::var_os("HOME").as_deref() == Some(root.join("home").as_os_str()));
    let original = checked_config(&root)?;
    let Some(crate::runtime_evidence::VerifiedLaunchRuntime::LegacyPortable(verified)) =
        verify_runtime_for_launch(&original, MIN_GUEST_RPC_PROTOCOL_VERSION)?
    else {
        anyhow::bail!("lost original portable Runtime verification");
    };
    println!("original signed Runtime selection verified");

    let scratch = tempfile::tempdir_in(root.join("tmp"))?;
    let original_tree_path = Path::new(original.verity_path.as_deref().context("missing tree")?);
    let mut changed_tree = fs::read(original_tree_path)?;
    changed_tree[0] ^= 1;
    let altered_tree = scratch.path().join("altered.verity");
    fs::write(&altered_tree, changed_tree)?;

    for (label, path, roothash, reason) in [
        (
            "replaced-workload-verity-path",
            original.kernel_path.clone(),
            original.roothash.clone(),
            "tree differs",
        ),
        (
            "same-size-altered-verity-tree",
            Some(altered_tree.display().to_string()),
            original.roothash.clone(),
            "tree differs",
        ),
        (
            "replaced-workload-roothash",
            original.verity_path.clone(),
            Some("f".repeat(64)),
            "binding differs",
        ),
        (
            "replaced-both",
            original.kernel_path.clone(),
            Some("f".repeat(64)),
            "binding differs",
        ),
        ("omitted-pair", None, None, "binding differs"),
    ] {
        ensure!(path != original.verity_path || roothash != original.roothash);
        let mut config = original.clone();
        config.verity_path = path;
        config.roothash = roothash;
        let error = verify_runtime_for_launch(&config, MIN_GUEST_RPC_PROTOCOL_VERSION)
            .expect_err("mutated workload verity selection reached launch");
        ensure!(
            error.to_string().contains(reason),
            "{label}: unexpected refusal: {error:#}"
        );
        println!("{label}: refused");
    }

    let bound = verified.snapshot_in(&original, scratch.path())?;
    let bound_tree = Path::new(bound.verity_path.as_deref().context("snapshot lost tree")?);
    let generation = bound_tree.parent().context("missing snapshot generation")?;
    ensure!(generation.parent() == Some(scratch.path()));
    ensure!(Path::new(&bound.rootfs_path).parent() == Some(generation));
    ensure!(
        bound_tree
            .file_name()
            .is_some_and(|name| name == "rootfs.verity")
    );
    ensure!(bound_tree != original_tree_path);
    ensure!(fs::metadata(bound_tree)?.permissions().mode() & 0o777 == 0o400);
    ensure!(fs::read(bound_tree)? == fs::read(original_tree_path)?);
    ensure!(bound.roothash == original.roothash);
    ensure!(verify_runtime_for_launch(&bound, MIN_GUEST_RPC_PROTOCOL_VERSION)?.is_some());
    println!("owned generation retained and reverified the original signed tree and root");
    Ok(())
}
