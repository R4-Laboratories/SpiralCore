#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/directory-work-tmp"
cd "$q/directory-work"
for package in spiralcore-directory-macos spiralcore-transfer spiralcore-mvm-flowmux spiralcore-mvm-live; do
  cargo metadata --locked --offline --manifest-path crates/$package/Cargo.toml --format-version 1 > "$q/directory-metadata-$package.json"
done
cargo test --offline --locked --manifest-path crates/spiralcore-directory-macos/Cargo.toml --all-targets > "$q/directory-helper-final.log" 2>&1
cargo clippy --offline --locked --manifest-path crates/spiralcore-directory-macos/Cargo.toml --all-targets -- -D warnings > "$q/directory-helper-clippy.log" 2>&1
cargo test --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned:: -- --show-output --test-threads=1 > "$q/directory-core-final.log" 2>&1
cargo test --release --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store --test owned_store_resources --test owned_store_allocation -- --show-output --test-threads=1 > "$q/directory-populated-final.log" 2>&1
cargo clippy --release --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets -- -D warnings > "$q/directory-core-clippy.log" 2>&1
cargo test --release --offline --locked --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets -- --show-output > "$q/directory-flowmux-final.log" 2>&1
