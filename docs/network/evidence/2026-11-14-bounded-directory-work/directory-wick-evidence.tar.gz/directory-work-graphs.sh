#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
mkdir -m700 "$q/directory-baseline"
tar -xf "$q/directory-baseline.tar" -C "$q/directory-baseline"
for target in x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu x86_64-apple-darwin aarch64-apple-darwin; do
  for revision in baseline work; do
    for kind in normal,build features; do
      cargo tree --offline --locked --manifest-path "$q/directory-$revision/crates/spiralcore-mvm-flowmux/Cargo.toml" --target "$target" -e "$kind" > "$q/directory-graph-$revision-$target-${kind/,/-}.txt"
    done
  done
done
