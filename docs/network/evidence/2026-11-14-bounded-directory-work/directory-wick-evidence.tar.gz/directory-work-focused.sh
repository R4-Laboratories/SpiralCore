#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/directory-work-tmp"
cd "$q/directory-work"
tar -xzf "$q/directory-work-source.tar.gz"
rustc -vV > "$q/directory-work-rustc.txt"
cargo metadata --offline --manifest-path crates/spiralcore-directory-macos/Cargo.toml --format-version 1 > "$q/directory-helper-metadata.json"
cargo test --offline --locked --manifest-path crates/spiralcore-directory-macos/Cargo.toml --all-targets > "$q/directory-helper-first.log" 2>&1
cargo metadata --offline --manifest-path crates/spiralcore-transfer/Cargo.toml --format-version 1 > "$q/directory-core-metadata.json"
/usr/bin/time -v cargo test --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned:: -- --show-output --test-threads=1 > "$q/directory-core-first.log" 2>&1
