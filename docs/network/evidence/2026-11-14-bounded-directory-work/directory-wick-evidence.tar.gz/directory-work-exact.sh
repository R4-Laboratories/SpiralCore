#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 TMPDIR="$q/directory-work-tmp"
cd "$q/directory-work"
sha256sum -c "$q/directory-work-source.sha256" > "$q/directory-exact-source-before.txt"
rustc -vV > "$q/directory-exact-rustc.txt"
sha256sum "$CARGO_TARGET_DIR"/debug/deps/spiralcore_directory_macos-* "$CARGO_TARGET_DIR"/release/deps/owned_store_allocation-5fd45f986111e48f > "$q/directory-exact-exe-before.txt"
/usr/bin/time -v cargo test --offline --locked --manifest-path crates/spiralcore-directory-macos/Cargo.toml --all-targets > "$q/directory-exact-helper.log" 2>&1
/usr/bin/time -v cargo test --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --lib endpoint::storage::owned:: -- --show-output --test-threads=1 > "$q/directory-exact-core.log" 2>&1
/usr/bin/time -v cargo test --release --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --test owned_store --test owned_store_resources --test owned_store_allocation -- --show-output --test-threads=1 > "$q/directory-exact-populated.log" 2>&1
/usr/bin/time -v cargo test --release --offline --locked --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --all-targets -- --show-output > "$q/directory-exact-flowmux.log" 2>&1
cargo clippy --release --offline --locked --manifest-path crates/spiralcore-transfer/Cargo.toml --all-targets -- -D warnings > "$q/directory-exact-core-clippy.log" 2>&1
cargo clippy --offline --locked --manifest-path crates/spiralcore-directory-macos/Cargo.toml --all-targets -- -D warnings > "$q/directory-exact-helper-clippy.log" 2>&1
sha256sum -c "$q/directory-work-source.sha256" > "$q/directory-exact-source-after.txt"
sha256sum "$CARGO_TARGET_DIR"/debug/deps/spiralcore_directory_macos-* "$CARGO_TARGET_DIR"/release/deps/owned_store_allocation-5fd45f986111e48f > "$q/directory-exact-exe-after.txt"
cmp "$q/directory-exact-exe-before.txt" "$q/directory-exact-exe-after.txt"
