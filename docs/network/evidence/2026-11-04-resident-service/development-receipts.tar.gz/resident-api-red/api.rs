use spiralcore_mvm_live::installed_parent::InstalledResident;
fn main() { let _ = InstalledResident::new; }
