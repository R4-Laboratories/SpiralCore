#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
mkdir -p "$q/privacy-graphs"
for label in live adapter journal owner supervisor witness guest live-linux mvm; do
  raw="$q/privacy-sdk-metadata1-$label.json"
  root="$q/credit-sdk-work"
  if [ "$label" = mvm ]; then raw="$q/privacy-mvm-full2-metadata.json"; root="$q/flowmux-credit-mvm-work"; fi
  jq -S --arg root "$root" --arg expected_mvm 'git+https://github.com/Casey-allard/mvm?rev=e95f1119dac66e45a81c4eead8f4e747a1286a86#e95f1119dac66e45a81c4eead8f4e747a1286a86' --arg expected_core 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' -f "$q/current-owner-final-graph.jq" "$raw" > "$q/privacy-graphs/$label-after.json"
done
python3 - <<'PY'
from pathlib import Path
import json
q=Path('/var/tmp/sc-direct-flowmux.iptmjZre');output=q/'privacy-graphs';summary=[]
for label in ['live','adapter','journal','owner','supervisor','witness','guest','mvm']:
 before=json.loads((q/'admitted-final-graphs'/f'{label}-after.json').read_text());after=json.loads((output/f'{label}-after.json').read_text());mapping={};versions=[]
 for key in before['packages']:
  name,version,source=json.loads(key)
  if (source=='REVIEWED_MVM_SOURCE' or (label=='mvm' and source.startswith('/'))) and version=='0.28.0-rc.6':
   new=json.dumps([name,'0.28.0-rc.7',source],separators=(',',':'));versions.append(name)
  else:new=key
  mapping[key]=new
 old={mapping[n['id']]:dict(n,id=mapping[n['id']],deps=[dict(d,pkg=mapping[d['pkg']]) for d in n['deps']]) for n in before['nodes']}
 new={n['id']:n for n in after['nodes']}
 delta={'label':label,'owned_prerelease_updates':versions,'added_packages':sorted(set(new)-set(old)),'removed_packages':sorted(set(old)-set(new)),'node_changes':[]}
 for key in sorted(set(old)&set(new)):
  a,b=old[key],new[key];adeps={json.dumps(d,sort_keys=True) for d in a['deps']};bdeps={json.dumps(d,sort_keys=True) for d in b['deps']}
  if a['features']!=b['features'] or adeps!=bdeps:
   delta['node_changes'].append({'node':key,'features_before':a['features'],'features_after':b['features'],'added_deps':[json.loads(x) for x in sorted(bdeps-adeps)],'removed_deps':[json.loads(x) for x in sorted(adeps-bdeps)]})
 delta['new_nodes']=[new[key] for key in delta['added_packages']]
 (output/f'{label}-delta.json').write_text(json.dumps(delta,indent=2)+'\n');summary.append(delta)
 print(json.dumps(delta))
(output/'deltas.json').write_text(json.dumps(summary,indent=2)+'\n')
PY
