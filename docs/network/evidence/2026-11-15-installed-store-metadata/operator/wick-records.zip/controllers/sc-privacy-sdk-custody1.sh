#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/privacy-sdk-custody1"
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$out-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
mkdir -m700 "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-ps.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
ulimit -Sn 4096
ulimit -S -s 8192
printf '%s\n' d8f328f9122b37edef228406e47d5d33e6c9ecca > "$out-spiralcore-source.txt"
printf '%s\n' e95f1119dac66e45a81c4eead8f4e747a1286a86 > "$out-mvm-source.txt"
systemctl --user show sc-privacy-sdk-custody1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p TasksMax -p LimitNOFILE -p LimitSTACK -p UMask > "$out-limits.txt"
test "$(cat "$q/privacy-mvm-full2-exit.txt")" = 0
cd "$q/flowmux-credit-mvm-work"
sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-before.txt"
cd "$q/credit-sdk-work"
sha256sum -c "$q/privacy-sdk-custody1-frozen-inputs.sha256" > "$out-sdk-inputs-before.txt"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-sdk-file-set-before.sha256"
cmp "$q/privacy-sdk-custody1-frozen-inputs.sha256" "$out-sdk-file-set-before.sha256"
finish() {
  original=$?
  trap - EXIT
  set +e
  sha256sum -c "$q/privacy-sdk-custody1-frozen-inputs.sha256" > "$out-sdk-inputs-after.txt"
  sdk_hash=$?
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-sdk-file-set-after.sha256"
  enumeration=$?
  cmp "$q/privacy-sdk-custody1-frozen-inputs.sha256" "$out-sdk-file-set-after.sha256"
  sdk_set=$?
  cd "$q/flowmux-credit-mvm-work"
  sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-after.txt"
  mvm_hash=$?
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-mvm-file-set-after.sha256"
  mvm_enumeration=$?
  cmp "$q/privacy-mvm-full2-frozen-inputs.sha256" "$out-mvm-file-set-after.sha256"
  mvm_set=$?
  final=$original
  if [ "$sdk_hash" -ne 0 ] || [ "$enumeration" -ne 0 ] || [ "$sdk_set" -ne 0 ] || [ "$mvm_hash" -ne 0 ] || [ "$mvm_enumeration" -ne 0 ] || [ "$mvm_set" -ne 0 ]; then final=90; fi
  printf '{"original_exit":%s,"sdk_hash_exit":%s,"sdk_enumeration_exit":%s,"sdk_file_set_exit":%s,"mvm_hash_exit":%s,"mvm_enumeration_exit":%s,"mvm_file_set_exit":%s,"final_exit":%s}\n' "$original" "$sdk_hash" "$enumeration" "$sdk_set" "$mvm_hash" "$mvm_enumeration" "$mvm_set" "$final" > "$out-outcome.json"
  printf '%s\n' "$final" > "$out-exit.txt"
  echo "PRIVACY_SDK_CUSTODY1_TERMINAL original=$original final=$final"
  exit "$final"
}
trap finish EXIT
rustc -Vv > "$out-toolchain.txt"
test "$(cat "$q/privacy-sdk3-exit.txt")" = 0
for label in owner supervisor; do
  manifest="crates/spiralcore-mvm-live/tests/installed-$label-harness/Cargo.toml"
  cargo metadata --locked --offline --format-version=1 --manifest-path "$manifest" > "$out-$label-metadata.json"
  /usr/bin/time -v -o "$out-$label-build-time.txt" cargo test --locked --offline --manifest-path "$manifest" --no-run --message-format=json > "$out-$label-build.jsonl" 2> "$out-$label-build-stderr.txt"
  python3 "$q/sc-privacy-sdk-harness-artifacts.py" "$out-$label-build.jsonl" "$out-$label-metadata.json" "$out-$label"
  /usr/bin/time -v -o "$out-$label-tests-time.txt" cargo test --locked --offline --manifest-path "$manifest" -- --test-threads=1 > "$out-$label-tests.txt" 2>&1
  sha256sum -c "$out-$label-executables-before.sha256" > "$out-$label-executables-after.txt"
  python3 "$q/sc-privacy-sdk-harness-runtime.py" "$out-$label-tests.txt" "$out-$label-executables-before.json" "$out-$label-runtime.json"
done
echo PRIVACY_SDK_HARNESS_CUSTODY_PASS
