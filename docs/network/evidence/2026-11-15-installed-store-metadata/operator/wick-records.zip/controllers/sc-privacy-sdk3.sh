#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/privacy-sdk3"
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$out-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
mkdir -m700 "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-ps.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
ulimit -Sn 4096
ulimit -S -s 8192
printf '%s\n' 180075a4f304d7f31449b55170940ae00fbb5a67 > "$out-spiralcore-source.txt"
printf '%s\n' e95f1119dac66e45a81c4eead8f4e747a1286a86 > "$out-mvm-source.txt"
systemctl --user show sc-privacy-sdk3 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p TasksMax -p LimitNOFILE -p LimitSTACK -p UMask > "$out-limits.txt"
test "$(cat "$q/privacy-mvm-full2-exit.txt")" = 0
cd "$q/flowmux-credit-mvm-work"
sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-before.txt"
cd "$q/credit-sdk-work"
sha256sum -c "$q/privacy-sdk3-frozen-inputs.sha256" > "$out-sdk-inputs-before.txt"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-sdk-file-set-before.sha256"
cmp "$q/privacy-sdk3-frozen-inputs.sha256" "$out-sdk-file-set-before.sha256"
finish() {
  original=$?
  trap - EXIT
  set +e
  sha256sum -c "$q/privacy-sdk3-frozen-inputs.sha256" > "$out-sdk-inputs-after.txt"
  sdk_hash=$?
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-sdk-file-set-after.sha256"
  enumeration=$?
  cmp "$q/privacy-sdk3-frozen-inputs.sha256" "$out-sdk-file-set-after.sha256"
  sdk_set=$?
  cd "$q/flowmux-credit-mvm-work"
  sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-after.txt"
  mvm_hash=$?
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-mvm-file-set-after.sha256"
  mvm_enumeration=$?
  cmp "$q/privacy-mvm-full2-frozen-inputs.sha256" "$out-mvm-file-set-after.sha256"
  mvm_set=$?
  final=$original
  if [ "$sdk_hash" -ne 0 ] || [ "$enumeration" -ne 0 ] || [ "$sdk_set" -ne 0 ] || [ "$mvm_hash" -ne 0 ] || [ "$mvm_enumeration" -ne 0 ] || [ "$mvm_set" -ne 0 ]; then final=90; fi
  printf '{"original_exit":%s,"sdk_hash_exit":%s,"sdk_enumeration_exit":%s,"sdk_file_set_exit":%s,"mvm_hash_exit":%s,"mvm_enumeration_exit":%s,"mvm_file_set_exit":%s,"final_exit":%s}\n' "$original" "$sdk_hash" "$enumeration" "$sdk_set" "$mvm_hash" "$mvm_enumeration" "$mvm_set" "$final" > "$out-outcome.json"
  printf '%s\n' "$final" > "$out-exit.txt"
  echo "PRIVACY_SDK3_TERMINAL original=$original final=$final"
  exit "$final"
}
trap finish EXIT
rustc -Vv > "$out-toolchain.txt"
for label in live adapter journal witness; do
  manifest="crates/spiralcore-mvm-$label/Cargo.toml";features=()
  case "$label" in live) features=(--features canonical-host);; adapter) features=(--features live,conformance,hardware-sha256);; journal) manifest=crates/spiralcore-mvm-journal-host/Cargo.toml;; witness) manifest=tools/installed-flowmux-witness/Cargo.toml;features=(--features installed-linux);; esac
  cargo metadata --locked --offline --format-version=1 --manifest-path "$manifest" "${features[@]}" > "$out-$label-metadata.json"
done
printf '%s\n' 'No SpiralCore Rust files changed in this consumer/configuration slice. The additional broad dependency-format check in privacy-sdk2 failed against unchanged shared-core inputs and remains recorded there; it is not claimed green. MVM source formatting passed in frozen full2.' > "$out-format-scope.txt"
/usr/bin/time -v -o "$out-live-clippy-time.txt" cargo clippy --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --all-targets -- -D warnings > "$out-live-clippy.txt" 2>&1
/usr/bin/time -v -o "$out-live-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/Cargo.toml --features canonical-host --lib --no-run --message-format=json > "$out-live-build.jsonl" 2> "$out-live-build-stderr.txt"
python3 "$q/sc-privacy-sdk-profiles.py" "$out-live-build.jsonl" "$out-live-metadata.json" "$out-live-profiles"
executable=$(jq -ers '[.[] | select(.reason=="compiler-artifact" and .target.name=="spiralcore_mvm_live" and .profile.test and .executable)] | if length==1 and .[0].fresh==false then .[0].executable else error("new SDK executable required") end' "$out-live-build.jsonl")
sha256sum "$executable" > "$out-live-executable-before.sha256"
/usr/bin/time -v -o "$out-live-tests-time.txt" "$executable" --test-threads=1 > "$out-live-tests.txt" 2>&1
grep -E '^test result: ok\. 175 passed; 0 failed; 1 ignored; 0 measured;' "$out-live-tests.txt"
sha256sum -c "$out-live-executable-before.sha256" > "$out-live-executable-after.txt"
sha256sum -c "$out-live-profiles.sha256" > "$out-live-profile-artifacts-after.txt"
/usr/bin/time -v -o "$out-owner-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml -- --test-threads=1 > "$out-owner.txt" 2>&1
/usr/bin/time -v -o "$out-supervisor-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml -- --test-threads=1 > "$out-supervisor.txt" 2>&1
/usr/bin/time -v -o "$out-adapter-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-adapter/Cargo.toml --features live,conformance,hardware-sha256 --all-targets --no-run --message-format=json > "$out-adapter-build.jsonl" 2> "$out-adapter-build-stderr.txt"
python3 "$q/sc-privacy-sdk-profiles.py" "$out-adapter-build.jsonl" "$out-adapter-metadata.json" "$out-adapter-profiles"
/usr/bin/time -v -o "$out-witness-build-time.txt" cargo build --locked --offline --manifest-path tools/installed-flowmux-witness/Cargo.toml --features installed-linux --bins --message-format=json > "$out-witness-build.jsonl" 2> "$out-witness-build-stderr.txt"
python3 "$q/sc-privacy-sdk-profiles.py" "$out-witness-build.jsonl" "$out-witness-metadata.json" "$out-witness-profiles"
/usr/bin/time -v -o "$out-guest-time.txt" cargo check --locked --offline --manifest-path tools/installed-flowmux-witness/guest/Cargo.toml --all-targets > "$out-guest.txt" 2>&1
/usr/bin/time -v -o "$out-journal-build-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-journal-host/Cargo.toml --test addressed --no-run --message-format=json > "$out-journal-build.jsonl" 2> "$out-journal-build-stderr.txt"
python3 "$q/sc-privacy-sdk-profiles.py" "$out-journal-build.jsonl" "$out-journal-metadata.json" "$out-journal-profiles"
executable=$(jq -ers '[.[] | select(.reason=="compiler-artifact" and .target.name=="addressed" and .profile.test and .executable) | .executable] | if length==1 then .[0] else error("one addressed executable required") end' "$out-journal-build.jsonl")
sha256sum "$executable" > "$out-journal-executable-before.sha256"
/usr/bin/time -v -o "$out-journal-time.txt" "$executable" --test-threads=1 --nocapture > "$out-journal.txt" 2>&1
sha256sum -c "$out-journal-executable-before.sha256" > "$out-journal-executable-after.txt"
for label in adapter witness journal; do sha256sum -c "$out-$label-profiles.sha256" > "$out-$label-profile-artifacts-after.txt"; done
echo PRIVACY_SDK3_COMPONENT_GATES_PASS
