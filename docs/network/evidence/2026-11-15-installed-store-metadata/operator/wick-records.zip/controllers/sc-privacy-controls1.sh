#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/privacy-controls1"
manifest="$out-frozen-inputs.sha256"
umask 0022
umask > "$out-umask.txt"
export PATH="$q/qualification-tools/uv/bin:/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$out-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_GPU_TEST_EXPECT_NATIVE=1 PYTHONDONTWRITEBYTECODE=1
export UV_CACHE_DIR="$q/qualification-cache/uv" npm_config_cache="$q/qualification-cache/npm"
mkdir -m700 "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-pc.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
ulimit -Sn 4096
ulimit -S -s 8192
cd "$q/flowmux-credit-mvm-work"
source scripts/dev-env.sh
sha256sum -c "$manifest" > "$out-inputs-before.txt"
find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-before.sha256"
cmp "$manifest" "$out-file-set-before.sha256"
finish() {
  original=$?
  trap - EXIT
  set +e
  sha256sum -c "$manifest" > "$out-inputs-after.txt"
  hashes=$?
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-after.sha256"
  files=$?
  cmp "$manifest" "$out-file-set-after.sha256"
  comparison=$?
  final=$original
  if [ "$hashes" -ne 0 ] || [ "$files" -ne 0 ] || [ "$comparison" -ne 0 ]; then final=90; fi
  printf '{"original_exit":%s,"source_hash_exit":%s,"file_enumeration_exit":%s,"file_set_comparison_exit":%s,"final_exit":%s}\n' "$original" "$hashes" "$files" "$comparison" "$final" > "$out-outcome.json"
  printf '%s\n' "$final" > "$out-exit.txt"
  echo "PRIVACY_CONTROLS1_TERMINAL original=$original source_hash=$hashes files=$comparison final=$final"
  exit "$final"
}
trap finish EXIT
printf 'e95f1119dac66e45a81c4eead8f4e747a1286a86\n' > "$out-source.txt"
systemctl --user show sc-privacy-controls1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p TasksMax -p LimitNOFILE -p LimitSTACK -p RuntimeMaxUSec -p UMask > "$out-limits.txt"
rustc -Vv > "$out-toolchain.txt"
cargo metadata --locked --offline --format-version=1 > "$out-metadata.json"
jq -e --arg source 'git+https://github.com/R4-Laboratories/SpiralCore?rev=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2#8994951b7c13fe5acf6f5ea3060ad4e51dc473c2' '[.packages[] | select(.name|test("^(spiralcore-|uor-r4-object-store)"))] as $core | ($core|length)==5 and all($core[];.source==$source)' "$out-metadata.json" > "$out-pin-check.txt"
cargo fmt --all -- --check > "$out-format.txt" 2>&1
record() {
  label=$1
  shift
  set +e
  /usr/bin/time -v -o "$out-$label-time.txt" "$@" > "$out-$label.txt" 2>&1
  result=$?
  set -e
  printf '%s\n' "$result" > "$out-$label-exit.txt"
  echo "PRIVACY_CONTROLS1_PHASE $label exit=$result"
}
record clippy cargo clippy --locked --offline -p mvm-hostd --lib --tests -- -D warnings
if [ "$(cat "$out-clippy-exit.txt")" -ne 0 ]; then exit 101; fi
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline -p mvm-hostd --lib --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
jq -s -e --arg source "$q/flowmux-credit-mvm-work/crates/mvm-hostd/src/lib.rs" '[.[] | select(.reason=="compiler-artifact" and .profile.test==true and .target.src_path==$source and .executable!=null)] | if length==1 and .[0].fresh==false then .[0] else error("one newly compiled current-root test artifact required") end' "$out-build.jsonl" > "$out-selected-artifact.json"
executable=$(jq -er .executable "$out-selected-artifact.json")
case "$executable" in "$CARGO_TARGET_DIR"/debug/deps/mvm_hostd-*) ;; *) exit 90 ;; esac
sha256sum "$executable" > "$out-executable-before.sha256"
"$executable" --list > "$out-test-list.txt"
record ordinary "$executable" resource_pool_tests:: --test-threads=1 --nocapture
if [ "$(cat "$out-ordinary-exit.txt")" -ne 0 ]; then exit 101; fi
root_tmp=$(sudo -n mktemp -d /tmp/sc-pu.XXXXXX)
printf '%s\n' "$root_tmp" > "$out-root-tmp.txt"
sudo -n mkdir -m700 "$out-root-state"
for suffix in capture_refuses_and_retains_original_store_and_debit retirement_refuses_and_retains_original_lease_lock_and_debit; do
  test_name="supervisor::endpoint::flowmux::spiralcore_payload::resource_pool_tests::owner_mode_tests::foreign_uid_$suffix"
  grep -Fx "$test_name: test" "$out-test-list.txt" > "$out-root-$suffix-selected.txt"
  record "root-$suffix" sudo -n env MVM_HOME="$out-root-state" TMPDIR="$root_tmp" "$executable" "$test_name" --exact --ignored --test-threads=1 --nocapture
  if [ "$(cat "$out-root-$suffix-exit.txt")" -ne 0 ]; then exit 101; fi
done
sha256sum -c "$out-executable-before.sha256" > "$out-executable-after.txt"
echo PRIVACY_CONTROLS1_FOCUSED_PASS
