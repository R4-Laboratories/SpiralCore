#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/privacy-sdk-metadata1"
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_NET_GIT_FETCH_WITH_CLI=true CARGO_BUILD_JOBS=2
cd "$q/credit-sdk-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
systemctl --user show sc-privacy-sdk-metadata1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p TasksMax -p LimitNOFILE -p LimitSTACK -p UMask > "$out-limits.txt"
finish() {
  original=$?
  trap - EXIT
  set +e
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
  enumeration=$?
  printf '{"original_exit":%s,"enumeration_exit":%s,"scope":"resolver phase; only reviewed lockfiles may change"}\n' "$original" "$enumeration" > "$out-outcome.json"
  exit "$original"
}
trap finish EXIT
while IFS='|' read -r label manifest features; do
  args=(--format-version=1 --manifest-path "$manifest")
  if [ -n "$features" ]; then args+=(--features "$features"); fi
  /usr/bin/time -v -o "$out-$label-time.txt" cargo metadata "${args[@]}" > "$out-$label.json" 2> "$out-$label.stderr"
done <<'MANIFESTS'
adapter|crates/spiralcore-mvm-adapter/Cargo.toml|live,conformance,hardware-sha256
live|crates/spiralcore-mvm-live/Cargo.toml|canonical-host
owner|crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml|
supervisor|crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml|
witness|tools/installed-flowmux-witness/Cargo.toml|installed-linux
guest|tools/installed-flowmux-witness/guest/Cargo.toml|
journal|crates/spiralcore-mvm-journal-host/Cargo.toml|
live-linux|crates/spiralcore-mvm-live/Cargo.toml|canonical-host,linux-host
MANIFESTS
echo PRIVACY_SDK_RESOLVED_EIGHT_GRAPHS
