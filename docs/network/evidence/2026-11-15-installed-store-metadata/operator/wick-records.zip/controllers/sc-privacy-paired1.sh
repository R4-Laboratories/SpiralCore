#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/privacy-paired1"
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$out-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
mkdir -m700 "$MVM_HOME"
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-pp.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
ulimit -Sn 4096
ulimit -S -s 8192
test "$(cat "$q/privacy-sdk3-exit.txt")" = 0
systemctl --user show sc-privacy-paired1 -p InvocationID -p MemoryMax -p MemorySwapMax -p CPUQuotaPerSecUSec -p TasksMax -p LimitNOFILE -p LimitSTACK -p UMask > "$out-limits.txt"
cd "$q/flowmux-credit-mvm-work"
sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-before.txt"
cd "$q/credit-sdk-work"
sha256sum -c "$q/privacy-sdk3-frozen-inputs.sha256" > "$out-sdk-inputs-before.txt"
cd "$q/credit-paired/fixtures"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-fixtures-before.sha256"
cd "$q/credit-paired/paired-guest"
sha256sum -c "$q/privacy-paired1-frozen-inputs.sha256" > "$out-inputs-before.txt"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-before.sha256"
cmp "$q/privacy-paired1-frozen-inputs.sha256" "$out-file-set-before.sha256"
finish() {
  original=$?
  trap - EXIT
  set +e
  cd "$q/credit-paired/paired-guest"
  sha256sum -c "$q/privacy-paired1-frozen-inputs.sha256" > "$out-inputs-after.txt"; paired=$?
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-file-set-after.sha256"; files=$?
  cmp "$q/privacy-paired1-frozen-inputs.sha256" "$out-file-set-after.sha256"; paired_set=$?
  cd "$q/credit-sdk-work"
  sha256sum -c "$q/privacy-sdk3-frozen-inputs.sha256" > "$out-sdk-inputs-after.txt"; sdk=$?
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-sdk-file-set-after.sha256"; sdk_enum=$?
  cmp "$q/privacy-sdk3-frozen-inputs.sha256" "$out-sdk-file-set-after.sha256"; sdk_set=$?
  cd "$q/flowmux-credit-mvm-work"
  sha256sum -c "$q/privacy-mvm-full2-frozen-inputs.sha256" > "$out-mvm-inputs-after.txt"; mvm=$?
  find . -path ./.git -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-mvm-file-set-after.sha256"; mvm_enum=$?
  cmp "$q/privacy-mvm-full2-frozen-inputs.sha256" "$out-mvm-file-set-after.sha256"; mvm_set=$?
  cd "$q/credit-paired/fixtures"
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-fixtures-after.sha256"; fixture_enum=$?
  cmp "$out-fixtures-before.sha256" "$out-fixtures-after.sha256"; fixture_set=$?
  final=$original
  for value in "$paired" "$files" "$paired_set" "$sdk" "$sdk_enum" "$sdk_set" "$mvm" "$mvm_enum" "$mvm_set" "$fixture_enum" "$fixture_set"; do if [ "$value" -ne 0 ]; then final=90; fi; done
  printf '{"original_exit":%s,"paired_hash":%s,"paired_enumeration":%s,"paired_set":%s,"sdk_hash":%s,"sdk_enumeration":%s,"sdk_set":%s,"mvm_hash":%s,"mvm_enumeration":%s,"mvm_set":%s,"fixture_enumeration":%s,"fixture_set":%s,"final_exit":%s}\n' "$original" "$paired" "$files" "$paired_set" "$sdk" "$sdk_enum" "$sdk_set" "$mvm" "$mvm_enum" "$mvm_set" "$fixture_enum" "$fixture_set" "$final" > "$out-outcome.json"
  printf '%s\n' "$final" > "$out-exit.txt"
  echo "PRIVACY_PAIRED1_TERMINAL original=$original final=$final"
  exit "$final"
}
trap finish EXIT
rustc -Vv > "$out-toolchain.txt"
cargo metadata --locked --offline --format-version=1 --features object-reader-v1,large-object-fixture,sender-ordinal-v1 > "$out-metadata.json" 2> "$out-metadata.stderr"
/usr/bin/time -v -o "$out-build-time.txt" cargo test --locked --offline --features object-reader-v1,large-object-fixture,sender-ordinal-v1 --all-targets --no-run --message-format=json > "$out-build.jsonl" 2> "$out-build-stderr.txt"
python3 - "$out" <<'PY'
from pathlib import Path
import hashlib,json,sys
out=sys.argv[1];meta=json.loads(Path(out+'-metadata.json').read_text());package=next(p for p in meta['packages'] if p['name']=='spiralcore-paired-journal-workloads');features=next(n['features'] for n in meta['resolve']['nodes'] if n['id']==package['id']);expected={t['name'] for t in package['targets'] if t['test'] and set(t.get('required-features',[]))<=set(features)}
rows=[json.loads(s) for s in Path(out+'-build.jsonl').read_text().splitlines()];selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('package_id')==package['id'] and r['profile']['test'] and r.get('executable')]
assert selected and len(selected)==len(expected) and {r['target']['name'] for r in selected}==expected
records=[]
for r in selected:
 p=Path(r['executable']);raw=p.read_bytes();assert raw.startswith(b'\x7fELF') and not r['fresh'],(str(p),'fresh current-source ELF required')
 records.append({'path':str(p),'target':r['target']['name'],'source':r['target']['src_path'],'fresh':r['fresh'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
Path(out+'-executables-before.json').write_text(json.dumps(records,indent=2)+'\n');Path(out+'-executables-before.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
PY
/usr/bin/time -v -o "$out-tests-time.txt" cargo test --locked --offline --features object-reader-v1,large-object-fixture,sender-ordinal-v1 --all-targets > "$out-tests.txt" 2>&1
sha256sum -c "$out-executables-before.sha256" > "$out-executables-after.txt"
python3 - "$out" <<'PY'
from pathlib import Path
import json,re,sys
out=sys.argv[1];rows=json.loads(Path(out+'-executables-before.json').read_text());text=Path(out+'-tests.txt').read_text();paths=re.findall(r'^     Running .*? \(([^)]+)\)$',text,re.M);assert len(paths)==len(rows) and set(paths)=={r['path'] for r in rows}
Path(out+'-runtime-executable-set.json').write_text(json.dumps({'compiled_targets':len(rows),'actual_running_targets':len(paths),'exact_match':True},indent=2)+'\n')
PY
echo PRIVACY_PAIRED1_COMPONENT_GATES_PASS
