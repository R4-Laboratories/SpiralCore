from pathlib import Path
import hashlib,json,sys
build,metadata,out=sys.argv[1:]
meta=json.loads(Path(metadata).read_text());source='git+https://github.com/Casey-allard/mvm?rev=e95f1119dac66e45a81c4eead8f4e747a1286a86#e95f1119dac66e45a81c4eead8f4e747a1286a86'
ids={p['name']:p['id'] for p in meta['packages'] if p['source']==source and p['name'] in {'mvm-core','mvm-crypto'}}
assert set(ids)=={'mvm-core','mvm-crypto'}
rows=[json.loads(line) for line in Path(build).read_text().splitlines()];records=[]
for name,package_id in ids.items():
 selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('package_id')==package_id and r['target']['kind']==['lib'] and not r['profile']['test']]
 assert len(selected)==1,(name,len(selected))
 row=selected[0];profile=row['profile'];assert profile['opt_level']=='2' and profile['overflow_checks'] and profile['debug_assertions'],(name,profile)
 files=[]
 for filename in row['filenames']:
  p=Path(filename);h=hashlib.sha256()
  with p.open('rb') as stream:
   for block in iter(lambda:stream.read(4<<20),b''):h.update(block)
  files.append({'path':filename,'bytes':p.stat().st_size,'sha256':h.hexdigest()})
 records.append({'name':name,'package_id':package_id,'source':source,'profile':profile,'fresh':row['fresh'],'files':files})
Path(out+'.json').write_text(json.dumps(records,indent=2)+'\n')
Path(out+'.sha256').write_text(''.join(f['sha256']+'  '+f['path']+'\n' for r in records for f in r['files']))
print(json.dumps({'packages':[r['name'] for r in records],'opt_level':'2','overflow_checks':True,'scope':'actual invoking-workspace compiler artifacts; no performance claim'}))
