from pathlib import Path
import hashlib,json,sys
build,metadata,out=sys.argv[1:];meta=json.loads(Path(metadata).read_text());members=set(meta['workspace_members']);features={n['id']:set(n['features']) for n in meta['resolve']['nodes']};expected={(p['id'],t['name']) for p in meta['packages'] if p['id'] in members for t in p['targets'] if t['test'] and set(t.get('required-features',[]))<=features[p['id']]}
rows=[json.loads(s) for s in Path(build).read_text().splitlines()];selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('package_id') in members and r['profile']['test'] and r.get('executable')]
assert selected and len(selected)==len(expected) and {(r['package_id'],r['target']['name']) for r in selected}==expected
records=[]
for r in selected:
 p=Path(r['executable']);raw=p.read_bytes();assert raw.startswith(b'\x7fELF')
 records.append({'path':str(p),'package_id':r['package_id'],'target':r['target']['name'],'source_path':r['target']['src_path'],'fresh':r['fresh'],'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
Path(out+'-executables-before.json').write_text(json.dumps(records,indent=2)+'\n');Path(out+'-executables-before.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
