from pathlib import Path
import json,re,sys
raw=Path(sys.argv[1]).read_text();rows=json.loads(Path(sys.argv[2]).read_text())
expected={x['path'] for x in rows}
actual=re.findall(r'^     Running .* \((/[^()\n]+)\)$',raw,re.MULTILINE)
assert len(expected)==285,len(expected)
assert len(actual)==len(expected),len(actual)
assert set(actual)==expected,{'missing':sorted(expected-set(actual)),'extra':sorted(set(actual)-expected)}
result={'expected':len(expected),'running_lines':len(actual),'unique_executed':len(set(actual)),'exact_match':True}
Path(sys.argv[3]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
