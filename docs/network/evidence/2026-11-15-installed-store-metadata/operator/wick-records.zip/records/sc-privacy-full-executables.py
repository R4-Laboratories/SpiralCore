from pathlib import Path
import hashlib,json,sys
build,out,root,prior_path,expected_path=sys.argv[1:]
prior={r['path']:r for r in json.loads(Path(prior_path).read_text())}
expected=json.loads(Path(expected_path).read_text())
expected_keys={(r['target'],r['source_path']) for r in expected['expected_targets']}
assert len(expected_keys)==expected['expected_count']==285
rows=[json.loads(x) for x in Path(build).read_text().splitlines()]
old=[b'/var/tmp/sc-direct-flowmux.iptmjZre/'+x for x in (b'verified-runtime-owner-work',b'worker-funding-mvm-work',b'mvm-directory-work',b'workspace-contract-mvm-work')]
selected={}
for row in rows:
    if row.get('reason')!='compiler-artifact' or not row.get('profile',{}).get('test') or not row.get('executable'):continue
    path=Path(row['executable']);raw=path.read_bytes();digest=hashlib.sha256(raw).hexdigest()
    assert row['target']['src_path'].startswith(root+'/'),row
    assert raw.startswith(b'\x7fELF'),str(path)
    assert sum(raw.count(value) for value in old)==0,str(path)
    previous=prior.get(str(path))
    if row['fresh']:assert previous and previous['sha256']==digest,(str(path),'unproven reused executable')
    if row['target']['name']=='mvm_build':assert (root+'/crates/mvm-build').encode() in raw
    selected[str(path)]={'path':str(path),'target':row['target']['name'],'source_path':row['target']['src_path'],'package_id':row['package_id'],'fresh':row['fresh'],'bytes':len(raw),'sha256':digest,'prior_root_occurrences':0,'current_root_occurrences':raw.count(root.encode()),'same_root_reuse_verified':bool(row['fresh']),'reuse_receipt':previous.get('receipt','published B2 same-root hash') if row['fresh'] else None,'recompiled_byte_identical_to_prior':bool(not row['fresh'] and previous and previous['sha256']==digest)}
actual_keys={(r['target'],r['source_path']) for r in selected.values()}
assert actual_keys==expected_keys,{'missing':sorted(expected_keys-actual_keys),'extra':sorted(actual_keys-expected_keys)}
assert len(selected)==len(expected_keys)
records=sorted(selected.values(),key=lambda r:r['path'])
Path(out+'-executables-before.json').write_text(json.dumps(records,indent=2)+'\n')
Path(out+'-executables-before.sha256').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
print(json.dumps({'test_executables':len(records),'bytes':sum(r['bytes'] for r in records),'recompiled':sum(not r['fresh'] for r in records),'verified_same_root_reuse':sum(r['fresh'] for r in records),'prior_root_occurrences':0,'exact_expected_target_set':True}))
