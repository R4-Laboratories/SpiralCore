from pathlib import Path
import json,re,sys
log,artifacts,out=sys.argv[1:];records=json.loads(Path(artifacts).read_text());text=Path(log).read_text();paths=re.findall(r'^     Running .*? \(([^)]+)\)$',text,re.M)
assert len(paths)==len(records) and set(paths)=={r['path'] for r in records}
summary=[];current=None
for line in text.splitlines():
 if line.startswith('     Running '):current='binary'
 elif line.startswith('   Doc-tests '):current='doc'
 elif current=='binary':
  m=re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if m:summary.append({'status':m[1],'passed':int(m[2]),'failed':int(m[3]),'ignored':int(m[4])})
assert summary and all(r['status']=='ok' and r['failed']==0 for r in summary)
Path(out).write_text(json.dumps({'actual_paths':paths,'exact_compiler_set':True,'summary':summary,'passed':sum(r['passed'] for r in summary),'ignored':sum(r['ignored'] for r in summary),'scope':'new follow-up execution; not reconstruction of SDK3 original prehash'},indent=2)+'\n')
