from pathlib import Path
import json
q=Path('/var/tmp/sc-direct-flowmux.iptmjZre');out=q/'privacy-graphs';summaries=[]
for label in ['live','adapter','journal','owner','supervisor','witness','guest','mvm']:
 baseline=out/f'{label}-before.json'
 if not baseline.exists():baseline=q/'admitted-final-graphs'/f'{label}-after.json'
 before=json.loads(baseline.read_text());after=json.loads((out/f'{label}-after.json').read_text());mapping={};versions=[]
 for key in before['packages']:
  name,version,source=json.loads(key)
  owned=source=='REVIEWED_MVM_SOURCE' or (label=='mvm' and source.startswith('/'))
  if owned and version=='0.28.0-rc.6':
   replacement=json.dumps([name,'0.28.0-rc.7',source],separators=(',',':'));versions.append(name)
  else:replacement=key
  mapping[key]=replacement
 expected={'packages':sorted(mapping[k] for k in before['packages']),'nodes':[]}
 for node in before['nodes']:
  expected['nodes'].append(dict(node,id=mapping[node['id']],deps=[dict(dep,pkg=mapping[dep['pkg']]) for dep in node['deps']]))
 if label!='mvm':
  core=json.dumps(['mvm-core','0.28.0-rc.7','REVIEWED_MVM_SOURCE'],separators=(',',':'))
  crypto=json.dumps(['mvm-crypto','0.28.0-rc.7','REVIEWED_MVM_SOURCE'],separators=(',',':'))
  node=next(n for n in expected['nodes'] if n['id']==core)
  aes=[d for d in node['deps'] if d['name']=='aes_gcm'];assert len(aes)==1,(label,aes)
  assert aes[0]['dep_kinds']==[{'kind':None,'target':None}]
  node['deps'].remove(aes[0]);node['deps'].append({'name':'mvm_crypto','pkg':crypto,'dep_kinds':[{'kind':None,'target':None}]})
  assert crypto not in expected['packages'];expected['packages'].append(crypto)
  expected['nodes'].append({'id':crypto,'features':[],'deps':aes})
 for node in expected['nodes']:node['deps'].sort(key=lambda d:(d['name'],d['pkg'],json.dumps(d['dep_kinds'],sort_keys=True)))
 expected['packages'].sort();expected['nodes'].sort(key=lambda n:n['id'])
 assert expected==after,(label,'unexplained package, edge or feature change')
 summary={'label':label,'baseline_source':'5819ec8dc2d2ed897cc4716aa242131acef9f5c5' if label=='mvm' else 'b2def5fd556e6ab9aabeb281b554c6ef6bb060d9','candidate_source':'e95f1119dac66e45a81c4eead8f4e747a1286a86','owned_rc6_to_rc7_packages':versions,'packages':len(after['packages']),'edges':sum(len(n['deps']) for n in after['nodes']),'features':sum(len(n['features']) for n in after['nodes']),'change':'owned prerelease labels only' if label=='mvm' else 'owned prerelease labels plus canonical mvm-crypto leaf wrapping the unchanged AES-GCM dependency','all_other_packages_edges_features_equal':True}
 (out/f'{label}-qualified-summary.json').write_text(json.dumps(summary,indent=2)+'\n');summaries.append(summary)
 print(json.dumps({k:v for k,v in summary.items() if k!='owned_rc6_to_rc7_packages'}))
assert (out/'live-after.json').read_bytes()==(out/'live-linux-after.json').read_bytes(),'explicit linux-host alias unexpectedly changes graph'
(out/'qualified-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
