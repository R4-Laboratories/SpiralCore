def package_key:
  . as $package |
  ($package.source // "") as $source |
  [
    $package.name,
    (if ($source | startswith("git+https://github.com/Casey-allard/mvm?rev=")) and
        ($package.version == "0.28.0-rc.3" or $package.version == "0.28.0-rc.5")
     then "MVM_WORKSPACE_VERSION" else $package.version end),
    (if $package.source == null then
       ($package.manifest_path | ltrimstr($root))
     elif ($source | startswith("git+https://github.com/Casey-allard/mvm?rev=")) then
       "REVIEWED_MVM_SOURCE"
     else $source end)
  ] | tojson;

if all(.packages[];
    if ((.source // "") | startswith("git+https://github.com/Casey-allard/mvm?rev="))
    then .source == $expected_source else true end)
then . else error("mixed or unexpected contributor revision") end |
. as $document |
(reduce .packages[] as $package ({}; .[$package.id] = ($package | package_key))) as $ids |
{
  packages: ([.packages[] | $ids[.id]] | sort),
  nodes: ([.resolve.nodes[] | {
    id: $ids[.id],
    features: (.features | sort),
    deps: ([.deps[] | {
      name,
      pkg: $ids[.pkg],
      dep_kinds: (.dep_kinds | sort_by(.kind, .target))
    }] | sort_by(.name, .pkg, .dep_kinds))
  }] | sort_by(.id))
}
