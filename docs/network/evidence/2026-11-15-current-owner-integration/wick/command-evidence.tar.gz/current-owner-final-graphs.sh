#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/current-owner-final-graphs"
mkdir -m700 "$out"
for label in adapter live owner supervisor witness guest journal mvm; do
  for side in before after; do
    if [ "$side" = before ]; then
      input="$q/current-owner-sdk-$label-qualified-metadata.json"
      mvm=d338f528601e247bc1e798bfa860213e9f8db865
      core=86497e8868146f2a21ba581dd09fcfabfca6486d
    else
      input="$q/current-owner-sdk-core-$label-qualified-metadata.json"
      mvm=4031a54d6596cd5a12d572d12357287d97cc1042
      core=8994951b7c13fe5acf6f5ea3060ad4e51dc473c2
    fi
    root="$q/current-owner-sdk-work"
    if [ "$label" = mvm ]; then
      root="$q/current-owner-port-work"
      if [ "$side" = before ]; then input="$q/current-owner-full-metadata.json"; else input="$q/current-owner-full-core-metadata.json"; fi
    fi
    jq -S --arg root "$root" --arg expected_mvm "git+https://github.com/Casey-allard/mvm?rev=$mvm#$mvm" --arg expected_core "git+https://github.com/R4-Laboratories/SpiralCore?rev=$core#$core" -f "$q/current-owner-final-graph.jq" "$input" > "$out/$label-$side.json"
  done
  cmp "$out/$label-before.json" "$out/$label-after.json"
  jq --arg label "$label" '{label:$label,normalized_equal:true,packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps[]]|length),feature_memberships:([.nodes[].features[]]|length)}' "$out/$label-after.json" > "$out/$label-summary.json"
done
jq -s '.' "$out/"*-summary.json > "$out/summary.json"
cat "$out/summary.json"
