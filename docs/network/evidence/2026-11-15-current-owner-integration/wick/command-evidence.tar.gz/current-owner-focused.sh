#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
work="$q/current-owner-port-work"
out="$q/current-owner-focused"
umask 0022
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo"
export CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/current-owner-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export TMPDIR
TMPDIR=$(mktemp -d /tmp/sc-own.XXXXXX)
printf '%s\n' "$TMPDIR" > "$out-private-tmp.txt"
cd "$work"
source scripts/dev-env.sh
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
  cmp "$out-before.sha256" "$out-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  exit "$rc"
}
trap finish EXIT
cargo fmt --all -- --check > "$out-format.txt" 2>&1
/usr/bin/time -v -o "$out-flowmux-time.txt" cargo test --locked --offline -p mvm-hostd --lib supervisor::endpoint::flowmux:: -- --test-threads=1 --nocapture > "$out-flowmux.txt" 2>&1
/usr/bin/time -v -o "$out-registered-time.txt" cargo test --locked --offline -p mvm-hostd --test registered_direct_tcp -- --test-threads=1 --nocapture > "$out-registered.txt" 2>&1
/usr/bin/time -v -o "$out-volume-time.txt" cargo test --locked --offline -p mvm-client --lib volume:: -- --test-threads=1 > "$out-volume.txt" 2>&1
echo CURRENT_OWNER_FOCUSED_TESTS_VERIFIED
