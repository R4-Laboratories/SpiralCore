#!/usr/bin/env bash
set -euo pipefail
phase="$1"
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/current-owner-$phase"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/current-owner-state" MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd "$q/current-owner-port-work"
source scripts/dev-env.sh
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
set +e
/usr/bin/time -v -o "$out-time.txt" cargo test --locked --offline -p mvm-client --lib volume:: -- --test-threads=1 > "$out-tests.txt" 2>&1
rc=$?
set -e
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
cmp "$out-before.sha256" "$out-after.sha256" || rc=90
printf '%s\n' "$rc" > "$out-exit.txt"
exit "$rc"
