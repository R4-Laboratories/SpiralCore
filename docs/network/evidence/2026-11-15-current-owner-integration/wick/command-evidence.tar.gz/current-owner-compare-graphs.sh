#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/current-owner-sdk-graph-comparison"
mkdir -m 700 "$out"
for label in adapter live owner supervisor witness guest journal; do
  for side in before after; do
    if [ "$side" = before ]; then
      input="$q/workspace-contract-sdk-graphs-$label-metadata.json"
      root="$q/workspace-contract-fixture-work"
      revision=04a5e3e06f4fc48bc2c122518c42605b8032aa32
    else
      input="$q/current-owner-sdk-$label-qualified-metadata.json"
      root="$q/current-owner-sdk-work"
      revision=d338f528601e247bc1e798bfa860213e9f8db865
    fi
    expected_source="git+https://github.com/Casey-allard/mvm?rev=$revision#$revision"
    jq -S --arg root "$root" --arg expected_source "$expected_source" -f "$q/current-owner-normalize-graph.jq" "$input" > "$out/$label-$side.json"
  done
  if cmp -s "$out/$label-before.json" "$out/$label-after.json"; then
    jq --arg label "$label" '{label:$label,normalized_equal:true,packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps[]]|length),feature_memberships:([.nodes[].features[]]|length)}' "$out/$label-after.json" > "$out/$label-summary.json"
  else
    diff -u "$out/$label-before.json" "$out/$label-after.json" > "$out/$label-diff.txt" || true
    jq --arg label "$label" '{label:$label,normalized_equal:false,packages:(.packages|length),nodes:(.nodes|length),edges:([.nodes[].deps[]]|length),feature_memberships:([.nodes[].features[]]|length)}' "$out/$label-after.json" > "$out/$label-summary.json"
  fi
done
jq -s '.' "$out/"*-summary.json > "$out/summary.json"
cat "$out/summary.json"
