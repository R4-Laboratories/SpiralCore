#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
work="$q/current-owner-work"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin
export CARGO_HOME="$q/source/.mvm-test/cargo"
export CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/current-owner-state"
export MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
mkdir -m 700 -p "$MVM_HOME"
cd "$work"
source scripts/dev-env.sh
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/current-owner-baseline-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$q/current-owner-baseline-after.sha256"
  cmp "$q/current-owner-baseline-before.sha256" "$q/current-owner-baseline-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$q/current-owner-baseline-exit.txt"
  exit "$rc"
}
trap finish EXIT
rustc -Vv > "$q/current-owner-baseline-toolchain.txt"
/usr/bin/time -v -o "$q/current-owner-baseline-time.txt" cargo check --locked --offline -p mvm-hostd > "$q/current-owner-baseline-cargo.txt" 2>&1
echo CURRENT_OWNER_BASELINE_VERIFIED
