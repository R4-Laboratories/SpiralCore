def package_key:
  . as $package |
  ($package.source // "") as $source |
  [
    $package.name,
    $package.version,
    (if $package.source == null then
       if ($package.manifest_path | startswith($root + "/"))
       then ($package.manifest_path | ltrimstr($root))
       else error("local package outside declared source root") end
     elif ($source | startswith("git+https://github.com/Casey-allard/mvm?rev=")) then
       "REVIEWED_MVM_SOURCE"
     elif ($source | startswith("git+https://github.com/R4-Laboratories/SpiralCore?rev=")) then
       "REVIEWED_SHARED_CORE_SOURCE"
     else $source end)
  ] | tojson;

if all(.packages[];
    if ((.source // "") | startswith("git+https://github.com/Casey-allard/mvm?rev="))
    then .source == $expected_mvm
    elif ((.source // "") | startswith("git+https://github.com/R4-Laboratories/SpiralCore?rev="))
    then .source == $expected_core else true end)
then . else error("mixed or unexpected reviewed source") end |
(reduce .packages[] as $package ({}; .[$package.id] = ($package | package_key))) as $ids |
{
  packages: ([.packages[] | $ids[.id]] | sort),
  nodes: ([.resolve.nodes[] | {
    id: $ids[.id],
    features: (.features | sort),
    deps: ([.deps[] | {
      name,
      pkg: $ids[.pkg],
      dep_kinds: (.dep_kinds | sort_by(.kind, .target))
    }] | sort_by(.name, .pkg, .dep_kinds))
  }] | sort_by(.id))
}
