#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
cargo metadata --locked --offline --format-version=1 --manifest-path "$q/current-owner-paired/before/paired-guest/Cargo.toml" --features object-reader-v1,large-object-fixture,sender-ordinal-v1 > "$q/current-owner-paired-before.json" 2> "$q/current-owner-paired-before.stderr"
cargo metadata --offline --format-version=1 --manifest-path "$q/current-owner-paired/after/paired-guest/Cargo.toml" --features object-reader-v1,large-object-fixture,sender-ordinal-v1 > "$q/current-owner-paired-after.json" 2> "$q/current-owner-paired-after.stderr"
echo CURRENT_OWNER_PAIRED_METADATA_GENERATED
