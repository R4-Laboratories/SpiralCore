#!/usr/bin/env bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/current-owner-sdk-core"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
cd "$q/current-owner-sdk-work"
while IFS='|' read -r label manifest features; do
  args=(--locked --offline --format-version=1 --manifest-path "$manifest")
  if [ -n "$features" ]; then args+=(--features "$features"); fi
  cargo metadata "${args[@]}" > "$out-$label-qualified-metadata.json" 2> "$out-$label-qualified-metadata.stderr"
done <<'MANIFESTS'
adapter|crates/spiralcore-mvm-adapter/Cargo.toml|live,conformance,hardware-sha256
live|crates/spiralcore-mvm-live/Cargo.toml|canonical-host
owner|crates/spiralcore-mvm-live/tests/installed-owner-harness/Cargo.toml|
supervisor|crates/spiralcore-mvm-live/tests/installed-supervisor-harness/Cargo.toml|
witness|tools/installed-flowmux-witness/Cargo.toml|installed-linux
guest|tools/installed-flowmux-witness/guest/Cargo.toml|
journal|crates/spiralcore-mvm-journal-host/Cargo.toml|
MANIFESTS
echo CURRENT_OWNER_SDK_LOCKED_FEATURE_GRAPHS_VERIFIED
