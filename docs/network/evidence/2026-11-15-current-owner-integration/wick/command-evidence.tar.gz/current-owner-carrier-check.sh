#!/usr/bin/env bash
set -euo pipefail
phase="$1"
q=/var/tmp/sc-direct-flowmux.iptmjZre
out="$q/current-owner-carrier-$phase"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin RUSTUP_TOOLCHAIN=1.97.1
export CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd "$q/current-owner-carrier-work"
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
set +e
if [ "$phase" = red ]; then
  /usr/bin/time -v -o "$out-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml --lib tls::readiness_tests::shutdown_after_session_entry_preserves_original_owner_refusal -- --exact --test-threads=1 > "$out-tests.txt" 2>&1
else
  /usr/bin/time -v -o "$out-time.txt" cargo test --locked --offline --manifest-path crates/spiralcore-mvm-flowmux/Cargo.toml -- --test-threads=1 --nocapture > "$out-tests.txt" 2>&1
fi
rc=$?
set -e
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
cmp "$out-before.sha256" "$out-after.sha256" || rc=90
printf '%s\n' "$rc" > "$out-exit.txt"
exit "$rc"
