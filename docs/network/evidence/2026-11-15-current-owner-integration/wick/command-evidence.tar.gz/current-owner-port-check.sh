#!/usr/bin/env bash
set -euo pipefail
phase="$1"
q=/var/tmp/sc-direct-flowmux.iptmjZre
work="$q/current-owner-port-work"
out="$q/current-owner-port-$phase"
export PATH=/home/callard/.cargo/bin:/usr/bin:/bin
export CARGO_HOME="$q/source/.mvm-test/cargo"
export CARGO_TARGET_DIR="$q/source/.mvm-test/target"
export MVM_HOME="$q/current-owner-state"
export MVM_DEV_ENV_KEEP_INHERITED=1
export CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd "$work"
source scripts/dev-env.sh
find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-before.sha256"
finish() {
  rc=$?
  trap - EXIT
  find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > "$out-after.sha256"
  cmp "$out-before.sha256" "$out-after.sha256" || rc=90
  printf '%s\n' "$rc" > "$out-exit.txt"
  exit "$rc"
}
trap finish EXIT
/usr/bin/time -v -o "$out-time.txt" cargo check --locked --offline -p mvm-hostd --all-targets > "$out-cargo.txt" 2>&1
echo CURRENT_OWNER_PORT_ALL_TARGETS_VERIFIED
