from pathlib import Path
import hashlib,json,subprocess,sys
r=Path('/var/tmp/spiralcore-native-assets-20261105')
t=Path('/var/tmp/spiralcore-installed-supervisor-20261103/component-target/release')
fp=t/'.fingerprint'
client=fp/'mvm-client-32cbd0c8016106bb'
deps=json.loads((client/'lib-mvm_client.json').read_text())['deps']
wanted={'mvm_core','mvm_runtime','mvm_bundler','mvm_build','anyhow','serde_json'}
external={'mvm_client':t/'deps/libmvm_client-32cbd0c8016106bb.rlib'}
for _,crate,_,fingerprint in deps:
 if crate not in wanted:continue
 key=fingerprint.to_bytes(8,'little').hex()
 variants=[p for p in fp.iterdir() if (p/f'lib-{crate}').is_file() and (p/f'lib-{crate}').read_text().strip()==key]
 assert len(variants)==1,(crate,key,variants)
 variant=variants[0].name.rsplit('-',1)[1]
 external[crate]=t/f'deps/lib{crate}-{variant}.rlib'
assert set(external)==wanted|{'mvm_client'}
paths=[r/'prepare.rs',*external.values()]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={str(p):digest(p) for p in paths}
label=sys.argv[1]
out=r/f'link-{label}';out.mkdir()
(out/'input-sha256.json').write_text(json.dumps(pins,indent=2))
rustc='/home/callard/.rustup/toolchains/1.97.1-x86_64-unknown-linux-gnu/bin/rustc'
argv=[rustc,'--edition=2024','-C','opt-level=1','-C','debuginfo=0','-L',f'dependency={t}/deps','-o',str(out/'prepare'),str(r/'prepare.rs')]
for crate,p in external.items():argv+=['--extern',f'{crate}={p}']
(out/'argv.json').write_text(json.dumps(argv,indent=2))
with (out/'compiler.txt').open('w') as log:
 done=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT)
(out/'compiler.exit').write_text(str(done.returncode)+'\n')
assert all(digest(Path(p))==h for p,h in pins.items())
print((out/'compiler.txt').read_text()[:4800])
if done.returncode==0:
 (out/'binary.sha256').write_text(digest(out/'prepare')+'\n')
raise SystemExit(done.returncode)
