#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="/home/callard/.cargo/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target"
cd "$q/mvm-store-consumer"
for target in x86_64-unknown-linux-gnu aarch64-apple-darwin x86_64-pc-windows-msvc; do
  cargo tree --locked --offline -p mvm-hostd --target "$target" -e features > "$q/mvm-store-graph-$target-candidate.txt"
done
for package in mvmctl mvm-builder-guest; do
  cargo tree --locked --offline -p "$package" --target x86_64-unknown-linux-gnu -e normal,build --prefix none > "$q/mvm-store-graph-$package-candidate.txt"
done
