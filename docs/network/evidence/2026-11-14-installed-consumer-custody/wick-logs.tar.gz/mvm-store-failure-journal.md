# Consumer qualification setup failures

- Local merge commit hook started Clippy in the pre-existing local target. Interrupted with original session (exit130); identified and removed421 generated cache files newer than task branch creation (48,603,681 bytes), preserving older361MiB cache. Subsequent commits use the hook-supported MVM_SKIP_CLIPPY=1; full required checks run on bounded Wick scope before publication.
- First remote baseline launch preceded completion of source export, so workspace discovery could not find xtask/Cargo.toml. The export completed; all tracked source files were then verified by SHA-256 before retry. Original log retained as mvm-store-baseline-export-incomplete.log.
- Baseline compiled successfully on complete source but two custody controls could not create their fixture root because inherited TMPDIR pointed to a directory removed during prior housekeeping. No attach hook was reached. This is setup failure, not reader/store qualification. Original log retained as mvm-store-baseline-missing-tmp.log.

Next single change: create and select a fresh owned private mvm-store-tmp directory before invoking the unchanged baseline custody selectors. Verify nonzero original hook tests before copying candidate pin changes. No deadline, security, codec, reservation or assertion changes.

## Next setup/qualification checkpoint

- Target-graph capture refused uncached getrandom0.3.4 under offline mode. Completed locked dependency fetch; no registry versions were changed.
- First native CI source gate expected four packages in target-filtered metadata. Linux/macOS correctly contain three active packages, with the Windows-only fourth retained in Cargo.lock. Correct gate requires all three exact native names at the reviewed source plus all four uniform lock source rows. No runtime assertion/deadline/security check changes.
- First full serial workspace run failed the mvm-build producing-tree provenance test because the verified source archive lacked Git metadata (mvm-build:1430 passed,1failed,6ignored). This is not evidence against the store behavior. Next single setup change: attach matching public611a3c7 Cargo checkout Git metadata and the final doc-only review row, verify every source file, then rerun the unchanged exact provenance selector before the full workspace. Do not skip or stub the source-identity guard.

## Follow-up runner findings

- Native ARM build after the corrected metadata check exited101 compiling quote/proc-macro2. stderr was retained in artifact14136462782 (SHA256 f6e42cdd1db55906afca148c11bcd5d0e73245d6afa82e6a463ffbc612a069a7); compiler-message JSON stdout was outside the uploaded evidence, so exact compiler cause is unavailable. Next workflow preserves/displays JSON diagnostics and explicitly installs lld required by the consumer's Linux Cargo config. No assertion or product gate changes.
- Genuine-Git workspace rerun reached mvm-build1423pass/8fail/6ignored. Lock/storage controls refused temp directories mode775 under inherited umask0002; overlay VERSION mode644 vs664 also failed. Exact source unchanged; rerun under explicit0022. The first failed full-workspace-final log was accidentally overwritten by the rerun script; exact failure excerpts remain in the tool transcript and this journal. Do not claim the original raw file is retained. No check bypass.
