#!/bin/bash
set -euo pipefail
umask 022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin"
export RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_HOME="$q/mvm-store-consumer-home" MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 TMPDIR="$q/mvm-store-tmp"
mkdir -m700 -p "$MVM_HOME"
cd "$q/mvm-store-consumer"
source scripts/dev-env.sh
/usr/bin/time -v cargo test --locked --offline -p mvm-hostd --lib supervisor::flowmux::owned_relays::custody_tests:: -- --test-threads=1 --show-output > "$q/mvm-store-baseline.log" 2>&1
