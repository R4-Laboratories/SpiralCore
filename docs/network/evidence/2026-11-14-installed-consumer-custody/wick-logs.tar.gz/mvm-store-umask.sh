#!/bin/bash
set -euo pipefail
q=/var/tmp/sc-direct-flowmux.iptmjZre
umask 0022
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 MVM_HOME="$q/mvm-store-consumer-home" TMPDIR="$q/mvm-store-tmp"
cd "$q/mvm-store-consumer"
source scripts/dev-env.sh
/usr/bin/time -v cargo test --locked --offline -p mvm-build --lib guest_bins::tests::the_producer_records_the_producing_tree_and_every_member -- --exact --show-output > "$q/mvm-store-provenance.log" 2>&1
/usr/bin/time -v cargo test --locked --offline --workspace -- --test-threads=1 > "$q/mvm-store-workspace-final.log" 2>&1
sha256sum -c "$q/mvm-store-final-source.sha256" > "$q/mvm-store-final-source-after.txt"
