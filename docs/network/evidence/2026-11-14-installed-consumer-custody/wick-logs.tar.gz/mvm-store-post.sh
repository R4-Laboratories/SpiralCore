#!/bin/bash
set -euo pipefail
umask 0022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin" RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 MVM_HOME="$q/mvm-store-consumer-home" TMPDIR="$q/mvm-store-tmp"
cd "$q/mvm-store-consumer"
source scripts/dev-env.sh
sha256sum -c "$q/mvm-store-final-source.sha256" > "$q/mvm-store-post-source-before.txt"
executable=$(sed -n 's/^     Running tests\/registered_direct_tcp.rs (\(.*\))$/\1/p' "$q/mvm-store-workspace-final.log")
[[ "$executable" == "$CARGO_TARGET_DIR"/debug/deps/registered_direct_tcp-* ]]
test -x "$executable"
sha256sum "$executable" > "$q/mvm-store-registered-isolated-before.sha256"
"$executable" --list --format terse > "$q/mvm-store-registered-test-list.txt"
grep -Fx 'registered_prepare::registered_direct_tcp_transfers_exact_bytes_and_refunds_a_failed_peer: test' "$q/mvm-store-registered-test-list.txt"
/usr/bin/time -v "$executable" --exact registered_prepare::registered_direct_tcp_transfers_exact_bytes_and_refunds_a_failed_peer --show-output --test-threads=1 > "$q/mvm-store-registered-isolated.log" 2>&1
grep -E '^test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured;' "$q/mvm-store-registered-isolated.log"
sha256sum "$executable" > "$q/mvm-store-registered-isolated-after.sha256"
cmp "$q/mvm-store-registered-isolated-before.sha256" "$q/mvm-store-registered-isolated-after.sha256"
cp Cargo.lock "$q/mvm-store-saved-Cargo.lock"
cp crates/mvm-hostd/Cargo.toml "$q/mvm-store-saved-hostd-Cargo.toml"
restore() {
  cp "$q/mvm-store-saved-Cargo.lock" Cargo.lock
  cp "$q/mvm-store-saved-hostd-Cargo.toml" crates/mvm-hostd/Cargo.toml
}
trap restore EXIT
capture() {
  local variant=$1
  for target in x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu aarch64-apple-darwin x86_64-apple-darwin x86_64-pc-windows-msvc aarch64-pc-windows-msvc; do
    cargo tree --locked --offline -p mvm-hostd --target "$target" -e normal,build,features > "$q/mvm-store-matched-$target-$variant.txt"
  done
  for package in mvmctl mvm-builder-guest; do
    cargo tree --locked --offline -p "$package" --target x86_64-unknown-linux-gnu -e normal,build --prefix none > "$q/mvm-store-matched-$package-$variant.txt"
  done
}
capture candidate
cp "$q/mvm-store-baseline-Cargo.lock" Cargo.lock
cp "$q/mvm-store-baseline-hostd-Cargo.toml" crates/mvm-hostd/Cargo.toml
capture baseline
restore
trap - EXIT
sha256sum -c "$q/mvm-store-final-source.sha256" > "$q/mvm-store-post-source-after.txt"
