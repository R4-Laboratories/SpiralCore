#!/bin/bash
set -euo pipefail
umask 022
q=/var/tmp/sc-direct-flowmux.iptmjZre
export PATH="$q/runtime-compat-tools/bin:/home/callard/.cargo/bin:/usr/local/bin:/usr/bin:/bin"
export RUSTUP_TOOLCHAIN=1.97.1 CARGO_HOME="$q/source/.mvm-test/cargo" CARGO_TARGET_DIR="$q/source/.mvm-test/target" CARGO_BUILD_JOBS=2 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export MVM_HOME="$q/mvm-store-consumer-home" MVM_DEV_ENV_KEEP_INHERITED=1 MVM_ALLOW_NATIVE_GPU_BUILD=1 MVM_GPU_TEST_EXPECT_NATIVE=1 TMPDIR="$q/mvm-store-tmp"
cd "$q/mvm-store-consumer"
source scripts/dev-env.sh
run() { local name=$1; shift; /usr/bin/time -v "$@" > "$q/mvm-store-$name.log" 2>&1 || { tail -45 "$q/mvm-store-$name.log"; return 1; }; }
run metadata cargo metadata --locked --format-version 1
run custody cargo test --locked --offline -p mvm-hostd --lib supervisor::flowmux::owned_relays::custody_tests:: -- --test-threads=1 --show-output
run payload cargo test --locked --offline -p mvm-hostd --lib supervisor::flowmux::spiralcore_payload:: -- --test-threads=1 --show-output
run registered cargo test --locked --offline -p mvm-hostd --test registered_direct_tcp -- --test-threads=1 --show-output
run format cargo fmt --all -- --check
run strict cargo clippy --locked --offline --workspace --all-targets -- -D warnings
run gated just check::gated
run workspace cargo test --locked --offline --workspace -- --test-threads=1
sha256sum -c "$q/mvm-store-candidate-source.sha256" > "$q/mvm-store-final-source-check.txt"
