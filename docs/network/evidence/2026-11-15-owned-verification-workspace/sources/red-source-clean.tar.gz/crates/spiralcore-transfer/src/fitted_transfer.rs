//! Shared framing and prepared decoders for bounded fitted-artifact profiles.
use crate::{
    protocol::{Mode, Reader},
    Error, Result, MAX_CHUNK,
};

pub(crate) fn is_fitted(mode: Mode) -> bool {
    matches!(
        mode,
        Mode::SchemaV1 | Mode::ZstdDictionaryV1 | Mode::SchemaZstdV1
    )
}

pub(crate) fn is_buffered(mode: Mode) -> bool {
    is_fitted(mode) || mode == Mode::ZstdWholeV1
}

pub(crate) fn encoded_cap(mode: Mode, len: usize) -> Result<usize> {
    if len > crate::client::MAX_BATCHED_OBJECT {
        return Err(Error::Limit);
    }
    match mode {
        Mode::SchemaV1 => Ok(len + 5 * len.min(65536) + 48),
        Mode::ZstdDictionaryV1 => crate::zstd_prefix::encoded_cap(len),
        Mode::SchemaZstdV1 => crate::schema_zstd::encoded_cap(len),
        Mode::ZstdWholeV1 => crate::zstd_whole::encoded_cap(len),
        _ => Err(Error::Unsupported),
    }
}

pub(crate) const DATA_HEADER: usize = 6;
pub(crate) const MAX_FRAGMENTS: usize = 512;

pub(crate) fn fragment(mode: Mode, chunk: &[u8]) -> Vec<u8> {
    let mut body = Vec::with_capacity(chunk.len() + DATA_HEADER);
    body.push(mode as u8);
    body.extend_from_slice(&(chunk.len() as u32).to_le_bytes());
    body.push(1);
    body.extend_from_slice(chunk);
    body
}

pub(crate) fn chunks(mode: Mode, encoded: &[u8]) -> Result<Vec<Vec<u8>>> {
    if !is_buffered(mode) {
        return Err(Error::Unsupported);
    }
    if encoded.is_empty() || encoded.len().div_ceil(MAX_CHUNK) > MAX_FRAGMENTS {
        return Err(Error::Limit);
    }
    Ok(encoded
        .chunks(MAX_CHUNK)
        .map(|chunk| fragment(mode, chunk))
        .collect())
}

pub(crate) fn append(
    mode: Mode,
    encoded: &mut Vec<u8>,
    count: &mut usize,
    len: usize,
    body: &[u8],
) -> Result<()> {
    let cap = encoded_cap(mode, len)?;
    let mut r = Reader::new(body);
    if r.u8()? != mode as u8 {
        return Err(Error::Malformed);
    }
    let n = r.u32()? as usize;
    if r.u8()? != 1 {
        return Err(Error::Unsupported);
    }
    if n == 0 || n > MAX_CHUNK || *count >= MAX_FRAGMENTS {
        return Err(Error::Limit);
    }
    let chunk = r.take(n)?;
    r.end()?;
    if encoded.len().checked_add(n).ok_or(Error::Limit)? > cap {
        return Err(Error::Limit);
    }
    encoded.extend_from_slice(chunk);
    *count += 1;
    Ok(())
}

pub(crate) fn decode_with_resource_profile(
    mode: Mode,
    artifact: &[u8],
    encoded: &[u8],
    len: usize,
    resources: crate::resource_profile::ResourceProfile,
) -> Result<Vec<u8>> {
    if resources == crate::resource_profile::ResourceProfile::SmallV1 {
        resources.check_target(len, len)?;
        resources.check_artifact(artifact.len())?;
        return match mode {
            Mode::SchemaV1 => crate::schema::decode(artifact, encoded, len),
            Mode::SchemaZstdV1 => {
                crate::schema_zstd::PreparedDecoder::new_with_resource_profile(artifact, resources)?
                    .decode(encoded, len)
            }
            Mode::ZstdWholeV1 => {
                crate::zstd_whole::PreparedDecoder::new_with_resource_profile(resources)?
                    .decode(encoded, len)
            }
            _ => Err(Error::Unsupported),
        };
    }
    match mode {
        Mode::SchemaV1 => crate::schema::decode(artifact, encoded, len),
        Mode::ZstdDictionaryV1 => crate::zstd_dictionary::decode(artifact, encoded, len),
        Mode::SchemaZstdV1 => crate::schema_zstd::decode(artifact, encoded, len),
        Mode::ZstdWholeV1 => crate::zstd_whole::decode(encoded, len),
        _ => Err(Error::Unsupported),
    }
}

pub(crate) const CODEC_CHARGE: u64 = 5 << 20;

pub(crate) enum PreparedDecoder {
    Schema(crate::schema::PreparedSchema),
    Dictionary(crate::zstd_dictionary::PreparedDecoder),
    CompressedSchema(crate::schema_zstd::PreparedDecoder),
    Whole(crate::zstd_whole::PreparedDecoder),
}
impl PreparedDecoder {
    pub(crate) fn new(mode: Mode, artifact: &[u8]) -> Result<Self> {
        let decoder = match mode {
            Mode::SchemaV1 => Self::Schema(crate::schema::PreparedSchema::new(artifact)?),
            Mode::ZstdDictionaryV1 => {
                Self::Dictionary(crate::zstd_dictionary::PreparedDecoder::new(artifact)?)
            }
            Mode::SchemaZstdV1 => {
                Self::CompressedSchema(crate::schema_zstd::PreparedDecoder::new(artifact)?)
            }
            Mode::ZstdWholeV1 => Self::Whole(crate::zstd_whole::PreparedDecoder::new()?),
            _ => return Err(Error::Unsupported),
        };
        if decoder.charge() > CODEC_CHARGE {
            return Err(Error::Limit);
        }
        Ok(decoder)
    }
    fn charge(&self) -> u64 {
        match self {
            Self::Schema(p) => p.retained_charge(),
            Self::Dictionary(p) => p.retained_charge(),
            Self::CompressedSchema(p) => p.retained_charge(),
            Self::Whole(p) => p.retained_charge(),
        }
    }
    pub(crate) fn decode(&mut self, encoded: &[u8], len: usize) -> Result<Vec<u8>> {
        match self {
            Self::Schema(p) => p.decode(encoded, len),
            Self::Dictionary(p) => p.decode(encoded, len),
            Self::CompressedSchema(p) => p.decode(encoded, len),
            Self::Whole(p) => p.decode(encoded, len),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn frame_validation_is_atomic_and_separately_bounds_count_and_bytes() {
        for mode in [Mode::SchemaV1, Mode::ZstdDictionaryV1, Mode::SchemaZstdV1] {
            let body = chunks(mode, &[7]).unwrap().remove(0);
            let mut bytes = vec![];
            let mut count = 0;
            for _ in 0..512 {
                append(mode, &mut bytes, &mut count, 65536, &body).unwrap();
            }
            assert_eq!(
                append(mode, &mut bytes, &mut count, 65536, &body),
                Err(Error::Limit)
            );
            assert_eq!(bytes, vec![7; 512]);
            assert_eq!(count, 512);
            let mut count = 0;
            let mut bytes = vec![0; encoded_cap(mode, 1).unwrap()];
            assert_eq!(
                append(mode, &mut bytes, &mut count, 1, &body),
                Err(Error::Limit)
            );
            assert_eq!(count, 0);
            bytes.clear();
            for bad in [
                body[..body.len() - 1].to_vec(),
                [body.clone(), vec![0]].concat(),
            ] {
                assert_eq!(
                    append(mode, &mut bytes, &mut count, 1, &bad),
                    Err(Error::Malformed)
                );
                assert!(bytes.is_empty());
            }
            let mut bad = body.clone();
            bad[0] = 0;
            assert_eq!(
                append(mode, &mut bytes, &mut count, 1, &bad),
                Err(Error::Malformed)
            );
            bad = body.clone();
            bad[5] = 2;
            assert_eq!(
                append(mode, &mut bytes, &mut count, 1, &bad),
                Err(Error::Unsupported)
            );
            bad = body;
            bad[1..5].fill(0);
            assert_eq!(
                append(mode, &mut bytes, &mut count, 1, &bad),
                Err(Error::Limit)
            );
            assert!(bytes.is_empty());
            assert_eq!(count, 0);
        }
    }
}
