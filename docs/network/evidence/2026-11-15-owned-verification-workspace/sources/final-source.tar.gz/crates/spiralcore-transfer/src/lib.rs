#![forbid(unsafe_code)]

// Without the diagnostic feature the original storage expression is unchanged.
macro_rules! commit_stage {
    ($stage:ident, $operation:expr) => {{
        #[cfg(feature = "witness-stall")]
        {
            $crate::witness_stall::with_stage($crate::witness_stall::CommitStage::$stage, || {
                $operation
            })
        }
        #[cfg(not(feature = "witness-stall"))]
        {
            $operation
        }
    }};
}

pub mod client;
pub mod dag;
pub mod delta;
pub mod endpoint;
mod fitted_transfer;
pub mod prepared;
pub mod protocol;
pub mod resource_profile;
pub mod schema;
pub mod schema_selection;
pub mod schema_zstd;
pub mod selection;
pub mod session;
pub mod shared_runtime;
pub mod shared_transfer;
pub mod v1;
pub mod wan;
#[cfg(feature = "witness-stall")]
pub mod witness_stall;
pub mod zstd_dictionary;
pub mod zstd_prefix;
pub mod zstd_whole;
use sha2::{Digest, Sha256};
pub type Id = [u8; 32];
pub type Result<T> = std::result::Result<T, Error>;
pub const MAX_OBJECT: u64 = 64 * 1024 * 1024;
pub const MAX_FRAME: usize = 65536;
pub const MAX_CHUNK: usize = 60 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u16)]
pub enum Error {
    Malformed = 1,
    Unauthorized = 2,
    Limit = 3,
    Integrity = 4,
    Missing = 5,
    Sequence = 6,
    Unknown = 7,
    Expired = 8,
    Storage = 9,
    Unsupported = 10,
}
impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{self:?}")
    }
}
impl std::error::Error for Error {}
impl From<std::io::Error> for Error {
    fn from(_: std::io::Error) -> Self {
        Self::Storage
    }
}
pub fn hash(domain: &[u8], parts: &[&[u8]]) -> Id {
    let mut h = Sha256::new();
    h.update(domain);
    for p in parts {
        h.update(p);
    }
    h.finalize().into()
}
pub(crate) fn object_hasher(len: u64) -> Sha256 {
    let mut h = Sha256::new();
    h.update(b"spiralcore.object.bytes.v1\0");
    h.update(len.to_le_bytes());
    h
}
pub fn object_id(bytes: &[u8]) -> Id {
    let mut h = object_hasher(bytes.len() as u64);
    h.update(bytes);
    h.finalize().into()
}
pub fn hex(id: &Id) -> String {
    id.iter().map(|b| format!("{b:02x}")).collect()
}
