//! Focused no-boot regression on the real, locally signed portable asset.

use super::*;
use anyhow::ensure;

use mvm_core::{
    arch::GuestArch,
    packs::Sha256Hex,
    plan::{
        FsTrustStore,
        bundle::{ArtifactRole, BundleRegistry, verify_bundle_file},
    },
    vm_backend::{BundleBootAssetsPin, LegacyPortableRuntimeProof},
};

#[test]
#[ignore = "requires the independently prepared signed Firecracker fixture"]
fn installed_firecracker_carrier_preserves_actual_signed_portable_runtime() -> Result<()> {
    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT")
            .context("exact isolated native fixture root required")?,
    );
    ensure!(root.is_absolute() && root.canonicalize()? == root);
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    ensure!(std::env::var_os("HOME").as_deref() == Some(root.join("home").as_os_str()));
    let archive = root.join("installed-native-witness.mvmpkg");
    let trust = FsTrustStore::default_path()?;
    let verified = verify_bundle_file(&archive, &trust)?;
    let registry = BundleRegistry::default_path()?;
    let installed = registry
        .find(&verified.bundle_sha256)?
        .context("original installed native fixture missing")?;
    ensure!(installed.manifest == verified.manifest);
    let path = |role: ArtifactRole| -> Result<PathBuf> {
        Ok(installed.root.join(
            &installed
                .manifest
                .find_by_role(&role)
                .context("actual signed artifact role missing")?
                .path,
        ))
    };
    let original_root = verified
        .boot_assets
        .as_ref()
        .context("verified portable runtime missing")?
        .image_set
        .manifest_sha256
        .clone();
    let actual_verity = verified
        .manifest
        .verity
        .as_ref()
        .context("signed workload verity absent")?;
    let req = LocalRunRequest {
        name: "native-asset-attachment-proof".into(),
        rootfs_path: path(ArtifactRole::Rootfs)?,
        kernel_path: Some(path(ArtifactRole::Kernel)?),
        verity_path: Some(path(ArtifactRole::VerityHashSidecar)?),
        roothash: Some(actual_verity.roothash.clone()),
        cpus: 1,
        mem_mib: 1024,
        backend_name: "firecracker".into(),
        volumes: Vec::new(),
        destroy_on_exit: false,
        grants: None,
        secrets: Vec::new(),
        secret_release: SecretReleasePolicy::None,
        signed_plan: None,
        registry_pack_image: None,
    };
    // The prior protected canonical Client resolver populated this exact
    // image-set cache. The existing Runtime verifier reauthenticates every
    // selected byte from the same actual original archive before the test.
    let cache = PathBuf::from(mvm_core::config::mvm_cache_dir())
        .join("image-set")
        .join(original_root.as_str());
    let initrd = cache.join("0.22.0/x86_64/initramfs.cpio.gz");
    let overlay = cache.join("runtime-overlay/0.22.0/x86_64");
    let boot_pin = BundleBootAssetsPin {
        manifest_sha256: original_root.clone(),
        arch: GuestArch::host(),
        initrd_sha256: Sha256Hex::new(mvm_core::crypto::image_verify::sha256_file(&initrd)?)?,
    };
    let proof = LegacyPortableRuntimeProof {
        archive: registry.archive_path(&verified.bundle_sha256),
        pin: verified.plan_artifact(),
        manifest_sha256: original_root.as_str().into(),
        arch: GuestArch::host(),
    };
    let path_string = |path: &std::path::Path| path.to_string_lossy().into_owned();
    let mut config = VmStartConfig {
        name: req.name,
        rootfs_path: path_string(&req.rootfs_path),
        kernel_path: req.kernel_path.as_deref().map(path_string),
        verity_path: req.verity_path.as_deref().map(path_string),
        roothash: req.roothash,
        cpus: req.cpus,
        memory_mib: req.mem_mib,
        initrd_path: Some(path_string(&initrd)),
        runtime_overlay_path: Some(path_string(&overlay.join("overlay.ext4"))),
        runtime_overlay_verity_path: Some(path_string(&overlay.join("overlay.verity"))),
        runtime_overlay_roothash: Some(
            std::fs::read_to_string(overlay.join("overlay.roothash"))?
                .trim_end()
                .into(),
        ),
        runtime_overlay_version: Some(
            std::fs::read_to_string(overlay.join("VERSION"))?
                .trim_end()
                .into(),
        ),
        bundle_boot_assets: Some(boot_pin),
        legacy_portable_runtime: Some(proof.clone()),
        ..Default::default()
    };
    let original = mvm_runtime::runtime_evidence::verify_runtime_for_launch(
        &config,
        mvm_runtime::runtime_evidence::MIN_GUEST_RPC_PROTOCOL_VERSION,
    )?;
    ensure!(
        original.is_some(),
        "exact portable fixture must be verified before the gate"
    );
    drop(original);
    eprintln!("actual signed portable runtime verified before canonical Hostd attachment");
    let carrier = InstalledPortableRuntime::from_config(&config)?;
    let wrong_bundle = InstalledPortableRuntime::from_config(&config)?;
    config.legacy_portable_runtime = None;
    config.bundle_boot_assets = None;
    config.initrd_path = None;
    config.runtime_overlay_path = None;
    config.runtime_overlay_verity_path = None;
    config.runtime_overlay_roothash = None;
    config.runtime_overlay_version = None;
    let failure = wrong_bundle
        .attach(&mut config, None)
        .expect_err("portable selection without the original admitted pin must refuse");
    ensure!(
        failure
            .to_string()
            .contains("differs from original admitted bundle")
    );
    ensure!(config.legacy_portable_runtime.is_none() && config.initrd_path.is_none());
    carrier.attach(&mut config, Some(&verified.plan_artifact()))?;
    ensure!(config.legacy_portable_runtime.as_ref() == Some(&proof));
    ensure!(!config.unsigned_runtime_development && config.runtime_release_proof.is_none());
    Ok(())
}
