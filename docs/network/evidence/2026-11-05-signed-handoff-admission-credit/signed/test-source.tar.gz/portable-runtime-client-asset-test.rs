use super::*;

#[test]
#[ignore = "requires the verified signed Firecracker fixture"]
fn original_signed_bundle_selects_only_its_portable_runtime() -> Result<()> {
    let root = PathBuf::from(
        std::env::var_os("SPIRALCORE_NATIVE_ASSET_ROOT")
            .context("exact isolated native fixture root required")?,
    );
    ensure!(root.is_absolute() && root.canonicalize()? == root);
    ensure!(mvm_core::config::mvm_home_strict()? == root.join("mvm"));
    let archive = root.join("installed-native-witness.mvmpkg");
    let verified = verify_bundle_file(&archive, &FsTrustStore::default_path()?)?;
    let pin = verified.plan_artifact();
    let registry = BundleRegistry::default_path()?;
    let installed = registry
        .find(&pin.bundle_sha256)?
        .context("original installed native fixture missing")?;
    let rootfs = installed.root.join(
        &installed
            .manifest
            .find_by_role(&ArtifactRole::Rootfs)
            .context("original signed rootfs missing")?
            .path,
    );
    let mut wrong = pin.clone();
    wrong.manifest_sig_base64.clear();
    let refusal = match select_original_portable_runtime(&wrong, &rootfs, "firecracker") {
        Err(error) => error,
        Ok(_) => anyhow::bail!("different original pin was accepted"),
    };
    ensure!(
        refusal
            .to_string()
            .contains("differs from original admitted bundle")
    );

    let selected = select_original_portable_runtime(&pin, &rootfs, "firecracker")?;
    ensure!(
        selected
            .legacy_portable_runtime
            .as_ref()
            .is_some_and(|proof| proof.pin == pin)
    );
    ensure!(selected.rootfs_path == rootfs.to_str().context("non-UTF-8 fixture path")?);
    let verity = verified
        .manifest
        .verity
        .as_ref()
        .context("original signed verity binding absent")?;
    ensure!(selected.roothash.as_ref() == Some(&verity.roothash));
    ensure!(selected.verity_path.is_some());
    ensure!(
        mvm_runtime::runtime_evidence::verify_runtime_for_launch(
            &selected,
            mvm_runtime::runtime_evidence::MIN_GUEST_RPC_PROTOCOL_VERSION,
        )?
        .is_some()
    );
    mvm_hostd::run::InstalledPortableRuntime::from_config(&selected)?;
    Ok(())
}
