from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time

stage = Path(__file__).resolve().parent
composition = stage / "validation-portable-verity-composed"
base = Path("/var/tmp/spiralcore-retained-activation-20261105")
assets = Path("/var/tmp/spiralcore-native-assets-20261105")
out = stage / "validation-portable-signed-asset"
out.mkdir(mode=0o700)
os.umask(0o077)

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(name, data):
    (out / name).write_text(json.dumps(data, indent=2) + "\n")

def run(name, command, env, cwd, timeout=None):
    write(name + "-argv.json", command)
    with (out / (name + ".out")).open("w") as stdout, (out / (name + ".err")).open("w") as stderr:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
        (out / (name + ".pid")).write_text(str(process.pid) + "\n")
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise
    write(name + "-status.json", {"exit": code})
    return code

status = 1
try:
    deadline = time.monotonic() + 900
    while not (composition / "terminal.json").is_file():
        os.kill(203056, 0)
        if time.monotonic() >= deadline:
            raise TimeoutError("composition observation expired")
        time.sleep(3)
    assert json.loads((composition / "terminal.json").read_text())["exit"] == 0
    original_sdk = base / "sdk"
    sdk = out / "sdk"
    shutil.copytree(original_sdk, sdk, symlinks=True)
    source_pins = json.loads((composition / "source-after.json").read_text())["sdk"]
    assert all(digest(sdk / path) == pin for path, pin in source_pins.items())
    tests = [
        ("mvm-hostd", "run::portable_runtime_asset_tests::installed_firecracker_carrier_preserves_actual_signed_portable_runtime",
         "crates/mvm-hostd/src/run.rs", "portable_runtime_asset_tests", "portable-runtime-asset-carrier-test.rs",
         "882f46dac158f238f37435e414189253b900dedc148bcca45e4b8ff2c45e4a5c"),
        ("mvm-client", "launch::bundle_runtime::portable_runtime_asset_tests::original_signed_bundle_selects_only_its_portable_runtime",
         "crates/mvm-client/src/launch/bundle_runtime.rs", "portable_runtime_asset_tests", "portable-runtime-client-asset-test.rs",
         "669916e3e4e0f21d04e69d6528813d673975a28ecd6f5991dc7eb0a892fd6106"),
    ]
    for _, _, path, module, fixture, expected in tests:
        assert digest(stage / fixture) == expected
        leaf = sdk / path
        rel = leaf.stem + "/" + module + ".rs"
        test = leaf.parent / rel
        test.parent.mkdir(exist_ok=True)
        assert not test.exists()
        shutil.copyfile(stage / fixture, test)
        with leaf.open("a") as handle:
            handle.write(f'\n#[cfg(test)]\n#[path = "{rel}"]\nmod {module};\n')
        source_pins[path] = digest(leaf)
        source_pins[str(test.relative_to(sdk))] = expected
    overlay = out / "overlay.toml"
    overlay.write_text((base / "component-overlay.toml").read_text().replace(str(original_sdk), str(sdk)))
    env = os.environ | {
        "CARGO_TARGET_DIR": "/var/tmp/spiralcore-resident-parent-20261103/publication-target",
        "CARGO_BUILD_JOBS": "1", "CARGO_INCREMENTAL": "0",
    }
    for key in ("RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "MVM_UPDATE_DOWNLOAD_URL",
                "MVM_ALLOW_UNSIGNED_RUNTIME", "MVM_ALLOW_UNSIGNED_IMAGE_SET"):
        env.pop(key, None)
    cargo = ["/home/callard/.cargo/bin/cargo", "+1.97.1"]
    config = ["--offline", "--config", str(overlay), "--manifest-path", str(sdk / "Cargo.toml")]
    source_pins["Cargo.lock"] = digest(sdk / "Cargo.lock")
    write("lock-original.json", {"sha256": source_pins["Cargo.lock"]})
    status = run("lock", cargo + ["generate-lockfile"] + config, env, sdk)
    if status:
        raise SystemExit(status)
    source_pins["Cargo.lock"] = digest(sdk / "Cargo.lock")
    write("source-before.json", source_pins)
    asset_pins = json.loads((assets / "portable-proof-red-corrected" / "asset-pins.json").read_text())
    assert all(digest(Path(path)) == pin for path, pin in asset_pins.items())
    write("assets-before.json", asset_pins)
    command = cargo + ["test", "--locked", "--release", "--jobs", "1", "--lib", "--no-run", "--message-format=json"] + config
    for name, *_ in tests:
        command += ["-p", name]
    status = run("build", command, env, sdk)
    if status:
        raise SystemExit(status)
    events = [json.loads(line) for line in (out / "build.out").read_text().splitlines()]
    with tempfile.TemporaryDirectory(prefix=".spiralcore-signed-asset-", dir="/home/callard") as scratch:
        for package, test, *_ in tests:
            executable, = {event["executable"] for event in events
                           if event.get("executable") and event["target"]["name"] == package.replace("-", "_")
                           and event["profile"]["test"]}
            protected = out / (package + "-protected")
            shutil.copyfile(executable, protected)
            protected.chmod(0o500)
            identity = digest(protected)
            assert identity == digest(Path(executable))
            write(package + "-binary.json", {"sha256": identity})
            test_env = env | {
                "MVM_HOME": str(assets / "mvm"), "HOME": str(assets / "home"),
                "TMPDIR": scratch, "SPIRALCORE_NATIVE_ASSET_ROOT": str(assets),
            }
            status = run(package, [str(protected), "--exact", test, "--ignored", "--test-threads=1",
                                   "--nocapture"], test_env, sdk, timeout=90)
            assert "1 passed" in (out / (package + ".out")).read_text() or status
            assert digest(protected) == identity
            if status:
                raise SystemExit(status)
    assert all(digest(sdk / path) == pin for path, pin in source_pins.items())
    assert all(digest(Path(path)) == pin for path, pin in asset_pins.items())
    write("source-after.json", source_pins)
    write("assets-after.json", asset_pins)
except BaseException:
    status = status or 1
    raise
finally:
    write("terminal.json", {"exit": status})
raise SystemExit(status)
