from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile,time
stage=Path(__file__).resolve().parent
composed=Path('/var/tmp/spiralcore-composed-runtime-20261105')
previous=composed/'validation-portable-verity-composed'
signed=composed/'validation-portable-signed-asset'
out=stage/'green'
out.mkdir(mode=0o700)
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,data):
    (out/name).write_text(json.dumps(data,indent=2)+'\n')
status=1
try:
    assert json.loads((stage/'red'/'terminal.json').read_text())['exit']==101
    assert json.loads((stage/'red'/'build-status.json').read_text())['exit']==0
    assert 'admission scratch remains charged' in (stage/'red'/'execute.err').read_text()
    source=Path('/var/tmp/spiralcore-retained-activation-20261105/source')
    rel='crates/spiralcore-mvm-live/src/installed_parent/resident_tests.rs'
    path=source/rel
    pins=json.loads((previous/'source-after.json').read_text())['source']
    assert all(sha(source/leaf)==expected for leaf,expected in pins.items())
    assert sha(path)==sha(stage/'resident_tests.rs.before')
    new=stage/'resident_tests.green.rs'
    assert sha(new)=='a543120a13146132a30597e4bd9bcc493daa561dd610c15548396c08ab4a489d'
    resident=path.with_name('resident.rs')
    candidate=stage/'resident.rs'
    assert sha(resident)==sha(stage/'resident.rs.before')
    assert sha(candidate)=='fa3f0828feea6a8626b6303f44109f505bb7135a0535b4424ac128ac118acfa3'
    original=path.read_bytes()
    original_resident=resident.read_bytes()
    try:
        path.write_bytes(new.read_bytes())
        resident.write_bytes(candidate.read_bytes())
        expected=pins|{rel:sha(path),str(resident.relative_to(source)):sha(resident)}
        write('executed-source-before.json',expected)
        config=json.loads((previous/'command.json').read_text())
        with tempfile.TemporaryDirectory(prefix='.spiralcore-admission-scratch-',dir='/home/callard') as scratch:
            env=os.environ|config['env']|{'TMPDIR':scratch}
            with (out/'build.out').open('w') as stdout,(out/'build.err').open('w') as stderr:
                build=subprocess.Popen(config['argv'],cwd=source,env=env,stdout=stdout,stderr=stderr)
                write('cargo.json',{'pid':build.pid,'argv':config['argv']})
                status=build.wait()
            write('build-status.json',{'exit':status})
            if status==0:
                events=[json.loads(line) for line in (out/'build.out').read_text().splitlines()]
                binary,={e['executable'] for e in events if e.get('executable') and e['target']['name']=='spiralcore_mvm_live'}
                protected=out/'protected-test'
                shutil.copyfile(binary,protected)
                protected.chmod(0o500)
                identity=sha(protected)
                assert identity==sha(Path(binary))
                write('binary.json',{'sha256':identity})
                command=[str(protected),'installed_parent::','--test-threads=1','--nocapture']
                with (out/'execute.out').open('w') as stdout,(out/'execute.err').open('w') as stderr:
                    status=subprocess.call(command,cwd=source,env=env,stdout=stdout,stderr=stderr,timeout=60)
                write('execute-status.json',{'exit':status})
                assert sha(protected)==identity
                assert all(sha(source/leaf)==pin for leaf,pin in expected.items())
                write('executed-source-after.json',expected)
    finally:
        path.write_bytes(original)
        resident.write_bytes(original_resident)
    assert all(sha(source/leaf)==expected for leaf,expected in pins.items())
    write('restored-source.json',pins)
finally:
    write('terminal.json',{'exit':status})
raise SystemExit(status)
