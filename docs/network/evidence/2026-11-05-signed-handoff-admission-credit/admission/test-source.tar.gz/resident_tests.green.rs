use super::*;
use std::{
    fs,
    os::unix::fs::PermissionsExt,
    sync::atomic::{AtomicBool, AtomicUsize, Ordering},
    task::Waker,
};

fn prepared_service() -> (tempfile::TempDir, InstalledResident) {
    prepared_service_with_backend(LocalBackend::with_hypervisor("mock"))
}
fn prepared_service_with_backend(backend: LocalBackend) -> (tempfile::TempDir, InstalledResident) {
    let home = tempfile::Builder::new()
        .permissions(fs::Permissions::from_mode(0o700))
        .tempdir()
        .unwrap();
    let config = crate::installed_supervisor::InstalledConfig::canonical_native_profile();
    let owner = crate::installed_owner::InstallationOwner::initialize(
        &home.path().join("installation"),
        crate::installed_owner::InstallationKey {
            installation: [66; 32],
            profile: config.profile_hash(),
        },
    )
    .unwrap();
    let supervisor = InstalledSupervisor::start(owner, config).unwrap();
    let service = InstalledResident::prepare(supervisor, backend).unwrap();
    (home, service)
}

#[test]
fn missing_helper_profile_refuses_without_consuming_resident_or_credit() {
    let (_home, mut service) = prepared_service();
    let before = service.usage().unwrap();
    assert!(service.start_owned_host_agent().is_err());
    assert!(!service.closed && !service.quarantined);
    assert_eq!(service.usage().unwrap().usage, before.usage);
    assert_eq!(
        service.usage().unwrap().active_reservations,
        before.active_reservations
    );
    service.try_finish().unwrap();
}

#[test]
fn helper_start_refuses_after_vm_reservation_and_after_admission_close() {
    let (_home, mut service) = prepared_service();
    let id = service
        .begin_launch(request("helper-after-vm-refusal"), "local")
        .unwrap();
    let before = service.usage().unwrap().usage;
    assert!(service.start_owned_host_agent().is_err());
    assert_eq!(service.usage().unwrap().usage, before);
    service.request_stop(id).unwrap();
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    assert_eq!(
        runtime.block_on(service.drive_once()).unwrap().state,
        ResidentStatus::UnusedRetired
    );
    let error = service.start_owned_host_agent().unwrap_err();
    assert!(
        error.to_string().contains("helper must precede"),
        "completed original preparation was forgotten: {error}"
    );
    service.close_admission();
    let before = service.usage().unwrap().usage;
    assert!(service.start_owned_host_agent().is_err());
    assert_eq!(service.usage().unwrap().usage, before);
    service.try_finish().unwrap();
}

#[test]
fn poisoned_helper_state_preserves_whole_resident_without_a_vm() {
    let (_home, mut service) = prepared_service();
    let live = service.live.as_ref().unwrap();
    let backend = Arc::downgrade(&live.backend);
    let pool = live.provider.shared.pool.clone();
    let before = pool.snapshot().unwrap().usage;
    let _ = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _held = live.provider.shared.host_agent.lock().unwrap();
        panic!("controlled helper-state poison before startup");
    }));
    assert!(service.start_owned_host_agent().is_err());
    assert!(service.quarantined && service.closed);
    assert!(
        service.live.is_some(),
        "unknown startup lost actual resident custody"
    );
    assert!(service.try_finish().is_err());
    drop(service);
    assert!(backend.upgrade().is_some());
    assert_eq!(pool.snapshot().unwrap().usage, before);
    // No helper or guest ran. Only original managed-owner retention is tested.
}

#[test]
#[ignore = "requires protected same-revision canonical helper binaries and a fresh synthetic MVM_HOME"]
fn resident_stops_actual_helper_then_drops_backend_before_final_alias_drain() {
    assert!(std::env::var_os("MVM_HOST_AGENT_PATH").is_some());
    assert!(std::env::var_os("MVM_HOME").is_some());
    let keys = mvm_core::config::mvm_keys_dir();
    assert!(!keys.exists());
    let _identity = mvm_hostd::audit::host_keypair::load_or_init_at(&keys).unwrap();
    let (_home, mut service) = prepared_service_with_backend(LocalBackend::with_hypervisor(
        if cfg!(target_os = "linux") {
            "firecracker"
        } else {
            "hvf"
        },
    ));
    let live = service.live.as_ref().unwrap();
    live.provider
        .configure_host_agent(
            service.supervisor.as_ref().unwrap(),
            "local",
            super::super::host_agent::QualifiedHostAgentProfile::fixture(ManagedClaim {
                // Functional custody fixture; these candidate numbers do not
                // qualify a shipping resource model or activate a native profile.
                host_plaintext_bytes: 40 << 20,
                host_metadata_bytes: 12 << 20,
                host_stack_bytes: if cfg!(target_os = "linux") {
                    32 << 20
                } else {
                    34 << 20
                },
                workers: 2,
                ..Default::default()
            }),
        )
        .unwrap();
    let pool = live.provider.shared.pool.clone();
    let backend = Arc::downgrade(&live.backend);
    service.start_owned_host_agent().unwrap();
    let live = service.live.as_ref().unwrap();
    assert!(Arc::ptr_eq(&backend.upgrade().unwrap(), &live.backend));
    let alias = live.helper.as_ref().unwrap().registrar().unwrap();
    assert!(service.start_owned_host_agent().is_err());
    assert_eq!(pool.snapshot().unwrap().usage.workers, 2);
    service.close_admission();
    assert!(
        service.try_finish().is_err(),
        "external registrar alias still owns its credit"
    );
    assert!(
        service.live.is_none(),
        "positive helper shutdown did not release the backend table"
    );
    assert!(
        backend.upgrade().is_none(),
        "original backend registrar still retained"
    );
    assert_eq!(pool.snapshot().unwrap().usage.workers, 2);
    drop(alias);
    assert_eq!(pool.snapshot().unwrap().usage.workers, 0);
    service.try_finish().unwrap();
}
fn request(name: &str) -> LaunchRequest {
    LaunchRequest::builder(
        mvm_client::LifecycleMode::Transient,
        mvm_client::RootfsSource::LocalPath("/nonexistent/resident-policy-rootfs".into()),
    )
    .name(name)
    .cpus(1)
    .memory_mib(1024)
    .build()
    .unwrap()
}

struct Gate {
    inner: Pin<Box<dyn Future<Output = OperationResult>>>,
    released: Arc<AtomicBool>,
    polls: Arc<AtomicUsize>,
    drops: Arc<AtomicUsize>,
}
impl Future for Gate {
    type Output = OperationResult;
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        self.polls.fetch_add(1, Ordering::SeqCst);
        if !self.released.load(Ordering::SeqCst) {
            return Poll::Pending;
        }
        self.inner.as_mut().poll(cx)
    }
}
impl Drop for Gate {
    fn drop(&mut self) {
        self.drops.fetch_add(1, Ordering::SeqCst);
    }
}

#[test]
fn canceled_driver_preserves_both_original_operations_and_polls_them_fairly() {
    let (_home, mut service) = prepared_service();
    // This private policy fixture intentionally leaves the global provider
    // absent. Once released, canonical preflight returns genuine unused proof.
    let first = service
        .begin_launch(request("resident-policy-a"), "local")
        .unwrap();
    let second = service
        .begin_launch(request("resident-policy-b"), "local")
        .unwrap();
    service.request_stop(first).unwrap();
    let release = Arc::new(AtomicBool::new(false));
    let drops = Arc::new(AtomicUsize::new(0));
    let polls = [Arc::new(AtomicUsize::new(0)), Arc::new(AtomicUsize::new(0))];
    for (index, slot) in service.live.as_mut().unwrap().slots.iter_mut().enumerate() {
        let op = slot.as_mut().unwrap().operation.as_mut().unwrap();
        let inner = std::mem::replace(
            &mut op.future,
            Box::pin(std::future::pending::<OperationResult>()),
        );
        // Extra wrappers are controlled test instrumentation, not a resource
        // claim for the production future layout.
        op.future = Box::pin(Gate {
            inner,
            released: release.clone(),
            polls: polls[index].clone(),
            drops: drops.clone(),
        });
    }
    let mut cx = Context::from_waker(Waker::noop());
    {
        let mut drive = Box::pin(service.drive_once());
        assert!(drive.as_mut().poll(&mut cx).is_pending());
    }
    assert_eq!(drops.load(Ordering::SeqCst), 0);
    assert_eq!(polls[0].load(Ordering::SeqCst), 1);
    assert_eq!(polls[1].load(Ordering::SeqCst), 1);
    assert_eq!(service.usage().unwrap().usage.guests, 2);
    release.store(true, Ordering::SeqCst);
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    let a = runtime.block_on(service.drive_once()).unwrap();
    assert_eq!(a.state, ResidentStatus::UnusedRetired);
    assert_eq!(a.id, first);
    assert_eq!(service.usage().unwrap().usage.guests, 1);
    let b = runtime.block_on(service.drive_once()).unwrap();
    assert_eq!(b.id, second);
    assert_eq!(b.state, ResidentStatus::UnusedRetired);
    assert_eq!(drops.load(Ordering::SeqCst), 2);
    assert_eq!(service.usage().unwrap().usage.guests, 0);
    service.close_admission();
    service.try_finish().unwrap();
}

#[test]
fn incomplete_drop_retains_entire_original_backend_table_and_guest_owner() {
    let (home, mut service) = prepared_service();
    let pool = service.live.as_ref().unwrap().provider.shared.pool.clone();
    let backend = Arc::downgrade(&service.live.as_ref().unwrap().backend);
    service
        .begin_launch(request("resident-drop-quarantine"), "local")
        .unwrap();
    let before = pool.snapshot().unwrap().usage;
    drop(service);
    assert!(backend.upgrade().is_some());
    assert_eq!(pool.snapshot().unwrap().usage, before);
    assert_eq!(before.guests, 1);
    assert!(matches!(
        crate::installed_owner::InstallationOwner::open(
            &home.path().join("installation"),
            crate::installed_owner::InstallationKey {
                installation: [66; 32],
                profile: crate::installed_supervisor::InstalledConfig::canonical_native_profile()
                    .profile_hash(),
            },
        ),
        Err(crate::installed_owner::OwnerError::Busy)
    ));
    // Deliberate bounded quarantine until this test process exits. No VM ran.
}

struct Panics {
    polls: Arc<AtomicUsize>,
    drops: Arc<AtomicUsize>,
}
impl Future for Panics {
    type Output = OperationResult;
    fn poll(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<Self::Output> {
        self.polls.fetch_add(1, Ordering::SeqCst);
        panic!("controlled canonical operation unwind");
    }
}
impl Drop for Panics {
    fn drop(&mut self) {
        self.drops.fetch_add(1, Ordering::SeqCst);
    }
}

#[test]
fn caught_operation_unwind_fences_admission_reentry_and_global_finish_without_refund() {
    let (_home, mut service) = prepared_service();
    service
        .begin_launch(request("resident-panic-original"), "local")
        .unwrap();
    let pool = service.live.as_ref().unwrap().provider.shared.pool.clone();
    let backend = Arc::downgrade(&service.live.as_ref().unwrap().backend);
    let polls = Arc::new(AtomicUsize::new(0));
    let drops = Arc::new(AtomicUsize::new(0));
    service.live.as_mut().unwrap().slots[0]
        .as_mut()
        .unwrap()
        .operation
        .as_mut()
        .unwrap()
        .future = Box::pin(Panics {
        polls: polls.clone(),
        drops: drops.clone(),
    });
    let before = pool.snapshot().unwrap().usage;
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        runtime.block_on(service.drive_once())
    }));
    assert!(result.is_err());
    assert!(
        service
            .begin_launch(request("resident-after-panic"), "local")
            .is_err(),
        "caught operation unwind left resident admission open"
    );
    assert!(runtime.block_on(service.drive_once()).is_err());
    assert!(service.try_finish().is_err());
    assert_eq!(polls.load(Ordering::SeqCst), 1);
    assert_eq!(drops.load(Ordering::SeqCst), 0);
    assert_eq!(pool.snapshot().unwrap().usage, before);
    assert!(backend.upgrade().is_some());
    drop(service);
    assert_eq!(drops.load(Ordering::SeqCst), 0);
    assert_eq!(pool.snapshot().unwrap().usage, before);
}

#[derive(Debug)]
struct CleanupDropPanic;
impl std::fmt::Display for CleanupDropPanic {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("controlled cleanup diagnostic drop")
    }
}
impl std::error::Error for CleanupDropPanic {}
impl Drop for CleanupDropPanic {
    fn drop(&mut self) {
        panic!("controlled completed-slot cleanup unwind");
    }
}

#[test]
fn caught_request_stop_cleanup_unwind_quarantines_the_other_original_slot() {
    let (_home, mut service) = prepared_service();
    let first = service
        .begin_launch(request("resident-stop-unwind"), "local")
        .unwrap();
    let second = service
        .begin_launch(request("resident-still-owned"), "local")
        .unwrap();
    let pool = service.live.as_ref().unwrap().provider.shared.pool.clone();
    let backend = Arc::downgrade(&service.live.as_ref().unwrap().backend);
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    // Execute the actual first canonical pure preflight, retain its original
    // sealed unused certificate, and leave the second future entirely unpolled.
    let slot = service.live.as_mut().unwrap().slots[first.slot]
        .as_mut()
        .unwrap();
    let mut operation = slot.operation.take().unwrap();
    let OperationResult::Launch(Err(failure)) = runtime.block_on(operation.future.as_mut()) else {
        panic!("expected real unsupported-backend preflight result");
    };
    let (_, unused) = failure.into_parts();
    slot.state = State::Unused(unused.expect("original unused certificate"));
    slot.error = Some(anyhow::Error::new(CleanupDropPanic));
    let original_second = Arc::downgrade(
        &service.live.as_ref().unwrap().slots[second.slot]
            .as_ref()
            .unwrap()
            .owner
            .grant,
    );
    let result =
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| service.request_stop(first)));
    assert!(result.is_err());
    assert!(
        service
            .begin_launch(request("resident-after-stop-unwind"), "local")
            .is_err(),
        "caught request_stop cleanup unwind left admission open"
    );
    assert!(runtime.block_on(service.drive_once()).is_err());
    assert!(service.try_finish().is_err());
    // Only the positively unused first grant may release. The actual unpolled
    // second grant and original backend must survive the caught cleanup panic.
    assert_eq!(pool.snapshot().unwrap().usage.guests, 1);
    assert_eq!(
        pool.snapshot().unwrap().usage.guest_memory_bytes,
        1024 * 1024 * 1024
    );
    assert!(backend.upgrade().is_some());
    assert!(original_second.upgrade().is_some());
    drop(service);
    assert!(backend.upgrade().is_some());
    assert!(original_second.upgrade().is_some());
}

// Included only in the isolated installed-resident test module.
#[test]
fn resident_admitted_launch_returns_unused_original_slot() {
    const CHILD: &str = "SPIRALCORE_RESIDENT_ADMISSION_FIXTURE";
    if std::env::var_os(CHILD).is_none() {
        let home = tempfile::tempdir().unwrap();
        let status = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "resident_admitted_launch_returns_unused_original_slot",
                "--test-threads=1",
                "--nocapture",
            ])
            .env(CHILD, "1")
            .env("MVM_HOME", home.path())
            .status()
            .unwrap();
        assert!(status.success());
        return;
    }

    use mvm_core::plan::{
        NetworkMode, PlanSeccompTier, SecretReleasePolicy, SynthesisInput, Variant,
    };
    use mvm_hostd::plan_admission::{InMemoryNonceLedger, RunPosture, SystemClock, admit_for_run};

    let (backend, hypervisor) = if cfg!(target_os = "linux") {
        (BackendKind::Firecracker, "firecracker")
    } else {
        (BackendKind::Hvf, "hvf")
    };
    let (_installation, mut service) =
        prepared_service_with_backend(LocalBackend::with_hypervisor(hypervisor));
    let keys = mvm_core::config::mvm_keys_dir();
    let ledger = InMemoryNonceLedger::new();
    let admit = |tenant| {
        let input = SynthesisInput::builder()
            .vm_name("resident-admitted-refusal")
            .tenant(tenant)
            .backend_name(hypervisor)
            .image_name("fixture")
            .image_sha256("deadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeefdeadbeef")
            .seccomp_tier(PlanSeccompTier::Standard)
            .secret_release(SecretReleasePolicy::None)
            .secrets(Vec::new())
            .network_mode(NetworkMode::default())
            .cpus(1)
            .mem_mib(1024)
            .disk_mib(0)
            .boot_timeout_secs(60)
            .destroy_on_exit(true)
            .shares(Vec::new())
            .redaction(Default::default())
            .reversible_replacement(Default::default())
            .audit_labels(Default::default())
            .services(Vec::new())
            .stream_edges(Vec::new())
            .stream_retention(Default::default())
            .build()
            .unwrap();
        admit_for_run(
            &input,
            &SystemClock,
            &ledger,
            Some(&keys),
            None,
            RunPosture::on_backend(Variant::Dev, backend),
        )
        .expect("original token from actual MVM signed admission")
    };

    let before = service.usage().unwrap();
    let vm = "resident-admitted-refusal";
    // A fixed fixture fee proves ledger custody only. No shipping size claim.
    let profile = QualifiedAdmissionFunding {
        metadata_bytes: 16 << 20,
        retained_metadata_bytes: 128 << 10,
    };
    if std::env::var_os(CHILD).as_deref() == Some(std::ffi::OsStr::new("saturation")) {
        let pool = &service.live.as_ref().unwrap().provider.shared.pool;
        let all_local_credit = pool
            .reserve(
                tenant_tag("local"),
                ManagedClaim {
                    host_metadata_bytes: (256 << 20) - profile.retained_metadata_bytes,
                    ..Default::default()
                },
            )
            .unwrap();
        let saturated = service.usage().unwrap();
        let public_signer = keys.join(mvm_hostd::audit::host_keypair::PUBLIC_FILENAME);
        assert!(
            !public_signer.exists(),
            "isolated signer is initially absent"
        );
        assert!(
            service
                .begin_launch_admitted(request(vm), "local", &profile, || Ok(admit("local")))
                .is_err(),
            "resident must refuse under full tenant metadata usage"
        );
        assert!(!service.live.as_ref().unwrap().has_issued_vm);
        assert_eq!(service.usage().unwrap().usage, saturated.usage);
        assert!(!mvm_core::config::vm_state_dir(vm).exists());
        assert!(
            !public_signer.exists(),
            "canonical admission created a signer before acquiring resident funding"
        );
        drop(all_local_credit);
        service.try_finish().unwrap();
        return;
    }
    if std::env::var_os(CHILD).as_deref() == Some(std::ffi::OsStr::new("split")) {
        let pool = service.live.as_ref().unwrap().provider.shared.pool.clone();
        let profile = QualifiedAdmissionFunding {
            metadata_bytes: 160 << 20,
            retained_metadata_bytes: 128 << 10,
        };
        let id = service
            .begin_launch_admitted(request(vm), "local", &profile, || {
                let active = pool.snapshot().unwrap();
                assert_eq!(
                    active.usage.host_metadata_bytes - before.usage.host_metadata_bytes,
                    profile.metadata_bytes,
                    "entire verified-bundle workspace must be prepaid before signing"
                );
                Ok(admit("local"))
            })
            .unwrap();
        let retained =
            service.usage().unwrap().usage.host_metadata_bytes - before.usage.host_metadata_bytes;
        assert!(
            retained < 2 << 20,
            "admission scratch remains charged after the original token is retained: {retained}"
        );
        assert!(
            retained >= 128 << 10,
            "original retained token lost its prepaid credit"
        );
        let runtime = tokio::runtime::Builder::new_current_thread()
            .enable_all()
            .build()
            .unwrap();
        let progress = runtime.block_on(service.drive_once()).unwrap();
        assert_eq!(progress.id, id);
        assert_eq!(progress.state, ResidentStatus::UnusedRetired);
        assert_eq!(service.usage().unwrap().usage, before.usage);
        drop(pool);
        service.try_finish().unwrap();
        return;
    }
    assert!(
        service
            .begin_launch_admitted(request(vm), "local", &profile, || Ok(admit("foreign")))
            .is_err(),
        "foreign signed tenant must be refused before the resident issues a slot"
    );
    assert!(!service.live.as_ref().unwrap().has_issued_vm);
    assert_eq!(service.usage().unwrap().usage, before.usage);

    // This process deliberately has no global installed provider. The exact
    // original local token reaches the Client's pure preflight, which returns
    // both original owners. Resident must retire its exact unused slot.
    assert!(mvm_hostd::host_lifetime_parent::require_installed().is_err());
    let pool = service.live.as_ref().unwrap().provider.shared.pool.clone();
    let id = service
        .begin_launch_admitted(request(vm), "local", &profile, || {
            let charged = pool.snapshot().unwrap();
            assert_eq!(
                charged.usage.host_metadata_bytes,
                before.usage.host_metadata_bytes + profile.metadata_bytes
            );
            assert_eq!(charged.active_reservations, before.active_reservations + 2);
            Ok(admit("local"))
        })
        .unwrap();
    assert!(
        service.usage().unwrap().usage.host_metadata_bytes
            >= before.usage.host_metadata_bytes + profile.retained_metadata_bytes
    );
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .unwrap();
    let progress = runtime.block_on(service.drive_once()).unwrap();
    assert_eq!(progress.id, id);
    assert_eq!(progress.state, ResidentStatus::UnusedRetired);
    let after = service.usage().unwrap();
    assert_eq!(after.usage, before.usage);
    assert_eq!(after.active_reservations, before.active_reservations);
    assert!(!mvm_core::config::vm_state_dir(vm).exists());
    assert!(!mvm_core::config::machine_spec_path(vm).exists());
    drop(pool);
    service.try_finish().unwrap();
}

#[test]
fn saturated_original_resident_refuses_before_canonical_signer_creation() {
    let home = tempfile::tempdir().unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "resident_admitted_launch_returns_unused_original_slot",
            "--test-threads=1",
            "--nocapture",
        ])
        .env("SPIRALCORE_RESIDENT_ADMISSION_FIXTURE", "saturation")
        .env("MVM_HOME", home.path())
        .status()
        .unwrap();
    assert!(status.success());
}

#[test]
fn signed_admission_releases_scratch_before_resident_retains_token() {
    let home = tempfile::tempdir().unwrap();
    let status = std::process::Command::new(std::env::current_exe().unwrap())
        .args([
            "resident_admitted_launch_returns_unused_original_slot",
            "--test-threads=1",
            "--nocapture",
        ])
        .env("SPIRALCORE_RESIDENT_ADMISSION_FIXTURE", "split")
        .env("MVM_HOME", home.path())
        .status()
        .unwrap();
    assert!(status.success());
}
